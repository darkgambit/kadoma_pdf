"""Let a window the person has to use take the front, then take it back.

KADOMA opens maximised and on top, so a page being read is not buried the moment
another window is clicked. `WS_EX_TOPMOST`, though, is unconditional: Windows
keeps a topmost window above *every* ordinary window, including a mail compose
window and the printer driver's own settings dialog. Both are places where the
person has to type into something that is not KADOMA, and being unable to see
what they are typing is not a reasonable reading of "on top".

The fix is not to stop being on top. It is to drop the style just before asking
for an external window and put it back when KADOMA is the active window again.
That covers a compose window which takes several seconds to appear and stays
open as long as the person wants, as well as a synchronous driver dialog which
blocks until it is closed.

Windows-only and pure ctypes: `SetWindowPos` is handled by the window manager,
so it is safe to call from the server thread rather than having to marshal a
call onto the WebView2 UI thread. On macOS and Linux every function is a no-op
— those builds still use pywebview's own `on_top` flag at creation time.
"""
from __future__ import annotations

import ctypes
import os
import sys
import threading
import time
from ctypes import wintypes

IS_WINDOWS = sys.platform == 'win32'

HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
GWL_EXSTYLE = -20
WS_EX_TOPMOST = 0x00000008
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010
SWP_FLAGS = SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE

_WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


def _user32():
    dll = ctypes.windll.user32
    dll.GetForegroundWindow.argtypes = []
    dll.GetForegroundWindow.restype = wintypes.HWND
    dll.IsWindow.argtypes = [wintypes.HWND]
    dll.IsWindow.restype = wintypes.BOOL
    dll.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    dll.GetWindowTextLengthW.restype = ctypes.c_int
    dll.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    dll.GetWindowTextW.restype = ctypes.c_int
    dll.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    dll.GetWindowThreadProcessId.restype = wintypes.DWORD
    dll.EnumWindows.argtypes = [_WNDENUMPROC, wintypes.LPARAM]
    dll.EnumWindows.restype = wintypes.BOOL
    dll.IsWindowVisible.argtypes = [wintypes.HWND]
    dll.IsWindowVisible.restype = wintypes.BOOL
    dll.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    dll.GetWindowLongW.restype = wintypes.LONG
    dll.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND,
                                 ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                 wintypes.UINT]
    dll.SetWindowPos.restype = wintypes.BOOL
    return dll


def is_topmost(hwnd: int | None) -> bool:
    """Read the real window style, so a check can prove what happened."""
    if not IS_WINDOWS or not hwnd:
        return False
    try:
        return bool(_user32().GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST)
    except Exception:  # noqa: BLE001 - a window that vanished is not on top
        return False


def set_topmost(hwnd: int | None, flag: bool) -> bool:
    """Add or remove WS_EX_TOPMOST without moving, resizing or activating."""
    if not IS_WINDOWS or not hwnd:
        return False
    try:
        after = wintypes.HWND(HWND_TOPMOST if flag else HWND_NOTOPMOST)
        return bool(_user32().SetWindowPos(hwnd, after, 0, 0, 0, 0, SWP_FLAGS))
    except Exception:  # noqa: BLE001 - a window that vanished cannot be styled
        return False


def foreground_window() -> int | None:
    if not IS_WINDOWS:
        return None
    try:
        return _user32().GetForegroundWindow() or None
    except Exception:  # noqa: BLE001
        return None


def app_windows() -> list[tuple[int, str]]:
    """Visible titled top-level windows belonging to this process.

    The handle is discovered rather than taken from pywebview internals: those
    differ per backend, while the process id and the window title are the same
    everywhere. `check_exe.py` uses the same approach from outside the process.
    """
    if not IS_WINDOWS:
        return []
    user32 = _user32()
    found: list[tuple[int, str]] = []
    pid = os.getpid()

    def collect(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid:
            buffer = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buffer, length + 1)
            found.append((hwnd, buffer.value))
        return True

    try:
        user32.EnumWindows(_WNDENUMPROC(collect), 0)
    except Exception:  # noqa: BLE001
        return []
    return found


class FrontGuard:
    """Step aside for an external window; take the front back on return.

    `release()` is called just before the shell asks for a compose window, a
    driver dialog, Explorer or Windows Settings. The watcher then waits for the
    person to use that window and come back to KADOMA before restoring the
    topmost style. Two edge cases matter:

    * an external window that never appears or never takes focus — after
      `no_show_timeout` seconds the style is restored anyway, so a failed mail
      hand-off cannot leave the application permanently demoted;
    * an external window the person keeps open for ten minutes — no timeout
      applies once another window has actually been seen in front.
    """

    def __init__(self, interval: float = 0.2, no_show_timeout: float = 8.0):
        self.interval = interval
        self.no_show_timeout = no_show_timeout
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._hwnd: int | None = None
        self._released = False
        self._saw_other = False
        self._applied = False
        self._released_at = 0.0

    def resolve(self) -> int | None:
        """Find our window once, then remember it."""
        if self._hwnd and IS_WINDOWS and _user32().IsWindow(self._hwnd):
            return self._hwnd
        windows = app_windows()
        # Prefer the titled application window. A windowed build owns no other
        # top-level windows, but a source run may share the process with a
        # helper, and styling the wrong one would be worse than doing nothing.
        match = next((hwnd for hwnd, title in windows if 'kadoma' in title.lower()), None)
        self._hwnd = match if match is not None else (windows[0][0] if len(windows) == 1 else None)
        return self._hwnd

    def release(self) -> bool:
        """Drop the topmost style now. Safe from any thread, before any window."""
        if not IS_WINDOWS:
            return False
        with self._lock:
            self._released = True
            self._saw_other = False
            self._applied = False
            self._released_at = time.monotonic()
        hwnd = self.resolve()
        applied = bool(hwnd and set_topmost(hwnd, False))
        if applied:
            with self._lock:
                self._applied = True
        # If the window is not up yet, the watcher applies this as soon as it
        # appears: a very early request must not be silently dropped.
        return applied

    def restore(self) -> bool:
        with self._lock:
            self._released = False
            self._saw_other = False
            self._applied = False
        return set_topmost(self.resolve(), True)

    @property
    def released(self) -> bool:
        with self._lock:
            return self._released

    def start(self) -> bool:
        if not IS_WINDOWS or (self._thread and self._thread.is_alive()):
            return False
        self._stop.clear()
        self._thread = threading.Thread(target=self._watch, name='kadoma-window-front', daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()

    def _watch(self) -> None:
        while not self._stop.wait(self.interval):
            hwnd = self.resolve()
            if not hwnd:
                continue
            with self._lock:
                released = self._released
                applied = self._applied
            if not released:
                continue
            if not applied:
                # A release asked for before the window existed, or one whose
                # SetWindowPos failed. Try again now that we have a handle.
                if set_topmost(hwnd, False):
                    with self._lock:
                        self._applied = True
                continue
            other_in_front = foreground_window() != hwnd
            if other_in_front:
                with self._lock:
                    self._saw_other = True
                continue
            with self._lock:
                came_back = self._saw_other
                waited = time.monotonic() - self._released_at
            # Coming back from the external window is the normal path. The
            # timeout only covers the case where nothing ever took the front.
            if came_back or waited >= self.no_show_timeout:
                self.restore()
