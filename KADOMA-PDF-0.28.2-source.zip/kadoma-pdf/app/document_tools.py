"""Page furniture and file-level tools.

Watermark, header and footer, page and Bates numbering, cropping, bookmarks,
attachments and compression — the tools a PDF application is expected to have
once it can edit pages at all.

Each function takes an **open** PyMuPDF document and already-untrusted options,
changes the document in place, and raises `PDFError` with a sentence somebody can
act on. Locking, undo history and HTTP belong to the engine, which is what makes
these testable without a server or a window.

Two rules run through the whole module:

* Every option is validated here, not in the interface. A number that arrives as
  a string, a page index past the end, a colour that is not a colour — all of it
  is refused with a reason rather than written into somebody's document.
* Nothing is written outside the page. A header sits in the margin, a watermark
  inside the page box, and a crop can never produce a page with no paper in it.
"""
from __future__ import annotations

import base64
import datetime
import difflib
import io
import re

import pymupdf as fitz
from PIL import Image

from .errors import PDFError

# The tokens a header, footer or numbering pattern may use. Anything else is
# refused, because a literal "{page}" stamped on 300 pages is worse than an
# error message before anything is written.
TOKENS = ('page', 'pages', 'bates', 'date', 'filename', 'title')
SLOTS = ('header_left', 'header_center', 'header_right',
         'footer_left', 'footer_center', 'footer_right')
POSITIONS = ('footer_center', 'footer_left', 'footer_right',
             'header_center', 'header_left', 'header_right')


# ------------------------------------------------------------------ validation

def pages_of(selected, count: int) -> list[int]:
    """0-based page indices from whatever the interface sent."""
    if selected is None or (isinstance(selected, list) and not selected):
        return list(range(count))
    if not isinstance(selected, list):
        raise PDFError("Choose which pages to change.")
    chosen: list[int] = []
    for index in selected:
        if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < count:
            raise PDFError("A page in that selection is not in this document.")
        if index not in chosen:
            chosen.append(index)
    return chosen


def _text(value, label: str, limit: int = 200, required: bool = False) -> str:
    if value is None:
        value = ''
    if not isinstance(value, str):
        raise PDFError(f"{label} must be text.")
    if len(value) > limit:
        raise PDFError(f"{label} is limited to {limit} characters.")
    if required and not value.strip():
        raise PDFError(f"{label} is required.")
    return value


def _number(value, low: float, high: float, label: str, default: float) -> float:
    if value is None or value == '':
        return default
    if isinstance(value, bool):
        raise PDFError(f"{label} must be a number.")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise PDFError(f"{label} must be a number.") from None
    if not low <= number <= high:
        raise PDFError(f"{label} must be between {low:g} and {high:g}.")
    return number


def _colour(value, default: str = '#808080') -> tuple[float, float, float]:
    text = value if isinstance(value, str) and value.strip() else default
    match = re.fullmatch(r'#?([0-9a-fA-F]{6})', text.strip())
    if not match:
        raise PDFError("Choose a colour as #rrggbb.")
    raw = match.group(1)
    return tuple(int(raw[index:index + 2], 16) / 255 for index in (0, 2, 4))


def _binary(value, label: str) -> bytes:
    """Bytes from JSON, where they arrive base64-encoded, or as they are.

    The interface sends an uploaded file as base64 because JSON has no bytes;
    a test or a script may hand over bytes directly. Both are the same thing by
    the time it reaches PyMuPDF, so the conversion happens once, here.
    """
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    if isinstance(value, str) and value:
        try:
            return base64.b64decode(value, validate=True)
        except Exception:
            raise PDFError(f"{label} could not be read.") from None
    raise PDFError(f"{label} is missing.")


def _check_tokens(pattern: str, label: str) -> None:
    for name in re.findall(r'\{([^{}]*)\}', pattern):
        if name not in TOKENS:
            raise PDFError(f"{label} uses {{{name}}}, which is not one of "
                           f"{', '.join('{' + token + '}' for token in TOKENS)}.")


def _expand(pattern: str, *, number: int, total: int, name: str, title: str,
            bates: str, today: str) -> str:
    return (pattern
            .replace('{page}', str(number))
            .replace('{pages}', str(total))
            .replace('{bates}', bates)
            .replace('{date}', today)
            .replace('{filename}', name)
            .replace('{title}', title))


# ------------------------------------------------------------------- watermark

def _watermark_image(data: bytes, opacity: float, angle: float) -> bytes:
    """The image with its transparency baked in, and turned if it needs turning.

    PyMuPDF can place an image but not fade it or spin it by an arbitrary angle,
    so the work is done once in PIL and the result is what gets embedded.
    """
    try:
        image = Image.open(io.BytesIO(data)).convert('RGBA')
    except Exception as exc:
        raise PDFError("That watermark image could not be read.") from exc
    if opacity < 1:
        alpha = image.getchannel('A').point(lambda value: int(value * opacity))
        image.putalpha(alpha)
    if angle:
        image = image.rotate(-angle, expand=True, resample=Image.BICUBIC)
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    return buffer.getvalue()


def watermark(doc: fitz.Document, options: dict) -> dict:
    """Stamp text or a picture across pages, faded and optionally rotated."""
    selection = pages_of(options.get('pages'), len(doc))
    kind = options.get('kind', 'text')
    if kind not in ('text', 'image'):
        raise PDFError("Choose a text or an image watermark.")
    opacity = _number(options.get('opacity'), 0.02, 1, 'Opacity', 0.12)
    angle = _number(options.get('rotation'), -90, 90, 'Rotation', 45)
    layout = options.get('layout', 'center')
    if layout not in ('center', 'tile', 'top', 'bottom'):
        raise PDFError("Choose where the watermark goes.")

    text = ''
    size = 48.0
    colour = _colour(options.get('color'), '#7a7a7a')
    stream = b''
    if kind == 'text':
        text = _text(options.get('text'), 'Watermark text', 120, required=True)
        size = _number(options.get('size'), 6, 300, 'Font size', 48)
    else:
        stream = _watermark_image(_binary(options.get('image'), 'The watermark image'),
                                  opacity, angle)

    scale = _number(options.get('scale'), 0.05, 1, 'Image size', 0.4)

    for index in selection:
        page = doc[index]
        box = page.rect
        centres = []
        if layout == 'tile':
            step_x = (fitz.get_text_length(text, fontsize=size) if kind == 'text'
                      else box.width * scale) * 1.6 + 40
            step_y = (size * 3 if kind == 'text' else box.width * scale) + 60
            y = box.y0 + step_y / 2
            while y < box.y1:
                x = box.x0 + step_x / 2
                while x < box.x1:
                    centres.append(fitz.Point(x, y))
                    x += step_x
                y += step_y
        else:
            y = {'center': box.y0 + box.height / 2,
                 'top': box.y0 + box.height * 0.18,
                 'bottom': box.y0 + box.height * 0.82}[layout]
            centres.append(fitz.Point(box.x0 + box.width / 2, y))

        for centre in centres:
            if kind == 'text':
                width = fitz.get_text_length(text, fontsize=size)
                point = fitz.Point(centre.x - width / 2, centre.y + size * 0.35)
                page.insert_text(point, text, fontsize=size, fontname='helv',
                                 color=colour, fill_opacity=opacity,
                                 morph=(fitz.Point(centre), fitz.Matrix(angle)) if angle else None,
                                 overlay=True)
            else:
                with Image.open(io.BytesIO(stream)) as placed:
                    ratio = placed.height / placed.width if placed.width else 1
                width = box.width * scale
                height = width * ratio
                rect = fitz.Rect(centre.x - width / 2, centre.y - height / 2,
                                 centre.x + width / 2, centre.y + height / 2)
                page.insert_image(rect, stream=stream, overlay=True)
    return {'pages': len(selection), 'kind': kind, 'layout': layout, 'opacity': opacity}


# --------------------------------------------------------- header and footer

def header_footer(doc: fitz.Document, options: dict) -> dict:
    """Text in the margins, with tokens for page number, date and file name."""
    selection = pages_of(options.get('pages'), len(doc))
    size = _number(options.get('size'), 6, 24, 'Font size', 9)
    colour = _colour(options.get('color'), '#555555')
    margin = _number(options.get('margin'), 10, 120, 'Margin', 36)
    skip_first = bool(options.get('skipFirst'))
    start = int(_number(options.get('numberStart'), 1, 9_999_999, 'First page number', 1))
    digits = int(_number(options.get('digits'), 1, 12, 'Digits', 6))
    name = _text(options.get('name'), 'File name', 200)
    title = _text(options.get('title'), 'Title', 200)
    today = options.get('date') if isinstance(options.get('date'), str) and options.get('date') \
        else datetime.date.today().isoformat()

    slots = {}
    for key in SLOTS:
        value = _text(options.get(key), key.replace('_', ' ').title(), 300)
        if value.strip():
            _check_tokens(value, key.replace('_', ' ').title())
            slots[key] = value
    if not slots:
        raise PDFError("Write something to put in the header or footer.")

    written = 0
    for index in selection:
        if skip_first and index == 0:
            continue
        page = doc[index]
        box = page.rect
        number = start + index
        bates = str(number).zfill(digits)
        for key, pattern in slots.items():
            value = _expand(pattern, number=number, total=len(doc), name=name,
                            title=title, bates=bates, today=today)
            if not value.strip():
                continue
            row, column = key.split('_')
            width = (box.width - 2 * margin) / 3
            x0 = margin + {'left': 0, 'center': 1, 'right': 2}[column] * width
            if row == 'header':
                rect = fitz.Rect(x0, max(2, margin - size * 1.6), x0 + width, margin + 1)
            else:
                rect = fitz.Rect(x0, box.y1 - margin - 1, x0 + width,
                                 min(box.y1 - 2, box.y1 - margin + size * 1.7))
            if rect.height < size:
                rect.y1 = rect.y0 + size * 1.6
            page.insert_textbox(rect, value, fontsize=size, fontname='helv', color=colour,
                                align={'left': 0, 'center': 1, 'right': 2}[column],
                                overlay=True)
            written += 1
    return {'pages': len(selection), 'written': written}


def numbering(doc: fitz.Document, options: dict) -> dict:
    """Page numbers or Bates stamps, placed with the header/footer machinery.

    Sharing that code is deliberate: a page number and a header are the same
    operation with a different string, and two implementations would drift.
    """
    mode = options.get('mode', 'page')
    if mode not in ('page', 'bates'):
        raise PDFError("Choose page numbers or Bates numbering.")
    position = options.get('position', 'footer_center')
    if position not in POSITIONS:
        raise PDFError("Choose where the numbers go.")
    start = int(_number(options.get('start'), 1, 9_999_999, 'First number', 1))
    digits = int(_number(options.get('digits'), 1, 12, 'Digits', 6))
    if mode == 'page':
        pattern = _text(options.get('format'), 'Number format', 120) or 'Page {page} of {pages}'
    else:
        prefix = _text(options.get('prefix'), 'Bates prefix', 60)
        pattern = prefix + '{bates}'
    _check_tokens(pattern, 'The number format')
    payload = {key: options.get(key) for key in
               ('pages', 'size', 'color', 'margin', 'skipFirst', 'name', 'title', 'date')}
    payload[position] = pattern
    payload['numberStart'] = start
    payload['digits'] = digits
    result = header_footer(doc, payload)
    return {'mode': mode, 'pages': result['pages'], 'written': result['written']}


# ------------------------------------------------------------------------ crop

def crop(doc: fitz.Document, options: dict) -> dict:
    """Trim margins off pages. The page is cropped, never rewritten."""
    selection = pages_of(options.get('pages'), len(doc))
    unit = options.get('unit', 'pt')
    if unit not in ('pt', 'mm', 'in'):
        raise PDFError("Choose points, millimetres or inches.")
    factor = {'pt': 1.0, 'mm': 72 / 25.4, 'in': 72.0}[unit]
    margins = {side: _number(options.get(side), 0, 2000, side.title(), 0) * factor
               for side in ('top', 'bottom', 'left', 'right')}
    if not any(margins.values()):
        raise PDFError("Set at least one margin to crop.")

    changed = 0
    for index in selection:
        page = doc[index]
        box = page.cropbox
        rect = fitz.Rect(box.x0 + margins['left'], box.y0 + margins['top'],
                         box.x1 - margins['right'], box.y1 - margins['bottom'])
        if rect.width < 20 or rect.height < 20:
            raise PDFError("Those margins leave no page to show.")
        if rect == box:
            continue
        page.set_cropbox(rect)
        changed += 1
    return {'pages': changed}


# ------------------------------------------------------------------- bookmarks

def bookmarks(doc: fitz.Document, options: dict) -> dict:
    """List, replace or generate the document's outline."""
    mode = options.get('mode', 'list')
    if mode not in ('list', 'set', 'auto', 'clear'):
        raise PDFError("Choose what to do with the bookmarks.")
    if mode == 'list':
        return {'bookmarks': _toc(doc)}
    if mode == 'clear':
        doc.set_toc([])
        return {'bookmarks': []}
    if mode == 'set':
        entries = options.get('bookmarks')
        if not isinstance(entries, list):
            raise PDFError("The bookmarks must be a list.")
        cleaned = []
        for entry in entries[:500]:
            if not isinstance(entry, dict):
                raise PDFError("Each bookmark needs a title and a page.")
            level = int(_number(entry.get('level'), 1, 6, 'Bookmark level', 1))
            title = _text(entry.get('title'), 'Bookmark title', 200, required=True)
            page = int(_number(entry.get('page'), 1, len(doc), 'Bookmark page', 1))
            cleaned.append([level, title.strip(), page])
        doc.set_toc(_normalise(cleaned))
        return {'bookmarks': _toc(doc)}
    found = detect_headings(doc, levels=int(_number(options.get('levels'), 1, 3, 'Heading levels', 2)))
    doc.set_toc(_normalise(found))
    return {'bookmarks': _toc(doc), 'found': len(found)}


def _normalise(entries: list[list]) -> list[list]:
    """Make an outline a reader will accept.

    Two rules PyMuPDF enforces and a heading detector cannot know: the first item
    is always level one, and a level may never jump by more than one. Without
    this, a document whose biggest heading appears on page three produces an
    outline that raises instead of opening.
    """
    cleaned: list[list] = []
    previous = 0
    for level, title, page in entries:
        level = 1 if not cleaned else max(1, min(int(level), previous + 1))
        cleaned.append([level, title, page])
        previous = level
    return cleaned


def _toc(doc: fitz.Document) -> list[dict]:
    return [{'level': level, 'title': title, 'page': page}
            for level, title, page in doc.get_toc(simple=True)]


def detect_headings(doc: fitz.Document, levels: int = 2, limit: int = 400) -> list[list]:
    """Build an outline from the type sizes on the page.

    Body text is the size that carries the most characters; anything meaningfully
    larger is a heading, and the biggest of those is level one.

    Two things are deliberately not headings, because the first version of this
    produced both: a **watermark**, which is huge, and a **running header**,
    which is on every page. Anything whose text repeats across more than a third
    of the pages is furniture, not structure. A title that wraps onto a second
    line is joined back into one entry.

    It is a heuristic and it says so: a document with no clear size hierarchy
    produces a short outline or none at all, rather than a guess per line.
    """
    by_size: dict[float, int] = {}
    spans: list[dict] = []
    for index, page in enumerate(doc):
        for block in page.get_text('dict', flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)['blocks']:
            for line in block.get('lines', []):
                # Text that is not horizontal is a watermark or a sidebar, never
                # a heading. The direction vector is exact, where "does it repeat
                # across pages" is not: a one-page document has no repetition to
                # measure, and its rotated watermark was the first thing this
                # detector offered as a chapter title.
                direction = line.get('dir') or (1, 0)
                if abs(direction[1]) > 0.02:
                    continue
                for span in line['spans']:
                    text = (span.get('text') or '').strip()
                    if not text or not re.search(r'[^\W\d_]', text, re.UNICODE):
                        continue
                    size = round(float(span['size']), 1)
                    by_size[size] = by_size.get(size, 0) + len(text)
                    spans.append({'size': size, 'text': text, 'page': index,
                                  'x0': span['bbox'][0], 'y0': span['bbox'][1],
                                  'y1': span['bbox'][3]})
    if not by_size or not spans:
        return []
    body = max(by_size, key=lambda key: by_size[key])
    heading_sizes = sorted({size for size in by_size if size >= body * 1.15}, reverse=True)[:levels]
    if not heading_sizes:
        return []
    level_of = {size: position + 1 for position, size in enumerate(heading_sizes)}

    # Furniture repeats: a watermark on every page, a running header on most.
    pages_with: dict[str, set[int]] = {}
    for span in spans:
        key = re.sub(r'\s+', ' ', span['text']).strip().lower()
        pages_with.setdefault(key, set()).add(span['page'])
    repeat_limit = max(2, int(len(doc) * 0.34))

    candidates = [span for span in spans
                  if span['size'] in level_of
                  and 2 <= len(span['text']) <= 160
                  and len(pages_with[re.sub(r'\s+', ' ', span['text']).strip().lower()]) <= repeat_limit]

    # A title that wraps is two spans on consecutive lines at the same size and
    # the same left edge; joining them gives "Quarterly performance report"
    # rather than two bookmarks.
    merged: list[dict] = []
    for span in candidates:
        previous = merged[-1] if merged else None
        if (previous and previous['page'] == span['page'] and previous['size'] == span['size']
                and abs(previous['x0'] - span['x0']) < 2
                and 0 <= span['y0'] - previous['y1'] <= span['size'] * 0.8
                and len(previous['text']) + len(span['text']) < 120):
            previous['text'] = f"{previous['text']} {span['text']}"
            previous['y1'] = span['y1']
            continue
        merged.append(dict(span))

    entries: list[list] = []
    seen: set[tuple[int, str]] = set()
    for span in merged:
        key = (span['page'], span['text'].lower())
        if key in seen:
            continue
        seen.add(key)
        entries.append([level_of[span['size']], span['text'], span['page'] + 1])
        if len(entries) >= limit:
            break
    return entries


# ---------------------------------------------------------------- attachments

def attachments(doc: fitz.Document, options: dict) -> dict:
    """Files carried inside the PDF: list, add, extract or remove."""
    mode = options.get('mode', 'list')
    if mode not in ('list', 'add', 'extract', 'delete'):
        raise PDFError("Choose what to do with the attachments.")
    if mode == 'list':
        return {'attachments': attachment_list(doc)}
    name = _text(options.get('name'), 'Attachment name', 200, required=True)
    if mode == 'add':
        data = _binary(options.get('data'), 'The file to attach')
        if name in doc.embfile_names():
            raise PDFError(f"“{name}” is already attached. Remove it first.")
        doc.embfile_add(name, data, filename=name, ufilename=name,
                        desc=_text(options.get('description'), 'Description', 200))
        return {'attachments': attachment_list(doc)}
    if name not in doc.embfile_names():
        raise PDFError(f"“{name}” is not attached to this document.")
    if mode == 'extract':
        return {'name': name, 'data': doc.embfile_get(name)}
    doc.embfile_del(name)
    return {'attachments': attachment_list(doc)}


def attachment_list(doc: fitz.Document) -> list[dict]:
    found = []
    for name in doc.embfile_names():
        try:
            info = doc.embfile_info(name)
        except Exception:
            info = {}
        found.append({'name': name, 'size': info.get('size', 0),
                      'description': info.get('desc', '') or ''})
    return found


# ------------------------------------------------------------------ compression

def compress(doc: fitz.Document, options: dict) -> tuple[bytes, int]:
    """Re-save the document smaller, and report what it was before.

    Three things make a PDF large, and this addresses all three: images stored at
    a resolution nobody can see, fonts carrying glyphs the document never uses,
    and objects left behind by earlier edits. The image step is the only lossy
    one, and its quality is chosen by the person.
    """
    quality = int(_number(options.get('quality'), 30, 95, 'Image quality', 72))
    dpi = _number(options.get('dpi'), 36, 600, 'Image resolution', 150)
    before = doc.tobytes(garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP)
    try:
        # Only images that are stored above the target resolution are touched, so
        # a document that is already lean comes out almost unchanged.
        doc.rewrite_images(dpi_threshold=int(dpi), dpi_target=int(dpi), quality=quality)
    except Exception:
        # A single malformed image should not cost the whole compression; the
        # rest of the saving below still applies.
        pass
    try:
        doc.subset_fonts()
    except Exception:
        pass
    data = doc.tobytes(garbage=4, deflate=True, deflate_images=True, deflate_fonts=True,
                       clean=True, encryption=fitz.PDF_ENCRYPT_KEEP)
    return data, len(before)


# ---------------------------------------------------------------------- stamps
# The standard stamps a document gets marked with. The colours are the point:
# "Confidential" in green reads as a mistake.
STAMPS = {
    'Approved': '#1e7a3c',
    'Reviewed': '#1f5c8a',
    'Draft': '#8a6d1f',
    'Confidential': '#b3261e',
    'Final': '#1e7a3c',
    'For Public Release': '#1f5c8a',
    'Void': '#b3261e',
}
PAGE_SIZES = {
    'A3': (841.89, 1190.55),
    'A4': (595.276, 841.89),
    'A5': (419.528, 595.276),
    'Letter': (612.0, 792.0),
    'Legal': (612.0, 1008.0),
    'Tabloid': (792.0, 1224.0),
}


def stamp(doc: fitz.Document, options: dict) -> dict:
    """A bordered mark — Approved, Draft, Confidential — where it is clicked."""
    index = int(_number(options.get('page'), 0, max(0, len(doc) - 1), 'Page', 0))
    label = _text(options.get('label'), 'Stamp', 40) or 'Approved'
    if label not in STAMPS and label != 'Custom':
        raise PDFError(f"“{label}” is not one of the standard stamps.")
    text = label if label != 'Custom' else _text(options.get('text'), 'Stamp text', 60, required=True)
    colour = _colour(options.get('color'), STAMPS.get(label, '#b3261e'))
    size = _number(options.get('size'), 8, 72, 'Font size', 20)
    with_date = bool(options.get('date'))
    x = _number(options.get('x'), 0, doc[index].rect.width, 'Horizontal position', 72)
    y = _number(options.get('y'), 0, doc[index].rect.height, 'Vertical position', 120)

    page = doc[index]
    width = max(120.0, fitz.get_text_length(text, fontname='hebo', fontsize=size) + size * 2.4)
    height = size * (3.8 if with_date else 2.6)
    rect = fitz.Rect(x, y, x + width, y + height)
    # Keep the whole stamp on the page rather than half of it in the margin.
    if rect.x1 > page.rect.x1 - 4:
        rect = rect + (page.rect.x1 - 4 - rect.x1, 0, page.rect.x1 - 4 - rect.x1, 0)
    if rect.y1 > page.rect.y1 - 4:
        rect = rect + (0, page.rect.y1 - 4 - rect.y1, 0, page.rect.y1 - 4 - rect.y1)
    if rect.x0 < 4:
        rect = fitz.Rect(4, rect.y0, 4 + width, rect.y1)

    page.draw_rect(rect, color=colour, width=2.2, radius=0.12, overlay=True)
    # The label is drawn with `insert_text` rather than `insert_textbox`: a box
    # that is a fraction too short still writes the text *and* returns a failure,
    # so retrying at a smaller size left the label on the page twice. Measuring
    # the line first means there is nothing to retry.
    middle = rect.y0 + height * (0.42 if with_date else 0.5)
    _centred(page, text, rect, middle + size * .36, size, 'hebo', colour)
    if with_date:
        when = options.get('date') if isinstance(options.get('date'), str) else \
            datetime.date.today().isoformat()
        _centred(page, when, rect, rect.y1 - size * .55, size * .55, 'helv', colour)
    return {'page': index, 'label': text}


def _centred(page: fitz.Page, text: str, rect: fitz.Rect, baseline: float,
             size: float, font: str, colour) -> None:
    """One line of text, centred horizontally on the stamp."""
    width = fitz.get_text_length(text, fontname=font, fontsize=size)
    page.insert_text(((rect.x0 + rect.x1 - width) / 2, baseline), text,
                     fontsize=size, fontname=font, color=colour, overlay=True)


# ----------------------------------------------------------------------- links

def links(doc: fitz.Document, options: dict) -> dict:
    """Web and page links: list what is on a page, add one, remove one."""
    mode = options.get('mode', 'list')
    if mode not in ('list', 'add', 'remove'):
        raise PDFError("Choose what to do with the links.")
    index = int(_number(options.get('page'), 0, max(0, len(doc) - 1), 'Page', 0))
    page = doc[index]
    if mode == 'list':
        return {'links': _link_list(page)}
    if mode == 'remove':
        wanted = options.get('index')
        found = page.get_links()
        if not isinstance(wanted, int) or not 0 <= wanted < len(found):
            raise PDFError("That link is no longer on this page.")
        page.delete_link(found[wanted])
        # The page's link list is stale from the moment the document was loaded,
        # so the answer is rebuilt from the list that was read above.
        remaining = [entry for entry in _link_list(page) if entry['index'] != wanted]
        for position, entry in enumerate(remaining):
            entry['index'] = position
        return {'links': remaining}

    rect = fitz.Rect(*[float(value) for value in options.get('rect', [])])
    if rect.is_empty or rect.width < 4 or rect.height < 4:
        raise PDFError("Drag a box on the page to place the link.")
    kind = options.get('kind', 'uri')
    existing = _link_list(page)
    if kind == 'uri':
        url = _text(options.get('url'), 'Address', 2000, required=True).strip()
        if not re.match(r'^(https?://|mailto:|ftp://)\S+$', url, re.IGNORECASE):
            raise PDFError("A link address must start with http://, https://, mailto: or ftp://.")
        page.insert_link({'kind': fitz.LINK_URI, 'from': rect, 'uri': url})
        label, sort = url, 'web'
    elif kind == 'goto':
        target = int(_number(options.get('target'), 1, len(doc), 'Target page', 1)) - 1
        page.insert_link({'kind': fitz.LINK_GOTO, 'from': rect, 'page': target,
                          'to': fitz.Point(0, 0)})
        label, sort = f'Page {target + 1}', 'page'
    else:
        raise PDFError("Choose a web address or a page in this document.")
    # PyMuPDF keeps the page's link list from when it was loaded, so the link that
    # was just written is invisible to `get_links()` — the interface would report
    # "no links" straight after adding one. The new link is the last entry in the
    # page's annotation array, so it is appended rather than re-read.
    existing.append({'index': len(existing), 'kind': sort, 'label': label,
                     'rect': [rect.x0, rect.y0, rect.x1, rect.y1]})
    return {'links': existing}


def _link_list(page: fitz.Page) -> list[dict]:
    found = []
    for position, link in enumerate(page.get_links()):
        kind = link.get('kind')
        if kind == fitz.LINK_URI:
            label, sort = link.get('uri', ''), 'web'
        elif kind == fitz.LINK_GOTO:
            label, sort = f'Page {int(link.get("page", 0)) + 1}', 'page'
        else:
            label, sort = 'Other link', 'other'
        box = link.get('from') or fitz.Rect()
        found.append({'index': position, 'kind': sort, 'label': label,
                      'rect': [box.x0, box.y0, box.x1, box.y1]})
    return found


# ---------------------------------------------------------------------- resize

def resize(doc: fitz.Document, options: dict) -> dict:
    """Change the paper size, optionally scaling what is on the page to fit.

    Without scaling, the content keeps its size and the page gets a new edge —
    which is what "set the page size" means. With scaling, the content is
    multiplied into the new box: the page's own content stream is wrapped in one
    transformation, and annotations, form fields and links are moved with it.
    Without that second step a signature would end up pointing at nothing.
    """
    preset = options.get('size', 'A4')
    if preset != 'Custom' and preset not in PAGE_SIZES:
        raise PDFError("Choose a page size.")
    unit = options.get('unit', 'mm')
    if unit not in ('pt', 'mm', 'in'):
        raise PDFError("Choose points, millimetres or inches.")
    factor = {'pt': 1.0, 'mm': 72 / 25.4, 'in': 72.0}[unit]
    if preset == 'Custom':
        width = _number(options.get('width'), 36, 20000, 'Width', 210) * factor
        height = _number(options.get('height'), 36, 20000, 'Height', 297) * factor
    else:
        width, height = PAGE_SIZES[preset]
    scale = bool(options.get('scale', True))
    selection = pages_of(options.get('pages'), len(doc))

    moved = 0
    for index in selection:
        page = doc[index]
        box = page.rect
        old_height = box.height
        sx, sy = width / box.width, height / box.height
        # One uniform factor keeps circles round; the page may end up with a
        # margin, which is better than a squashed drawing.
        uniform = min(sx, sy)
        sx, sy = (uniform, uniform) if scale else (1.0, 1.0)
        # Everything that floats on the page is measured in the old coordinate
        # space, so it is read first and written after the box has changed.
        boxes = _capture_geometry(doc, page)
        page.set_mediabox(fitz.Rect(0, 0, width, height))
        # The drawing is anchored at the page's top-left corner in both cases: a
        # new paper size should not make the content jump up the page, and it is
        # the bottom edge that moves when the page gets shorter.
        shift = height - sy * old_height
        _scale_contents(doc, page, sx, sy, shift)
        _move_geometry(doc, boxes, sx, sy, shift)
        if scale:
            moved += 1
    return {'pages': len(selection), 'width': round(width, 1), 'height': round(height, 1),
            'scaled': scale, 'moved': moved}


def _scale_contents(doc: fitz.Document, page: fitz.Page, sx: float, sy: float,
                    shift: float) -> None:
    """Scale the page's own drawing, anchored at its top-left corner.

    `shift` moves the result down in PDF coordinates (which start at the bottom),
    so the top of the old page lands on the top of the new one instead of the
    content sinking to the bottom-left.
    """
    page.wrap_contents()
    contents = page.get_contents()
    if not contents:
        return
    first = doc.xref_stream(contents[0])
    matrix = f'q {sx:.6f} 0 0 {sy:.6f} 0 {shift:.6f} cm\n'.encode()
    doc.update_stream(contents[0], matrix + first)
    last = doc.xref_stream(contents[-1])
    doc.update_stream(contents[-1], last + b'\nQ')


def _capture_geometry(doc: fitz.Document, page: fitz.Page) -> list:
    """Every annotation on the page — links, form fields, comments — as a raw
    /Rect in PDF coordinates.

    Read from the page's annotation array instead of from `Annot` objects, for
    two reasons. An annotation's rectangle is only valid while its page object is
    alive, and one that outlives its page **crashes the process** rather than
    raising. And PyMuPDF keeps a page's link list from the moment it was loaded,
    so a link added earlier in the same session is invisible to `get_links()` and
    would be left behind at the old size. The annotation array has neither
    problem: it is the file's own structure, and it is always current.
    """
    kind, raw = doc.xref_get_key(page.xref, 'Annots')
    if kind != 'array':
        return []
    boxes = []
    for xref in re.findall(r'(\d+)\s+0\s+R', raw):
        rect = _pdf_rect(doc, int(xref))
        if rect:
            boxes.append((int(xref), rect))
    return boxes


def _pdf_rect(doc: fitz.Document, xref: int) -> list | None:
    kind, raw = doc.xref_get_key(xref, 'Rect')
    if kind == 'xref':
        try:
            return _pdf_rect(doc, int(raw.split()[0]))
        except ValueError:
            return None
    if kind != 'array':
        return None
    try:
        numbers = [float(value) for value in raw.strip('[]').split()]
    except ValueError:
        return None
    return numbers if len(numbers) == 4 else None


def _move_geometry(doc: fitz.Document, boxes: list,
                   sx: float, sy: float, shift: float) -> None:
    """Scale every rectangle into the new page box, in PDF coordinates.

    Both sides of this calculation are in PDF space — the page's own coordinate
    system, which starts at the bottom-left — so the same numbers that were
    written into the content stream's transformation apply unchanged here:
    x becomes x*sx, y becomes y*sy + shift.
    """
    def moved(values):
        out = []
        for index, value in enumerate(values):
            out.append(f'{value * sx:.4f}' if index % 2 == 0 else f'{value * sy + shift:.4f}')
        return out

    for xref, rect in boxes:
        doc.xref_set_key(xref, 'Rect', '[' + ' '.join(moved(rect)) + ']')
        # Highlights, underlines and strike-throughs carry their geometry in
        # QuadPoints; moving only the bounding box would leave the marks where
        # the text used to be.
        kind, raw = doc.xref_get_key(xref, 'QuadPoints')
        if kind == 'array':
            numbers = [float(value) for value in raw.strip('[]').split()]
            doc.xref_set_key(xref, 'QuadPoints', '[' + ' '.join(moved(numbers)) + ']')


# --------------------------------------------------------------------- compare

def compare(left: fitz.Document, right: fitz.Document, options: dict | None = None) -> dict:
    """Word-by-word comparison of two documents, page by page.

    This is a text comparison, not a visual one: it says which pages differ and
    what was added or removed on them. It does not attempt to say that a moved
    paragraph is the same paragraph, and it does not redraw the pages — a claim
    about layout would need a rendering comparison that cannot explain itself.
    """
    options = options or {}
    limit = int(_number(options.get('limit'), 5, 200, 'Words to show', 40))
    total = max(len(left), len(right))
    pages = []
    for index in range(total):
        if index >= len(left):
            status, added, removed, ratio = 'added', _words(right[index]), [], 0.0
        elif index >= len(right):
            status, added, removed, ratio = 'removed', [], _words(left[index]), 0.0
        else:
            a, b = _words(left[index]), _words(right[index])
            if a == b:
                status, added, removed, ratio = 'same', [], [], 1.0
            else:
                matcher = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
                ratio = round(matcher.ratio(), 3)
                added, removed = [], []
                for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                    if tag in ('replace', 'delete'):
                        removed.extend(a[i1:i2])
                    if tag in ('replace', 'insert'):
                        added.extend(b[j1:j2])
                status = 'changed'
        pages.append({'page': index + 1, 'status': status, 'ratio': ratio,
                      'added': added[:limit], 'removed': removed[:limit],
                      'addedCount': len(added), 'removedCount': len(removed)})
    differing = [page for page in pages if page['status'] != 'same']
    return {
        'pages': pages,
        'differing': len(differing),
        'total': total,
        'identical': not differing,
        'leftPages': len(left),
        'rightPages': len(right),
    }


def _words(page: fitz.Page) -> list[str]:
    """The page's words, normalised so whitespace is not a difference."""
    text = page.get_text('text')
    return re.findall(r'\S+', text)
