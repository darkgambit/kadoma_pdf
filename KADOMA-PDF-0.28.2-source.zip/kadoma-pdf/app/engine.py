"""The actual PDF engine. All MuPDF access is serialized across request threads.

Working documents and undo history are held in memory; no persistent document
library is created. Upload transport and optional converters can use temporary
files. A file on disk is written in exactly two cases: the user saves a document
back over the file it was opened from, or the user chooses a destination for a
copy. Nothing is written on open, on edit, or on close.
"""
from __future__ import annotations

import base64
import csv
import html
import io
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
import zipfile
from collections import OrderedDict
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import pymupdf as fitz
from PIL import Image, ImageOps

from . import ai, form_prep, rtl

MAX_UPLOAD = 500 * 1024 * 1024
MAX_PAGES = 500
MAX_DOCUMENTS = 6
# Splitting produces files rather than consuming them, so the ceiling is about
# how many downloads a person can reasonably handle, not about upload size.
MAX_SPLIT_FILES = 200
# Undo holds full copies of the document, so its ceiling is in bytes as well as
# steps: a 400 MB file gets no undo snapshots rather than a second 400 MB in RAM.
MAX_HISTORY_BYTES = 100 * 1024 * 1024
MAX_HISTORY_STEPS = 12
# A copy of a 500 MB document is 500 MB; the export ceiling has to allow at
# least one of those or a large document could be opened and never written out.
MAX_EXPORT_BYTES = 500 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 40_000_000
fitz.TOOLS.set_small_glyph_heights(True)


# Defined in its own module so the document tools can raise it without importing
# this one; re-exported here because that is where everything else expects it.
from .errors import PDFError  # noqa: E402
from . import document_tools  # noqa: E402


def safe_name(name: str, default="Untitled.pdf") -> str:
    name = (name or default).replace('\\', '/').split('/')[-1]
    name = re.sub(r'[\x00-\x1f\x7f<>:"|?*]', '_', name).strip(' .')[:180]
    return name or default


# --------------------------------------------------------------- date fields
# PDF has no date field type. The convention real tools use is a text field with
# a JavaScript format action, but this application deliberately does not write
# JavaScript into documents — it strips JavaScript during redaction and makes no
# scripting claims. Instead a plain text field carries two private keys that
# describe what it is. Verified to survive a full save, a reload, and a
# garbage-collecting clean save, so the field is still a date field after the
# file is closed and reopened.
DATE_KIND_KEY = 'KADOMAKind'
DATE_FORMAT_KEY = 'KADOMAFormat'
DATE_KIND = 'date'

# label -> strftime pattern. These are the formats people actually ask for; the
# value is always stored as text exactly as displayed.
DATE_FORMATS = {
    'YYYY-MM-DD': '%Y-%m-%d',
    'DD/MM/YYYY': '%d/%m/%Y',
    'MM/DD/YYYY': '%m/%d/%Y',
    'DD.MM.YYYY': '%d.%m.%Y',
}
DEFAULT_DATE_FORMAT = 'YYYY-MM-DD'


def date_pattern(label: str) -> str:
    return DATE_FORMATS.get(label, DATE_FORMATS[DEFAULT_DATE_FORMAT])


def parse_date(value: str, label: str = DEFAULT_DATE_FORMAT):
    """Parse a date in the field's own format, or None if it is not a date.

    Accepts the ISO form as a fallback so a value typed by another tool, or one
    of ours read back after a format change, is never silently rejected.
    """
    text = (value or '').strip()
    if not text:
        return None
    for pattern in (date_pattern(label), '%Y-%m-%d'):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    return None


def format_date(value, label: str = DEFAULT_DATE_FORMAT) -> str:
    return value.strftime(date_pattern(label))


def widget_kind(doc, widget) -> tuple[str, str | None]:
    """(kind, format) for a widget. Plain fields report ('text', None) etc."""
    kind, fmt = 'text', None
    if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
        kind = 'checkbox'
    elif widget.field_type in (fitz.PDF_WIDGET_TYPE_COMBOBOX, fitz.PDF_WIDGET_TYPE_LISTBOX):
        kind = 'dropdown'
    try:
        stored = doc.xref_get_key(widget.xref, DATE_KIND_KEY)
        if stored and stored[0] == 'string' and stored[1] == DATE_KIND:
            kind = DATE_KIND
            label = doc.xref_get_key(widget.xref, DATE_FORMAT_KEY)
            if label and label[0] == 'string' and label[1] in DATE_FORMATS:
                fmt = label[1]
            else:
                fmt = DEFAULT_DATE_FORMAT
    except Exception:
        pass
    return kind, fmt


def number(value: Any, low: float, high: float, label: str) -> float:
    try:
        n = float(value)
    except (ValueError, TypeError):
        raise PDFError(f"{label} must be a number.")
    if not math.isfinite(n) or not low <= n <= high:
        raise PDFError(f"{label} must be between {low:g} and {high:g}.")
    return n


def color(value: str = '#292b3d') -> tuple[float, float, float]:
    if not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
        raise PDFError("Choose a valid six-digit color.")
    return tuple(int(value[i:i + 2], 16) / 255 for i in (1, 3, 5))


# Substitute families offered by insert_htmlbox, mapped from the PDF font name
# so a direct edit starts from a closer match than a fixed default.
PDF_FONT_FOR_FAMILY = {'sans-serif': 'helv', 'serif': 'tiro', 'monospace': 'cour'}


def font_family(name: str) -> str:
    """Best-effort substitute family for an original PDF font name."""
    lowered = (name or '').lower()
    if any(k in lowered for k in ('courier', 'mono', 'consol', 'menlo', 'lucidaconsole')):
        return 'monospace'
    if any(k in lowered for k in ('times', 'serif', 'georgia', 'garamond', 'book', 'roman', 'century', 'palatino')):
        return 'serif'
    return 'sans-serif'


def indices(values: Any, count: int, *, all_if_empty=True) -> list[int]:
    if values is None or values == []:
        if all_if_empty:
            return list(range(count))
        raise PDFError("Select at least one page.")
    if not isinstance(values, list):
        raise PDFError("Page selection must be a list.")
    result = []
    for n in values:
        if isinstance(n, bool) or not isinstance(n, int) or not 0 <= n < count:
            raise PDFError("A selected page is outside this document.")
        if n in result:
            raise PDFError("Each page can only be selected once.")
        result.append(n)
    return result


def page_at(doc: fitz.Document, index: Any) -> fitz.Page:
    if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(doc):
        raise PDFError("This page does not exist.", 404, "page_not_found")
    return doc[index]


def parse_pages(spec: Any, count: int, label: str) -> list[int]:
    """Turn a page selection into a list of page indices, in the order given.

    Accepts what somebody would actually type when combining files: blank or
    "all" for the whole document, and things like "1-3, 5" or "9,2". The order
    is preserved rather than sorted, because asking for "9,2" is a reasonable
    way to say which of two pages should come first.

    Page 0 does not exist in a PDF as people read it, so numbering starts at 1
    and a range that runs past the end is refused instead of quietly shortened —
    silently dropping pages from a merge is how people lose part of a document
    without noticing.
    """
    if spec is None or spec == []:
        return list(range(count))
    if isinstance(spec, list):
        return indices(spec, count)
    if not isinstance(spec, str):
        raise PDFError(f"{label}: enter page numbers such as 1-3, 5, or leave it blank for all.")
    text = spec.replace(' ', '')
    if not text or text.lower() == 'all':
        return list(range(count))
    if not re.fullmatch(r'\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*', text):
        raise PDFError(f"{label}: use page numbers separated by commas, or inclusive ranges such as 1-3, 5.")
    picked: list[int] = []
    for part in text.split(','):
        first, _, last = part.partition('-')
        start, end = int(first), int(last or first)
        if start < 1 or end < start:
            raise PDFError(f"{label}: use ranges like 1-3, with the smaller page first.")
        if end > count:
            raise PDFError(f"{label} has {count} page{'' if count == 1 else 's'}; "
                           f"page {end} does not exist.")
        for n in range(start, end + 1):
            if n - 1 not in picked:
                picked.append(n - 1)
    if not picked:
        raise PDFError(f"{label}: select at least one page.")
    return picked


def consecutive_runs(pages: list[int]) -> list[tuple[int, int]]:
    """Group page indices into runs of consecutive pages.

    A selection of 1-200 is one copy operation rather than two hundred, which
    matters once somebody combines long documents. The runs stay in the order
    the pages were asked for, so a reordered selection is still honoured.
    """
    runs: list[list[int]] = []
    for index in pages:
        if runs and index == runs[-1][1] + 1:
            runs[-1][1] = index
        else:
            runs.append([index, index])
    return [(first, last) for first, last in runs]


# ------------------------------------------------------------------- splitting
# Splitting is the other half of combining: instead of many files becoming one,
# one file becomes many. The page grouping is decided here rather than in the
# interface, so the preview somebody reads before pressing the button is the
# engine's own answer and cannot drift from what is actually written.

SPLIT_MODES = ('chunks', 'parts', 'ranges')


def split_part_name(base: str, number: int, group: list[int]) -> str:
    """A file name that says which pages are inside it.

    Numbering starts at 1 and is zero-padded so the parts sort in order in a
    file manager. The page span is spelled out because a folder of files called
    "part-001" through "part-020" tells nobody which one holds page 47.
    """
    first, last = group[0] + 1, group[-1] + 1
    span = f'page-{first}' if first == last else f'pages-{first}-{last}'
    return f'{base}-part-{number:03d}-{span}.pdf'


def split_groups(count: int, options: dict) -> list[list[int]]:
    """The page groups a split would produce, in order.

    Raises rather than guessing: a page range past the end of the document, a
    request for more files than there are pages, or a chunk size of zero are all
    things somebody can type by accident, and silently shortening the output is
    how part of a document goes missing without anybody noticing.
    """
    mode = options.get('mode', 'chunks')
    if mode not in SPLIT_MODES:
        raise PDFError("Choose how to split: every few pages, a number of files, or your own page ranges.")
    if mode == 'chunks':
        size = options.get('size', 1)
        if isinstance(size, bool) or not isinstance(size, int):
            raise PDFError("Enter how many pages each file should hold.")
        if not 1 <= size <= MAX_PAGES:
            raise PDFError(f"Each file must hold between 1 and {MAX_PAGES} pages.")
        groups = [list(range(start, min(start + size, count))) for start in range(0, count, size)]
    elif mode == 'parts':
        parts = options.get('parts', 2)
        if isinstance(parts, bool) or not isinstance(parts, int):
            raise PDFError("Enter how many files you want.")
        if not 2 <= parts <= MAX_SPLIT_FILES:
            raise PDFError(f"Choose between 2 and {MAX_SPLIT_FILES} files.")
        if parts > count:
            raise PDFError(f"A {count}-page document cannot become {parts} files. "
                           f"Choose at most {count}.")
        # Divided as evenly as possible, with the longer parts first, so a
        # 10-page document asked to become 3 files gives 4, 3 and 3 pages.
        base, extra = divmod(count, parts)
        groups, cursor = [], 0
        for n in range(parts):
            take = base + (1 if n < extra else 0)
            groups.append(list(range(cursor, cursor + take)))
            cursor += take
    else:
        spec = options.get('ranges', '')
        if not isinstance(spec, str):
            raise PDFError("Enter the page ranges, one file per range, such as 1-3, 4-6, 7-10.")
        text = spec.replace(' ', '')
        if not text:
            raise PDFError("Enter the page ranges, one file per range, such as 1-3, 4-6, 7-10.")
        if not re.fullmatch(r'\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*', text):
            raise PDFError("Use page numbers separated by commas, one range per file, such as 1-3, 4-6.")
        groups = []
        for part in text.split(','):
            first, _, last = part.partition('-')
            start, end = int(first), int(last or first)
            if start < 1 or end < start:
                raise PDFError("Use ranges like 1-3, with the smaller page first.")
            if end > count:
                raise PDFError(f"This document has {count} page{'' if count == 1 else 's'}; "
                               f"page {end} does not exist.")
            groups.append(list(range(start - 1, end)))
    if len(groups) > MAX_SPLIT_FILES:
        raise PDFError(f"A split is limited to {MAX_SPLIT_FILES} files.", 413, 'too_many_files')
    return groups


def omitted_ranges(present: set[int], count: int) -> list[list[int]]:
    """The pages in no part at all, as compact runs, so a gap can be reported.

    Only the "your own page ranges" mode can leave a page out, and somebody who
    types 1-3, 7-10 has probably made a mistake rather than meant to drop pages
    4 to 6. Reporting it is the difference between a deliberate omission and a
    silent one.
    """
    runs: list[list[int]] = []
    for index in range(count):
        if index in present:
            continue
        if runs and index == runs[-1][1] + 1:
            runs[-1][1] = index
        else:
            runs.append([index, index])
    return runs


def page_span_label(runs: list[list[int]]) -> str:
    return ', '.join(str(a + 1) if a == b else f'{a + 1}\u2013{b + 1}' for a, b in runs)


def display_rect(page: fitz.Page, value: Any) -> fitz.Rect:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise PDFError("Select an area on the page first.")
    a = [number(x, -100000, 100000, 'Position') for x in value]
    rect = fitz.Rect(a).normalize() & page.rect
    if rect.is_empty or rect.width < 1 or rect.height < 1:
        raise PDFError("Draw a larger area inside the page.")
    # Browser coordinates follow the displayed (rotated) page.
    return rect * page.derotation_matrix


def bounds(rect: fitz.Rect, page: fitz.Page) -> list[float]:
    return [round(x, 3) for x in rect * page.rotation_matrix]


def scan_background(page: fitz.Page, rect: fitz.Rect) -> tuple[float, float, float]:
    """The colour of the paper around a box on a scanned page.

    Replacing text on a scan means painting over the ink, which is pixels rather
    than text. White is the wrong guess for a photographed page or a grey form:
    it leaves a bright rectangle in the middle of a grey sheet. So the ring just
    outside the box is sampled and its median taken — the paper, not the ink,
    because a tight selection is mostly the letters inside it. A median rather
    than a mean, because one stray dark pixel should not darken the patch.
    """
    try:
        clip = (fitz.Rect(rect) + (-3, -3, 3, 3)) & page.rect
        pixmap = page.get_pixmap(clip=clip, dpi=72, alpha=False, colorspace=fitz.csRGB)
        width, height, channels, samples = pixmap.width, pixmap.height, pixmap.n, pixmap.samples
        if width < 6 or height < 6 or channels < 3:
            return (1, 1, 1)
        ring: list[tuple[int, int, int]] = []
        for x in range(width):
            for y in (0, 1, height - 2, height - 1):
                offset = (y * width + x) * channels
                ring.append((samples[offset], samples[offset + 1], samples[offset + 2]))
        for y in range(height):
            for x in (0, 1, width - 2, width - 1):
                offset = (y * width + x) * channels
                ring.append((samples[offset], samples[offset + 1], samples[offset + 2]))
        if not ring:
            return (1, 1, 1)
        middle = len(ring) // 2
        return tuple(sorted(pixel[channel] for pixel in ring)[middle] / 255
                     for channel in range(3))
    except Exception:
        return (1, 1, 1)


def free_right_limit(page: fitz.Page, rect: fitz.Rect, margin: float = 16.0) -> float:
    """Rightmost x a horizontal text box may grow to without touching other text.

    Used before a replacement is written, so typed text can stay at its own font
    size instead of shrinking into the original selection box.
    """
    limit = page.mediabox.x1 - margin
    for block in page.get_text('dict', flags=fitz.TEXTFLAGS_DICT & ~(fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_PRESERVE_LIGATURES))['blocks']:
        for line in block.get('lines', []):
            for span in line['spans']:
                if not span['text'].strip():
                    continue
                other = fitz.Rect(span['bbox'])
                if other.x0 >= rect.x1 - .5 and other.y1 > rect.y0 + 1 and other.y0 < rect.y1 - 1:
                    limit = min(limit, other.x0 - 2.0)
    return limit


def free_left_limit(page: fitz.Page, rect: fitz.Rect, margin: float = 16.0) -> float:
    """Leftmost x a horizontal text box may grow to without touching other text.

    The mirror of free_right_limit, and needed for Arabic/Hebrew: an RTL
    replacement grows away from its right edge, so the free space to look for is
    on the left.
    """
    limit = page.mediabox.x0 + margin
    for block in page.get_text('dict', flags=fitz.TEXTFLAGS_DICT & ~(fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_PRESERVE_LIGATURES))['blocks']:
        for line in block.get('lines', []):
            for span in line['spans']:
                if not span['text'].strip():
                    continue
                other = fitz.Rect(span['bbox'])
                if other.x1 <= rect.x0 + .5 and other.y1 > rect.y0 + 1 and other.y0 < rect.y1 - 1:
                    limit = max(limit, other.x1 + 2.0)
    return limit


def measure_text(text: str, size: float, family: str) -> float | None:
    """Width of `text` at `size`, or None when it cannot be measured.

    Latin text is measured with the base-14 substitute. RTL text cannot be:
    those fonts have no Arabic glyphs, so the measurement would be meaningless.
    The embedded font chosen by app.rtl is used instead.
    """
    if rtl.is_rtl(text):
        chosen = rtl.choose_font()
        if not chosen['path']:
            return None
        try:
            font = fitz.Font(fontfile=chosen['path'])
            return font.text_length(text, fontsize=size)
        except Exception:
            return None
    try:
        return fitz.get_text_length(text, fontname=PDF_FONT_FOR_FAMILY[family], fontsize=size)
    except Exception:
        return None


def grow_to_fit(rect: fitz.Rect, text: str, size: float, family: str, limit: float,
                leftward: bool = False) -> fitz.Rect:
    """Widen a single-line replacement box into free space, never past an obstacle.

    `leftward` grows the left edge instead, which is how RTL text expands.
    """
    if '\n' in text:
        return rect
    if not leftward and limit <= rect.x1:
        return rect
    if leftward and limit >= rect.x0:
        return rect
    needed = measure_text(text, size, family)
    if needed is None:
        return rect
    if leftward:
        target = rect.x1 - needed - 2.0
        if target < rect.x0:
            rect.x0 = max(target, limit)
    else:
        target = rect.x0 + needed + 2.0
        if target > rect.x1:
            rect.x1 = min(target, limit)
    return rect


def text_layout(text: str, size: float, family: str, text_color: str, rtl_text: bool):
    """(markup, css, archive) for insert_htmlbox.

    RTL text must go through the HTML/Story layout path: it is the only MuPDF
    route that applies Arabic shaping and the bidi algorithm, and it needs an
    embedded font because the base-14 fonts carry no Arabic glyphs. LTR text
    keeps the previous behaviour exactly.
    """
    body = html.escape(text).replace('\n', '<br>')
    base = (f'* {{margin:0;padding:0;}} div {{font-size:{size}pt;line-height:1.15;'
            f'color:{text_color};')
    if not rtl_text:
        return f'<div>{body}</div>', base + f'font-family:{family};}}', None
    archive, url = rtl.font_archive()
    if not url:
        # No Arabic-capable font anywhere. Render anyway with whatever MuPDF can
        # substitute, rather than refusing the edit outright.
        return f'<div dir="rtl">{body}</div>', base + 'direction:rtl;}', None
    # `direction:rtl` alone is what right-aligns this text. Do NOT add
    # `text-align:right`: measured against MuPDF's layout engine it moves the
    # text to the *left* edge, the opposite of what the property means. RTL is
    # right-aligned by default, so the declaration is not just unnecessary but
    # actively wrong here.
    css = (f'@font-face{{font-family:pdrtl;src:url({url});}}'
           + base + 'font-family:pdrtl;direction:rtl;}')
    return f'<div dir="rtl">{body}</div>', css, archive


def image_bytes(data: bytes) -> bytes:
    try:
        with Image.open(io.BytesIO(data)) as image:
            if image.width * image.height > 40_000_000:
                raise PDFError("The image exceeds the 40-megapixel limit.")
            image = ImageOps.exif_transpose(image)
            image.load()
            # Re-encoding drops EXIF, scripts, and other source metadata.
            image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
            out = io.BytesIO()
            image.save(out, 'PNG')
            return out.getvalue()
    except PDFError:
        raise
    except (Exception, Image.DecompressionBombWarning) as exc:
        raise PDFError("This image could not be read. Use a JPG, PNG, or WebP image.") from exc


def find_soffice() -> str | None:
    override = os.environ.get('PAPERDESK_LIBREOFFICE')
    candidates = [override, shutil.which('libreoffice'), shutil.which('soffice'),
                  '/Applications/LibreOffice.app/Contents/MacOS/soffice',
                  r'C:\Program Files\LibreOffice\program\soffice.exe',
                  r'C:\Program Files (x86)\LibreOffice\program\soffice.exe']
    return next((str(x) for x in candidates if x and Path(x).is_file()), None)


def find_tesseract() -> str | None:
    candidates = [os.environ.get('PAPERDESK_TESSERACT'), shutil.which('tesseract'),
                  '/opt/homebrew/bin/tesseract', '/usr/local/bin/tesseract',
                  r'C:\Program Files\Tesseract-OCR\tesseract.exe']
    return next((str(x) for x in candidates if x and Path(x).is_file()), None)


class PlainHTML(HTMLParser):
    """Local HTML conversion deliberately never fetches remote resources."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style', 'head', 'iframe', 'object'):
            self.skip += 1
        elif not self.skip and tag in ('p', 'div', 'br', 'h1', 'h2', 'h3', 'li', 'tr', 'section'):
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in ('script', 'style', 'head', 'iframe', 'object'):
            self.skip = max(0, self.skip - 1)
        elif not self.skip and tag in ('p', 'div', 'h1', 'h2', 'h3', 'li', 'tr'):
            self.parts.append('\n')

    def handle_data(self, text):
        if not self.skip:
            self.parts.append(text)


def text_pdf(text: str, title: str) -> bytes:
    # MuPDF's HTML layout supports Unicode shaping, using local built-in fonts.
    if len(text) > 1_000_000:
        raise PDFError("Text/HTML files are limited to one million characters.")
    markup = '<h1>' + html.escape(Path(title).stem) + '</h1>'
    markup += ''.join('<p>' + html.escape(line) + '</p>'
                      for line in text.splitlines() if line.strip())
    story = fitz.Story(markup, user_css='body {font-family:sans-serif;font-size:11pt;} p {margin:0 0 8pt;} h1 {font-size:22pt;}')
    out = io.BytesIO()
    writer = fitz.DocumentWriter(out)
    page_rect = fitz.Rect(0, 0, 595, 842)
    content_rect = fitz.Rect(48, 48, 547, 794)
    for n in range(MAX_PAGES):
        more, _ = story.place(content_rect)
        device = writer.begin_page(page_rect)
        story.draw(device)
        writer.end_page()
        if not more:
            break
    else:
        writer.close()
        raise PDFError(f"The converted document exceeds {MAX_PAGES} pages.")
    writer.close()
    return out.getvalue()


def office_pdf(data: bytes, name: str) -> bytes:
    exe = find_soffice()
    if not exe:
        raise PDFError("Office-to-PDF conversion requires LibreOffice. Install it locally, then restart KADOMA.", 409, 'libreoffice_missing')
    with tempfile.TemporaryDirectory(prefix='kadoma-office-') as directory:
        root = Path(directory)
        source = root / safe_name(name)
        source.write_bytes(data)
        output = root / 'output'
        output.mkdir()
        profile_root = root / 'profile'
        (profile_root / 'user').mkdir(parents=True)
        (profile_root / 'user' / 'registrymodifications.xcu').write_text(
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<oor:items xmlns:oor="http://openoffice.org/2001/registry">'
            '<item oor:path="/org.openoffice.Office.Common/Security/Scripting">'
            '<prop oor:name="MacroSecurityLevel" oor:op="fuse"><value>3</value></prop>'
            '</item></oor:items>', encoding='utf-8')
        profile = profile_root.as_uri()
        try:
            result = subprocess.run([exe, f'-env:UserInstallation={profile}', '--headless',
                                     '--convert-to', 'pdf', '--outdir', str(output), str(source)],
                                    capture_output=True, timeout=100, check=False)
        except subprocess.TimeoutExpired as exc:
            raise PDFError("LibreOffice took too long to convert this file.", 408, 'conversion_timeout') from exc
        files = list(output.glob('*.pdf'))
        if result.returncode or not files:
            raise PDFError("LibreOffice could not convert this file. Check that it is not password-protected or damaged.")
        return files[0].read_bytes()


def convert_input(data: bytes, name: str) -> bytes:
    if not data or len(data) > MAX_UPLOAD:
        raise PDFError(f"Choose a non-empty file smaller than {MAX_UPLOAD // (1024 * 1024)} MB.", 413, 'file_too_large')
    ext = Path(name).suffix.lower()
    if ext == '.pdf':
        return data
    if ext in ('.png', '.jpg', '.jpeg', '.webp', '.tif', '.tiff', '.bmp'):
        stream = image_bytes(data)
        with Image.open(io.BytesIO(stream)) as im:
            w, h = im.size
        with fitz.open() as doc:
            page = doc.new_page(width=595, height=842)
            page.insert_image(fitz.Rect(24, 24, 571, 818), stream=stream, keep_proportion=True)
            return doc.tobytes(deflate=True)
    if ext in ('.docx', '.xlsx', '.pptx', '.doc', '.xls', '.ppt', '.odt', '.ods', '.odp'):
        return office_pdf(data, name)
    if ext in ('.html', '.htm', '.txt', '.md'):
        text = data.decode('utf-8', errors='replace')
        if ext in ('.html', '.htm'):
            parser = PlainHTML()
            parser.feed(text)
            text = ''.join(parser.parts)
        return text_pdf(text, name)
    raise PDFError("Unsupported file. Open a PDF, image, Office document, or local HTML/text file.")


@dataclass
class DocumentState:
    id: str
    name: str
    data: bytes
    password: str = ''
    owner: bool = True
    revision: int = 0
    modified: bool = False
    undo: list[tuple[bytes, bool]] = field(default_factory=list)
    redo: list[tuple[bytes, bool]] = field(default_factory=list)
    meta_cache: dict | None = None
    opened: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    # Where this document came from, if it came from a file rather than an
    # upload. `stamp` is the file's (mtime_ns, size) when it was read or last
    # saved, so an overwrite can tell whether somebody else changed it in the
    # meantime. `saved_revision` is the revision last written to disk; the
    # interface compares it with `revision` to know whether there is anything
    # unsaved, which is a different question from "has this been edited".
    path: str | None = None
    stamp: tuple[int, int] | None = None
    saved_revision: int | None = None


def file_stamp(path: str | Path) -> tuple[int, int] | None:
    """(mtime_ns, size), or None if the file is not there."""
    try:
        info = os.stat(path)
    except OSError:
        return None
    return (info.st_mtime_ns, info.st_size)


def same_file(first: str | Path, second: str | Path) -> bool:
    """True when two paths name the same file, including case on Windows."""
    try:
        return os.path.normcase(os.path.realpath(first)) == os.path.normcase(os.path.realpath(second))
    except OSError:
        return False


class Engine:
    def __init__(self):
        self.lock = threading.RLock()
        self.documents: OrderedDict[str, DocumentState] = OrderedDict()

    def get(self, ident: str) -> DocumentState:
        state = self.documents.get(ident)
        if not state:
            raise PDFError("This document is no longer open. Please open the file again.", 404, 'document_not_found')
        self.documents.move_to_end(ident)
        return state

    @contextmanager
    def opened(self, state: DocumentState):
        doc = fitz.open(stream=state.data, filetype='pdf')
        if doc.needs_pass and not doc.authenticate(state.password):
            doc.close()
            raise PDFError("The document could not be unlocked.", 401, 'password_required')
        elif doc.metadata.get('encryption'):
            doc.authenticate(state.password)
        try:
            yield doc
        finally:
            doc.close()

    @staticmethod
    def permission(state: DocumentState, doc: fitz.Document, flag: int):
        if not state.owner and not doc.permissions & flag:
            raise PDFError("The PDF owner has restricted this action. Reopen it using the owner password.", 403, 'permission_denied')

    def load(self, data: bytes, name: str, password: str = '',
             path: str | Path | None = None) -> dict:
        with self.lock:
            original = safe_name(name)
            data = convert_input(data, original)
            try:
                doc = fitz.open(stream=data, filetype='pdf')
            except Exception as exc:
                raise PDFError("This file is not a readable PDF, or it is damaged.") from exc
            with doc:
                encrypted = bool(doc.is_encrypted or (doc.metadata or {}).get('encryption'))
                auth = doc.authenticate(password) if encrypted else 4
                if encrypted and not auth:
                    raise PDFError("Enter the PDF password to open this document.", 401, 'password_required')
                if not 0 < len(doc) <= MAX_PAGES:
                    raise PDFError(f"Documents must contain between 1 and {MAX_PAGES} pages.")
                owner = bool(auth & 4) or not encrypted
            name = original if Path(original).suffix.lower() == '.pdf' else Path(original).stem + '.pdf'
            state = DocumentState(uuid.uuid4().hex, name, data, password, owner)
            # Only a PDF on disk can be saved over. Anything else was converted
            # on the way in — a .docx opened here is a PDF in memory — and
            # writing that back would replace the person's original with a
            # different format. Those documents keep no path, so the first save
            # asks where to put the copy.
            if path and Path(original).suffix.lower() == '.pdf':
                state.path = str(path)
                state.stamp = file_stamp(path)
            self.documents[state.id] = state
            while len(self.documents) > MAX_DOCUMENTS:
                self.documents.popitem(last=False)
            return self.meta(state.id)

    def blank(self, name='Untitled.pdf') -> dict:
        with self.lock, fitz.open() as doc:
            doc.new_page(width=595, height=842)
            return self.load(doc.tobytes(), safe_name(name))

    def scan_form(self, ident: str) -> dict:
        """Where a form field could go, without changing anything."""
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                found = form_prep.scan(doc)
                return {'candidates': found, 'pageCount': len(doc),
                        'limit': form_prep.MAX_FIELDS}

    def close(self, ident: str):
        with self.lock:
            self.documents.pop(ident, None)

    def meta(self, ident: str) -> dict:
        with self.lock:
            state = self.get(ident)
            if state.meta_cache:
                return dict(state.meta_cache)
            with self.opened(state) as doc:
                pages, words, images, forms, comments = [], 0, set(), 0, 0
                for page in doc:
                    pages.append({'width': round(page.rect.width, 3), 'height': round(page.rect.height, 3), 'rotation': page.rotation})
                    words += len(page.get_text('words'))
                    images.update(x[0] for x in page.get_images())
                    forms += sum(1 for _ in page.widgets() or [])
                    comments += sum(1 for _ in page.annots() or [])
                encrypted = bool(doc.metadata.get('encryption'))
                result = {'id': state.id, 'name': state.name, 'pageCount': len(doc), 'pages': pages,
                          'wordCount': words, 'imageCount': len(images), 'formCount': forms,
                          'annotationCount': comments, 'size': len(state.data), 'revision': state.revision,
                          'modified': state.modified, 'canUndo': bool(state.undo), 'canRedo': bool(state.redo),
                          'encrypted': encrypted, 'owner': state.owner,
                          'canEdit': state.owner or bool(doc.permissions & fitz.PDF_PERM_MODIFY),
                          'canAssemble': state.owner or bool(doc.permissions & fitz.PDF_PERM_ASSEMBLE),
                          'canCopy': state.owner or bool(doc.permissions & fitz.PDF_PERM_COPY),
                          'canAnnotate': state.owner or bool(doc.permissions & fitz.PDF_PERM_ANNOTATE),
                          'canFill': state.owner or bool(doc.permissions & fitz.PDF_PERM_FORM),
                          'canPrint': state.owner or bool(doc.permissions & fitz.PDF_PERM_PRINT),
                          'title': doc.metadata.get('title') or '', 'opened': state.opened,
                          # Where this document lives on disk, whether it can be
                          # written back over that file, and whether there is
                          # anything on screen that the file does not have yet.
                          'path': state.path, 'savedRevision': state.saved_revision,
                          'canSave': bool(state.path),
                          'dirty': state.modified and state.saved_revision != state.revision}
            state.meta_cache = result
            return dict(result)

    def render(self, ident: str, page_index: int, scale: float = 1.35) -> bytes:
        scale = number(scale, .08, 3, 'Render scale')
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                page = page_at(doc, page_index)
                if page.rect.width * page.rect.height * scale * scale > 20_000_000:
                    scale = math.sqrt(20_000_000 / (page.rect.width * page.rect.height))
                return page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False, annots=True).tobytes('png')

    def content(self, ident: str, page_index: int) -> dict:
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                page = page_at(doc, page_index)
                can_copy = state.owner or bool(doc.permissions & fitz.PDF_PERM_COPY)
                can_edit = state.owner or bool(doc.permissions & fitz.PDF_PERM_MODIFY)
                can_fill = state.owner or bool(doc.permissions & fitz.PDF_PERM_FORM)
                spans = []
                # Spans are additionally clustered into editable "runs": a run is
                # the visible text a person would click once. Consecutive spans on
                # one line stay together unless a wide horizontal gap (a table
                # column, a right-aligned header) separates them, so replacing a
                # run never silently swallows an unrelated cell.
                runs: list[dict] = []
                blocks = page.get_text('dict', flags=fitz.TEXTFLAGS_DICT & ~(fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_PRESERVE_LIGATURES))['blocks'] if can_copy else []
                for block in blocks:
                    for line in block.get('lines', []):
                        dx, dy = line.get('dir', (1, 0))
                        rotation = int(round(math.degrees(math.atan2(-dy, dx)) / 90) * 90) % 360
                        run = None
                        for span in line['spans']:
                            if not span['text'].strip():
                                continue
                            # Shaped Arabic comes back as presentation forms. The
                            # interface must show the letters the user typed, so
                            # every string handed out is normalised to logical form.
                            piece = rtl.logical(span['text'])
                            rect = fitz.Rect(span['bbox'])
                            size = round(span['size'], 2)
                            gap = None if run is None else rect.x0 - run['_right']
                            if run is None or gap > max(4.0, .5 * max(size, run['_size'])):
                                run = {'text': '', 'rect': fitz.Rect(rect), 'size': size,
                                       'color': f"#{span['color']:06x}", 'font': span['font'],
                                       'rotation': rotation, 'spans': [], '_right': rect.x1, '_size': size}
                                runs.append(run)
                            elif gap > .28 * size:
                                run['text'] += ' '
                            run['text'] += piece
                            run['rect'].include_rect(rect)
                            run['spans'].append(len(spans))
                            run['_right'] = max(run['_right'], rect.x1)
                            if size > run['_size']:
                                run.update(size=size, font=span['font'], color=f"#{span['color']:06x}", _size=size)
                            spans.append({'text': piece, 'rect': bounds(rect, page), 'font': span['font'],
                                          'size': size, 'color': f"#{span['color']:06x}", 'rotation': rotation,
                                          'family': font_family(span['font']), 'run': len(runs) - 1,
                                          'rtl': rtl.is_rtl(piece)})
                editable = [{'text': run['text'], 'rect': bounds(run['rect'], page), 'size': run['size'],
                             'color': run['color'], 'font': run['font'], 'rotation': run['rotation'],
                             'family': font_family(run['font']), 'spanCount': len(run['spans']),
                             'rtl': rtl.is_rtl(run['text'])}
                            for run in runs]
                pictures = []
                for info in page.get_image_info(xrefs=True) if can_copy or can_edit else []:
                    pictures.append({'xref': info['xref'], 'rect': bounds(fitz.Rect(info['bbox']), page),
                                     'width': info['width'], 'height': info['height']})
                widgets = []
                for widget in (page.widgets() or []) if can_copy or can_edit or can_fill else []:
                    kind, date_format = widget_kind(doc, widget)
                    widgets.append({'xref': widget.xref, 'name': widget.field_name, 'label': widget.field_label or widget.field_name,
                                    'type': widget.field_type, 'typeName': widget.field_type_string,
                                    'kind': kind, 'dateFormat': date_format,
                                    'value': widget.field_value, 'rect': bounds(widget.rect, page),
                                    'choices': list(widget.choice_values or []), 'readOnly': bool(widget.field_flags & fitz.PDF_FIELD_IS_READ_ONLY),
                                    'checkedValue': widget.on_state() if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX else None})
                annotations = []
                for annot in page.annots() or []:
                    annotations.append({'xref': annot.xref, 'type': annot.type[1], 'content': annot.info.get('content') or '',
                                        'author': annot.info.get('title') or 'Me', 'rect': bounds(annot.rect, page)})
                return {'spans': spans[:10000], 'runs': editable[:4000], 'images': pictures,
                        'widgets': widgets, 'annotations': annotations}

    def search(self, ident: str, query: str) -> list[dict]:
        if not query.strip() or len(query) > 200:
            return []
        # The query arrives as the letters the user typed; the document may hold
        # shaped presentation forms, so both sides are compared in logical form.
        needle = rtl.logical(query).strip()
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                self.permission(state, doc, fitz.PDF_PERM_COPY)
                result: list[dict] = []
                seen: set[tuple] = set()

                def add(page: fitz.Page, rect: fitz.Rect, text: str):
                    key = (page.number, round(rect.x0, 1), round(rect.y0, 1),
                           round(rect.x1, 1), round(rect.y1, 1))
                    if key not in seen:
                        seen.add(key)
                        result.append({'page': page.number, 'rect': bounds(rect, page), 'text': text})

                for page in doc:
                    for found in page.search_for(needle):
                        add(page, found, rtl.logical(page.get_textbox(found)).strip())
                    if rtl.is_rtl(needle):
                        for rect, text in rtl_word_matches(page, needle):
                            add(page, rect, text)
                    if len(result) >= 300:
                        break
                return result[:300]

    def commit(self, state: DocumentState, doc: fitz.Document, *, irreversible=False,
               data: bytes | None = None):
        # `data` is for tools that save the document their own way — compression
        # asks PyMuPDF for extra deflation, and re-saving it here would undo that.
        if data is None:
            data = doc.tobytes(garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP)
        if len(data) > MAX_UPLOAD:
            raise PDFError(f"The edited PDF exceeds the {MAX_UPLOAD // (1024 * 1024)} MB working-document limit.", 413)
        if irreversible:
            state.undo.clear()
            state.redo.clear()
        else:
            state.undo.append((state.data, state.modified))
            while len(state.undo) > MAX_HISTORY_STEPS or sum(len(d) for d, _ in state.undo) > MAX_HISTORY_BYTES:
                state.undo.pop(0)
            state.redo.clear()
        state.data = data
        state.revision += 1
        state.modified = True
        state.meta_cache = None

    def history(self, ident: str, action: str) -> dict:
        with self.lock:
            state = self.get(ident)
            source, target = (state.undo, state.redo) if action == 'undo' else (state.redo, state.undo)
            if not source:
                raise PDFError(f"There is nothing to {action}.", 409)
            target.append((state.data, state.modified))
            state.data, state.modified = source.pop()
            state.revision += 1
            state.meta_cache = None
            return self.meta(ident)

    # ------------------------------------------------------ page furniture
    # Watermark, header and footer, numbering, crop, bookmarks, attachments and
    # compression. They live in their own module because none of them needs the
    # engine's history or locking; this wrapper adds exactly that, and nothing
    # else, so each tool can be tested against a bare document.
    FURNITURE = ('watermark', 'header_footer', 'numbering', 'crop', 'bookmarks',
                 'attachments', 'compress', 'stamp', 'links', 'resize')

    def document_tool(self, ident: str, payload: dict) -> dict:
        action = payload.get('action')
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                if action == 'compress':
                    self.permission(state, doc, fitz.PDF_PERM_MODIFY)
                    data, before = document_tools.compress(doc, payload)
                    self.commit(state, doc, data=data)
                    return {**self.meta(ident), 'beforeSize': before,
                            'afterSize': len(state.data)}
                # Reading an attachment or listing bookmarks changes nothing, so
                # it is not an edit and must not land in the undo history.
                if action == 'attachments' and payload.get('mode') == 'extract':
                    found = document_tools.attachments(doc, payload)
                    return {'result': {'name': found['name'],
                                       'data': base64.b64encode(found['data']).decode('ascii')}}
                if action == 'bookmarks' and payload.get('mode', 'list') == 'list':
                    return {'result': document_tools.bookmarks(doc, payload)}
                if action == 'links' and payload.get('mode', 'list') == 'list':
                    return {'result': document_tools.links(doc, payload)}
                # Listing is a read, so only the edits need write permission.
                self.permission(state, doc, fitz.PDF_PERM_MODIFY)
                handler = {'watermark': document_tools.watermark,
                           'header_footer': document_tools.header_footer,
                           'numbering': document_tools.numbering,
                           'crop': document_tools.crop,
                           'bookmarks': document_tools.bookmarks,
                           'attachments': document_tools.attachments,
                           'stamp': document_tools.stamp,
                           'links': document_tools.links,
                           'resize': document_tools.resize}[action]
                result = handler(doc, payload)
                self.commit(state, doc)
                return {**self.meta(ident), 'result': result}

    def compare_documents(self, ident: str, other: str, options: dict | None = None) -> dict:
        """Compare two open documents. Reading only: nothing is edited."""
        if not isinstance(other, str) or not other:
            raise PDFError('Choose a document to compare with.')
        with self.lock:
            left = self.get(ident)
            right = self.get(other)
            with self.opened(left) as a, self.opened(right) as b:
                return document_tools.compare(a, b, options or {})

    def operation(self, ident: str, payload: dict) -> dict:
        action = payload.get('action')
        if action in ('undo', 'redo'):
            return self.history(ident, action)
        if action in self.FURNITURE:
            return self.document_tool(ident, payload)
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                if action in ('rotate', 'delete_pages', 'reorder', 'duplicate', 'insert_blank'):
                    perm = fitz.PDF_PERM_ASSEMBLE
                elif action in ('fill_forms', 'clear_fields'):
                    perm = fitz.PDF_PERM_FORM
                elif action in ('highlight', 'comment', 'delete_annotation'):
                    perm = fitz.PDF_PERM_ANNOTATE
                else:
                    perm = fitz.PDF_PERM_MODIFY
                self.permission(state, doc, perm)
                irreversible = False
                if action in ('rotate', 'delete_pages', 'reorder', 'duplicate', 'insert_blank'):
                    selected = indices(payload.get('pages'), len(doc), all_if_empty=False) if action != 'insert_blank' else []
                    if action == 'rotate':
                        angle = payload.get('angle', 90)
                        if angle not in (-270, -180, -90, 90, 180, 270):
                            raise PDFError("Rotation must be in quarter turns.")
                        for i in selected:
                            doc[i].set_rotation((doc[i].rotation + angle) % 360)
                    elif action == 'delete_pages':
                        if len(selected) >= len(doc):
                            raise PDFError("Keep at least one page in the document.")
                        for i in sorted(selected, reverse=True):
                            doc.delete_page(i)
                    elif action == 'reorder':
                        if len(selected) != len(doc):
                            raise PDFError("A page reorder must include every page exactly once.")
                        doc.select(selected)
                    elif action == 'duplicate':
                        if len(doc) + len(selected) > MAX_PAGES:
                            raise PDFError(f"The document cannot exceed {MAX_PAGES} pages.")
                        # Copy pages and their annotations/forms. Give cloned fields
                        # unique names so readers do not link values to the originals.
                        known_names = {w.field_name for p in doc for w in p.widgets() or []}
                        for i in selected:
                            doc.fullcopy_page(i)
                            copied_page = doc[-1]
                            for widget in list(copied_page.widgets() or []):
                                base = widget.field_name
                                name, suffix = base, 1
                                while name in known_names:
                                    name = f'{base}_copy{suffix}'
                                    suffix += 1
                                if name != base:
                                    widget.field_name = name
                                    widget.update()
                                known_names.add(name)
                    else:
                        if len(doc) >= MAX_PAGES:
                            raise PDFError(f"The document cannot exceed {MAX_PAGES} pages.")
                        position = payload.get('position', len(doc))
                        if not isinstance(position, int) or not 0 <= position <= len(doc):
                            raise PDFError("Invalid insertion position.")
                        doc.new_page(pno=position, width=595, height=842)
                elif action == 'fill_forms':
                    values = payload.get('values')
                    if not isinstance(values, dict) or len(values) > 500:
                        raise PDFError("Choose the form fields to update.")
                    changed = 0
                    for p in doc:
                        emptied = []
                        for widget in p.widgets() or []:
                            key = str(widget.xref)
                            if key not in values:
                                continue
                            value = values[key]
                            if widget.field_flags & fitz.PDF_FIELD_IS_READ_ONLY:
                                raise PDFError(f'The field {widget.field_name} is read-only.')
                            if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                if not isinstance(value, bool):
                                    raise PDFError('Checkbox values must be true or false.')
                                widget.field_value = widget.on_state() if value else 'Off'
                            elif widget.field_type in (fitz.PDF_WIDGET_TYPE_COMBOBOX, fitz.PDF_WIDGET_TYPE_LISTBOX):
                                if value not in (widget.choice_values or []):
                                    raise PDFError(f"Choose a valid option for {widget.field_name}.")
                                widget.field_value = value
                            elif widget.field_type == fitz.PDF_WIDGET_TYPE_TEXT:
                                if not isinstance(value, str) or len(value) > 5000:
                                    raise PDFError("Form text must be under 5,000 characters.")
                                kind, date_format = widget_kind(doc, widget)
                                if kind == DATE_KIND and value.strip():
                                    # A date field is still a text field in the PDF, so
                                    # the value is checked here instead. Anything that is
                                    # not a real date in this field's own format is
                                    # refused rather than written as free text.
                                    if parse_date(value, date_format) is None:
                                        raise PDFError(f"{widget.field_name} must be a date in the "
                                                       f"{date_format} format.")
                                    value = format_date(parse_date(value, date_format), date_format)
                                if value:
                                    widget.field_value = value
                                else:
                                    # Erasing a value needs the same treatment as
                                    # clearing one: PyMuPDF silently ignores
                                    # `field_value = ''`, so the field keeps its old
                                    # value and it stays in the saved file. Somebody
                                    # who empties a field and applies expects it gone,
                                    # and an emptied field is often the whole point
                                    # (taking a name back off a shared form). The
                                    # value is removed from the field dictionary
                                    # instead, and the appearance rebuilt below.
                                    doc.xref_set_key(widget.xref, 'V', 'null')
                                    emptied.append(widget.xref)
                                    changed += 1
                                    continue
                            else:
                                raise PDFError("This form field type is not supported for filling.")
                            widget.update()
                            changed += 1
                        # Re-read: the objects above are stale once their field
                        # dictionaries have been edited.
                        if emptied:
                            for widget in p.widgets() or []:
                                if widget.xref in emptied:
                                    widget.update()
                    if not changed:
                        raise PDFError("No matching form fields were found.")
                elif action == 'clear_fields':
                    # Reset what was filled in, without touching the fields
                    # themselves or any page content. Undoable like any other edit.
                    #
                    # Note for anyone tempted to simplify this: PyMuPDF silently
                    # ignores `widget.field_value = ''` for text and choice fields,
                    # so an empty string is not how a field is emptied. The value
                    # has to be removed from the field dictionary and the
                    # appearance then rebuilt from it, or the old text stays on
                    # the page even though the value reads back as empty.
                    cleared = 0
                    for p in doc:
                        pending = []
                        for widget in list(p.widgets() or []):
                            if widget.field_flags & fitz.PDF_FIELD_IS_READ_ONLY:
                                continue
                            if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                if (widget.field_value or 'Off') == 'Off':
                                    continue
                                pending.append((widget.xref, 'checkbox'))
                            elif widget.field_type in (fitz.PDF_WIDGET_TYPE_COMBOBOX, fitz.PDF_WIDGET_TYPE_LISTBOX):
                                if not (widget.field_value or ''):
                                    continue
                                # A choice field carries both a value and a
                                # selected index; leaving the index behind would
                                # re-select the old option in some readers.
                                doc.xref_set_key(widget.xref, 'V', 'null')
                                doc.xref_set_key(widget.xref, 'I', 'null')
                                pending.append((widget.xref, 'choice'))
                            elif widget.field_type == fitz.PDF_WIDGET_TYPE_TEXT:
                                if not (widget.field_value or ''):
                                    continue
                                doc.xref_set_key(widget.xref, 'V', 'null')
                                pending.append((widget.xref, 'text'))
                        if not pending:
                            continue
                        kinds = dict(pending)
                        # Re-read the widgets: the objects held above are stale
                        # after the field dictionaries were edited.
                        for widget in (p.widgets() or []):
                            if widget.xref not in kinds:
                                continue
                            if kinds[widget.xref] == 'checkbox':
                                widget.field_value = 'Off'
                            widget.update()
                            cleared += 1
                    if not cleared:
                        raise PDFError('There is nothing filled in to clear.')
                elif action == 'prepare_form':
                    # Works on whatever pages the scan found, so it is not tied
                    # to the page that happens to be on screen.
                    fields = payload.get('fields')
                    if not isinstance(fields, list) or not fields:
                        raise PDFError("Choose at least one place to put a field.")
                    if len(fields) > form_prep.MAX_FIELDS:
                        raise PDFError(f"A run is limited to {form_prep.MAX_FIELDS} fields.")
                    created = form_prep.apply(doc, fields, self._create_field,
                                               date_format=DEFAULT_DATE_FORMAT)
                    if not created:
                        raise PDFError("None of those places could take a field.")
                elif action == 'add_fields':
                    # A whole form in one step, which is what a prompt produces.
                    # Adding them one at a time would leave twenty undo steps
                    # behind and twenty chances to stop half way.
                    specs = payload.get('fields')
                    if not isinstance(specs, list) or not specs or len(specs) > ai.MAX_FIELDS:
                        raise PDFError(f"Describe between 1 and {ai.MAX_FIELDS} fields.")
                    if payload.get('newPage', True):
                        if len(doc) >= MAX_PAGES:
                            raise PDFError(f"The document cannot exceed {MAX_PAGES} pages.")
                        target = doc.new_page(-1, width=595, height=842)
                    else:
                        target = page_at(doc, payload.get('page'))
                    try:
                        rects = ai.layout_fields(specs, target.rect.width, target.rect.height)
                    except ai.AIError as exc:
                        raise PDFError(exc.message, exc.status, exc.code) from exc
                    existing = {w.field_name for p in doc for w in p.widgets() or []}
                    for spec, rect in zip(specs, rects):
                        if not isinstance(spec, dict):
                            raise PDFError("Each field needs a name and a type.")
                        label = re.sub(r'\s+', ' ', str(spec.get('label') or spec.get('name') or '')).strip()[:80]
                        if not label:
                            raise PDFError("Each field needs a name.")
                        kind = spec.get('kind')
                        if kind not in Engine.FIELD_TYPES:
                            kind = 'text'
                        choices = [str(c)[:150] for c in (spec.get('choices') or []) if str(c).strip()][:100]
                        if kind == 'dropdown' and not choices:
                            kind = 'text'
                        date_format = spec.get('dateFormat')
                        if date_format not in DATE_FORMATS:
                            date_format = DEFAULT_DATE_FORMAT
                        name = self._unique_field_name(ai.field_name(label), existing)
                        self._create_field(doc, target, fitz.Rect(rect), name, kind, label=label,
                                           date_format=date_format, choices=choices)
                        existing.add(name)
                else:
                    page = page_at(doc, payload.get('page'))
                    if action in ('add_text', 'replace_text'):
                        rect = display_rect(page, payload.get('rect'))
                        text = payload.get('text', '')
                        if not isinstance(text, str) or len(text) > 5000:
                            raise PDFError("Text must be under 5,000 characters.")
                        # Deleting text is a real edit: an empty replacement removes
                        # the selection. Only brand-new text must be non-empty.
                        if action == 'add_text' and not text.strip():
                            raise PDFError("Enter some text first.")
                        size = number(payload.get('size', 12), 6, 96, 'Font size')
                        text_color = payload.get('color', '#292b3d')
                        color(text_color)
                        family = payload.get('family', 'sans-serif')
                        if family not in ('sans-serif', 'serif', 'monospace'):
                            raise PDFError("Choose a supported font family.")
                        rotation = payload.get('rotation', page.rotation)
                        if rotation not in (0, 90, 180, 270):
                            raise PDFError("Only horizontal and vertical text can be replaced.")
                        # Arabic/Hebrew text is laid out right to left and must be
                        # embedded with a font that actually carries the glyphs.
                        rtl_text = rtl.is_rtl(text)
                        if rtl_text and not rtl.choose_font()['path']:
                            raise PDFError("No Arabic-capable font was found on this computer, so "
                                           "right-to-left text cannot be added. Install one (for "
                                           "example Noto Sans Arabic) and try again.", 409,
                                           'rtl_font_missing')
                        if action == 'replace_text':
                            # Two kinds of scan reach this point. One has been
                            # through OCR: Tesseract's invisible GlyphLessFont text
                            # sits over the raster. The other is a picture and
                            # nothing else, where somebody has dragged a box over
                            # the ink to replace it. Both need the same treatment,
                            # because in both the old words are pixels rather than
                            # text: they have to be painted over as well as
                            # removed, or the replacement lands on top of the
                            # original and neither can be read.
                            scanned = not page.get_text('text').strip()
                            if not scanned:
                                for block in page.get_text('dict', flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)['blocks']:
                                    for line in block.get('lines', []):
                                        for span in line['spans']:
                                            if 'glyphless' in span['font'].lower() and fitz.Rect(span['bbox']).intersects(rect):
                                                scanned = True
                            # Measured before the original text disappears, so a
                            # longer replacement keeps its size instead of shrinking.
                            # RTL text grows leftwards into its free space.
                            if payload.get('expand', True):
                                room = free_left_limit(page, rect) if rtl_text else free_right_limit(page, rect)
                            else:
                                room = rect.x0 if rtl_text else rect.x1
                            page.add_redact_annot(rect, fill=scan_background(page, rect) if scanned else None, cross_out=False)
                            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS if scanned else 0,
                                                  graphics=0, text=fitz.PDF_REDACT_TEXT_REMOVE)
                            if text.strip():
                                # A glyph-height selection is smaller than a text layout box.
                                # A small vertical expansion lets one-line replacements fit.
                                if rotation in (0, 180):
                                    rect.y0 = max(0, rect.y0 - 1)
                                    rect.y1 = min(page.mediabox.height, rect.y1 + size * .45)
                                    rect = grow_to_fit(rect, text, size, family, room, leftward=rtl_text)
                                else:
                                    rect.x1 = min(page.mediabox.width, rect.x1 + size * .45)
                        if text.strip():
                            markup, css, archive = text_layout(text, size, family, text_color, rtl_text)
                            spare, scale = page.insert_htmlbox(rect, markup, css=css, archive=archive,
                                                              rotate=rotation, scale_low=.55)
                            if spare < 0:
                                raise PDFError("This text does not fit. Enlarge the area or reduce the font size.")
                    elif action == 'highlight':
                        rect = display_rect(page, payload.get('rect'))
                        annot = page.add_highlight_annot(rect)
                        annot.set_colors(stroke=color(payload.get('color', '#f5ce58')))
                        annot.set_opacity(.5)
                        annot.update()
                    elif action == 'comment':
                        text = payload.get('text', '')
                        if not isinstance(text, str) or not text.strip() or len(text) > 3000:
                            raise PDFError("Write a comment of 1 to 3,000 characters.")
                        x = number(payload.get('x'), 0, page.rect.width, 'Horizontal position')
                        y = number(payload.get('y'), 0, page.rect.height, 'Vertical position')
                        point = fitz.Point(x, y) * page.derotation_matrix
                        annot = page.add_text_annot(point, text, icon='Comment')
                        annot.set_info(title='Me', subject='KADOMA comment')
                        annot.set_colors(stroke=color('#7162da'))
                        annot.update()
                    elif action == 'delete_annotation':
                        xref = payload.get('xref')
                        annotation = next((a for a in page.annots() or [] if a.xref == xref), None)
                        if not annotation:
                            raise PDFError("This annotation no longer exists.")
                        page.delete_annot(annotation)
                    elif action == 'redact':
                        rect = display_rect(page, payload.get('rect'))
                        # Also remove overlapping field values and annotations; a black
                        # rectangle over a widget is NOT an effective redaction.
                        for widget in list(page.widgets() or []):
                            if widget.rect.intersects(rect):
                                page.delete_widget(widget)
                        for annot in list(page.annots() or []):
                            if annot.rect.intersects(rect):
                                page.delete_annot(annot)
                        page.add_redact_annot(rect, fill=color(payload.get('color', '#111111')), cross_out=False)
                        page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS,
                                              graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
                                              text=fitz.PDF_REDACT_TEXT_REMOVE)
                        # Strip hidden attachments, JavaScript, metadata and thumbnails
                        # which may otherwise preserve confidential source information.
                        doc.scrub(attached_files=True, embedded_files=True, javascript=True,
                                  metadata=True, thumbnails=True, xml_metadata=True,
                                  clean_pages=False, hidden_text=False, redactions=False,
                                  remove_links=False, reset_fields=False, reset_responses=False)
                        irreversible = True
                    elif action == 'add_field':
                        rect = display_rect(page, payload.get('rect'))
                        raw = payload.get('name')
                        name = raw.strip() if isinstance(raw, str) else ''
                        if not name or len(name) > 80 or any(ord(x) < 32 for x in name):
                            raise PDFError("Enter a field name of 1 to 80 characters.")
                        if name in {w.field_name for p in doc for w in p.widgets() or []}:
                            raise PDFError("A field with that name already exists. Choose a unique name.")
                        kind = payload.get('type', 'text')
                        if kind not in Engine.FIELD_TYPES:
                            raise PDFError("Choose text, date, checkbox, or dropdown.")
                        date_format, choices = None, None
                        if kind == 'date':
                            date_format = payload.get('dateFormat') or DEFAULT_DATE_FORMAT
                            if date_format not in DATE_FORMATS:
                                raise PDFError("Choose a supported date format.")
                        elif kind == 'dropdown':
                            choices = payload.get('choices', [])
                            if not isinstance(choices, list) or not choices or len(choices) > 100 or any(not isinstance(x, str) or len(x) > 150 for x in choices):
                                raise PDFError("Enter between 1 and 100 dropdown options.")
                        self._create_field(doc, page, rect, name, kind,
                                           date_format=date_format, choices=choices)
                    elif action == 'delete_image':
                        xref = payload.get('xref')
                        if not isinstance(xref, int) or xref not in [i[0] for i in page.get_images()]:
                            raise PDFError("This image cannot be deleted independently.")
                        page.delete_image(xref)
                    else:
                        raise PDFError("This action is not supported.")
                if action in ('add_field', 'add_fields', 'prepare_form'):
                    # A field nobody else can type into is not a field. This is
                    # what gives the document the resources and the page links a
                    # strict reader insists on; it is idempotent, so running it
                    # after every creation path costs nothing and misses none.
                    form_prep.ensure_acroform(doc)
                self.commit(state, doc, irreversible=irreversible)
            return self.meta(ident)

    def insert_image(self, ident: str, page_index: int, data: bytes, rect: list | None, xref: int | None = None) -> dict:
        stream = image_bytes(data)
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                self.permission(state, doc, fitz.PDF_PERM_MODIFY)
                page = page_at(doc, page_index)
                if xref is not None:
                    if xref <= 0 or xref not in [i[0] for i in page.get_images()]:
                        raise PDFError("This image cannot be replaced independently.")
                    page.replace_image(xref, stream=stream)
                else:
                    r = display_rect(page, rect)
                    page.insert_image(r, stream=stream, keep_proportion=True, rotate=page.rotation)
                self.commit(state, doc)
            return self.meta(ident)

    def inspect_files(self, files: list[tuple[bytes, str]], passwords: list[str] | None = None) -> list[dict]:
        """Describe uploads without adding them to any document.

        This is what lets the merge list show what each file actually contains
        before anything is combined. A PDF's page count is readable even when
        the file is encrypted, so a locked document can still be listed with its
        real size while the password is being asked for.
        """
        self._check_batch(files)
        result = []
        for n, (data, name) in enumerate(files):
            entry = {'name': safe_name(name), 'pages': 0, 'size': len(data),
                     'kind': Path(safe_name(name)).suffix.lower().lstrip('.') or 'file',
                     'encrypted': False, 'locked': False, 'owner': True, 'readable': True, 'error': ''}
            password = passwords[n] if passwords and n < len(passwords) else ''
            try:
                # Held under the engine lock like every other read: opening a
                # stream is MuPDF work, and this module serialises all of it.
                with self.lock, fitz.open(stream=convert_input(data, name), filetype='pdf') as doc:
                    entry['pages'] = len(doc)
                    entry['encrypted'] = bool(doc.is_encrypted or (doc.metadata or {}).get('encryption'))
                    if entry['encrypted']:
                        auth = doc.authenticate(password)
                        entry['locked'] = not auth
                        entry['owner'] = bool(auth & 4)
            except PDFError as exc:
                entry.update(readable=False, error=exc.message)
            except Exception:
                entry.update(readable=False, error=f"Could not read {safe_name(name)}.")
            result.append(entry)
        return result

    FIELD_TYPES = {'text': fitz.PDF_WIDGET_TYPE_TEXT, 'checkbox': fitz.PDF_WIDGET_TYPE_CHECKBOX,
                   'dropdown': fitz.PDF_WIDGET_TYPE_COMBOBOX, 'date': fitz.PDF_WIDGET_TYPE_TEXT}

    @staticmethod
    def _unique_field_name(name: str, existing: set[str]) -> str:
        """A name no field in the document is using.

        Two fields asked for in one prompt can reduce to the same name — "Date"
        and "date", or two labels that differ only in punctuation — and a PDF
        with two fields sharing a name has one value between them.
        """
        if name not in existing:
            return name
        stem, suffix = name, 2
        while f'{stem}_{suffix}' in existing:
            suffix += 1
        return f'{stem}_{suffix}'

    @staticmethod
    def _create_field(doc: fitz.Document, page: fitz.Page, rect: fitz.Rect, name: str, kind: str, *,
                      label: str | None = None, date_format: str | None = None,
                      choices: list | None = None) -> str:
        """Create one real PDF form field and return its name.

        Shared by the single-field action and the bulk one, so both paths cannot
        drift apart in fonts, colours or the private keys a date field carries.
        """
        widget = fitz.Widget()
        widget.rect, widget.field_name = rect, name
        widget.field_label = label or name
        widget.field_type = Engine.FIELD_TYPES[kind]
        widget.text_font, widget.text_fontsize = 'Helv', 11
        widget.text_color = color('#292b3d')
        widget.border_color, widget.fill_color, widget.border_width = color('#b9b5ce'), (1, 1, 1), 1
        if kind == 'dropdown':
            widget.choice_values = list(choices or [])
            widget.field_value = widget.choice_values[0]
        elif kind == 'checkbox':
            widget.field_value = 'Off'
        else:
            widget.field_value = ''
        page.add_widget(widget)
        if kind == 'date':
            # Mark the field so it is still a date field after the document is
            # saved and reopened. The xref is only valid once the widget has been
            # written and read back.
            fresh = next((w for w in (page.widgets() or []) if w.field_name == name), None)
            if fresh is None:
                raise PDFError("The date field could not be created.")
            doc.xref_set_key(fresh.xref, DATE_KIND_KEY, f'({DATE_KIND})')
            doc.xref_set_key(fresh.xref, DATE_FORMAT_KEY, f'({date_format or DEFAULT_DATE_FORMAT})')
        return name

    @staticmethod
    def _check_batch(files: list[tuple[bytes, str]]):
        if not files:
            raise PDFError("Choose one or more files to combine.")
        if sum(len(data) for data, _ in files) > MAX_UPLOAD:
            raise PDFError(f"The combined size of the chosen files must be under {MAX_UPLOAD // (1024 * 1024)} MB.", 413, 'file_too_large')

    def _add_sources(self, doc: fitz.Document, files: list[tuple[bytes, str]], passwords: list[str] | None,
                     ranges: list | None, start_at: int | None = None) -> int:
        """Copy the chosen pages of every source into `doc`, in the order given.

        Returns how many pages were added. Shared by merging into an open
        document and by building a new one, so the two cannot drift apart: a
        page range, a password or a permission is handled identically either way.
        """
        cursor = len(doc) if start_at is None else max(0, min(int(start_at), len(doc)))
        added = 0
        for n, (data, name) in enumerate(files):
            label = safe_name(name)
            try:
                source = fitz.open(stream=convert_input(data, name), filetype='pdf')
            except PDFError:
                raise
            except Exception as exc:
                raise PDFError(f"Could not read {label}.") from exc
            with source:
                password = passwords[n] if passwords and n < len(passwords) else ''
                encrypted = bool(source.is_encrypted or (source.metadata or {}).get('encryption'))
                auth = source.authenticate(password) if encrypted else 4
                if encrypted and not auth:
                    raise PDFError(f"{label} needs a password. Enter it and combine again.",
                                   401, 'merge_password_required')
                # A document can permit reading while forbidding page assembly.
                # Copying its pages out anyway would ignore the owner's choice.
                if not (auth & 4) and not source.permissions & fitz.PDF_PERM_ASSEMBLE:
                    raise PDFError(f"{label} does not permit page assembly.", 403, 'permission_denied')
                pages = parse_pages(ranges[n] if ranges and n < len(ranges) else '', len(source), label)
                if len(doc) + len(pages) > MAX_PAGES:
                    raise PDFError(f"The combined document would exceed {MAX_PAGES} pages.")
                for first, last in consecutive_runs(pages):
                    doc.insert_pdf(source, from_page=first, to_page=last, start_at=cursor,
                                   widgets=True, links=True, annots=True)
                    cursor += last - first + 1
                    added += last - first + 1
        if not added:
            raise PDFError("None of the chosen files contributed a page.")
        return added

    def merge(self, ident: str, files: list[tuple[bytes, str]], passwords: list[str] | None = None,
              position: int | None = None, ranges: list | None = None) -> dict:
        """Add pages from other files into the open document.

        `position` is the page the new pages land in front of; leaving it out
        appends, which is what the older append-only behaviour did.
        """
        self._check_batch(files)
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                self.permission(state, doc, fitz.PDF_PERM_ASSEMBLE)
                self._add_sources(doc, files, passwords, ranges, position)
                self.commit(state, doc)
            return self.meta(ident)

    def combine(self, files: list[tuple[bytes, str]], passwords: list[str] | None = None,
                name: str = 'Combined.pdf', ranges: list | None = None) -> dict:
        """Build a brand-new document out of several files, in the order given.

        Nothing is appended to whatever happens to be open, which is the
        difference between combining files and merging them into the current
        document. The result is an ordinary working document from then on.
        """
        self._check_batch(files)
        with fitz.open() as doc:
            self._add_sources(doc, files, passwords, ranges)
            if len(doc) > MAX_PAGES:
                raise PDFError(f"Documents must contain at most {MAX_PAGES} pages.")
            data = doc.tobytes(garbage=4, deflate=True)
        stem = Path(safe_name(name)).stem or 'Combined'
        return self.load(data, f"{stem}.pdf")

    def open_documents(self) -> list[dict]:
        """Describe every document currently open in the workspace.

        These are what the merge window offers beside files chosen from disk, so
        a document somebody already has open does not have to be found on disk
        and handed to the app a second time. The page counts come from the same
        cached metadata the header uses, and a document that cannot be read is
        reported rather than quietly left out.
        """
        with self.lock:
            # Snapshot the ids first. get() and meta() move an entry to the end
            # of the ordered map, and mutating it mid-iteration would raise.
            result = []
            for ident in list(self.documents):
                state = self.documents.get(ident)
                if state is None:
                    continue
                try:
                    info = self.meta(ident)
                except PDFError as exc:
                    result.append({'id': ident, 'name': state.name, 'readable': False,
                                   'error': exc.message, 'pageCount': 0, 'size': len(state.data),
                                   'encrypted': bool(state.password), 'owner': state.owner,
                                   'canAssemble': False, 'modified': state.modified})
                    continue
                result.append({'id': ident, 'name': state.name, 'readable': True, 'error': '',
                               'pageCount': info['pageCount'], 'size': info['size'],
                               'encrypted': info['encrypted'], 'owner': info['owner'],
                               'canAssemble': info['canAssemble'], 'modified': info['modified']})
            return result

    def source_of(self, ident: str) -> tuple[bytes, str, str]:
        """The bytes, name and stored password of a document already open.

        This is how a document that is open becomes a merge source without being
        re-read from disk. It is handed over in exactly the shape an upload is,
        and then goes through the same reading, password and permission checks as
        any other source, so an open document cannot bypass a rule a file would
        have to satisfy. The password is the one already used to open it, so a
        protected document that is open is not unlocked a second time.
        """
        with self.lock:
            state = self.get(ident)
            return state.data, state.name, state.password

    def _split_plan(self, state: DocumentState, doc: fitz.Document, options: dict):
        """Validate a split and describe what it would produce.

        Returns the page groups (for writing the files) and the public plan (for
        the interface). Both come from one pass so the preview shown before the
        button is pressed is exactly what gets written afterwards.
        """
        self.permission(state, doc, fitz.PDF_PERM_ASSEMBLE)
        if doc.metadata.get('encryption'):
            # Re-encrypting every part would need both passwords again, and
            # quietly dropping the protection off a copy would be worse than
            # saying no. The message points at the way that does work.
            raise PDFError("Splitting a protected PDF is disabled. Unlock an authorized copy first, "
                           "then split that.", 403, 'permission_denied')
        count = len(doc)
        groups = split_groups(count, options or {})
        base = Path(state.name).stem or 'Document'
        parts = []
        present: set[int] = set()
        for number, group in enumerate(groups, start=1):
            present.update(group)
            parts.append({'index': number, 'name': split_part_name(base, number, group),
                          'first': group[0] + 1, 'last': group[-1] + 1, 'pages': len(group),
                          'indices': group})
        omitted = omitted_ranges(present, count)
        plan = {
            'mode': (options or {}).get('mode', 'chunks'),
            'base': base, 'pageCount': count, 'fileCount': len(parts),
            'pageTotal': sum(part['pages'] for part in parts),
            'archive': len(parts) > 1,
            'omitted': [index + 1 for run in omitted for index in range(run[0], run[1] + 1)],
            'omittedLabel': page_span_label(omitted),
            'parts': [{key: value for key, value in part.items() if key != 'indices'} for part in parts],
        }
        return groups, plan

    def split_plan(self, ident: str, options: dict | None = None) -> dict:
        """Describe the files a split would produce, without writing them.

        The split window asks this while the settings are being typed, so the
        file count and the names on screen are the engine's own answer rather
        than a second implementation in the interface that could disagree.
        """
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                return self._split_plan(state, doc, options or {})[1]

    def split(self, ident: str, options: dict | None = None) -> tuple[bytes, str, str]:
        """Write the open document out as several files.

        One part comes back as a plain PDF and more than one as a ZIP, because
        an archive holding a single file is just a worse PDF. Nothing is changed
        in the working document: splitting only reads.
        """
        options = options or {}
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                groups, plan = self._split_plan(state, doc, options)
                base = plan['base']
                if len(groups) == 1:
                    with fitz.open() as one:
                        for first, last in consecutive_runs(groups[0]):
                            one.insert_pdf(doc, from_page=first, to_page=last,
                                           widgets=True, links=True, annots=True)
                        data = one.tobytes(garbage=4, deflate=True)
                    name = plan['parts'][0]['name']
                    if len(data) > MAX_EXPORT_BYTES:
                        raise PDFError("This split exceeds 240 MB. Choose smaller parts.", 413)
                    return data, name, 'application/pdf'
                out = io.BytesIO()
                with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
                    for number, group in enumerate(groups, start=1):
                        with fitz.open() as one:
                            for first, last in consecutive_runs(group):
                                one.insert_pdf(doc, from_page=first, to_page=last,
                                               widgets=True, links=True, annots=True)
                            archive.writestr(split_part_name(base, number, group),
                                             one.tobytes(garbage=4, deflate=True))
                        if out.tell() > MAX_EXPORT_BYTES:
                            raise PDFError("This split exceeds 240 MB. Choose fewer or smaller parts.", 413)
                return out.getvalue(), f'{base}-split.zip', 'application/zip'

    def ocr(self, ident: str, selected: list[int] | None, language='eng') -> dict:
        exe = find_tesseract()
        if not exe:
            raise PDFError("OCR requires the local Tesseract engine. Install Tesseract and its language packs, then restart KADOMA.", 409, 'tesseract_missing')
        if not isinstance(language, str) or not re.fullmatch(r'[A-Za-z0-9_]+(?:\+[A-Za-z0-9_]+)*', language):
            raise PDFError("Choose valid OCR language codes, such as eng or eng+ara.")
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = exe
        with self.lock:
            state = self.get(ident)
            with self.opened(state) as doc:
                self.permission(state, doc, fitz.PDF_PERM_MODIFY)
                selection = indices(selected, len(doc))
                if len(selection) > 20:
                    raise PDFError("OCR is limited to 20 pages per run. Select a smaller range.")
                replacements = {}
                for index in selection:
                    page = doc[index]
                    if page.rect.get_area() * (200 / 72) ** 2 > 40_000_000:
                        raise PDFError("This page is too large for OCR.")
                    pixmap = page.get_pixmap(dpi=200, alpha=False, annots=True)
                    image = Image.frombytes('RGB', (pixmap.width, pixmap.height), pixmap.samples)
                    try:
                        replacements[index] = pytesseract.image_to_pdf_or_hocr(image, extension='pdf', lang=language, timeout=120)
                    except Exception as exc:
                        raise PDFError("OCR failed. Check that the selected language packs are installed and try fewer pages.") from exc
                for index in sorted(selection, reverse=True):
                    page = doc[index]
                    width, height = page.rect.width, page.rect.height
                    with fitz.open(stream=replacements[index], filetype='pdf') as result:
                        # A searchable raster copy intentionally flattens annotations
                        # and forms on only the selected pages.
                        new_page = doc.new_page(pno=index, width=width, height=height)
                        new_page.show_pdf_page(new_page.rect, result, 0)
                    doc.delete_page(index + 1)
                self.commit(state, doc)
            return self.meta(ident)

    def export(self, ident: str, format: str, options: dict | None = None) -> tuple[bytes, str, str]:
        options = options or {}
        with self.lock:
            state = self.get(ident)
            base = Path(state.name).stem
            with self.opened(state) as doc:
                selected = indices(options.get('pages'), len(doc))
                if format not in ('pdf', 'protected', 'split'):
                    self.permission(state, doc, fitz.PDF_PERM_COPY)
                if selected != list(range(len(doc))):
                    self.permission(state, doc, fitz.PDF_PERM_ASSEMBLE)
                if format == 'pdf':
                    subset = selected != list(range(len(doc)))
                    if subset:
                        doc.select(selected)
                    # One page out of many is a copy of that page, so the file is
                    # named after the page rather than after the whole document.
                    name = f'{base}-page-{selected[0] + 1:03}.pdf' if subset and len(selected) == 1 \
                        else base + '.pdf'
                    result = (doc.tobytes(garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_KEEP), name, 'application/pdf')
                elif format == 'protected':
                    if not state.owner:
                        raise PDFError("Use the owner password before changing document protection.", 403)
                    user, owner = options.get('openPassword', ''), options.get('ownerPassword', '')
                    if not isinstance(user, str) or not isinstance(owner, str) or len(user) < 6 or len(owner) < 8:
                        raise PDFError("Use an opening password of at least 6 characters and an owner password of at least 8.")
                    if user == owner or max(len(user.encode('utf-8')), len(owner.encode('utf-8'))) > 120:
                        raise PDFError("Use two different passwords, each shorter than 120 UTF-8 bytes.")
                    for option in ('allowPrinting', 'allowCopying', 'allowEditing'):
                        if option in options and not isinstance(options[option], bool):
                            raise PDFError('Permission settings must be true or false.')
                    permissions = fitz.PDF_PERM_ACCESSIBILITY
                    if options.get('allowPrinting', True):
                        permissions |= fitz.PDF_PERM_PRINT | fitz.PDF_PERM_PRINT_HQ
                    if options.get('allowCopying', False):
                        permissions |= fitz.PDF_PERM_COPY
                    if options.get('allowEditing', False):
                        permissions |= fitz.PDF_PERM_MODIFY | fitz.PDF_PERM_ANNOTATE | fitz.PDF_PERM_FORM | fitz.PDF_PERM_ASSEMBLE
                    if selected != list(range(len(doc))):
                        doc.select(selected)
                    result = (doc.tobytes(garbage=4, deflate=True, encryption=fitz.PDF_ENCRYPT_AES_256,
                                          owner_pw=owner, user_pw=user, permissions=permissions),
                              base + '-protected.pdf', 'application/pdf')
                elif format == 'txt':
                    text = '\n\n'.join(f'--- Page {i + 1} ---\n' + doc[i].get_text(sort=True, flags=fitz.TEXTFLAGS_TEXT & ~fitz.TEXT_PRESERVE_LIGATURES) for i in selected)
                    result = (text.encode('utf-8'), base + '.txt', 'text/plain; charset=utf-8')
                elif format == 'docx':
                    result = (export_word(doc, selected), base + '.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                elif format == 'xlsx':
                    strategy = options.get('tableStrategy', 'lines')
                    if strategy not in ('lines', 'text'):
                        raise PDFError("Choose ruled tables or borderless tables.")
                    result = (export_excel(doc, selected, strategy), base + '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                elif format == 'pptx':
                    result = (export_powerpoint(doc, selected), base + '.pptx', 'application/vnd.openxmlformats-officedocument.presentationml.presentation')
                elif format in ('images', 'split'):
                    image_format = options.get('imageFormat', 'png')
                    if image_format not in ('png', 'jpg'):
                        raise PDFError("Choose PNG or JPG.")
                    dpi = int(number(options.get('dpi', 150), 72, 300, 'Image resolution'))
                    if len(selected) > 80:
                        raise PDFError("Image/split exports are limited to 80 pages per run.")
                    out = io.BytesIO()
                    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
                        for index in selected:
                            if format == 'images':
                                p = doc[index]
                                if p.rect.width * p.rect.height * (dpi / 72) ** 2 > 20_000_000:
                                    raise PDFError("This page is too large at the chosen image resolution. Lower the DPI.")
                                pixmap = p.get_pixmap(dpi=dpi, alpha=False)
                                data = pixmap.tobytes('jpeg' if image_format == 'jpg' else 'png')
                                name = f'{base}-page-{index + 1:03}.{image_format}'
                            else:
                                self.permission(state, doc, fitz.PDF_PERM_ASSEMBLE)
                                with fitz.open() as one:
                                    one.insert_pdf(doc, from_page=index, to_page=index)
                                    # Preserve encryption rather than silently remove it.
                                    if doc.metadata.get('encryption'):
                                        raise PDFError("Split export of protected PDFs is disabled. Unlock an authorized copy first.", 403)
                                    data = one.tobytes(garbage=4, deflate=True)
                                name = f'{base}-page-{index + 1:03}.pdf'
                            archive.writestr(name, data)
                            if out.tell() > MAX_EXPORT_BYTES:
                                raise PDFError("This export exceeds 240 MB. Export fewer pages.", 413)
                    result = (out.getvalue(), base + ('-images.zip' if format == 'images' else '-pages.zip'), 'application/zip')
                else:
                    raise PDFError("Unsupported export format.")
            if len(result[0]) > MAX_EXPORT_BYTES:
                raise PDFError("This export exceeds 240 MB. Export fewer pages.", 413)
            return result

    def save(self, ident: str, target: str | None = None) -> dict:
        """Write the document to a PDF file on disk.

        With no `target` it overwrites the file the document was opened from —
        and only after checking that the file still looks the way it did when it
        was read, so an edit made in another program is never silently replaced.
        With a `target` it writes there and the document follows that path, so
        the next save goes to the same place.

        The bytes are written to a temporary file beside the destination and
        then moved into position in one step. A half-written PDF can therefore
        never replace a good one: either the whole file lands or nothing does.
        """
        with self.lock:
            state = self.get(ident)
            destination = target if target is not None else state.path
            if not destination:
                raise PDFError("This document has no file on disk yet. Choose where to save it.",
                               409, 'no_save_path')
            if not isinstance(destination, str) or not destination.strip():
                raise PDFError("Choose a file name to save to.", 422, 'invalid_path')
            path = Path(destination.strip()).expanduser()
            if not path.is_absolute():
                raise PDFError("Saving needs the full path to a file.", 422, 'invalid_path')
            if not path.suffix:
                path = path.with_suffix('.pdf')
            elif path.suffix.lower() != '.pdf':
                raise PDFError("KADOMA saves PDFs. Choose a name ending in .pdf.", 422, 'invalid_path')
            if not path.parent.is_dir():
                raise PDFError("That folder does not exist.", 404, 'folder_missing')
            in_place = bool(state.path) and same_file(state.path, path)
            if in_place and state.stamp and file_stamp(state.path) != state.stamp:
                raise PDFError("This file has changed on disk since it was opened. "
                               "Use Save as, so those changes are not overwritten.",
                               409, 'file_changed')
            data, _name, _mime = self.export(ident, 'pdf')
            temporary = path.parent / f'.{path.stem}.{uuid.uuid4().hex[:8]}.tmp'
            try:
                with open(temporary, 'wb') as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
                if path.exists():
                    # Keep the destination's permissions; os.replace would
                    # otherwise give it the temporary file's default mode.
                    try:
                        shutil.copymode(path, temporary)
                    except OSError:
                        pass
                os.replace(temporary, path)
            except OSError as exc:
                try:
                    temporary.unlink()
                except OSError:
                    pass
                raise PDFError("The file could not be written. It may be open in another program, "
                               "or the folder may be read-only.", 409, 'save_failed') from exc
            state.path = str(path)
            state.stamp = file_stamp(path)
            state.saved_revision = state.revision
            state.name = path.name
            state.meta_cache = None
            return {'saved': True, 'path': str(path), 'name': path.name,
                    'document': self.meta(ident)}


def cell_value(value: Any):
    """Avoid spreadsheet formula injection; parse only simple numeric amounts."""
    if value is None:
        return ''
    text = str(value).strip()
    stripped = re.sub(r'[$€£\s]', '', text)
    plain = stripped.rstrip('%').lstrip('+-')
    # Only unambiguous English-style comma groups are normalized. Locale
    # comma decimals remain text for review instead of being multiplied by 100.
    ambiguous_commas = ',' in stripped and not re.fullmatch(r'[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?%?', stripped)
    identifier = re.fullmatch(r'\d+', plain) and ((len(plain) > 1 and plain.startswith('0')) or len(plain) > 15)
    if ambiguous_commas or (identifier and not stripped.endswith('%')):
        return "'" + text if text.startswith(('=', '+', '-', '@')) else text
    cleaned = stripped.replace(',', '')
    if re.fullmatch(r'[+-]?\d+(?:\.\d+)?%?', cleaned):
        val = float(cleaned.rstrip('%'))
        return val / 100 if cleaned.endswith('%') else val
    return "'" + text if text.startswith(('=', '+', '-', '@')) else text


def export_excel(doc: fitz.Document, selected: list[int], strategy='lines') -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook()
    wb.remove(wb.active)
    any_tables = False
    notes = []
    for index in selected:
        tables = doc[index].find_tables(strategy=strategy).tables
        if tables:
            any_tables = True
            for n, table in enumerate(tables):
                sheet = wb.create_sheet(f'Page {index + 1} Table {n + 1}')
                rows = table.extract()
                for row in rows:
                    sheet.append([cell_value(x) for x in row])
                for cell in sheet[1]:
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.fill = PatternFill('solid', fgColor='7162DA')
                    cell.alignment = Alignment(vertical='center')
                sheet.freeze_panes = 'A2'
                sheet.auto_filter.ref = sheet.dimensions
                sheet.row_dimensions[1].height = 26
                for col in sheet.columns:
                    letter = col[0].column_letter
                    sheet.column_dimensions[letter].width = min(50, max(15, max(len(str(c.value or '')) for c in col) + 3))
        else:
            notes.append(index + 1)
            sheet = wb.create_sheet(f'Page {index + 1} Text')
            sheet.append(['Extracted text — no table detected'])
            sheet['A1'].font = Font(bold=True, color='7162DA')
            sheet.column_dimensions['A'].width = 105
            for line in doc[index].get_text(sort=True, flags=fitz.TEXTFLAGS_TEXT & ~fitz.TEXT_PRESERVE_LIGATURES).splitlines():
                if line.strip():
                    sheet.append([cell_value(line)])
    info = wb.create_sheet('Read me', 0)
    info.append(['KADOMA — PDF to Excel'])
    info.append(['Tables are detected from PDF geometry; verify totals and cell alignment.'])
    info.append(['Simple dot-decimal amounts and grouped comma thousands are parsed; ambiguous locale formats and long/zero-prefixed identifiers stay text.'])
    info.append(['No OCR is performed during export. Run OCR first for scanned PDFs.'])
    info.append(['Detection mode', 'Ruled tables' if strategy == 'lines' else 'Borderless text tables'])
    info.append(['Pages without detected tables', ', '.join(map(str, notes)) or 'None'])
    info.column_dimensions['A'].width = 95
    info.column_dimensions['B'].width = 45
    info['A1'].font = Font(bold=True, size=16, color='7162DA')
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def export_word(doc: fitz.Document, selected: list[int]) -> bytes:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    word = Document()
    word.styles['Normal'].font.name = 'Calibri'
    word.styles['Normal'].font.size = Pt(11)
    word.core_properties.title = doc.metadata.get('title') or 'PDF text export'
    word.core_properties.comments = 'Best-effort editable extraction by KADOMA; not a layout-identical conversion.'
    for n, index in enumerate(selected):
        if n:
            word.add_page_break()
        page = doc[index]
        table_objects = page.find_tables().tables
        table_bounds = [fitz.Rect(t.bbox) for t in table_objects]
        # Blocks follow vertical reading order. Table text is emitted once as cells.
        items = []
        for block in page.get_text('dict', sort=True, flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_LIGATURES)['blocks']:
            rect = fitz.Rect(block['bbox'])
            if block['type'] == 0:
                if any((rect & r).get_area() > rect.get_area() * .65 for r in table_bounds):
                    continue
                text = '\n'.join(''.join(s['text'] for s in line['spans']) for line in block['lines'])
                largest = max((s['size'] for line in block['lines'] for s in line['spans']), default=11)
                items.append((rect.y0, 'text', (text, largest)))
            elif block['type'] == 1:
                items.append((rect.y0, 'image', block))
        for table in table_objects:
            items.append((table.bbox[1], 'table', table.extract()))
        for _, kind, value in sorted(items, key=lambda x: x[0]):
            if kind == 'text':
                text, largest = value
                if not text.strip():
                    continue
                paragraph = word.add_paragraph(text, style='Heading 1' if largest >= 19 else 'Heading 2' if largest >= 14 else None)
                paragraph.paragraph_format.space_after = Pt(6)
            elif kind == 'image':
                try:
                    stream = image_bytes(value['image'])
                    word.add_picture(io.BytesIO(stream), width=Inches(min(6.3, (value['bbox'][2] - value['bbox'][0]) / 72)))
                except Exception:
                    word.add_paragraph('[Image could not be extracted]')
            else:
                if not value:
                    continue
                table = word.add_table(rows=len(value), cols=max(len(r) for r in value))
                table.style = 'Light Shading Accent 1'
                for row, values in zip(table.rows, value):
                    for cell, text in zip(row.cells, values):
                        cell.text = str(text or '')
    out = io.BytesIO()
    word.save(out)
    return out.getvalue()


def export_powerpoint(doc: fitz.Document, selected: list[int]) -> bytes:
    from pptx import Presentation
    from pptx.util import Inches
    presentation = Presentation()
    first = doc[selected[0]]
    presentation.slide_width = Inches(first.rect.width / 72)
    presentation.slide_height = Inches(first.rect.height / 72)
    sw, sh = presentation.slide_width, presentation.slide_height
    for index in selected:
        slide = presentation.slides.add_slide(presentation.slide_layouts[6])
        page = doc[index]
        scale = min(1.7, math.sqrt(15_000_000 / max(1, page.rect.get_area())))
        image = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).tobytes('png')
        ratio = min(sw / page.rect.width, sh / page.rect.height)
        w, h = int(page.rect.width * ratio), int(page.rect.height * ratio)
        slide.shapes.add_picture(io.BytesIO(image), (sw - w) // 2, (sh - h) // 2, width=w, height=h)
        slide.notes_slide.notes_text_frame.text = 'KADOMA visual export: this slide contains a page image, not editable PDF text.'
    out = io.BytesIO()
    presentation.save(out)
    return out.getvalue()


def rtl_word_matches(page: fitz.Page, needle: str) -> list[tuple[fitz.Rect, str]]:
    """Find `needle` among a page's words after normalising shaped text.

    `page.search_for()` cannot do this job. A document written with shaped
    Arabic stores presentation forms (U+FE70-U+FEFF), so searching for the
    logical letters the user typed finds *nothing at all* — verified, not
    assumed. Normalising every word to logical form and matching on that does
    work. MuPDF returns RTL words in logical reading order (the rightmost word
    first), so a straight left-to-right walk over them is correct.
    """
    rows: dict[int, list[tuple[fitz.Rect, str]]] = {}
    for word in page.get_text('words'):
        x0, y0, x1, y1, text = word[0], word[1], word[2], word[3], word[4]
        logical = rtl.logical(text).strip()
        if logical:
            # Words sharing a line share a baseline; bucketing on y0 groups them
            # without assuming any particular line spacing.
            rows.setdefault(round(y0 / 3.0), []).append((fitz.Rect(x0, y0, x1, y1), logical))
    # Tokens and candidates are compared in folded form so digit variants and
    # no-break spaces cannot stop a match that is obviously the same text.
    tokens = [t for t in rtl.search_key(needle).split() if t]
    if not tokens:
        return []
    found = []
    for key in sorted(rows):
        items = [(rect, rtl.search_key(text)) for rect, text in rows[key]]
        for start in range(len(items) - len(tokens) + 1):
            window = items[start:start + len(tokens)]
            if all(t == w or t in w or w in t for t, (_, w) in zip(tokens, window)):
                box = fitz.Rect(window[0][0])
                for rect, _ in window[1:]:
                    box.include_rect(rect)
                found.append((box, ' '.join(rows[key][start + i][1] for i in range(len(tokens)))))
    return found


def capabilities() -> dict:
    exe = find_tesseract()
    languages = []
    if exe:
        try:
            result = subprocess.run([exe, '--list-langs'], capture_output=True, text=True, timeout=5)
            languages = [x.strip() for x in result.stdout.splitlines()[1:] if re.fullmatch(r'[A-Za-z0-9_]+', x.strip())]
        except Exception:
            pass
    chosen = rtl.choose_font()
    # Read from the package rather than typed here: a version written twice is
    # a version that will disagree with itself eventually.
    from . import __version__
    return {'version': __version__, 'offline': True, 'libreoffice': bool(find_soffice()),
            'tesseract': bool(exe), 'ocrLanguages': languages,
            'maxUploadMB': MAX_UPLOAD // (1024 * 1024),
            'maxPages': MAX_PAGES, 'historySteps': MAX_HISTORY_STEPS,
            # How many documents the workspace keeps open at once. Several stay
            # open so one can be combined into another without being read from
            # disk again; the oldest is dropped past this limit.
            'maxDocuments': MAX_DOCUMENTS,
            'signatureType': 'visual', 'officeExport': 'best-effort', 'cloud': False,
            # AI is included, and the offline half of it needs no network at all.
            # Nothing is ever sent anywhere unless somebody connects a model of
            # their own, which is why 'aiCloud' is false rather than absent.
            'ai': True, 'aiOffline': True, 'aiCloud': False, 'aiModel': 'optional',
            'directTextEdit': True, 'editableTextUnit': 'line',
            # Splitting one document into several, and the three ways of deciding
            # where the cuts go.
            'split': True, 'splitModes': list(SPLIT_MODES), 'maxSplitFiles': MAX_SPLIT_FILES,
            'rtlText': bool(chosen['path']), 'rtlFont': chosen['name'],
            # 'exact' means Arabic survives an edit round-trip character for
            # character. 'approximate' means it renders correctly but reading it
            # back can mis-map ligatures, so the interface warns before editing.
            'rtlQuality': chosen['quality'], 'rtlBundledFont': bool(chosen['bundled'])}
