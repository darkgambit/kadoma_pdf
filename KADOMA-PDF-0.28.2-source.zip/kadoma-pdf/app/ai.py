"""Reading a document, and optionally asking a language model about it.

Two very different things live in this module, and the interface is careful never
to let them be confused with each other.

**The offline half is ordinary text analysis.** `summarize()` picks the sentences
that best represent the document by scoring the words they contain, and
`parse_form_prompt()` turns ordinary words into real PDF form fields. Neither is a
language model. Neither invents anything, neither paraphrases, and neither can
answer a question. Both run entirely on this computer and are the default.

**The model half is optional and off by default.** `chat()` talks to an
OpenAI-compatible endpoint that somebody configured themselves, with their own
key. Nothing is sent until a model has been connected and the person has agreed
to it, and then only the document's extracted text — never the file. The key is
held in memory for the session; this application writes no preferences to disk.

Being honest about which of the two produced a result matters more here than
anywhere else in the application: an extractive summary presented as though a
model wrote it would be a lie about what the reader is looking at.
"""
from __future__ import annotations

import json
import math
import re
import socket
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import urlsplit, urlunsplit

# The most text ever handed to a model in one request. A long report would
# otherwise be sent in full, which is slow, expensive and usually unnecessary —
# the beginning of a document carries most of what a summary needs.
MAX_MODEL_CHARS = 24000
MAX_FIELDS = 40
LOOPBACK_HOSTS = frozenset({'127.0.0.1', 'localhost', '::1', '[::1]', '0.0.0.0'})


class AIError(Exception):
    """A message for the person, in the same shape PDFError uses.

    Kept separate so this module stays free of the engine: it can be imported and
    tested on its own, and it never needs to know a PDF exists.
    """

    def __init__(self, message: str, status: int = 422, code: str = 'invalid_request'):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


# --------------------------------------------------------------- offline reading
# A compact English stop-word list. It only sharpens the scoring for English
# documents; other languages still work, because the ranking is by how often a
# word recurs within the document rather than by anything English-specific.
STOPWORDS = frozenset("""
a about above after again against all am an and any are aren't as at be because been before being
below between both but by can cannot could couldn't did didn't do does doesn't doing don't down
during each few for from further had hadn't has hasn't have haven't having he her here hers herself
him himself his how i if in into is isn't it its itself let's me more most mustn't my myself no nor
not of off on once only or other ought our ours ourselves out over own same shan't she should
shouldn't so some such than that the their theirs them themselves then there these they this those
through to too under until up very was wasn't we were weren't what when where which while who whom
why with won't would wouldn't you your yours yourself yourselves
""".split())

# Sentence-ending punctuation across the scripts this application supports:
# Latin, Arabic (؟ ۔) and CJK (。！？).
_SENTENCE_END = re.compile(r'[.!?\u2026\u061f\u06d4\u3002\uff01\uff1f]')
_CANDIDATE = re.compile(r'[^.!?\u2026\u061f\u06d4\u3002\uff01\uff1f]+[.!?\u2026\u061f\u06d4\u3002\uff01\uff1f]*')
_TOKEN = re.compile(r"\w[\w'\u2019-]*", re.UNICODE)
_ABBREVIATIONS = frozenset("""
mr mrs ms dr prof sr jr st no vs etc eg ie fig inc ltd co corp dept est approx vol p pp pt al cf ed
eds sec eq ref ch art min max avg tel fax misc incl excl jan feb mar apr jun jul aug sep sept oct nov dec
""".split())
# "e.g." and "i.e." survive the punctuation strip with their inner point intact.
_ABBREVIATIONS = _ABBREVIATIONS | {'e.g', 'i.e'}
# Points that are not the end of a sentence are swapped out before the split and
# put back afterwards. Repairing them afterwards is not possible: rejoining two
# halves inserts a space, so "2.1" would come back as "2. 1" and "e.g." as "e. g.".
_POINT_MARK = '\x00'


def _protect(text: str) -> str:
    """Hide the points that are not the end of a sentence.

    Two kinds. A point inside a run of letters is part of a word ("e.g.", "U.S.",
    "2.1"), and so is the point that closes such a run. A point followed straight
    by a letter or a digit is the same thing written loosely. Everything else is
    left alone, including a point before a closing quote, which does end a
    sentence.
    """
    text = re.sub(r'\b(?:[A-Za-z]\.){2,}', lambda m: m.group(0).replace('.', _POINT_MARK), text)
    return re.sub(r'\.(?=[A-Za-z0-9])', _POINT_MARK, text)


def _restore(text: str) -> str:
    return text.replace(_POINT_MARK, '.')


def _clip(text: str, limit: int = MAX_MODEL_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(' ', 1)[0] + '\u2026'


def strip_page_markers(text: str) -> str:
    """Drop the '--- Page N ---' lines the text export inserts."""
    return re.sub(r'^\s*-{2,}\s*Page\s+\d+\s*-{2,}\s*$', ' ', text or '', flags=re.MULTILINE)


def sentences(text: str) -> list[str]:
    """Split text into sentences, resisting the usual false stops.

    A splitter that cuts after "No." or inside "3.5" makes the summary read as
    though somebody stuttered, so a candidate cut is merged back when the piece
    before it ends in a known abbreviation or a number, or when the piece after
    it starts with a lower-case letter — which, in a document that uses case at
    all, means the sentence had not finished.
    """
    flat = re.sub(r'[ \t\r\f\v]+', ' ', strip_page_markers(text or '')).strip()
    if not flat:
        return []
    flat = _protect(flat)
    merged: list[str] = []
    for raw in _CANDIDATE.findall(flat):
        piece = raw.strip()
        if not piece:
            continue
        if merged and _continues(merged[-1], piece):
            merged[-1] = f'{merged[-1]} {piece}'
        else:
            merged.append(piece)
    expanded: list[str] = []
    for piece in merged:
        expanded.extend(_split_blocks_at_lines(piece))
    cleaned = [re.sub(r'\s+', ' ', s).strip() for s in _reattach_closers(expanded)]
    return [_restore(s) for s in cleaned if _TOKEN.search(s)]


def _block_key(text: str) -> str:
    """A sentence with everything but its letters removed, for spotting repeats.

    Digits go too, so a running footer that differs only by its page number is
    recognised as the same line.
    """
    return re.sub(r'[^a-z]+', '', (text or '').lower())


def _repeated_blocks(parts: list[str], minimum: int = 20) -> set[str]:
    """Blocks that appear more than once, which in practice means furniture.

    A page header or footer repeats on every page, and because it repeats it
    carries the document's most frequent words — so a term-frequency ranking
    scores it highly and the summary fills up with the running title. Repeats are
    dropped instead. The length floor keeps genuine sentences that differ only in
    an amount from being mistaken for boilerplate.
    """
    counts: Counter[str] = Counter()
    for part in parts:
        key = _block_key(part)
        if len(key) >= minimum:
            counts[key] += 1
    return {key for key, count in counts.items() if count > 1}


def _split_blocks_at_lines(piece: str) -> list[str]:
    """Break a run with no full stops at the line breaks that start something new.

    A designed document — a report, an invoice, a brochure — extracts as one long
    run of headings, labels and figures with almost no sentence punctuation, so a
    whole page becomes a single "sentence" and summarising it means quoting the
    page. The line breaks are the only structure left, but they cannot simply be
    trusted: ordinary prose wraps mid-sentence too.

    The difference is what the next line starts with. A wrapped sentence carries
    on in lower case; a new heading, a new row or a new figure starts with a
    capital or a digit. So a lower-case line is joined back onto the one before
    it and everything else begins a new block.
    """
    if '\n' not in piece:
        return [piece]
    out: list[str] = []
    for line in (part.strip() for part in piece.split('\n')):
        if not line:
            continue
        if out and not (line[0].isupper() or line[0].isdigit()):
            out[-1] = f'{out[-1]} {line}'
        else:
            out.append(line)
    return out


def _reattach_closers(pieces: list[str]) -> list[str]:
    """Move a closing quote or bracket back onto the sentence it closes.

    The split happens at the point, so `He said "hello." Then he left.` cuts
    before the closing quote and leaves it stranded at the start of the next
    sentence. It belongs to the sentence that just ended.
    """
    closers = set('"\'\u201d\u2019)]}')
    out: list[str] = []
    for piece in pieces:
        lead = ''
        rest = piece
        while rest and rest[0] in closers:
            lead += rest[0]
            rest = rest[1:].lstrip()
        if lead and rest and out:
            out[-1] += lead
        if rest:
            out.append(rest)
    return out


def _continues(previous: str, piece: str) -> bool:
    tail = previous.rstrip(''.join(set('.!?\u2026\u061f\u06d4\u3002\uff01\uff1f'))).rsplit(' ', 1)[-1]
    tail = tail.strip('.,;:()[]"\'\u201c\u201d\u2018\u2019').lower()
    if tail in _ABBREVIATIONS:
        return True
    if tail.isdigit():
        return True
    head = piece.lstrip('"\'([\u201c\u2018')[:1]
    return bool(head) and head.islower()


def keywords(text: str, limit: int = 10) -> list[str]:
    """The words the document leans on, ignoring numbers and stop-words."""
    counts: Counter[str] = Counter()
    for token in _TOKEN.findall((text or '').lower()):
        if len(token) > 2 and token not in STOPWORDS and not token.isdigit():
            counts[token] += 1
    return [word for word, count in counts.most_common(limit * 3) if count > 1][:limit]


def summarize(text: str, limit: int = 5) -> dict:
    """Pick the sentences that best represent the document.

    This is extractive: every sentence returned is already in the document,
    quoted as it stands. Sentences are scored by the frequency of the words they
    contain, normalised for length so a long sentence cannot win by being long,
    with a small bonus for appearing early — where a document usually states what
    it is about.
    """
    limit = max(1, min(int(limit or 5), 12))
    parts = sentences(text)
    if not parts:
        raise AIError('There is no text in this document to summarise. '
                      'If it is a scan, run OCR first and try again.', 409, 'no_text')

    tokenised = [[t for t in _TOKEN.findall(part.lower()) if len(t) > 1 and t not in STOPWORDS]
                 for part in parts]
    frequency: Counter[str] = Counter(t for tokens in tokenised for t in tokens)

    # A designed document — a report, a brochure, an invoice — extracts as a pile
    # of headings and labels. Those are not sentences, and a summary made of them
    # tells nobody anything, so short fragments are only used when there is
    # nothing else to choose from.
    boilerplate = _repeated_blocks(parts)
    eligible = [i for i, tokens in enumerate(tokenised)
                if len(tokens) >= 4 and _block_key(parts[i]) not in boilerplate]
    if not eligible:
        eligible = [i for i, tokens in enumerate(tokenised) if len(tokens) >= 4]
    if not eligible:
        eligible = list(range(len(parts)))

    if frequency:
        heaviest = max(frequency.values())
        early = max(1, len(parts) // 5)
        scores = []
        for index, tokens in enumerate(tokenised):
            if not tokens:
                scores.append(0.0)
                continue
            weight = sum(frequency[t] for t in tokens) / (heaviest * math.sqrt(len(tokens)))
            scores.append(weight * (1.25 if index < early else 1.0) * (1.1 if index == 0 else 1.0))
        ranked = sorted(eligible, key=lambda i: (-scores[i], i))
        chosen = sorted(ranked[:limit])
    else:
        # Nothing but numbers and stop-words: fall back to the opening sentences
        # rather than pretend a ranking happened.
        chosen = list(range(min(limit, len(parts))))

    return {
        'summary': ' '.join(parts[i] for i in chosen),
        'sentences': [parts[i] for i in chosen],
        'keywords': keywords(text),
        'selected': len(chosen),
        'sentenceCount': len(parts),
        'wordCount': len(_TOKEN.findall(text or '')),
        'characters': len(text or ''),
    }


# ------------------------------------------------------- prompt to form fields
# Ordinary words in, real PDF fields out. Longest phrase first, because "date of
# birth" contains "date" and "address line 1" contains "address": matching the
# short phrase first would produce two fields for one request.
FIELD_CATALOG: tuple[tuple[str, str, str, bool], ...] = (
    ('date of birth', 'Date of birth', 'date', False),
    ('birth date', 'Date of birth', 'date', False),
    ('date signed', 'Date signed', 'date', False),
    ('signature date', 'Date signed', 'date', False),
    ('expiry date', 'Expiry date', 'date', False),
    ('due date', 'Due date', 'date', False),
    ('full name', 'Full name', 'text', False),
    ('first name', 'First name', 'text', False),
    ('given name', 'First name', 'text', False),
    ('middle name', 'Middle name', 'text', False),
    ('last name', 'Last name', 'text', False),
    ('family name', 'Last name', 'text', False),
    ('surname', 'Last name', 'text', False),
    ('email address', 'Email', 'text', False),
    ('e-mail address', 'Email', 'text', False),
    ('e-mail', 'Email', 'text', False),
    ('email', 'Email', 'text', False),
    ('phone number', 'Phone', 'text', False),
    ('telephone number', 'Phone', 'text', False),
    ('contact number', 'Phone', 'text', False),
    ('telephone', 'Phone', 'text', False),
    ('mobile number', 'Mobile', 'text', False),
    ('phone', 'Phone', 'text', False),
    ('mobile', 'Mobile', 'text', False),
    ('address line 1', 'Address line 1', 'text', False),
    ('address line 2', 'Address line 2', 'text', False),
    ('street address', 'Street address', 'text', False),
    ('postal code', 'Postal code', 'text', False),
    ('postcode', 'Postal code', 'text', False),
    ('zip code', 'Postal code', 'text', False),
    ('address', 'Address', 'text', False),
    ('zip', 'Postal code', 'text', False),
    ('city', 'City', 'text', False),
    ('town', 'Town', 'text', False),
    ('province', 'Province', 'text', False),
    ('county', 'County', 'text', False),
    ('state', 'State', 'text', False),
    ('country', 'Country', 'text', False),
    ('company name', 'Company', 'text', False),
    ('organisation', 'Organisation', 'text', False),
    ('organization', 'Organisation', 'text', False),
    ('employer', 'Employer', 'text', False),
    ('company', 'Company', 'text', False),
    ('department', 'Department', 'text', False),
    ('job title', 'Job title', 'text', False),
    ('position', 'Position', 'text', False),
    ('invoice number', 'Invoice number', 'text', False),
    ('invoice no', 'Invoice number', 'text', False),
    ('reference number', 'Reference', 'text', False),
    ('reference', 'Reference', 'text', False),
    ('account number', 'Account number', 'text', False),
    ('customer id', 'Customer ID', 'text', False),
    ('employee id', 'Employee ID', 'text', False),
    ('tax id', 'Tax ID', 'text', False),
    ('vat number', 'VAT number', 'text', False),
    ('amount', 'Amount', 'text', False),
    ('quantity', 'Quantity', 'text', False),
    ('total', 'Total', 'text', False),
    ('website', 'Website', 'text', False),
    ('signature', 'Signature', 'text', False),
    ('date', 'Date', 'date', False),
    ('notes', 'Notes', 'text', True),
    ('comments', 'Comments', 'text', True),
    ('remarks', 'Remarks', 'text', True),
    ('description', 'Description', 'text', True),
    ('message', 'Message', 'text', True),
    ('reason', 'Reason', 'text', True),
    ('agreement', 'Agree', 'checkbox', False),
    ('approval', 'Approved', 'checkbox', False),
    ('agree', 'Agree', 'checkbox', False),
    ('approve', 'Approved', 'checkbox', False),
    ('consent', 'Consent', 'checkbox', False),
    ('accepted', 'Accepted', 'checkbox', False),
    ('accept', 'Accepted', 'checkbox', False),
    ('confirmed', 'Confirmed', 'checkbox', False),
    ('confirm', 'Confirmed', 'checkbox', False),
    ('checkbox', 'Checkbox', 'checkbox', False),
)
_ORDERED_CATALOG = tuple(sorted(FIELD_CATALOG, key=lambda entry: -len(entry[0])))
_CHECKBOX_WORDS = ('agree', 'approve', 'accept', 'confirm', 'consent', 'acknowledg', 'declar')
_QUOTED = re.compile(r'["\u201c\u201d\u2018\u2019\']([^"\u201c\u201d\u2018\u2019\']{2,60})["\u201c\u201d\u2018\u2019\']')
_CHOICES_KEYWORD = re.compile(
    r'\b(?:choose from|select from|choice of|options?|dropdown|choices?)\b', re.IGNORECASE)
_CHOICES = re.compile(
    r'\b(?:choose from|select from|choice of|options?|dropdown|choices?)\s*[:\-]?\s*([^.;\n]+)',
    re.IGNORECASE)
_SPLIT_CHOICES = re.compile(r'\s*(?:,|/|\||\bor\b|\band\b)\s*', re.IGNORECASE)


def word_count(text: str) -> int:
    return len(_TOKEN.findall(text or ''))


def field_name(label: str) -> str:
    """A PDF field name for a label: letters, digits and underscores."""
    return _snake(label)


def _snake(label: str) -> str:
    name = re.sub(r'[^0-9a-zA-Z]+', '_', label.strip().lower()).strip('_')
    name = re.sub(r'_+', '_', name)[:60]
    if not name or name[0].isdigit():
        name = f'field_{name}' if name else 'field'
    return name


def _kind_for(label: str) -> str:
    lowered = label.lower()
    if any(word in lowered for word in _CHECKBOX_WORDS):
        return 'checkbox'
    if 'date' in lowered or 'dob' in lowered or lowered.strip() in ('signed', 'expires'):
        return 'date'
    return 'text'


def field_spec(label: str, kind: str = 'text', choices: list[str] | None = None,
               wide: bool = False, date_format: str | None = None) -> dict:
    """One field, in the shape the engine and the interface both expect."""
    clean = re.sub(r'\s+', ' ', str(label or '').strip())[:80]
    if not clean:
        raise AIError('A field needs a name.')
    if kind not in ('text', 'date', 'checkbox', 'dropdown'):
        kind = 'text'
    options = [str(c).strip()[:150] for c in (choices or []) if str(c).strip()][:100]
    if kind == 'dropdown' and not options:
        # A dropdown with nothing to choose from is not a dropdown.
        kind = 'text'
    spec = {'label': clean, 'name': field_name(clean), 'kind': kind,
            'choices': options, 'wide': bool(wide)}
    if kind == 'date':
        spec['dateFormat'] = date_format or 'YYYY-MM-DD'
    return spec


def _trailing_options(captured: str) -> str:
    """Keep only the list at the end of a captured clause.

    "for department with options Sales, Support" is one clause containing two
    trigger words; the options are what follows the last of them.
    """
    last = None
    for match in _CHOICES_KEYWORD.finditer(captured):
        last = match
    tail = captured[last.end():] if last else captured
    return re.sub(r'^\s*(?:with|of|for|are|is|be|:|-)\s+', '', tail.strip(), flags=re.IGNORECASE)


def _parse_choices(text: str) -> list[str]:
    parts = [p.strip(' .') for p in _SPLIT_CHOICES.split(text.strip())]
    return [p[:150] for p in parts if 1 <= len(p) <= 150][:100]


def parse_form_prompt(prompt: str) -> list[dict]:
    """Turn an ordinary sentence into a list of form fields.

    Recognises the field names people actually write, infers a type from the
    words ("date signed" is a date, "agree to the terms" is a checkbox), and
    picks up choices from "choose from A, B or C". Anything in quotes is taken as
    a field name verbatim, which is the escape hatch for names the catalogue has
    never heard of. It is a parser, not a model: it does not guess at meaning,
    and when it recognises nothing it says so instead of inventing fields.
    """
    text = re.sub(r'\s+', ' ', str(prompt or '')).strip()
    if not text:
        raise AIError('Describe the fields you want, for example: full name, email, '
                      'date signed, and a checkbox to agree to the terms.')

    # A bare type word in front of a phrase is the type of that phrase, not a
    # field of its own: "a checkbox to agree" is one field called Agree.
    generic = [m.span() for m in
               re.finditer(r'\bcheckbox\b\s+(?:to|for|that|saying|labelled|labeled)\b',
                           text, re.IGNORECASE)]

    hits: list[tuple[int, int, str, str, bool]] = []
    for phrase, label, kind, wide in _ORDERED_CATALOG:
        for match in re.finditer(rf'\b{re.escape(phrase)}\b', text, re.IGNORECASE):
            hits.append((match.start(), match.end(), label, kind, wide))
    for match in _QUOTED.finditer(text):
        label = re.sub(r'\s+', ' ', match.group(1)).strip()
        if label:
            hits.append((match.start(), match.end(), label[:80], _kind_for(label), False))

    # A short phrase inside a longer one is the same request, not a second field.
    hits = [hit for hit in hits
            if not any(other[0] <= hit[0] and hit[1] <= other[1] and other[:2] != hit[:2]
                       for other in hits)]
    hits = [hit for hit in hits
            if not (hit[2] == 'Checkbox' and any(a <= hit[0] and hit[1] <= b for a, b in generic))]

    placed: list[tuple[int, int, dict]] = []
    seen: set[str] = set()
    for start, end, label, kind, wide in sorted(hits):
        key = label.lower()
        if key in seen:
            continue
        seen.add(key)
        placed.append((start, end, field_spec(label, kind, wide=wide)))
    placed = placed[:MAX_FIELDS]

    # "choose from Yes, No" — the options belong to the field just before them,
    # or become a field of their own when the prompt names no field at all.
    for match in _CHOICES.finditer(text):
        choices = _parse_choices(_trailing_options(match.group(1)))
        if len(choices) < 2:
            continue
        inner = list(_CHOICES_KEYWORD.finditer(match.group(0)))
        anchor = match.start() + inner[-1].end() if inner else match.end()
        before = [entry for entry in placed if entry[1] <= anchor]
        if before:
            target = max(before, key=lambda entry: entry[1])[2]
            target['kind'] = 'dropdown'
            target['choices'] = choices
        elif len(placed) < MAX_FIELDS:
            placed.append((match.start(), match.end(), field_spec('Choice', 'dropdown', choices)))

    fields = [spec for _start, _end, spec in sorted(placed)][:MAX_FIELDS]
    if not fields:
        raise AIError('No fields were recognised in that. Name them plainly — '
                      'for example: full name, email, date signed, and a checkbox to agree — '
                      'or put the exact names in quotes.')
    return fields


def layout_fields(fields: list[dict], width: float = 595.0, height: float = 842.0) -> list[list[float]]:
    """Where each field goes on a fresh A4 page: two columns, top to bottom.

    Refuses rather than overflowing: a field placed past the bottom margin would
    be off the page, and a form that silently loses its last three fields is
    worse than being told to ask for fewer.
    """
    margin, top, bottom = 56.0, 96.0, height - 72.0
    gutter, row_gap, field_height, wide_height = 24.0, 14.0, 26.0, 58.0
    column = (width - 2 * margin - gutter) / 2
    rects: list[list[float]] = []
    y, used = top, 0
    for spec in fields:
        wide = bool(spec.get('wide'))
        if wide and used:
            y += field_height + row_gap
            used = 0
        tall = wide_height if wide else field_height
        broad = (width - 2 * margin) if wide else column
        x = margin if used == 0 else margin + column + gutter
        if y + tall > bottom:
            raise AIError(f'That is {len(fields)} fields, and only {len(rects)} fit on one page. '
                          f'Ask for fewer, or add them a page at a time.')
        rects.append([x, y, x + broad, y + tall])
        if wide:
            y += tall + row_gap
        else:
            used += 1
            if used == 2:
                y += field_height + row_gap
                used = 0
    return rects


# ------------------------------------------------------------ optional model
@dataclass
class ModelConfig:
    """Where to reach a model, and the key to use. Never written to disk."""

    endpoint: str = ''
    model: str = ''
    api_key: str = ''
    headers: dict = field(default_factory=dict)

    @property
    def configured(self) -> bool:
        return bool(self.endpoint.strip() and self.model.strip())

    def public(self) -> dict:
        """What may be shown or sent back — never the key itself."""
        return {'endpoint': self.endpoint, 'model': self.model,
                'configured': self.configured, 'keySet': bool(self.api_key)}


def chat_url(endpoint: str) -> str:
    """The chat-completions URL for a base address or a full one."""
    raw = (endpoint or '').strip()
    if not raw:
        raise AIError('Enter the address of the model endpoint.', 409, 'ai_not_configured')
    parts = urlsplit(raw)
    if parts.scheme not in ('http', 'https') or not parts.netloc:
        raise AIError('The model address must be a full http:// or https:// address.')
    path = parts.path.rstrip('/')
    if not path.endswith('/chat/completions'):
        path = f'{path}/chat/completions'
    return urlunsplit((parts.scheme, parts.netloc, path, '', ''))


def chat(config: ModelConfig, system: str, user: str, timeout: float = 60.0) -> str:
    """One exchange with an OpenAI-compatible model.

    Plain standard-library HTTP: this application ships no HTTP client for
    anything else, and adding one for this would be one more thing to keep
    patched. The reply is validated before it is believed, and the key is never
    put into a message, a log or an error.
    """
    if not config.configured:
        raise AIError('No model is connected. Add its address and model name first.',
                      409, 'ai_not_configured')
    url = chat_url(config.endpoint)
    payload = {
        'model': config.model.strip(),
        'messages': [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}],
        'temperature': 0.2,
        'stream': False,
    }
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    if config.api_key:
        headers['Authorization'] = f'Bearer {config.api_key}'
    headers.update(config.headers or {})
    request = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'),
                                     headers=headers, method='POST')
    # A model running on this computer is not reached through a proxy. Without
    # this, a machine with HTTP_PROXY set sends a request for 127.0.0.1 to
    # whatever proxy it is configured with, and gets that proxy's error back.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) \
        if urlsplit(url).hostname in LOOPBACK_HOSTS else urllib.request.build_opener()
    try:
        with opener.open(request, timeout=timeout) as response:
            body = json.loads(response.read().decode('utf-8', 'replace'))
    except urllib.error.HTTPError as exc:
        detail = ''
        try:
            error = json.loads(exc.read().decode('utf-8', 'replace'))
            detail = str((error.get('error') or {}).get('message') or error.get('message') or '')
        except Exception:                                              # noqa: BLE001
            detail = ''
        message = f'The model refused the request (HTTP {exc.code}).'
        if detail:
            message = f'{message} {detail[:300]}'
        raise AIError(message, 502, 'ai_request_failed') from exc
    except (TimeoutError, socket.timeout) as exc:
        raise AIError('The model did not answer in time.', 504, 'ai_timeout') from exc
    except urllib.error.URLError as exc:
        raise AIError(f'The model could not be reached at {urlsplit(url).netloc}. '
                      'Check the address and this computer\u2019s connection.', 502,
                      'ai_unreachable') from exc
    except (OSError, ValueError) as exc:
        raise AIError('The model could not be reached, or its reply could not be read.',
                      502, 'ai_unreachable') from exc
    try:
        content = body['choices'][0]['message']['content']
    except (KeyError, IndexError, TypeError) as exc:
        raise AIError('The model sent a reply this application could not read.', 502,
                      'ai_bad_response') from exc
    if not isinstance(content, str) or not content.strip():
        raise AIError('The model sent an empty reply.', 502, 'ai_bad_response')
    return content.strip()


SUMMARY_SYSTEM = (
    'You summarise documents inside a PDF reader. Write in the same language as the '
    'document. Use only what the text says and never add facts that are not in it. '
    'Be concise and factual. Reply with plain prose and no markdown headings.'
)
FORM_SYSTEM = (
    'You design PDF forms. Reply with JSON only \u2014 no prose, no explanation and no code '
    'fences \u2014 in exactly this shape: '
    '{"fields":[{"label":"Full name","type":"text"},'
    '{"label":"Date signed","type":"date"},'
    '{"label":"Approved","type":"checkbox"},'
    '{"label":"Department","type":"dropdown","choices":["Sales","Support"]}]} '
    'type is one of text, date, checkbox or dropdown. A dropdown must include a '
    '"choices" list of strings. Use the field names the user asked for, in the order '
    'they asked for them, and use nothing else.'
)


def model_summary(config: ModelConfig, text: str, limit: int = 5, timeout: float = 90.0) -> str:
    prompt = (f'Summarise this document in about {max(1, min(int(limit or 5), 12))} sentences.\n\n'
              f'---\n{_clip(strip_page_markers(text))}')
    return chat(config, SUMMARY_SYSTEM, prompt, timeout=timeout)


def _json_from_reply(reply: str):
    cleaned = re.sub(r'^\s*```(?:json)?|```\s*$', '', reply.strip(), flags=re.MULTILINE).strip()
    start, end = cleaned.find('{'), cleaned.rfind('}')
    if start >= 0 and end > start:
        cleaned = cleaned[start:end + 1]
    try:
        return json.loads(cleaned)
    except (ValueError, TypeError) as exc:
        raise AIError('The model did not reply with usable JSON. Try again, or rephrase the prompt.',
                      502, 'ai_bad_response') from exc


def clean_model_fields(raw) -> list[dict]:
    """Accept only field descriptions this application can actually build."""
    entries = raw.get('fields') if isinstance(raw, dict) else raw
    if not isinstance(entries, list):
        raise AIError('The model did not reply with a list of fields.', 502, 'ai_bad_response')
    out: list[dict] = []
    for entry in entries[:MAX_FIELDS]:
        if not isinstance(entry, dict):
            continue
        label = str(entry.get('label') or entry.get('name') or '').strip()
        if not label:
            continue
        kind = str(entry.get('type') or 'text').strip().lower()
        choices = entry.get('choices') if isinstance(entry.get('choices'), list) else []
        out.append(field_spec(label, kind, choices))
    if not out:
        raise AIError('The model did not return any usable fields. Try rephrasing the prompt.',
                      502, 'ai_bad_response')
    return out


def model_fields(config: ModelConfig, prompt: str, sample: str = '', timeout: float = 90.0) -> list[dict]:
    user = f'Fields wanted: {prompt.strip()}'
    if sample.strip():
        user += f'\n\nDocument excerpt, for context only:\n---\n{_clip(sample, 4000)}'
    return clean_model_fields(_json_from_reply(chat(config, FORM_SYSTEM, user, timeout=timeout)))
