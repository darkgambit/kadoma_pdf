'use strict';

// No third-party JavaScript, remote services or analytics. The single exception
// to "nothing is stored" is the light/dark choice, which is one localStorage key
// read by theme.js before the page is drawn. It holds no document, no account and
// no history.
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = (name, cls = '') => `<svg${cls ? ` class="${cls}"` : ''} aria-hidden="true"><use href="#i-${name}"/></svg>`;
const token = new URLSearchParams(location.hash.slice(1)).get('session') || '';
if (token) history.replaceState(null, '', location.pathname);
// A proxied browser demo is NOT offline on the visitor's computer. Only the
// native loopback shell / a genuinely local server can make that privacy claim.
const isHostedPreview = !['localhost','127.0.0.1','::1','[::1]'].includes(location.hostname);
if (isHostedPreview) {
  // The badge that used to say this is gone from the top bar; the status bar
  // carries it now, and it says more.
  $('#status-text').textContent = 'Hosted demo: files are processed in this workspace, not on your computer';
  $('.status-right').innerHTML = icon('info') + 'Use non-sensitive samples. Desktop builds run locally.';
}
// --------------------------------------------------------------- light / dark
// theme.js has already put the right attribute on <html> before the page was
// drawn, so this only has to keep the button in step and remember a change.
const THEME_KEY = 'kadoma.theme';
function applyTheme(theme, remember = false) {
  const dark = theme === 'dark';
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  const button = $('#theme-button');
  if (button) {
    button.innerHTML = `<svg><use href="#i-${dark ? 'sun' : 'moon'}"/></svg>`;
    button.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
    button.setAttribute('aria-label', button.title);
    button.setAttribute('aria-pressed', String(dark));
  }
  if (remember) {
    try { localStorage.setItem(THEME_KEY, dark ? 'dark' : 'light'); } catch { /* storage unavailable */ }
  }
}
function toggleTheme() {
  applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true);
}
applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');

const state = {
  doc: null, page: 0, view: 'home', tool: 'view', content: null,
  selection: null, pendingImage: null, pendingDate: null, pendingStamp: null, imageReplaceXref: null,
  sheetURLs: new Set(), fieldType: 'text', dateFormat: 'YYYY-MM-DD', fieldNameDraft: '', formDraft: {}, capabilities: {}, zoom: '1.5', busy: 0,
  pageURL: null, thumbnailURLs: new Set(), imageObserver: null,
  zoomFactor: 1, renderedScale: 0, sharpenTimer: null,
  renderGeneration: 0, selectedPages: new Set(), dragPage: null,
  searchQuery: '', searchMatches: [], searchIndex: 0, searchGeneration: 0,
  convertFormat: 'docx', exportRange: 'all', lastExport: null, previewAcknowledged: false,
  inline: null, measureCanvas: null, inlineBackground: '#ffffff', share: null,
  // The right-hand tools panel is pinned open by default, exactly as it always
  // behaved. Unpinned, it collapses to a rail and floats out on demand; `peek`
  // is the sticky reveal you get by clicking the rail tab, as opposed to the
  // reveal that lasts only while the pointer or focus is on the rail.
  inspectorPinned: true, inspectorPeek: false,
  // The documents the engine is holding open. Several stay open at once, which
  // is what lets the merge window combine one into another without either being
  // read from disk again.
  openDocs: [],
  // Which panels are on screen. The page thumbnails start away — the Pages view
  // shows every page when it is wanted, and a column of thumbnails beside the
  // tools is not worth the width for reading. The tools panel starts open. The
  // menu bar is the only thing that changes either.
  showThumbnails: false, showTools: true, menuCollapsed: false,
  // The list of every tool, beside the document. It starts open because it is
  // the way into the application without going back to Home, and it is one
  // press to put away when the page needs the width.
  showToolRail: true,
  // AI reading. `status` is the server's view of whether a model is connected;
  // `summary` and `fields` hold results so the panel can be rebuilt without
  // losing them; `consented` is the session's answer to the one question that
  // has to be asked before anything leaves the computer.
  ai: { status: null, summary: null, fields: null, prompt: '', sentences: 5, consented: false },
};

class APIError extends Error {
  constructor(message, code, status) { super(message); this.code = code; this.status = status; }
}

async function api(path, options = {}) {
  const opts = { ...options, headers: { ...options.headers } };
  // Printing is the one call that can sit for minutes inside a printer driver.
  // A deadline turns "nothing happened" into a sentence somebody can act on.
  const timeout = options.timeout;
  let timer = null;
  if (timeout) {
    const controller = new AbortController();
    opts.signal = controller.signal;
    timer = setTimeout(() => controller.abort(), timeout);
  }
  delete opts.timeout;
  if (token) opts.headers.Authorization = `Bearer ${token}`;
  if (options.json !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(options.json);
    delete opts.json;
  }
  delete opts.raw;
  let response;
  try { response = await fetch('/api' + path, opts); }
  catch (error) {
    if (error.name === 'AbortError') throw new APIError('The printer has not answered yet. The job may still be printing — check the print queue before trying again.', 'timeout', 0);
    throw new APIError('The local PDF engine is not responding. Restart KADOMA and reopen your file.', 'connection_failed', 0);
  }
  finally { if (timer) clearTimeout(timer); }
  if (!response.ok) {
    let data = {};
    try { data = await response.json(); } catch {}
    const detail = typeof data.detail === 'string' ? data.detail : 'The local engine could not complete this request.';
    throw new APIError(detail, data.code, response.status);
  }
  return options.raw ? response : response.json();
}

const docPath = suffix => `/documents/${state.doc.id}${suffix}`;
function toast(message, error = false) {
  const item = document.createElement('div');
  item.className = 'toast' + (error ? ' error' : '');
  item.innerHTML = icon(error ? 'warning' : 'check') + `<span>${escapeHTML(message)}</span>`;
  $('#toast-stack').append(item);
  setTimeout(() => item.remove(), error ? 8000 : 4300);
}
function showError(error) { console.warn('KADOMA action failed:', error.code || error.name); toast(error.message || 'This action could not be completed.', true); }
async function busy(title, work, description = isHostedPreview ? 'Hosted demo: uploads are processed in this workspace. Use non-sensitive files.' : 'Your file never leaves this device.') {
  state.busy++;
  $('#busy-title').textContent = title;
  $('#busy-description').textContent = description;
  $('#busy-overlay').hidden = false;
  try { return await work(); }
  finally { state.busy--; $('#busy-overlay').hidden = state.busy === 0; }
}
function readableSize(size) { return size < 1024 * 1024 ? `${Math.max(1, Math.round(size / 1024))} KB` : `${(size / 1024 / 1024).toFixed(1)} MB`; }
function clearThumbnails() {
  if (state.imageObserver) state.imageObserver.disconnect();
  for (const url of state.thumbnailURLs) URL.revokeObjectURL(url);
  state.thumbnailURLs.clear();
}
function clearSearch() {
  state.searchGeneration++;
  state.searchQuery = '';
  state.searchMatches = [];
  state.searchIndex = 0;
  $('#document-search').value = '';
}

async function adoptDocument(info, { page = state.page, selected } = {}) {
  const previous = state.doc;
  const changed = previous?.id !== info.id;
  state.doc = info;
  state.page = Math.max(0, Math.min(info.pageCount - 1, page));
  state.selection = null;
  state.content = null;
  state.inline = null;
  if ($('#inline-editor')) $('#inline-editor').hidden = true;
  if (changed || previous?.revision !== info.revision) clearSearch();
  // The engine is now the source of truth for every field value, so anything
  // typed but not yet applied is dropped rather than shown over the new state.
  state.formDraft = {};
  if (changed) { state.pendingImage = null; state.imageReplaceXref = null; state.lastExport = null; }
  if (selected) state.selectedPages = new Set(selected);
  else if (changed) state.selectedPages = new Set([state.page]);
  else state.selectedPages = new Set([...state.selectedPages].filter(n => n < info.pageCount));
  updateHeader();
  renderToolbar();
  renderThumbnails();
  renderInspector();
  await renderPage();
  if (state.view === 'pages') renderOrganizer();
  // Opening a document no longer closes the one before it: the workspace keeps
  // several open so one can be combined into another without being found on
  // disk again. The engine drops the oldest past its own limit.
  refreshOpenDocuments();
}

// What the header says about where this document stands. "Saved" and "Unsaved
// changes" are answered by the engine, which remembers the revision it last
// wrote to disk — so switching away and back cannot make an unsaved document
// look saved, or the other way round.
function documentStatus(d) {
  if (d.path && d.savedRevision === d.revision) return 'Saved';
  if (d.modified) return state.lastExport === d.revision ? 'Copy exported' : 'Unsaved changes';
  if (d.encrypted) return 'Password-protected';
  if (isHostedPreview) return 'In hosted workspace';
  return 'On this device';
}
// Anything that would be lost by closing the document or the window. An
// exported copy counts: the person has the bytes, even though the file on disk
// is untouched.
function isDirty(d = state.doc) {
  return !!d && d.modified && d.savedRevision !== d.revision && state.lastExport !== d.revision;
}

// ---------------------------------------------------------- closing the app
// Closing a clean document should be instant. The shell asks the page one
// question at close time — is there anything to lose? — and the page keeps the
// answer ready, because asking during the close itself would need the thread
// that is closing.
let lastUnsavedFlag = null;

function syncUnsavedFlag() {
  const api = window.pywebview?.api;
  if (!api?.set_unsaved) return;
  const flag = isDirty();
  if (flag === lastUnsavedFlag) return;
  lastUnsavedFlag = flag;
  try { api.set_unsaved(flag); } catch { /* the shell is going away */ }
}

// Called by the shell when the window is closed with unsaved work. Three
// answers, because "are you sure?" is not the question: save, discard, cancel.
window.kadomaAskToSaveBeforeQuit = async () => {
  if (!isDirty()) { quitApp(); return; }
  const choice = await askSaveBeforeClose(state.doc?.name || 'this document');
  if (choice === 'cancel') {
    // Say so, so the next press of the close button asks again.
    try { window.pywebview?.api?.set_unsaved(isDirty()); } catch { /* going away */ }
    lastUnsavedFlag = null;
    return;
  }
  if (choice === 'save' && !(await saveDocument())) return;
  quitApp();
};

// The bridge is injected after the first render, so the answer is sent again
// the moment it exists: a change made before that point would otherwise never
// reach the shell, and closing would discard it without asking.
window.addEventListener('pywebviewready', () => {
  lastUnsavedFlag = null;
  syncUnsavedFlag();
});

function quitApp() {
  lastUnsavedFlag = false;
  try {
    if (window.pywebview?.api?.quit_app) { window.pywebview.api.quit_app(); return; }
  } catch { /* fall through to the browser's own close */ }
  window.close();
}

function updateHeader() {
  syncUnsavedFlag();
  if (!state.doc) return;
  renderTabs();
  const d = state.doc;
  $('#document-name').textContent = d.name;
  $('#document-details').textContent = `${d.pageCount} ${d.pageCount === 1 ? 'page' : 'pages'} · ${readableSize(d.size)}`;
  $('#document-change').textContent = documentStatus(d);
  $('#document-change').classList.toggle('unsaved', isDirty(d));
  $('#page-count').textContent = d.pageCount;
  $('#current-page').value = state.page + 1;
  $('#current-page').max = d.pageCount;
  $('#total-pages').textContent = `of ${d.pageCount}`;
  $('#previous-page').disabled = state.page === 0;
  $('#next-page').disabled = state.page === d.pageCount - 1;
  $('#undo').disabled = !d.canUndo;
  $('#redo').disabled = !d.canRedo;
  $('#export-document').disabled = false;
  $('#save-document').disabled = false;
  $('#save-as-document').disabled = false;
  // A document with no file behind it cannot be saved over; the button says
  // "Save as" would be needed rather than failing when it is pressed.
  $('#save-document').title = d.canSave
    ? `Save over ${d.name} (Ctrl/⌘ S)`
    : `Choose where to save ${d.name} (Ctrl/⌘ S)`;
  // Splitting reads pages out of the document, which is exactly what the
  // assembly permission governs, so the button says so instead of failing later.
  $('#split-document').disabled = !d.canAssemble;
  const viewNames = {edit:'PDF editor', pages:'Page organizer', document:'Document tools', convert:'PDF conversion', forms:'Forms & signatures', protect:'Document protection', ocr:'Text recognition', ai:'AI reading'};
  // The view name used to sit in a breadcrumb beside the wordmark; the tab
  // strip and the page label carry it now.
  if ($('.breadcrumb span')) $('.breadcrumb span').textContent = viewNames[state.view];
  $('#canvas-mode').innerHTML = `<span class="purple-dot"></span>${escapeHTML(viewNames[state.view])}`;
  updateDocSwitcher();
}

// --------------------------------------------------- documents open right now
// Several documents are held open at once. That is what makes "combine the
// document I already have open" possible, and the switcher is how you see them,
// move between them, and close one. The engine drops the oldest past its limit,
// which the menu says rather than leaving it to be discovered.
let docMenu = null;
async function refreshOpenDocuments() {
  try {
    const result = await api('/documents');
    state.openDocs = result.documents || [];
  } catch {
    state.openDocs = [];
  }
  updateDocSwitcher();
  renderTabs();
  if (docMenu) renderDocMenu();
  if (state.view === 'home') renderHome();
}
// ------------------------------------------------------------- document tabs
// The switcher menu lists what is open; the tabs make it visible. One press
// changes document, the × closes it, and a dot means there are changes that are
// not in a file yet.
function renderTabs() {
  const strip = $('#document-tabs');
  if (!strip) return;
  const docs = state.openDocs || [];
  // A single document needs no tab: the bar above already names it.
  strip.hidden = docs.length < 2;
  if (strip.hidden) { strip.innerHTML = ''; return; }
  strip.innerHTML = docs.map(doc => {
    const current = doc.id === state.doc?.id;
    const dirty = current ? isDirty() : doc.modified;
    return `<div class="document-tab${current ? ' current' : ''}" role="tab" aria-selected="${current}">
      <button class="tab-name" data-tab="${escapeHTML(doc.id)}" title="${escapeHTML(doc.name)}${dirty ? ' — unsaved changes' : ''}">
        <span class="tab-dot"${dirty ? '' : ' hidden'}></span>${escapeHTML(doc.name)}
      </button>
      <button class="tab-close" data-tab-close="${escapeHTML(doc.id)}" title="Close ${escapeHTML(doc.name)}" aria-label="Close ${escapeHTML(doc.name)}">${icon('close')}</button>
    </div>`;
  }).join('');
  $$('[data-tab]', strip).forEach(button => button.addEventListener('click', () => {
    if (button.dataset.tab !== state.doc?.id) switchDocument(button.dataset.tab);
  }));
  $$('[data-tab-close]', strip).forEach(button => button.addEventListener('click', event => {
    event.stopPropagation();
    closeDocument(button.dataset.tabClose);
  }));
}

function updateDocSwitcher() {
  const button = $('#doc-switcher');
  if (!button) return;
  const count = state.openDocs.length || (state.doc ? 1 : 0);
  const counter = $('#doc-switcher-count');
  if (counter) counter.textContent = count;
  button.hidden = count < 2;
  if (button.hidden) closeDocMenu();
}
function closeDocMenu() {
  if (docMenu) docMenu.remove();
  docMenu = null;
  $('#doc-switcher')?.setAttribute('aria-expanded','false');
}
function renderDocMenu() {
  if (!docMenu) return;
  const limit = state.capabilities.maxDocuments || 6;
  docMenu.innerHTML = '<div class="doc-menu-head">Open documents</div>' + state.openDocs.map(item => {
    const current = !!state.doc && item.id === state.doc.id;
    const facts = item.readable
      ? `${item.pageCount} ${item.pageCount === 1 ? 'page' : 'pages'} · ${readableSize(item.size)}${item.modified ? ' · edited' : ''}`
      : 'cannot be read';
    return `<div class="doc-menu-row${current ? ' current' : ''}">
      <button class="doc-menu-open" data-open-doc="${escapeHTML(item.id)}"${current ? ' aria-current="true"' : ''}><strong>${escapeHTML(item.name)}</strong><span>${escapeHTML(facts)}</span></button>
      <button class="icon-button small doc-menu-close" data-close-doc="${escapeHTML(item.id)}" title="Close ${escapeHTML(item.name)}" aria-label="Close ${escapeHTML(item.name)}">${icon('close')}</button>
    </div>`;
  }).join('') + `<div class="doc-menu-note">${state.openDocs.length >= limit
      ? `Up to ${limit} documents stay open; opening another closes the oldest. `
      : ''}Documents stay in memory until you close them or quit, so anything unsaved is lost then.</div>`;
}
function toggleDocMenu() {
  if (docMenu) { closeDocMenu(); return; }
  const button = $('#doc-switcher');
  if (!button) return;
  docMenu = document.createElement('div');
  docMenu.className = 'doc-menu';
  document.body.append(docMenu);
  renderDocMenu();
  // Anchored to the viewport and appended to <body>, so the document bar can
  // never clip it — the same reasoning as the calendar popover.
  const box = button.getBoundingClientRect();
  docMenu.style.top = `${Math.round(box.bottom + 7)}px`;
  docMenu.style.left = `${Math.round(Math.max(12, Math.min(box.left, window.innerWidth - 320)))}px`;
  button.setAttribute('aria-expanded','true');
  docMenu.addEventListener('click', event => {
    const open = event.target.closest('[data-open-doc]');
    if (open) { switchDocument(open.dataset.openDoc); return; }
    const close = event.target.closest('[data-close-doc]');
    if (close) closeDocument(close.dataset.closeDoc);
  });
}
async function switchDocument(id) {
  if (!id || state.doc?.id === id) { closeDocMenu(); return; }
  closeDocMenu();
  try {
    const info = await busy('Switching documents…', () => api(`/documents/${id}`));
    state.tool = 'view';
    await adoptDocument(info, {page:0});
    toast(`Switched to ${info.name}`);
  } catch (error) { showError(error); }
}
async function closeDocument(id) {
  const current = state.doc?.id === id;
  // Only the document on screen can lose unsaved edits; closing one of the
  // others cannot, because anything unsaved in it is still visible in the list.
  if (current && !await confirmClose()) return;
  closeDocMenu();
  try {
    await api(`/documents/${id}`, {method:'DELETE'});
    await refreshOpenDocuments();
    if (!current) { if (!$('#doc-switcher').hidden) toggleDocMenu(); return; }
    const next = state.openDocs[state.openDocs.length - 1];
    if (next) await switchDocument(next.id);
    else {
      // Never leave the workspace with nothing to show.
      const info = await busy('Opening a fresh page…', () => api('/documents/create', {method:'POST', json:{name:'Untitled.pdf'}}));
      state.tool = 'text';
      await adoptDocument(info, {page:0});
    }
  } catch (error) { showError(error); }
}

// ------------------------------------------------------------ context menus
// One menu element, positioned at the pointer, closed by anything that means
// "not that" — a press elsewhere, Escape, or the window losing focus.
let contextMenu = null;
function closeContextMenu() {
  if (!contextMenu) return;
  contextMenu.remove();
  contextMenu = null;
}
function showContextMenu(x, y, items) {
  closeContextMenu();
  const menu = document.createElement('div');
  menu.className = 'context-menu';
  menu.setAttribute('role', 'menu');
  menu.innerHTML = items.map((item, index) => item.separator
    ? '<div class="context-separator" role="separator"></div>'
    : `<button class="context-item${item.danger ? ' danger' : ''}" data-item="${index}" role="menuitem"${item.disabled ? ' disabled' : ''}>${icon(item.icon)}<span>${escapeHTML(item.label)}</span>${item.hint ? `<kbd>${escapeHTML(item.hint)}</kbd>` : ''}</button>`).join('');
  document.body.appendChild(menu);
  const box = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(8, Math.min(x, innerWidth - box.width - 8))}px`;
  menu.style.top = `${Math.max(8, Math.min(y, innerHeight - box.height - 8))}px`;
  menu.addEventListener('click', event => {
    const button = event.target.closest('[data-item]');
    if (!button) return;
    const item = items[Number(button.dataset.item)];
    closeContextMenu();
    if (!item.disabled) item.action();
  });
  contextMenu = menu;
}
document.addEventListener('pointerdown', event => {
  if (contextMenu && !contextMenu.contains(event.target)) closeContextMenu();
}, true);
// Delegated, because the banner is re-rendered with the overlay on every page.
document.addEventListener('click', event => {
  if (event.target.closest('[data-scan-edit]')) { event.preventDefault(); makePageEditable(); }
});
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeContextMenu(); }, true);
window.addEventListener('blur', closeContextMenu);
// Closing the whole window with unsaved work asks first. The browser writes the
// wording; the desktop shell may or may not show it, which is why the tab path
// is the one that is tested.
// The browser's own "leave site?" prompt. In the desktop shell the window's
// close question covers this, and asking twice would mean two dialogs for one
// close — so the shell's answer is the only one that counts there.
window.addEventListener('beforeunload', event => {
  if (desktopApp() || !isDirty()) return;
  event.preventDefault();
  event.returnValue = '';
});
window.addEventListener('resize', closeContextMenu);

// One page, one action. The selection is set first so the action and the page
// the menu was opened on cannot disagree.
function pageAction(page, action, payload = null) {
  state.selectedPages = new Set([page]);
  if (payload) { perform(payload, 'Rotating the page…').catch(showError); return; }
  handleAction(action);
}

function pageContextMenu(event, page) {
  event.preventDefault();
  event.stopPropagation();
  const d = state.doc;
  if (!d) return;
  showContextMenu(event.clientX, event.clientY, [
    {label: `Page ${page + 1}`, icon: 'file', disabled: true},
    {separator: true},
    {label: 'Rotate right', icon: 'rotate', disabled: !d.canEdit,
     action: () => pageAction(page, 'rotate', {action: 'rotate', pages: [page], angle: 90})},
    {label: 'Rotate left', icon: 'rotate', disabled: !d.canEdit,
     action: () => pageAction(page, 'rotate', {action: 'rotate', pages: [page], angle: -90})},
    {label: 'Copy page to a file…', icon: 'copy', disabled: !d.canCopy,
     action: () => showCopyPageDialog(page)},
    {label: 'Extract page', icon: 'download', disabled: !d.canCopy,
     action: () => pageAction(page, 'extract-pages')},
    {label: 'Duplicate page', icon: 'copy', disabled: !d.canAssemble,
     action: () => pageAction(page, 'duplicate-pages')},
    {separator: true},
    {label: 'Delete page', icon: 'trash', danger: true, disabled: !d.canAssemble || d.pageCount < 2,
     action: () => pageAction(page, 'delete-pages')},
  ]);
}

// ---------------------------------------------------- copy one page to a file
// A page lifted out of the document as a PDF of its own, under a name typed
// here. It is a copy: the document on screen is not touched. The file is
// written through the same path as an export, so the desktop build asks where
// it should go and the browser preview downloads it.
function suggestedPageName(page) {
  const stem = (state.doc?.name || 'document').replace(/\.pdf$/i, '');
  return `${stem} — page ${page + 1}.pdf`;
}

// Whatever is typed becomes a file name, so the characters a file name cannot
// hold are replaced rather than rejected, and the extension is not the person's
// problem: ".pdf" is added once, whether or not they typed it.
function cleanPdfName(raw, fallback) {
  let name = String(raw || '').trim()
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '-')
    .replace(/\s+/g, ' ')
    .replace(/\.pdf$/i, '')
    .replace(/^[.\s-]+|[.\s]+$/g, '');
  if (!name) return fallback;
  return name.slice(0, 116) + '.pdf';
}

function showCopyPageDialog(page) {
  const d = state.doc;
  if (!d) return;
  const suggested = suggestedPageName(page);
  const body = `
    <p class="confirm-description">Page ${page + 1} is copied into a PDF of its own, under the name below. The document you have open is not changed.</p>
    <div class="field"><label for="copy-name">File name</label>
      <input id="copy-name" value="${escapeHTML(suggested)}" maxlength="120" autocomplete="off" spellcheck="false"></div>
    <div class="inline-note">${icon('info')}<span>The copy keeps this page's size, text, images, links and comments. Nothing here changes the original.</span></div>
    <p class="field-error" id="copy-error"></p>`;
  const dialog = openModal('Copy this page out.', 'One page, one file, named how you like.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="copy-run">Save the copy</button>', 500);
  const input = $('#copy-name');
  input.focus();
  input.select();

  const run = async () => {
    const name = cleanPdfName(input.value, suggested);
    $('#copy-error').textContent = '';
    try {
      const saved = await busy('Copying the page…', async () => {
        const response = await api(docPath('/export/pdf'), { method: 'POST', json: { pages: [page] }, raw: true });
        return saveBlob(await response.blob(), name);
      });
      if (saved) { dialog.close(); toast(`Saved “${name}”`); }
    } catch (error) {
      $('#copy-error').textContent = error.message || 'That page could not be copied.';
    }
  };
  $('#copy-run').addEventListener('click', run);
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); run(); }
  });
}

function toolButton(tool, label, symbol, options = {}) {
  const disabled = options.disabled ? ' disabled' : '';
  return `<button class="tool-button${state.tool === tool ? ' active' : ''}${options.danger ? ' danger-text' : ''}" data-tool="${tool}" title="${escapeHTML(options.title || label)}"${disabled}>${icon(symbol)}<span class="tool-label">${escapeHTML(label)}</span></button>`;
}
function actionButton(action, label, symbol, disabled = false, title = label) {
  return `<button class="tool-button" data-action="${action}" title="${escapeHTML(title)}"${disabled ? ' disabled' : ''}>${icon(symbol)}<span class="tool-label">${escapeHTML(label)}</span></button>`;
}

function renderToolbar() {
  const d = state.doc;
  if (!d) return;
  let html = '';
  if (state.view === 'edit') {
    html = toolButton('view', 'View', 'eye', {title:'Reading view — nothing is armed. Pick a tool to change the document.'}) +
      toolButton('select', 'Select', 'select') +
      toolButton('edit', 'Edit text', 'edit', {disabled:!d.canEdit || !d.canCopy, title:'Replace selected text (E)'}) +
      toolButton('text', 'Add text', 'text', {disabled:!d.canEdit, title:'Draw an area for new text (T)'}) +
      toolButton('date', 'Date', 'calendar', {disabled:!d.canEdit, title:'Pick a date and place it on the page as selectable text'}) +
      toolButton('stamp', 'Stamp', 'shield', {disabled:!d.canEdit, title:'Place an Approved, Draft or Confidential stamp'}) +
      toolButton('link', 'Link', 'share', {disabled:!d.canEdit, title:'Drag a box and add a web or page link'}) +
      toolButton('image', 'Image', 'image', {disabled:!d.canEdit, title:'Insert a local image'}) +
      toolButton('highlight', 'Highlight', 'highlight', {disabled:!d.canAnnotate, title:'Highlight an area (H)'}) +
      toolButton('comment', 'Comment', 'comment', {disabled:!d.canAnnotate, title:'Place a comment (C)'}) +
      toolButton('signature', 'Sign', 'signature', {disabled:!d.canEdit, title:'Add a typed or drawn visual signature'});
  } else if (state.view === 'pages') {
    const noSelection = !state.selectedPages.size || !d.canAssemble;
    html = actionButton('select-all', 'Select all', 'pages') +
      actionButton('rotate-pages', 'Rotate', 'rotate', noSelection) +
      actionButton('duplicate-pages', 'Duplicate', 'copy', noSelection, 'Copy pages to the end; form field copies get unique names') +
      actionButton('delete-pages', 'Delete', 'trash', noSelection) +
      actionButton('extract-pages', 'Extract', 'download', !state.selectedPages.size) +
      `<span class="toolbar-label">${state.selectedPages.size} selected</span>`;
  } else if (state.view === 'forms') {
    html = toolButton('fill', 'Fill forms', 'form', {disabled:!d.canFill}) +
      toolButton('field-text', 'Text field', 'text', {disabled:!d.canEdit}) +
      toolButton('field-date', 'Date field', 'calendar', {disabled:!d.canEdit, title:'Add a date field that opens a calendar picker'}) +
      toolButton('field-checkbox', 'Checkbox', 'check', {disabled:!d.canEdit}) +
      toolButton('field-dropdown', 'Dropdown', 'down', {disabled:!d.canEdit}) +
      toolButton('signature', 'Sign', 'signature', {disabled:!d.canEdit});
  } else if (state.view === 'protect') {
    html = toolButton('secure', 'Password protection', 'lock') +
      toolButton('redact', 'Redact content', 'redact', {disabled:!d.canEdit, danger:true}) +
      `<span class="toolbar-label">AES-256 encryption · Real content removal</span>`;
  } else if (state.view === 'document') {
    html = DOC_TOOLS.map(tool => toolButton(tool.id, tool.label, tool.icon,
      {disabled:!d.canEdit, title:tool.hint})).join('');
  } else if (state.view === 'convert') {
    html = `<span class="toolbar-label">${icon('convert')} Convert locally. Review your exported file for accuracy.</span>`;
  } else if (state.view === 'ocr') {
    html = `<span class="toolbar-label">${icon('scan')} Searchable text with the local Tesseract engine</span>`;
  } else if (state.view === 'ai') {
    html = `<span class="toolbar-label">${icon('spark')} ${aiMode() === 'model'
      ? `Connected model: ${escapeHTML(aiModelLabel())}`
      : 'Offline reading — nothing leaves this computer'}</span>`;
  }
  $('#context-tools').innerHTML = html;
  $$('#context-tools [data-tool]').forEach(button => button.addEventListener('click', () => {
    // The document tools are actions, not modes: pressing one opens its dialog
    // and leaves nothing armed behind it.
    if (state.view === 'document' && DOC_TOOLS.some(tool => tool.id === button.dataset.tool)) {
      openDocumentTool(button.dataset.tool);
      return;
    }
    chooseTool(button.dataset.tool);
  }));
  $$('#context-tools [data-action]').forEach(button => button.addEventListener('click', () => handleAction(button.dataset.action)));
}


/* ---------------------------------------------------------------------- home
   The screen the application opens on. It is a map of what the application can
   actually do, laid out the way somebody looks for it, rather than a menu of
   nouns. Every card calls the same function the toolbar calls — nothing here is
   a placeholder, and a tool that does not exist is not on the list. */

const HOME_TOOLS = [
  {id:'create',   label:'Create PDF',      icon:'plus',      color:'#d9534f', group:'create'},
  {id:'combine',  label:'Combine Files',   icon:'merge',     color:'#4a7fd4', group:'create'},
  {id:'organize', label:'Organize Pages',  icon:'pages',     color:'#4f9a55', group:'create'},
  {id:'edit',     label:'Edit PDF',        icon:'edit',      color:'#b3549f', group:'create'},
  {id:'export',   label:'Export PDF',      icon:'download',  color:'#3f9aa0', group:'create'},
  {id:'scan',     label:'Scan & OCR',      icon:'scan',      color:'#4f9a6a', group:'create'},
  {id:'prepare',  label:'Prepare Form',    icon:'form',      color:'#2f7d8a', group:'forms'},
  {id:'fill',     label:'Fill & Sign',     icon:'form',      color:'#7d5cc4', group:'forms'},
  {id:'sign',     label:'Sign',            icon:'signature', color:'#b8792f', group:'forms'},
  {id:'protect',  label:'Protect',         icon:'lock',      color:'#5b6bb0', group:'forms'},
  {id:'rotate',   label:'Rotate Pages',    icon:'rotate',    color:'#4f9a55', group:'pages'},
  {id:'extract',  label:'Extract Pages',   icon:'download',  color:'#3f9aa0', group:'pages'},
  {id:'delete',   label:'Delete Pages',    icon:'trash',     color:'#c2554f', group:'pages'},
  {id:'split',    label:'Split PDF',       icon:'split',     color:'#7d5cc4', group:'pages'},
  {id:'watermark',label:'Watermark',       icon:'layers',    color:'#7d7a9a', group:'document'},
  {id:'numbering',label:'Page Numbers',    icon:'pages',     color:'#4f7a9a', group:'document'},
  {id:'compress', label:'Reduce Size',     icon:'down-arrow',color:'#4f9a6a', group:'document'},
  {id:'bookmarks',label:'Bookmarks',       icon:'pin',       color:'#9a7a4f', group:'document'},
  {id:'attach',   label:'Attachments',     icon:'folder',    color:'#6a6a9a', group:'document'},
];
const HOME_GROUPS = [
  {id:'create', title:'Create & Edit'},
  {id:'forms',  title:'Forms & Signatures'},
  {id:'pages',  title:'Page tools'},
  {id:'document', title:'Document tools'},
];

function runHomeTool(id) {
  if (id === 'create') { $('#new-document').click(); return; }
  if (id === 'combine') { $('#merge-document').click(); return; }
  if (id === 'export') { if (!state.doc) return; showExportDialog(); return; }
  if (!state.doc) { toast('Open a document first.', true); return; }
  if (id === 'organize') { setView('pages'); return; }
  if (id === 'edit') { setView('edit'); chooseTool('edit'); return; }
  if (id === 'scan') { setView('ocr'); return; }
  if (id === 'prepare') { setView('forms'); showPrepareFormDialog(); return; }
  if (id === 'fill') { setView('forms'); chooseTool('fill'); return; }
  if (id === 'sign') { setView('forms'); chooseTool('signature'); return; }
  if (id === 'protect') { setView('protect'); showProtectDialog(); return; }
  if (id === 'split') { showSplitDialog(); return; }
  if (['watermark','numbering','compress','bookmarks','attach'].includes(id)) {
    setView('document');
    openDocumentTool(id === 'attach' ? 'attachments' : id);
    return;
  }
  if (id === 'rotate' || id === 'extract' || id === 'delete') {
    // These need a page chosen first, so the card opens the pages and says so
    // rather than doing something surprising to page 1.
    setView('pages');
    toast(`Select the pages to ${id}, then use the button in the toolbar or on a page.`);
    return;
  }
}

function homeCard(tool) {
  return `<button class="home-card" data-home="${tool.id}">
    <span class="home-card-icon" style="--tool-color:${tool.color}">${icon(tool.icon)}</span>
    <span class="home-card-label">${escapeHTML(tool.label)}</span>
    <span class="home-card-open" aria-hidden="true">Open <svg><use href="#i-down"/></svg></span>
  </button>`;
}

// One list of tools, drawn twice: on the right of the home screen, and on the
// right of the document. Both call the same handler, so a tool cannot work on
// one screen and not the other.
function toolRailItems() {
  return HOME_TOOLS.map(tool => `
    <button class="home-tool" data-home="${tool.id}" title="${escapeHTML(tool.label)}">
      <span class="home-tool-icon" style="--tool-color:${tool.color}">${icon(tool.icon)}</span>
      <span>${escapeHTML(tool.label)}</span>
    </button>`).join('');
}

function renderToolRail() {
  const host = $('#tool-rail-list');
  if (!host || host.dataset.ready === '1') return;
  host.innerHTML = toolRailItems();
  host.dataset.ready = '1';
  $$('#tool-rail-list [data-home]').forEach(button =>
    button.addEventListener('click', () => runHomeTool(button.dataset.home)));
}

function renderHome() {
  const sections = $('#home-sections');
  const rail = $('#home-rail');
  if (!sections || !rail) return;
  const query = ($('#home-search')?.value || '').trim().toLowerCase();
  const matches = tool => !query || tool.label.toLowerCase().includes(query);

  sections.innerHTML = HOME_GROUPS.map(group => {
    const tools = HOME_TOOLS.filter(tool => tool.group === group.id && matches(tool));
    if (!tools.length) return '';
    return `<h2 class="home-section-title">${escapeHTML(group.title)}</h2><div class="home-grid">${tools.map(homeCard).join('')}</div>`;
  }).join('') || '<div class="empty-state home-empty">No tool matches that. Try “edit”, “combine” or “protect”.</div>';

  // The right-hand list is the same tools, always complete, so a search that
  // narrows the grid cannot make something look missing from the application.
  rail.innerHTML = `<div class="home-rail-title">Tools</div>` + toolRailItems();

  const docs = (state.openDocs || []).filter(doc => !query || doc.name.toLowerCase().includes(query));
  sections.insertAdjacentHTML('beforeend', `
    <h2 class="home-section-title">Recent</h2>
    <div class="home-recent">${docs.length ? docs.map(doc => `
      <button class="home-recent-row${doc.id === state.doc?.id ? ' current' : ''}" data-open-doc="${escapeHTML(doc.id)}">
        <span class="home-recent-icon">${icon('file')}</span>
        <span class="home-recent-text"><strong>${escapeHTML(doc.name)}</strong><span>${doc.pageCount} ${doc.pageCount === 1 ? 'page' : 'pages'}${doc.size ? ' · ' + readableSize(doc.size) : ''}${doc.id === state.doc?.id ? ' · open' : ''}</span></span>
      </button>`).join('') : '<div class="empty-state">Nothing open yet. Create a PDF, or open a file from the button above.</div>'}
    </div>`);

  $$('#home-sections [data-home], #home-rail [data-home]').forEach(button =>
    button.addEventListener('click', () => runHomeTool(button.dataset.home)));
  $$('#home-sections [data-open-doc]').forEach(button =>
    button.addEventListener('click', () => switchDocument(button.dataset.openDoc)));
}

function setView(view) {
  if (!state.doc && view !== 'home') return;
  clearSearch();
  closeInlineEdit();
  state.view = view;
  state.selection = null;
  state.pendingImage = null;
  state.fieldNameDraft = '';
  const home = view === 'home';
  // Home has no document on screen, so the document bar and the editing toolbar
  // go away with it: they would describe a document that is not being shown.
  $('#home-view').hidden = !home;
  $('#workspace').hidden = home;
  applyToolRail();
  $('#document-bar').hidden = home;
  $('#toolbar').hidden = home;
  $('#document-tabs').hidden = home || (state.openDocs || []).length < 2;
  $$('#navigation [data-view]').forEach(button => {
    const active = button.dataset.view === view;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
  });
  if (home) { renderHome(); return; }
  const defaultTools = {edit:'view', pages:'select', document:'select', convert:'select', forms:'fill', protect:'secure', ocr:'select'};
  state.tool = defaultTools[view] || 'select';
  if (view === 'edit' && (!state.doc.canEdit || !state.doc.canCopy)) state.tool = 'view';
  if (view === 'pages' && !state.selectedPages.size) state.selectedPages = new Set([state.page]);
  $('#canvas-scroll').hidden = view === 'pages';
  $('#organizer').hidden = view !== 'pages';
  updateHeader();
  renderToolbar();
  renderInspector();
  renderOverlay();
  if (view === 'pages') renderOrganizer(); else applyZoom();
}

function chooseTool(tool) {
  if (!state.doc) return;
  clearSearch();
  closeInlineEdit();
  if (tool === 'signature') { showSignatureDialog(); return; }
  if (tool === 'date') { showDateDialog(); return; }
  if (tool === 'stamp') { showStampDialog(); return; }
  if (tool === 'secure') { showProtectDialog(); return; }
  if (tool === 'image') {
    state.imageReplaceXref = null;
    $('#image-input').value = '';
    $('#image-input').click();
    return;
  }
  state.tool = tool;
  state.selection = null;
  state.pendingImage = null;
  state.pendingDate = null;
  state.pendingStamp = null;
  if (!tool.startsWith('field-')) state.fieldNameDraft = '';
  if (tool.startsWith('field-')) state.fieldType = tool.slice(6);
  renderToolbar();
  renderInspector();
  renderOverlay();
}

async function setPage(page) {
  if (!state.doc || !Number.isInteger(page) || page < 0 || page >= state.doc.pageCount) return;
  closeInlineEdit();
  state.page = page;
  state.selection = null;
  state.content = null;
  updateHeader();
  $$('.thumb-row').forEach(row => row.classList.toggle('active', Number(row.dataset.page) === page));
  $('.thumb-row.active')?.scrollIntoView({block:'nearest'});
  renderInspector();
  await renderPage();
  scrollPageIntoView(page);
}

// How large the page is drawn. The old ceiling of 125% meant "fit width" never
// actually filled the width on a normal screen — the page sat at 765 px in a
// 1212 px canvas — which is the opposite of what somebody reading wants. Fit now
// fits, up to a point where a small document would be absurd.
const FIT_MAX = 3;
function applyZoom() {
  if (!state.doc) return;
  const {width, height} = state.doc.pages[state.page];
  const container = $('#canvas-scroll');
  let factor;
  if (['fit','page'].includes(state.zoom)) {
    factor = Math.min(FIT_MAX, Math.max(.25, (container.clientWidth - (innerWidth < 1080 ? 34 : 52)) / width));
    if (state.zoom === 'page') factor = Math.min(factor, Math.max(.25, (container.clientHeight - 52) / height));
  } else {
    factor = Number(state.zoom);
  }
  if (!factor || factor < .15) factor = .7;
  state.zoomFactor = factor;
  // Every page is on screen now, so every page is sized, not just the current
  // one. Pages keep their own proportions; a mixed document stays mixed.
  buildPageStack();
  $$('.page-sheet').forEach(sheet => {
    const page = state.doc.pages[Number(sheet.dataset.page)];
    if (!page) return;
    sheet.style.width = `${Math.round(page.width * factor)}px`;
    sheet.style.minHeight = `${Math.round(page.height * factor)}px`;
  });
  $('.page-underlay').style.maxWidth = `${Math.round(width * factor)}px`;
  // Switching to the editor builds the stack without rendering a page, so the
  // current page has to be given the editing layer here as well — otherwise
  // `#paper` does not exist until the first render finishes.
  if ($('#paper')?.dataset.page !== String(state.page)) focusSheet(state.page);
  $('#zoom-select').value = state.zoom;
  if (state.inline) renderInlineEditor();
  scheduleSharpen();
}

// ------------------------------------------------------- the page stack
// Every page is drawn in one scrolling column. Only the current page carries
// the editing layer, which is moved into it rather than copied, so the overlay,
// the selection box and the in-place editor keep working exactly as before.
function stackKey() {
  const d = state.doc;
  // The zoom is part of the key: a page rendered for a different size would be
  // soft, so the stack is rebuilt when the size changes by a tenth.
  return `${d.id}:${d.revision}:${d.pageCount}:${Math.round((state.zoomFactor || 1) * 10)}`;
}

function buildPageStack() {
  const d = state.doc;
  const stack = $('#page-stack');
  if (!d || !stack) return;
  const key = stackKey();
  if (stack.dataset.key === key) return;
  const scale = renderScale().toFixed(2);
  stack.dataset.key = key;
  // The editing layer lives inside the current page. Replacing the stack's
  // markup would destroy it along with that page, so it is moved back to its
  // holder first — this is what made a second document throw "Cannot set
  // properties of null".
  const home = $('#overlay-home');
  const layer = ['#page-overlay', '#selection-box', '#inline-editor'].map(selector => $(selector));
  if (home) layer.forEach(node => { if (node) home.append(node); });
  // Page images belong to the stack being replaced; their blobs go with it.
  for (const url of state.sheetURLs) URL.revokeObjectURL(url);
  state.sheetURLs.clear();
  stack.innerHTML = d.pages.map((page, index) => `
    <div class="paper page-sheet" data-page="${index}">
      <img class="sheet-image" alt="Page ${index + 1}" draggable="false"
           data-render="/documents/${d.id}/pages/${index}/render?scale=${scale}&revision=${d.revision}">
    </div>`).join('');
  observeSheetImages();
}

// Pages are fetched as they come near the viewport, not all at once: a 200-page
// document should not open by rendering 200 pages.
function observeSheetImages() {
  state.sheetObserver?.disconnect();
  const root = $('#canvas-scroll');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const image = entry.target;
      if (!entry.isIntersecting || image.src || !image.dataset.render) return;
      // Through the same helper the thumbnails use: the render endpoint needs
      // the session token, which an <img src> cannot carry.
      loadThumbnail(image, state.sheetURLs);
    });
  }, {root, rootMargin: '800px 0px'});
  $$('.sheet-image').forEach(image => observer.observe(image));
  state.sheetObserver = observer;
}

// Puts the editing layer into the page that is current, and gives that page the
// `#paper` id so every existing selector keeps pointing at it.
function focusSheet(index) {
  const sheets = $$('.page-sheet');
  const sheet = sheets[index];
  if (!sheet) return;
  sheets.forEach((other, i) => {
    other.classList.toggle('current', i === index);
    if (i === index) return;
    other.removeAttribute('id');
    $('.sheet-image', other)?.removeAttribute('id');
  });
  sheet.id = 'paper';
  const image = $('.sheet-image', sheet);
  if (image) {
    image.id = 'pdf-page';
    if (!image.src && image.dataset.render) loadThumbnail(image, state.sheetURLs);
  }
  const layer = ['#page-overlay', '#selection-box', '#inline-editor'].map(selector => $(selector));
  if (layer.some(node => !node)) return;
  sheet.append(...layer);
}
// The page is rendered at the scale it is shown at, so a fitted page is a real
// rendering rather than a small one blown up. Re-rendering on every pixel of a
// window resize would be wasteful, so a change under a fifth is left alone.
function renderScale() {
  return Math.min(3.2, Math.max(1.2, (state.zoomFactor || 1) * (window.devicePixelRatio || 1)));
}
function scheduleSharpen() {
  if (state.view === 'pages' || !state.doc) return;
  clearTimeout(state.sharpenTimer);
  state.sharpenTimer = setTimeout(() => {
    const wanted = renderScale();
    if (!state.renderedScale || Math.abs(wanted - state.renderedScale) / state.renderedScale > .2) renderPage();
  }, 240);
}

async function renderPage() {
  if (!state.doc) return;
  const generation = ++state.renderGeneration;
  const doc = state.doc, page = state.page;
  applyZoom();
  buildPageStack();
  focusSheet(page);
  state.renderedScale = renderScale();
  $('#pdf-page').style.opacity = '.55';
  try {
    const [response, content] = await Promise.all([
      api(`/documents/${doc.id}/pages/${page}/render?scale=${renderScale().toFixed(2)}&revision=${doc.revision}`, {raw:true}),
      api(`/documents/${doc.id}/pages/${page}/content`).catch(error => {
        if (error.status === 403) return {spans:[],images:[],widgets:[],annotations:[]};
        throw error;
      }),
    ]);
    const blob = await response.blob();
    if (generation !== state.renderGeneration) return;
    const url = URL.createObjectURL(blob);
    if (state.pageURL) URL.revokeObjectURL(state.pageURL);
    state.pageURL = url;
    state.content = content;
    $('#pdf-page').src = url;
    $('#pdf-page').style.opacity = '1';
    renderOverlay();
    renderInspector();
  } catch (error) {
    if (generation === state.renderGeneration) { $('#pdf-page').style.opacity = '1'; showError(error); }
  }
}

// Scrolling to a page is not the same as the user scrolling: the page they are
// looking at must not change because the application moved the viewport.
let scrollSyncFrame = 0;
let ignoreScrollUntil = 0;

function scrollPageIntoView(index) {
  const sheet = $$('.page-sheet')[index];
  const scroller = $('#canvas-scroll');
  if (!sheet || !scroller) return;
  ignoreScrollUntil = performance.now() + 600;
  const delta = sheet.getBoundingClientRect().top - scroller.getBoundingClientRect().top;
  scroller.scrollTo({top: scroller.scrollTop + delta - 12, behavior: 'smooth'});
}

// The page in the middle of the window is the page being worked on. Scrolling
// is therefore navigation: the header, the thumbnails and the tools panel all
// follow it.
function syncPageToScroll() {
  if (state.view !== 'edit' || !state.doc || !$$('.page-sheet').length) return;
  if (performance.now() < ignoreScrollUntil) return;
  const scroller = $('#canvas-scroll');
  const box = scroller.getBoundingClientRect();
  const middle = box.top + box.height / 2;
  let best = state.page, bestGap = Infinity;
  $$('.page-sheet').forEach(sheet => {
    const rect = sheet.getBoundingClientRect();
    const gap = Math.abs(rect.top + rect.height / 2 - middle);
    if (gap < bestGap) { bestGap = gap; best = Number(sheet.dataset.page); }
  });
  if (best === state.page) return;
  closeInlineEdit();
  state.page = best;
  state.selection = null;
  state.content = null;
  updateHeader();
  $$('.thumb-row').forEach(row => row.classList.toggle('active', Number(row.dataset.page) === best));
  renderInspector();
  renderPage();
}

function observeImages(root) {
  if (!state.imageObserver) {
    state.imageObserver = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          state.imageObserver.unobserve(entry.target);
          loadThumbnail(entry.target);
        }
      }
    }, {rootMargin:'150px'});
  }
  $$('img[data-render]', root).forEach(image => state.imageObserver.observe(image));
}
async function loadThumbnail(image, bucket = state.thumbnailURLs) {
  try {
    const response = await api(image.dataset.render, {raw:true});
    const blob = await response.blob();
    if (!image.isConnected) return;
    const url = URL.createObjectURL(blob);
    bucket.add(url);
    image.src = url;
  } catch { image.alt = 'Preview unavailable'; }
}
function renderThumbnails() {
  if (!state.doc) return;
  clearThumbnails();
  const d = state.doc;
  $('#thumbnails').innerHTML = d.pages.map((p, i) => `<div class="thumb-row${i === state.page ? ' active' : ''}" data-page="${i}" draggable="true" tabindex="0" role="button" aria-label="Open page ${i + 1}"><div class="thumb-frame"><img data-render="/documents/${d.id}/pages/${i}/render?scale=.22&revision=${d.revision}" alt="Page ${i + 1} preview" style="aspect-ratio:${p.width}/${p.height}" draggable="false"></div><span class="thumb-number">${i + 1}</span></div>`).join('');
  $$('.thumb-row').forEach(row => {
    row.addEventListener('click', () => setPage(Number(row.dataset.page)));
    row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setPage(Number(row.dataset.page)); } });
    row.addEventListener('contextmenu', event => pageContextMenu(event, Number(row.dataset.page)));
    attachPageDrag(row);
  });
  observeImages($('#thumbnails'));
}
function attachPageDrag(element) {
  element.addEventListener('dragstart', event => {
    if (!state.doc.canAssemble) { event.preventDefault(); return; }
    state.dragPage = Number(element.dataset.page);
    event.dataTransfer.setData('application/kadoma-page', String(state.dragPage));
    event.dataTransfer.effectAllowed = 'move';
    element.classList.add('dragging');
  });
  element.addEventListener('dragover', event => {
    if (state.dragPage !== null) { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; element.classList.add('drop-target'); }
  });
  element.addEventListener('dragleave', () => element.classList.remove('drop-target'));
  element.addEventListener('drop', event => {
    if (state.dragPage === null) return;
    event.preventDefault(); event.stopPropagation();
    const from = state.dragPage, to = Number(element.dataset.page);
    state.dragPage = null;
    element.classList.remove('drop-target');
    if (from === to) return;
    const order = Array.from({length:state.doc.pageCount}, (_, i) => i);
    order.splice(to, 0, order.splice(from, 1)[0]);
    const selected = [...state.selectedPages].map(n => order.indexOf(n));
    perform({action:'reorder', pages:order}, 'Reordering pages…', {page:order.indexOf(state.page), selected}).then(() => toast('Page order updated')).catch(showError);
  });
  element.addEventListener('dragend', () => {
    state.dragPage = null;
    $$('.dragging,.drop-target').forEach(el => el.classList.remove('dragging','drop-target'));
  });
}

function renderOrganizer() {
  if (!state.doc) return;
  const d = state.doc;
  $('#organizer').innerHTML = `<div class="organizer-top"><div><h2>A little order. A lot of clarity.</h2><p>Scroll through every page. Click one to select it, use <b>Odd</b> or <b>Even</b> to select half the document at once, act on the selection in the toolbar, or use the buttons on a page to rotate, extract or remove just that one.</p></div><div class="organizer-buttons"><div class="select-group" role="group" aria-label="Select pages"><span class="select-label">Select</span><button class="chip" data-select="odd" title="Select pages 1, 3, 5…">Odd</button><button class="chip" data-select="even" title="Select pages 2, 4, 6…">Even</button><button class="chip" data-select="all" title="Select every page">All</button><button class="chip" data-select="none" title="Clear the selection">None</button></div><button class="button secondary" id="organizer-split">${icon('split')}Split</button><button class="button secondary" id="organizer-add">${icon('plus')}Add pages</button></div></div><div class="organizer-grid">${d.pages.map((p,i) => `<div class="organize-card${state.selectedPages.has(i) ? ' selected' : ''}" data-page="${i}" draggable="true" tabindex="0" role="button" aria-label="Select page ${i + 1}"><input type="checkbox" ${state.selectedPages.has(i) ? 'checked' : ''} aria-label="Select page ${i + 1}"><img data-render="/documents/${d.id}/pages/${i}/render?scale=.35&revision=${d.revision}" alt="Page ${i + 1}" style="aspect-ratio:${p.width}/${p.height}" draggable="false"><div class="organize-label"><span>Page ${i + 1}</span><span class="organize-actions"><button class="icon-button small" data-page-rotate="${i}" title="Rotate page ${i + 1}" aria-label="Rotate page ${i + 1}">${icon('rotate')}</button><button class="icon-button small" data-page-extract="${i}" title="Extract page ${i + 1}" aria-label="Extract page ${i + 1}">${icon('download')}</button><button class="icon-button small" data-page-delete="${i}" title="Delete page ${i + 1}" aria-label="Delete page ${i + 1}">${icon('trash')}</button>${icon('grip')}</span></div></div>`).join('')}</div>`;
  $('#organizer-add').addEventListener('click', showAddPages);
  $('#organizer-split').addEventListener('click', showSplitDialog);
  $$('[data-select]').forEach(button =>
    button.addEventListener('click', () => selectPageSet(button.dataset.select)));
  // One press on a page does that thing to that page. The selection is set
  // first so the action and the highlighted page cannot disagree.
  for (const [attribute, action] of [['data-page-rotate', 'rotate-pages'],
                                     ['data-page-extract', 'extract-pages'],
                                     ['data-page-delete', 'delete-pages']]) {
    $$(`[${attribute}]`).forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      const index = Number(button.getAttribute(attribute));
      state.selectedPages = new Set([index]);
      renderOrganizer();
      handleAction(action);
    }));
  }
  $$('.organize-card').forEach(card => {
    const toggle = () => {
      const i = Number(card.dataset.page);
      if (state.selectedPages.has(i)) state.selectedPages.delete(i); else state.selectedPages.add(i);
      card.classList.toggle('selected', state.selectedPages.has(i));
      $('input', card).checked = state.selectedPages.has(i);
      renderToolbar(); renderInspector();
    };
    card.addEventListener('click', toggle);
    card.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); toggle(); } });
    card.addEventListener('dblclick', () => { state.page = Number(card.dataset.page); setView('edit'); renderPage(); });
    card.addEventListener('contextmenu', event => pageContextMenu(event, Number(card.dataset.page)));
    attachPageDrag(card);
  });
  observeImages($('#organizer'));
}

// Odd means the first, third, fifth page — what a person counting from one
// calls odd, not what an array index calls odd. Selecting is separate from
// deleting on purpose: the pages are highlighted first, so what is about to go
// can be seen before anything is removed.
function selectPageSet(kind) {
  if (!state.doc) return;
  const count = state.doc.pageCount;
  const indices = Array.from({ length: count }, (_, index) => index);
  if (kind === 'none') state.selectedPages = new Set();
  else if (kind === 'all') state.selectedPages = new Set(indices);
  else if (kind === 'odd') state.selectedPages = new Set(indices.filter(index => index % 2 === 0));
  else if (kind === 'even') state.selectedPages = new Set(indices.filter(index => index % 2 === 1));
  renderOrganizer();
  renderToolbar();
  renderInspector();
  if (!state.selectedPages.size) {
    toast(kind === 'even' ? 'This document has no even pages.' : 'No pages selected.');
  }
}

function overlayPosition(rect) {
  const {width,height} = state.doc.pages[state.page];
  return `left:${rect[0] / width * 100}%;top:${rect[1] / height * 100}%;width:${(rect[2]-rect[0]) / width * 100}%;height:${(rect[3]-rect[1]) / height * 100}%`;
}
// A "run" is the visible line of text a person would click once. The engine
// clusters spans into runs so one click edits a whole sentence, while separate
// table cells and right-aligned labels stay independently editable.
function contentRuns() { return state.content?.runs || []; }
// A scanned page is a picture of a page: there is ink on it but no text layer,
// so "click a line and type over it" has nothing to click. Saying that is more
// useful than a tool that appears to do nothing.
function pageIsScanned() {
  const content = state.content;
  if (!content) return false;
  return (content.spans || []).length === 0 && (content.images || []).length > 0;
}
// A page with no text layer at all. This is what makes "click a line" impossible
// and "drag over the words" the only way in, so it is what the editor switches
// on — not whether the page happens to contain an image.
function pageHasNoText() {
  const content = state.content;
  if (!content) return false;
  return (content.spans || []).length === 0;
}
// The one-press version: recognise this page, then put the text tool back in
// the person's hand so the next click edits a line. Without this, "Edit text"
// on a scan is a tool that silently does nothing.
async function makePageEditable() {
  if (!state.doc) return;
  const page = state.page;
  if (!state.capabilities?.tesseract) { setView('ocr'); return; }
  const agreed = await confirmDialog('Make this page editable?',
    'The page is replaced with a searchable 200-DPI scan, and its text can then be clicked and edited. Annotations on this page are flattened into the image and any form fields on it are removed.',
    'Recognise text');
  if (!agreed) return;
  try {
    const languages = state.capabilities.ocrLanguages || [];
    const language = languages.includes('eng') ? 'eng' : (languages.filter(code => code !== 'osd')[0] || 'eng');
    const result = await busy('Reading the page…',
      () => api(docPath('/ocr'), {method:'POST', json:{pages:[page], language}}),
      'Local OCR. Nothing leaves this computer.');
    await adoptDocument(result, {page});
    setView('edit');
    chooseTool('edit');
    // Recognition can come back empty on a skewed or low-resolution page, and
    // claiming success then would send somebody clicking at nothing.
    toast((state.content?.spans || []).length
      ? 'Text recognised — click any line to edit it'
      : 'Nothing was recognised on this page — drag a box over the words to replace them instead',
      !(state.content?.spans || []).length);
  } catch (error) { showError(error); }
}

function scannedNotice() {
  if (!pageIsScanned() || !state.doc?.canEdit) return '';
  return `<div class="notice scanned-notice">${icon('scan')}<span><strong>This page is a scan.</strong> There is no text layer to click, so “Edit text” has nothing to open. Run OCR to add one — the text becomes searchable and editable — or use <b>Add text</b>, <b>Highlight</b>, <b>Comment</b> or <b>Sign</b>, which work on any page.</span></div>
    <button class="button secondary full" id="scan-this-page">${icon('scan')}Make this page editable</button>`;
}
function runForIndex(index) {
  const run = contentRuns()[index];
  if (run) return run;
  const span = state.content?.spans?.[index];
  return span ? {text:span.text, rect:span.rect, size:span.size, color:span.color, font:span.font, rotation:span.rotation, family:span.family || 'sans-serif'} : null;
}
function textSelection(runIndex) {
  const run = runForIndex(runIndex);
  if (!run) return null;
  return {kind:'text', runIndex, spanIndex:-1, rect:[...run.rect], text:run.text, size:run.size,
          color:run.color, family:run.family || 'sans-serif', originalFont:run.font, rotation:run.rotation || 0};
}
function runIndexAtPoint(point) {
  const runs = contentRuns();
  for (let i = runs.length - 1; i >= 0; i--) {
    const r = runs[i].rect;
    if (point.x >= r[0] - 1 && point.x <= r[2] + 1 && point.y >= r[1] - 1 && point.y <= r[3] + 1) return i;
  }
  return -1;
}
// A floating prompt at the bottom of the page area while a scan is open with
// the text tool: the tool is not broken, it has nothing to click yet.
function updateScanBanner() {
  const host = $('#canvas-area');
  const existing = $('#scan-hint');
  const show = state.view === 'edit' && state.tool === 'edit'
    && state.doc?.canEdit && pageIsScanned();
  if (!show) { existing?.remove(); return; }
  const banner = existing || document.createElement('div');
  banner.id = 'scan-hint';
  banner.className = 'scan-banner';
  banner.innerHTML = `<span><b>This page is a scan.</b> Drag a box over any text to replace it, or press <b>Make it editable</b> to recognise the whole page.</span>
    <button class="button primary small" data-scan-edit>${icon('scan')}Make it editable</button>`;
  if (!existing) host.appendChild(banner);
}

function renderOverlay() {
  const overlay = $('#page-overlay');
  if (!state.doc) return;
  const drawTools = ['text','image','signature','highlight','redact','field-text','field-checkbox','field-dropdown'];
  // On a page with no text layer the text tool draws a box instead of
  // clicking a line, so it gets the drawing cursor rather than the I-beam.
  const scanDrag = state.tool === 'edit' && pageHasNoText();
  overlay.className = 'page-overlay' + (drawTools.includes(state.tool) || scanDrag ? ' draw-cursor' : state.tool === 'edit' ? ' edit-cursor' : state.tool === 'comment' ? ' comment-cursor' : '');
  let html = '';
  const content = state.content || {spans:[],runs:[],images:[],widgets:[],annotations:[]};
  if (state.tool === 'edit') {
    html += content.spans.map((span,i) => {
      const selected = state.selection?.kind === 'text' && state.selection.runIndex === span.run;
      return `<button class="text-hit${selected ? ' selected' : ''}" style="${overlayPosition(span.rect)}" data-span="${i}" data-run="${span.run}" title="Edit: ${escapeHTML(span.text)}" aria-label="Edit text: ${escapeHTML(span.text)}"></button>`;
    }).join('');
  }
  if (state.tool === 'select') {
    html += content.images.map((image,i) => `<button class="image-hit${state.selection?.imageIndex === i ? ' selected' : ''}" style="${overlayPosition(image.rect)}" data-image="${i}" title="Select embedded image" aria-label="Select embedded image"></button>`).join('');
  }
  if (state.tool === 'fill') {
    html += content.widgets.map((widget,i) => `<button class="widget-hit" style="${overlayPosition(widget.rect)}" data-widget="${i}" aria-label="Fill ${escapeHTML(widget.label)}" title="Fill ${escapeHTML(widget.label)}"></button>`).join('');
  }
  html += state.searchMatches.map((match,i) => match.page === state.page ? `<span class="search-highlight${i === state.searchIndex ? ' current' : ''}" style="${overlayPosition(match.rect)}"></span>` : '').join('');
  overlay.innerHTML = html;
  updateScanBanner();
  $$('[data-span]', overlay).forEach(button => button.addEventListener('click', event => {
    event.stopPropagation();
    // The press that closed a previous in-place edit must not immediately open another.
    if (performance.now() - (state.lastInlineCommit || 0) < 350) return;
    const runIndex = Number(button.dataset.run);
    const selection = textSelection(runIndex);
    if (!selection) return;
    state.selection = selection;
    renderOverlay(); renderInspector();
    openInlineEdit(runIndex);
  }));
  $$('[data-image]', overlay).forEach(button => button.addEventListener('click', event => {
    event.stopPropagation();
    const i = Number(button.dataset.image);
    state.selection = {kind:'image',imageIndex:i,...content.images[i]};
    renderOverlay(); renderInspector();
  }));
  $$('[data-widget]', overlay).forEach(button => button.addEventListener('click', event => {
    event.stopPropagation();
    const widget = content.widgets[Number(button.dataset.widget)];
    $(`#fill-${widget.xref}`)?.focus();
    $(`#fill-${widget.xref}`)?.scrollIntoView({block:'nearest'});
  }));
  const selected = state.selection?.rect && !['text','image'].includes(state.selection.kind);
  $('#selection-box').hidden = !selected;
  if (selected) {
    $('#selection-box').style.cssText = overlayPosition(state.selection.rect);
    $('#selection-box').className = 'selection-box' + (state.tool === 'redact' ? ' redaction' : '');
  }
  const hints = {view:'Reading view — choose a tool when you want to make changes',select:'Select an embedded image, or choose an editing tool',edit:'Click any text on the page, then type directly over it',text:'Drag on the page to create a text area',image:'Drag an area on the page to place your image',signature:'Drag an area on the page to place your signature',highlight:'Drag over the content you want to highlight',comment:'Click on the page to place a comment',redact:'Drag over sensitive content, then apply redaction',fill:'Click a form field, then complete it in the panel',date:'Click on the page to place the date you chose',stamp:'Click on the page where the stamp should go',link:'Drag a box on the page to make it a link',secure:'Export an encrypted copy with your own passwords'};
  $('#tool-hint').textContent = state.tool === 'edit' && pageHasNoText()
    ? 'This page is a scan — drag over the words you want to replace'
    : state.tool.startsWith('field-') ? 'Drag an area on the page to create a form field'
    : state.tool === 'date' && state.pendingDate
      ? `Click on the page to place ${state.pendingDate.text}`
      : hints[state.tool] || 'Your PDF, entirely on this device';
  renderInlineEditor();
}

/* ---------------------------------------------------------------- direct edit
   Clicking text opens an editable box laid exactly over it, so the page itself
   is the editor: type, press Enter, and the change is written into the PDF. */

function normaliseText(value) { return String(value ?? '').replace(/\s+/g, ' ').trim(); }
function measureText(value, fontPx, family) {
  if (!state.measureCanvas) state.measureCanvas = document.createElement('canvas');
  const context = state.measureCanvas.getContext('2d');
  context.font = `${fontPx}px 'KADOMA Sans', ${family}`;
  return context.measureText(value).width;
}
function inlineText() {
  const node = $('#inline-text');
  return (node.innerText ?? node.textContent ?? '').replace(/\u00a0/g, ' ').replace(/\s+$/, '');
}
function inlineRightLimit(runIndex, rect) {
  const width = state.doc.pages[state.page].width;
  let limit = width - 16;
  contentRuns().forEach((run, index) => {
    if (index === runIndex) return;
    if (run.rect[0] >= rect[2] - .5 && run.rect[3] > rect[1] + 1 && run.rect[1] < rect[3] - 1) {
      limit = Math.min(limit, run.rect[0] - 2);
    }
  });
  return limit;
}
// Arabic and Hebrew grow away from their right edge, so the free space to look
// for is on the left. Mirroring the engine here keeps the on-screen preview and
// the final PDF in agreement.
function inlineLeftLimit(runIndex, rect) {
  let limit = 16;
  contentRuns().forEach((run, index) => {
    if (index === runIndex) return;
    if (run.rect[2] <= rect[0] + .5 && run.rect[3] > rect[1] + 1 && run.rect[1] < rect[3] - 1) {
      limit = Math.max(limit, run.rect[2] + 2);
    }
  });
  return limit;
}
// The page background under the text is sampled so the editable box blends in
// on tinted cards instead of showing a white rectangle. The most common colour
// in the region wins, which ignores the dark minority of glyph pixels.
function sampleBackground(rect) {
  try {
    const image = $('#pdf-page');
    const page = state.doc.pages[state.page];
    if (!image.naturalWidth) return '#ffffff';
    const sx = Math.max(0, Math.floor(rect[0] / page.width * image.naturalWidth));
    const sy = Math.max(0, Math.floor(rect[1] / page.height * image.naturalHeight));
    const sw = Math.max(1, Math.ceil((rect[2] - rect[0]) / page.width * image.naturalWidth));
    const sh = Math.max(1, Math.ceil((rect[3] - rect[1]) / page.height * image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = 40; canvas.height = 12;
    const context = canvas.getContext('2d', {willReadFrequently:true});
    context.drawImage(image, sx, sy, sw, sh, 0, 0, 40, 12);
    const data = context.getImageData(0, 0, 40, 12).data;
    const counts = new Map();
    for (let i = 0; i < data.length; i += 4) {
      const key = `${data[i] >> 4},${data[i + 1] >> 4},${data[i + 2] >> 4}`;
      const entry = counts.get(key) || [0, 0, 0, 0];
      entry[0]++; entry[1] += data[i]; entry[2] += data[i + 1]; entry[3] += data[i + 2];
      counts.set(key, entry);
    }
    let best = null;
    for (const entry of counts.values()) if (!best || entry[0] > best[0]) best = entry;
    if (!best) return '#ffffff';
    return `rgb(${Math.round(best[1] / best[0])},${Math.round(best[2] / best[0])},${Math.round(best[3] / best[0])})`;
  } catch { return '#ffffff'; }
}
function placeCaretAtEnd(element) {
  try {
    const range = document.createRange();
    range.selectNodeContents(element);
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  } catch {}
}
function renderInlineEditor() {
  const editor = $('#inline-editor');
  const edit = state.inline;
  if (!editor) return;
  if (!edit || !state.doc || edit.page !== state.page || state.tool !== 'edit') { editor.hidden = true; return; }
  const page = state.doc.pages[state.page];
  const image = $('#pdf-page');
  const scale = (image.clientWidth || page.width) / page.width;
  const rotation = ((edit.displayRotation % 360) + 360) % 360;
  const swapped = rotation === 90 || rotation === 270;
  const rectWidth = (edit.rect[2] - edit.rect[0]) * scale;
  const rectHeight = (edit.rect[3] - edit.rect[1]) * scale;
  const boxWidth = swapped ? rectHeight : rectWidth;
  const boxHeight = swapped ? rectWidth : rectHeight;
  const sizePx = Math.max(4, edit.size * scale);
  const value = inlineText();
  // Mirror the engine: a longer single line grows into free space while there is
  // any, and only shrinks once it meets the page margin or other text. RTL text
  // grows leftwards, so the box moves its left edge rather than its right one.
  let grow = 0, tight = false;
  if (!swapped && rotation === 0 && value && !value.includes('\n')) {
    const needed = measureText(value, sizePx, edit.family) / scale + 2;
    const original = edit.rect[2] - edit.rect[0];
    if (needed > original) {
      if (edit.rtl) {
        const limit = inlineLeftLimit(edit.runIndex, edit.rect);
        grow = Math.max(0, (Math.min(needed, edit.rect[2] - limit) - original) * scale);
        tight = needed > edit.rect[2] - limit;
      } else {
        const limit = inlineRightLimit(edit.runIndex, edit.rect);
        grow = Math.max(0, (Math.min(needed, limit - edit.rect[0]) - original) * scale);
        tight = needed > limit - edit.rect[0];
      }
    }
  }
  const growLeft = edit.rtl ? grow / scale : 0;
  editor.style.left = `${(edit.rect[0] - growLeft) / page.width * 100}%`;
  editor.style.top = `${edit.rect[1] / page.height * 100}%`;
  editor.style.width = `${boxWidth + (swapped ? 0 : grow)}px`;
  editor.style.height = `${boxHeight}px`;
  editor.classList.toggle('tight', tight);
  const text = $('#inline-text');
  text.style.width = `${boxWidth + (swapped ? 0 : grow)}px`;
  text.style.height = `${boxHeight}px`;
  text.style.fontSize = `${sizePx}px`;
  text.style.fontFamily = `'KADOMA Sans', ${edit.family}`;
  text.style.color = edit.color;
  text.style.lineHeight = '1.15';
  text.style.paddingTop = `${Math.max(0, (boxHeight - sizePx * 1.15) / 2)}px`;
  text.style.background = state.inlineBackground;
  text.style.transform = rotation ? `translate(-50%,-50%) rotate(${rotation}deg)` : 'translate(-50%,-50%)';
  // `auto` lets the browser pick the direction from what is actually typed, so
  // Arabic entered into a Latin line still reads correctly as it is typed.
  text.dir = 'auto';
  text.style.textAlign = edit.rtl ? 'right' : 'left';
  // Keep the toolbar clear of the page: above the text when there is room, below otherwise.
  $('#inline-toolbar').style.top = edit.rect[1] * scale > 48 ? 'calc(-100% - 7px)' : 'calc(100% + 7px)';
  $('#inline-hint').textContent = tight ? 'Won’t fit — text will shrink' : 'Enter applies · Esc cancels';
}
function openInlineEdit(runIndex) {
  if (!state.doc) return;
  if (!state.doc.canEdit || !state.doc.canCopy) {
    toast(state.doc.canEdit ? 'This PDF restricts copying its text, so it cannot be edited here.' : 'This PDF restricts editing. Reopen it with the owner password to make changes.', true);
    return;
  }
  if (state.inline?.runIndex === runIndex && state.inline.page === state.page) { $('#inline-text').focus(); return; }
  const run = runForIndex(runIndex);
  if (!run) return;
  const pageRotation = (state.doc.pages[state.page].rotation || 0) % 360;
  state.inline = {runIndex, page:state.page, rect:[...run.rect], size:run.size, color:run.color,
                  family:run.family || 'sans-serif', rotation:run.rotation || 0,
                  displayRotation:(pageRotation + (run.rotation || 0)) % 360, original:run.text,
                  rtl:!!run.rtl};
  state.inlineBackground = sampleBackground(state.inline.rect);
  if (state.tool !== 'edit') { state.tool = 'edit'; renderToolbar(); }
  state.selection = textSelection(runIndex);
  const text = $('#inline-text');
  text.textContent = run.text;
  $('#inline-size').value = run.size;
  $('#inline-color').value = run.color;
  $('#inline-family').value = run.family || 'sans-serif';
  $('#inline-editor').hidden = false;
  renderInlineEditor();
  renderInspector();
  text.focus();
  placeCaretAtEnd(text);
}
function closeInlineEdit() {
  state.inline = null;
  const editor = $('#inline-editor');
  if (!editor) return;
  editor.hidden = true;
  editor.classList.remove('tight');
  $('#inline-text').textContent = '';
}
function cancelInlineEdit() {
  closeInlineEdit();
  renderInspector();
  $('#tool-hint').textContent = 'Click any text on the page, then type directly over it';
}
async function commitInlineEdit({remove = false} = {}) {
  const edit = state.inline;
  if (!edit || !state.doc) { closeInlineEdit(); return; }
  const value = remove ? '' : inlineText();
  if (normaliseText(value) === normaliseText(edit.original)) { closeInlineEdit(); renderInspector(); return; }
  const payload = {action:'replace_text', page:edit.page, rect:edit.rect, text:value, size:edit.size,
                   color:edit.color, family:edit.family, rotation:edit.rotation, expand:true};
  try {
    await perform(payload, value.trim() ? 'Writing your text into the page…' : 'Removing the selected text…');
    closeInlineEdit();
    toast(value.trim() ? 'Text updated on the page. Save when you’re ready.' : 'Text removed from the PDF');
  } catch (error) {
    showError(error);
    $('#inline-text')?.focus();
  }
}

function inspectorHeader(title, subtitle, symbol, eyebrow = 'YOUR WORKSPACE') {
  return `<div class="inspector-header"><div class="eyebrow">${escapeHTML(eyebrow)}</div><h2>${icon(symbol)}${escapeHTML(title)}</h2><p>${escapeHTML(subtitle)}</p></div>`;
}
// ------------------------------------------------------------ the panel layout
// One place decides what is on screen, so the menu bar, the panels and the page
// fit can never disagree with each other.
function applyToolRail() {
  const rail = $('#tool-rail');
  if (rail) rail.hidden = !state.showToolRail || state.view === 'home';
}

function applyPanelLayout() {
  const pages = $('#pages-panel');
  if (pages) pages.hidden = !state.showThumbnails;
  const rail = $('#inspector-rail');
  if (rail) rail.hidden = !state.showTools;
  // Home has its own copy of this list, so the document's is only ever on
  // screen with a document.
  applyToolRail();
  const menu = $('#menu-bar');
  if (menu) menu.classList.toggle('collapsed', state.menuCollapsed);
  const both = !state.showThumbnails && !state.showTools && !state.showToolRail;
  $('#canvas-area')?.classList.toggle('focus', both);
  const label = (id, pressed, text) => {
    const button = $('#' + id);
    if (!button) return;
    button.setAttribute('aria-pressed', String(pressed));
    button.title = text;
    button.setAttribute('aria-label', text);
  };
  label('toggle-thumbnails', state.showThumbnails,
        state.showThumbnails ? 'Hide the page thumbnails' : 'Show the page thumbnails');
  label('toggle-tools', state.showTools,
        state.showTools ? 'Hide the tools panel' : 'Show the tools panel');
  label('toggle-rail', state.showToolRail,
        state.showToolRail ? 'Hide the list of all tools' : 'Show the list of all tools');
  label('toggle-focus', both, both ? 'Show the panels again' : 'Hide the panels for the largest page');
  const collapse = $('#menu-collapse');
  if (collapse) {
    collapse.setAttribute('aria-expanded', String(!state.menuCollapsed));
    const text = state.menuCollapsed ? 'Show the menu' : 'Hide the menu';
    collapse.title = text;
    collapse.setAttribute('aria-label', text);
  }
  // The page is fitted to the width it actually has, so it has to be measured
  // again every time that changes.
  if (state.view !== 'pages') applyZoom();
}
function toggleThumbnails() {
  state.showThumbnails = !state.showThumbnails;
  applyPanelLayout();
  toast(state.showThumbnails
    ? 'Page thumbnails shown'
    : 'Page thumbnails hidden — the Pages view still shows every page');
}
function toggleTools() {
  state.showTools = !state.showTools;
  applyPanelLayout();
  toast(state.showTools ? 'Tools panel shown' : 'Tools panel hidden');
}
function toggleRail() {
  state.showToolRail = !state.showToolRail;
  applyPanelLayout();
  toast(state.showToolRail
    ? 'Tool list shown beside the document'
    : 'Tool list hidden — Home still has every tool');
}
// One press for the largest page: every panel away, including the tool list.
// Pressing it again brings the tools and the list back, because those are what
// somebody is most likely to want next.
function toggleFocus() {
  const hidden = !state.showThumbnails && !state.showTools && !state.showToolRail;
  state.showThumbnails = false;
  state.showTools = hidden;
  state.showToolRail = hidden;
  applyPanelLayout();
  toast(hidden ? 'Panels shown' : 'Nothing but the page — press again for the panels');
}
function toggleMenu() {
  state.menuCollapsed = !state.menuCollapsed;
  applyPanelLayout();
}

// ---------------------------------------------------- the right-hand tools panel
// The panel can be pinned open or left to auto-hide, and the choice is per
// session (nothing is written to disk, like every other preference here).
// Pinned is the default and is exactly the behaviour the interface always had.
function applyInspectorMode() {
  const rail = $('#inspector-rail');
  if (!rail) return;
  rail.classList.toggle('auto-hide', !state.inspectorPinned);
  rail.classList.toggle('peek', !!state.inspectorPeek);
  const pin = $('#inspector-pin');
  if (pin) {
    pin.setAttribute('aria-pressed', String(state.inspectorPinned));
    pin.title = pin.ariaLabel = state.inspectorPinned ? 'Auto-hide the tools panel' : 'Pin the tools panel open';
  }
  const tab = $('#inspector-tab');
  if (tab) tab.setAttribute('aria-expanded', String(state.inspectorPinned || state.inspectorPeek));
}
function toggleInspectorPin() {
  state.inspectorPinned = !state.inspectorPinned;
  state.inspectorPeek = false;
  // The button that was just pressed keeps focus, and a focused control inside
  // the rail would hold the panel open by itself. Drop focus so auto-hide means
  // auto-hide the moment the pointer leaves.
  $('#inspector-pin')?.blur();
  applyInspectorMode();
  toast(state.inspectorPinned ? 'Tools panel pinned open' : 'Tools panel will hide until you need it');
}
// Clicking the rail tab makes the reveal sticky, so the panel can be used
// without holding the pointer over the rail. Clicking away or pressing Escape
// puts it back.
function setInspectorPeek(value) {
  if (state.inspectorPeek === value) return;
  state.inspectorPeek = value;
  applyInspectorMode();
}
const privacyCard = () => isHostedPreview
  ? `<div class="privacy-card hosted-privacy">${icon('warning')}<div><strong>Hosted preview, not the offline app.</strong><p>Uploads leave your device and are processed in this hosted workspace. Use sample or non-sensitive files. Native desktop builds run locally.</p></div></div>`
  : `<div class="privacy-card">${icon('shield')}<div><strong>Your files stay yours.</strong><p>Everything is processed locally. Save writes over the file you opened; Save as puts the copy somewhere else and leaves the original alone.</p></div></div>`;
function quickTools() {
  return `<div class="section-label">ADD SOMETHING</div><div class="quick-tools"><button class="quick-tool" data-quick="text">${icon('text')}Text</button><button class="quick-tool" data-quick="date">${icon('calendar')}Date</button><button class="quick-tool" data-quick="image">${icon('image')}Image</button><button class="quick-tool" data-quick="signature">${icon('signature')}Signature</button><button class="quick-tool" data-quick="highlight">${icon('highlight')}Highlight</button><button class="quick-tool" data-quick="comment">${icon('comment')}Comment</button></div>`;
}
function documentStats() {
  const d = state.doc;
  return `<div class="inspector-divider"></div><div class="section-label">DOCUMENT OVERVIEW</div><div class="document-stats"><div><div class="stat-value">${d.pageCount}</div><div class="stat-label">Pages</div></div><div><div class="stat-value">${d.wordCount.toLocaleString()}</div><div class="stat-label">Words</div></div><div><div class="stat-value">${d.imageCount}</div><div class="stat-label">Images</div></div><div><div class="stat-value">${d.formCount}</div><div class="stat-label">Form fields</div></div></div>`;
}
function formatOptions(current, includePDF = false) {
  const formats = [...(includePDF ? [{id:'pdf',name:'PDF document',desc:'Your updated PDF',letter:'P',color:''}] : []),
    {id:'docx',name:'Word',desc:'Editable text & tables',letter:'W',color:'word'},
    {id:'xlsx',name:'Excel',desc:'Detected tables',letter:'X',color:'excel'},
    {id:'pptx',name:'PowerPoint',desc:'Page-image slides',letter:'P',color:'ppt'},
    {id:'images',name:'Images',desc:'PNG or JPG in a ZIP',letter:'I',color:'image'},
    {id:'txt',name:'Plain text',desc:'Extracted document text',letter:'T',color:''},
    ...(includePDF ? [{id:'split',name:'Split PDF',desc:'One PDF per page, ZIP',letter:'S',color:''}] : [])];
  return `<div class="format-list">${formats.map(f => `<button class="format-option${current === f.id ? ' active' : ''}" data-format="${f.id}"><span class="format-letter ${f.color}">${f.letter}</span><span><span class="format-name">${f.name}</span><span class="format-desc">${f.desc}</span></span><span class="radio-dot"></span></button>`).join('')}</div>`;
}
function formatNotice(format) {
  const messages = {
    pdf:'Edits are saved to a new PDF copy. Existing password protection is preserved.',
    docx:'Best-effort text, image, and table extraction. Fonts, reading order, and page layout may differ from the original.',
    xlsx:'Detects ruled or borderless tables. Check cells, percentages, and totals in the exported workbook. Run OCR first for scans.',
    pptx:'Each PDF page becomes a slide image. Appearance is preserved, but slide text and graphics are not individually editable.',
    images:'Renders the selected pages as images and packages them in a ZIP file. Annotations are included.',
    txt:'Extracts searchable text. Scanned pages need OCR first.',
    split:'Exports each selected page as a separate PDF inside a ZIP. For equal blocks of pages, a set number of files, or your own page ranges, use the Split button. Protected PDFs cannot be split.'
  };
  return messages[format] || '';
}
function rangeFields(prefix, selected = 'all') {
  return `<div class="field"><label for="${prefix}-range">Pages to include</label><select id="${prefix}-range"><option value="all"${selected === 'all' ? ' selected' : ''}>All ${state.doc.pageCount} pages</option><option value="current"${selected === 'current' ? ' selected' : ''}>Current page (${state.page + 1})</option><option value="custom"${selected === 'custom' ? ' selected' : ''}>Custom page range</option></select></div><div class="field" id="${prefix}-custom-field"${selected === 'custom' ? '' : ' hidden'}><label for="${prefix}-custom">Page range</label><input id="${prefix}-custom" placeholder="e.g. 1-3, 5" autocomplete="off"><p class="help-text">Use page numbers, commas, and inclusive ranges.</p></div>`;
}
function exportSettings(format, prefix) {
  if (format === 'xlsx') return `<div class="field"><label for="${prefix}-table">Table detection</label><select id="${prefix}-table"><option value="lines">Ruled tables (visible borders)</option><option value="text">Borderless tables (text alignment)</option></select></div>`;
  if (format === 'images') return `<div class="field-row"><div class="field"><label for="${prefix}-image-format">Image format</label><select id="${prefix}-image-format"><option value="png">PNG</option><option value="jpg">JPG</option></select></div><div class="field"><label for="${prefix}-dpi">Resolution</label><select id="${prefix}-dpi"><option value="150">150 DPI</option><option value="300">300 DPI</option><option value="72">72 DPI</option></select></div></div>`;
  return '';
}

// ---------------------------------------------------------------- AI reading
// Two very different things live behind this panel, and the interface never
// blurs them. The offline reading quotes sentences that are already in the
// document, chosen by word frequency; it is not a language model and says so on
// every result. A model is used only if somebody connects one, and then every
// result is labelled with the model that produced it.
function aiModel() { return state.ai.status?.model || {}; }
function aiMode() { return aiModel().configured ? 'model' : 'offline'; }
function aiModelLabel() {
  const model = aiModel();
  if (!model.configured) return 'offline reading';
  let host = model.endpoint || '';
  try { host = new URL(model.endpoint).host; } catch { /* a bare address is fine */ }
  return `${model.model} at ${host}`;
}
async function refreshAiStatus() {
  try { state.ai.status = await api('/ai/status'); }
  catch { state.ai.status = null; }
}
// The one thing that must be asked before anything leaves the computer. Answered
// once per session, and only ever on the way to a model call.
async function confirmModelUse() {
  if (aiMode() !== 'model' || state.ai.consented) return true;
  const agreed = await confirmDialog('Send this document to the model?',
    `The text of this document will be sent to ${aiModelLabel()} to be read there. Only the extracted text is sent — never the file — and it does leave this computer. The offline reading always stays available and needs no connection.`,
    'Send it to the model');
  if (agreed) state.ai.consented = true;
  return agreed;
}
function aiFieldKind(field) {
  if (field.kind === 'date') return 'date field';
  if (field.kind === 'checkbox') return 'checkbox';
  if (field.kind === 'dropdown') return `dropdown: ${(field.choices || []).join(', ')}`;
  return 'text field';
}
function aiModeStrip() {
  const model = aiModel();
  return `<div class="ai-mode${model.configured ? ' connected' : ''}"><span class="ai-dot"></span><div>
      <strong>${model.configured ? 'Model connected' : 'Offline reading'}</strong>
      <span>${model.configured
        ? `${escapeHTML(aiModelLabel())} — its text is sent there when you use it.`
        : 'Everything runs on this computer. Nothing is sent anywhere.'}</span>
    </div><button class="button secondary small" id="ai-connect">${model.configured ? 'Change' : 'Connect a model'}</button></div>`;
}
function aiResultHTML() {
  const result = state.ai.summary;
  if (!result) return '';
  return `<div class="ai-result"><div class="ai-result-head">
      <span class="ai-tag ${result.mode}">${result.mode === 'offline' ? 'Offline' : 'Model'}</span>
      <span>${escapeHTML(result.mode === 'offline' ? 'quoted from this document' : (result.model || ''))}</span>
    </div><p>${escapeHTML(result.summary)}</p>
    ${(result.keywords || []).length ? `<div class="ai-keywords">${result.keywords.map(word => `<span>${escapeHTML(word)}</span>`).join('')}</div>` : ''}
    <div class="inline-note">${icon('info')}<span>${result.mode === 'offline'
      ? `${result.selected} of ${result.sentenceCount} sentences, chosen by word frequency and quoted as they stand. It does not paraphrase, and it cannot answer questions.`
      : `Written by ${escapeHTML(result.model || 'the connected model')} from this document’s text.`}</span></div></div>`;
}
function aiFieldsHTML() {
  const fields = state.ai.fields;
  if (!fields?.length) return '';
  return `<div class="ai-fields">${fields.map(field => `<div class="ai-field"><strong>${escapeHTML(field.label)}</strong><span>${escapeHTML(aiFieldKind(field))}</span></div>`).join('')}</div>
    <button class="button primary full" id="ai-add-fields">${icon('plus')}Add ${fields.length === 1 ? 'this field' : `these ${fields.length} fields`} to a new page</button>
    <div class="inline-note">${icon('info')}<span>A new page is added at the end and the fields are laid out on it, as one undoable step.</span></div>`;
}
function aiPanel() {
  const d = state.doc;
  const offline = aiMode() === 'offline';
  const body = `${aiModeStrip()}
    <div class="section-label">SUMMARISE</div>
    <div class="field"><label for="ai-sentences">Length</label><select id="ai-sentences">${[3, 5, 8].map(n => `<option value="${n}"${state.ai.sentences === n ? ' selected' : ''}>${n} sentences</option>`).join('')}</select></div>
    ${rangeFields('ai')}
    <button class="button primary full" id="ai-summarise"${!d.canCopy ? ' disabled' : ''}>${icon('spark')}Summarise this PDF</button>
    ${aiResultHTML()}
    <div class="section-label">BUILD A FORM FROM A PROMPT</div>
    <div class="field"><label for="ai-prompt">Describe the fields</label><textarea id="ai-prompt" rows="3" placeholder="full name, email, date signed, and a checkbox to agree to the terms">${escapeHTML(state.ai.prompt)}</textarea><p class="help-text">${offline
      ? 'Plain words. Read here, with no model involved.'
      : 'Plain words. The connected model designs the fields.'}</p></div>
    <button class="button primary full" id="ai-propose"${!d.canEdit ? ' disabled' : ''}>${icon('form')}Propose fields</button>
    ${aiFieldsHTML()}
    <div class="inline-note">${icon('shield')}<span>${offline
      ? 'Nothing here uses a network. The offline reading is ordinary text analysis, not a language model.'
      : 'The document’s text is sent to the connected model when you use it. Disconnect at any time to go back to the offline reading.'}</span></div>`;
  return {heading: inspectorHeader('Read it for you.', 'Summarise this document, or build a form from a sentence.', 'spark', 'AI READING'), body};
}

async function runAiSummary() {
  if (!state.doc) return;
  const mode = aiMode();
  if (!await confirmModelUse()) return;
  try {
    const pages = readPageRange('ai');
    const result = await busy(mode === 'model' ? 'Asking the model…' : 'Reading the document…',
      () => api(docPath('/ai/summary'), {method:'POST', json:{mode, sentences: state.ai.sentences, pages}}),
      mode === 'model' ? 'The document’s text is being sent to the connected model.' : 'Nothing leaves this computer.');
    state.ai.summary = result;
    renderInspector();
    toast(result.mode === 'offline' ? 'Offline summary ready' : `Summary written by ${result.model}`);
  } catch (error) { showError(error); }
}
async function runAiForm() {
  if (!state.doc) return;
  const typed = ($('#ai-prompt')?.value || state.ai.prompt || '').trim();
  if (!typed) { toast('Describe the fields you want first.', true); return; }
  state.ai.prompt = typed;
  const mode = aiMode();
  if (!await confirmModelUse()) return;
  try {
    const result = await busy(mode === 'model' ? 'Asking the model…' : 'Reading your words…',
      () => api(docPath('/ai/form'), {method:'POST', json:{mode, prompt: typed}}),
      mode === 'model' ? 'Your prompt and the document’s text are being sent to the connected model.' : 'Nothing leaves this computer.');
    state.ai.fields = result.fields;
    renderInspector();
    toast(`${result.fields.length} field${result.fields.length === 1 ? '' : 's'} proposed`);
  } catch (error) { showError(error); }
}
async function applyAiFields() {
  const fields = state.ai.fields;
  if (!fields?.length) return;
  const page = state.doc ? state.doc.pageCount : 0;      // the new page's index
  try {
    await perform({action:'add_fields', fields, newPage:true}, 'Building the form…', {page});
    state.ai.fields = null;
    renderInspector();
    toast(`${fields.length} field${fields.length === 1 ? '' : 's'} added to a new page`);
  } catch (error) { showError(error); }
}
function showConnectModelDialog() {
  const model = aiModel();
  const connected = !!model.configured;
  const dialog = openModal('Connect a model.',
    'Optional. Without one, everything in this panel runs on this computer.',
    `<div class="field"><label for="ai-endpoint">Endpoint address</label><input id="ai-endpoint" value="${escapeHTML(model.endpoint || '')}" placeholder="https://api.openai.com/v1" autocomplete="off"><p class="help-text">An OpenAI-compatible address. “/chat/completions” is added if you leave it off.</p></div>
     <div class="field"><label for="ai-model">Model name</label><input id="ai-model" value="${escapeHTML(model.model || '')}" placeholder="gpt-4o-mini" autocomplete="off"></div>
     <div class="field"><label for="ai-key">API key</label><input id="ai-key" type="password" autocomplete="off" placeholder="${connected ? 'Leave blank to keep the key already set' : 'Your own key'}"><p class="help-text">Kept in memory for this session only. It is never written to disk and never shown again.</p></div>
     <div class="notice"><strong>This is the one part of KADOMA that can leave your computer.</strong> When you use the model, this document’s extracted text is sent to the address above — never the file itself. Nothing is sent until you agree to it, and the offline reading always stays available.</div>`,
    `<button class="button secondary" data-close>Cancel</button>${connected ? '<button class="button danger-ghost" id="ai-disconnect">Disconnect</button>' : ''}<button class="button primary" id="ai-save">Connect</button>`, 540);
  $('#ai-save').addEventListener('click', async () => {
    try {
      const json = {mode:'model', endpoint:$('#ai-endpoint').value, model:$('#ai-model').value};
      // A blank key field means "keep the one already set", so the key never has
      // to be typed again — and never has to be shown again either.
      const key = $('#ai-key').value;
      if (key) json.apiKey = key;
      state.ai.status = await api('/ai/configure', {method:'POST', json});
      state.ai.consented = false;
      dialog.close();
      renderInspector();
      toast('Model connected. It is used only when you choose it.');
    } catch (error) { modalError(error); }
  });
  $('#ai-disconnect')?.addEventListener('click', async () => {
    try {
      state.ai.status = await api('/ai/configure', {method:'POST', json:{mode:'off'}});
      state.ai.consented = false;
      dialog.close();
      renderInspector();
      toast('Model disconnected — back to the offline reading');
    } catch (error) { modalError(error); }
  });
}

// The markup the inspector is currently showing, so an identical render can be
// skipped rather than rebuilt. See the comment in renderInspector.
let inspectorMarkup = '';

function renderInspector() {
  if (!state.doc) return;
  const pane = $('#inspector'), d = state.doc;
  let heading, body = '';
  if (state.searchQuery) {
    heading = inspectorHeader('Find in document', 'Search runs against the text inside this PDF, entirely offline.', 'search', 'LOCAL SEARCH');
    body = `<div class="section-label">${state.searchMatches.length} MATCH${state.searchMatches.length === 1 ? '' : 'ES'}</div>${state.searchMatches.length ? state.searchMatches.map((match,i) => `<button class="search-match${i === state.searchIndex ? ' active' : ''}" data-match="${i}"><span>Page ${match.page + 1}</span>${escapeHTML(match.text || state.searchQuery)}</button>`).join('') : '<div class="empty-state">No matching text found. If this is a scanned document, run OCR to make it searchable.</div>'}<button class="button ghost full" id="clear-search">${icon('close')}Clear search</button>`;
  } else if (state.view === 'pages') {
    heading = inspectorHeader('Every page in its place.', 'Small changes that make a document easier to work with.', 'pages', 'ORGANIZE PDF');
    body = `<div class="tool-callout">${icon('pages')}<h3>${state.selectedPages.size} ${state.selectedPages.size === 1 ? 'page' : 'pages'} selected</h3><p>Use the toolbar to rotate, duplicate, delete, or extract selected pages. Drag any preview to change its position.</p></div><div class="section-label">QUICK ACTIONS</div><div class="inline-actions"><button class="button secondary" id="organizer-select-all">Select all</button><button class="button secondary" id="organizer-clear">Clear</button></div><button class="button primary full" id="organizer-extract"${!state.selectedPages.size ? ' disabled' : ''}>${icon('download')}Export selected pages</button>${documentStats()}<div class="inline-note">${icon('info')}<span>Duplicate copies are added to the end. Copied form fields get unique names and independent values.</span></div>`;
  } else if (state.view === 'convert') {
    heading = inspectorHeader('A new format. Same story.', 'Make your PDF useful in the tools you use every day.', 'convert', 'CONVERT PDF');
    body = formatOptions(state.convertFormat) + rangeFields('convert') + exportSettings(state.convertFormat,'convert') + `<div class="notice purple">${escapeHTML(formatNotice(state.convertFormat))}</div><button class="button primary full" id="convert-export"${!d.canCopy ? ' disabled' : ''}>${icon('download')}Export ${state.convertFormat.toUpperCase() === 'IMAGES' ? 'images' : state.convertFormat.toUpperCase()}</button>`;
  } else if (state.view === 'ocr') {
    heading = inspectorHeader('Give scans a voice.', 'Turn scanned pages into searchable PDFs using local text recognition.', 'scan', 'OPTICAL CHARACTER RECOGNITION');
    const ready = state.capabilities.tesseract;
    body = `<div class="dependency-status${ready ? ' ready' : ''}"><span class="dependency-dot"></span>Tesseract ${ready ? (isHostedPreview ? 'available in demo workspace' : 'available on this device') : (isHostedPreview ? 'not installed in demo workspace' : 'not installed on this device')}</div>${!ready ? '<div class="notice"><strong>A local engine is needed.</strong>Install Tesseract and the languages you need. No document data is sent to a service.</div><button class="button secondary full" id="ocr-setup">View setup instructions</button><div class="inspector-divider"></div>' : ''}<div class="field"><label for="ocr-language">OCR language codes</label><input id="ocr-language" value="${escapeHTML((state.capabilities.ocrLanguages || []).includes('eng') ? 'eng' : (state.capabilities.ocrLanguages || []).filter(x => x !== 'osd')[0] || 'eng')}" placeholder="eng or eng+ara"><p class="help-text">Installed: ${escapeHTML((state.capabilities.ocrLanguages || []).join(', ') || 'none detected')}. Use + to combine languages.</p></div>${rangeFields('ocr','current')}<div class="notice purple"><strong>Creates searchable raster pages.</strong>Selected pages are rendered at 200 DPI. Annotations and form appearances are flattened into those pages; original vector text is replaced. Maximum 20 pages per run.</div><button class="button primary full" id="run-ocr"${!ready || !d.canEdit ? ' disabled' : ''}>${icon('scan')}Recognize text</button>`;
  } else if (state.view === 'ai') {
    const panel = aiPanel();
    heading = panel.heading;
    body = panel.body;
  } else if (state.view === 'protect' && state.tool !== 'redact') {
    heading = inspectorHeader('Keep it confidential.', 'Protect access to an exported copy with AES-256 encryption.', 'lock', 'DOCUMENT SECURITY');
    body = `<div class="field"><label for="open-password">Opening password</label><input id="open-password" type="password" placeholder="At least 6 characters" autocomplete="new-password"></div><div class="field"><label for="owner-password">Owner password</label><input id="owner-password" type="password" placeholder="Different, at least 8 characters" autocomplete="new-password"><p class="help-text">The owner password controls permissions. Keep both passwords somewhere safe.</p></div><div class="inspector-divider"></div><div class="section-label">ALLOW IN THE EXPORTED COPY</div><label class="check-row"><input id="allow-print" type="checkbox" checked><span>Printing</span></label><label class="check-row"><input id="allow-copy" type="checkbox"><span>Text and image copying</span></label><label class="check-row"><input id="allow-edit" type="checkbox"><span>Editing, annotations, and form filling</span></label><button class="button primary full" id="protect-export"${!d.owner ? ' disabled' : ''}>${icon('lock')}Export protected PDF</button><div class="inline-note">${icon('info')}<span>Permissions depend on the PDF reader and are not a guarantee against copying. Encryption protects opening the file. Use redaction to remove sensitive content.</span></div><button class="button ghost full" id="start-redact">${icon('redact')}Use the redaction tool</button>`;
  } else if (state.tool === 'redact') {
    heading = inspectorHeader('Remove it. For real.', 'Permanently remove underlying content, not just cover it with a black box.', 'redact', 'SECURE REDACTION');
    body = `<div class="tool-callout">${icon('redact')}<h3>${state.selection ? 'Area selected' : 'Select sensitive content'}</h3><p>Drag a rectangle over the text, image, or graphics you want to remove.</p></div><div class="field"><label for="redact-color">Redaction fill</label><input id="redact-color" type="color" value="#111111"></div><div class="notice error"><strong>This action clears undo history.</strong>Content and overlapping fields/comments are removed. Attachments, JavaScript, and metadata are stripped. Nothing is written to disk until you save.</div><button class="button danger full" id="apply-redaction"${!state.selection || !d.canEdit ? ' disabled' : ''}>${icon('redact')}Apply permanent redaction</button><div class="inline-note">${icon('info')}<span>Export and inspect the redacted copy before sharing it. Hidden information outside the selected area may need additional redaction.</span></div>`;
  } else if (state.tool.startsWith('field-')) {
    heading = inspectorHeader('Make it fillable.', 'Create real PDF form fields that work in compatible readers.', 'form', 'FORM CREATION');
    const selected = state.selection?.kind === 'field';
    body = `<div class="tool-callout">${icon('form')}<h3>${selected ? 'Field area selected' : 'Draw a field area'}</h3><p>Drag a rectangle on the page, give your field a unique name, and add it to the PDF.</p></div><div class="field"><label for="field-name">Field name</label><input id="field-name" value="${escapeHTML(state.selection?.fieldName || state.fieldNameDraft || `field_${d.formCount + 1}`)}" placeholder="e.g. reviewer_name" maxlength="80"></div><div class="field"><label for="field-type">Field type</label><select id="field-type"><option value="text"${state.fieldType === 'text' ? ' selected' : ''}>Text field</option><option value="date"${state.fieldType === 'date' ? ' selected' : ''}>Date field (calendar picker)</option><option value="checkbox"${state.fieldType === 'checkbox' ? ' selected' : ''}>Checkbox</option><option value="dropdown"${state.fieldType === 'dropdown' ? ' selected' : ''}>Dropdown list</option></select></div><div class="field" id="field-date-wrap"${state.fieldType === 'date' ? '' : ' hidden'}><label for="field-date-format">Date format</label><select id="field-date-format">${['YYYY-MM-DD', 'DD/MM/YYYY', 'MM/DD/YYYY', 'DD.MM.YYYY'].map(f => `<option value="${f}"${state.dateFormat === f ? ' selected' : ''}>${f}</option>`).join('')}</select></div><div class="field" id="field-choices-wrap"${state.fieldType === 'dropdown' ? '' : ' hidden'}><label for="field-choices">Dropdown options</label><textarea id="field-choices" placeholder="One option per line">Pending\nApproved\nNeeds changes</textarea></div><button class="button primary full" id="create-field"${!selected ? ' disabled' : ''}>${icon('plus')}Add form field</button><div class="inline-note">${icon('calendar')}<span>A date field is a real PDF field that carries its own format, and it opens a calendar to pick from instead of making you type. It stores the date as text, so any PDF reader can display it.</span></div>`;
  } else if (state.view === 'forms' && state.tool === 'fill') {
    heading = inspectorHeader('A few fields. All done.', 'Fill fields on this page, then export your completed document.', 'form', 'FILL PDF FORMS');
    const widgets = state.content?.widgets || [];
    // Values typed into these fields are held in `state.formDraft` as well as in
    // the input, so an unrelated re-render of the panel cannot silently throw
    // away something the person has already typed but not yet applied.
    const draft = state.formDraft;
    body = widgets.length ? `<div class="section-label">${widgets.length} FIELD${widgets.length === 1 ? '' : 'S'} ON PAGE ${state.page + 1}</div>${widgets.map(w => {
      const id = `fill-${w.xref}`;
      const value = draft[w.xref] !== undefined ? draft[w.xref] : (w.value || '');
      if (w.readOnly) return `<div class="notice">${escapeHTML(w.label)} is a read-only form field.</div>`;
      if (w.type === 2) return `<label class="check-row"><input id="${id}" data-field-xref="${w.xref}" type="checkbox"${value && value !== 'Off' ? ' checked' : ''}><span>${escapeHTML(w.label)}</span></label>`;
      if (w.type === 3 || w.type === 4) return `<div class="field"><label for="${id}">${escapeHTML(w.label)}</label><select id="${id}" data-field-xref="${w.xref}">${w.choices.map(c => `<option${c === value ? ' selected' : ''}>${escapeHTML(c)}</option>`).join('')}</select></div>`;
      // A date field is a text field underneath, so this has to be tested before
      // the plain text case below or it would render as an ordinary text box.
      if (w.kind === 'date') return `<div class="field date-field"><label for="${id}">${escapeHTML(w.label)}</label><div class="date-row"><input id="${id}" data-field-xref="${w.xref}" data-date-format="${escapeHTML(w.dateFormat || 'YYYY-MM-DD')}" value="${escapeHTML(value)}" placeholder="${escapeHTML(w.dateFormat || 'YYYY-MM-DD')}" autocomplete="off"><button type="button" class="icon-button small date-picker-button" data-calendar="${id}" title="Pick a date from a calendar" aria-label="Pick a date for ${escapeHTML(w.label)}"><svg><use href="#i-calendar"/></svg></button></div></div>`;
      if (w.type === 7) return `<div class="field"><label for="${id}">${escapeHTML(w.label)}</label><input id="${id}" data-field-xref="${w.xref}" value="${escapeHTML(value)}"></div>`;
      return `<div class="notice">${escapeHTML(w.label)}: this field type is read-only in KADOMA.</div>`;
    }).join('')}<button class="button primary full" id="save-form-values"${!d.canFill ? ' disabled' : ''}>${icon('check')}Apply field values</button>` : `<div class="tool-callout">${icon('form')}<h3>No fields on this page</h3><p>Use Text field, Date field, Checkbox, or Dropdown in the toolbar to make this PDF fillable.</p></div><button class="button secondary full" id="new-text-field">${icon('plus')}Create a text field</button>${d.formCount ? '<div class="inline-note">'+icon('info')+'<span>There are existing form fields on other pages — use the page arrows to find them.</span></div>' : ''}`;
    body += `<div class="inspector-divider"></div><button class="button secondary full" id="form-signature">${icon('signature')}Add a visual signature</button><div class="inline-note">${icon('info')}<span>Visual signatures are not cryptographic digital signatures. Certificate signing and signature requests are not included.</span></div>`;
  } else if (state.pendingImage && ['image','signature'].includes(state.tool)) {
    heading = inspectorHeader(state.tool === 'signature' ? 'Make your mark.' : 'Picture a better document.', 'Your selected image is ready to place on this page.', state.tool === 'signature' ? 'signature' : 'image');
    body = `<div class="file-chip">${escapeHTML(state.pendingImage.name)}</div><div class="tool-callout" style="margin-top:17px">${icon(state.tool === 'signature' ? 'signature' : 'image')}<h3>Drag to place</h3><p>Draw a rectangle on the page. The image keeps its proportions inside your chosen area.</p></div><button class="button secondary full" id="cancel-image">Cancel placement</button>${state.tool === 'signature' ? '<div class="inline-note">'+icon('info')+'<span>This is a visual signature image, not a certificate-based digital signature.</span></div>' : ''}`;
  } else if (state.selection?.kind === 'image') {
    heading = inspectorHeader('A fresh perspective.', 'Replace or remove this embedded PDF image.', 'image', 'IMAGE SELECTED');
    body = `<span class="selected-tag">${icon('image')}Embedded image</span><div class="document-stats"><div><div class="stat-value">${state.selection.width}px</div><div class="stat-label">Width</div></div><div><div class="stat-value">${state.selection.height}px</div><div class="stat-label">Height</div></div></div><button class="button primary full" id="replace-image"${state.selection.xref <= 0 || !d.canEdit ? ' disabled' : ''}>${icon('image')}Replace image</button><button class="button danger-ghost full" id="delete-image"${state.selection.xref <= 0 || !d.canEdit ? ' disabled' : ''}>${icon('trash')}Delete image</button><div class="notice">Replacing or deleting an image affects every use of that same embedded image in the document. Inline images cannot be replaced independently.</div>`;
  } else if (state.selection && ['edit','text'].includes(state.tool)) {
    // On a scan the box is not a text selection, and calling it one would be a
    // small lie in the one place the person is looking for the truth.
    heading = inspectorHeader(state.selection?.scan ? 'Change what the page says.' : state.tool === 'edit' ? 'Fine-tune the details.' : 'Put it into words.',
      state.selection?.scan ? 'The words under the box are ink, not text. They are painted over and your text is written in their place.'
        : state.tool === 'edit' ? 'Replace selected text directly in the PDF.' : 'Add text inside your selected area.',
      'text', state.selection?.scan ? 'SCAN SELECTED' : state.tool === 'edit' ? 'TEXT SELECTED' : 'NEW TEXT AREA');
    const s = state.selection;
    const editing = state.tool === 'edit';
    // On a page that is a picture, there is no text under the box to replace:
    // the ink is pixels, so it is painted over first. Saying that is the
    // difference between a tool people trust and one they think did nothing.
    const note = s.scan
      ? 'This page is a picture, so the old words are painted over with the page colour and the new text is written on top. Nothing underneath survives — keep a copy of the original if you may need it. Leave the box empty to erase an area.'
      : editing
        ? `The text on the page is editable in place too — click it and type. Original font: ${escapeHTML(s.originalFont || 'unknown')}. The replacement uses the selected family, grows into free space, or shrinks to fit. Whole-document reflow is not supported.`
        : 'Text may shrink to fit your area. Draw a larger area for longer passages.';
    body = `<span class="selected-tag">${icon('edit')}Page ${state.page + 1} · ${s.scan ? 'Scan selection' : editing ? 'Text selection' : 'New text'}</span><div class="field"><label for="edit-text-value">Text</label><textarea id="edit-text-value" rows="4">${escapeHTML(s.text || '')}</textarea></div><div class="field-row"><div class="field"><label for="text-font">Font family</label><select id="text-font"><option value="sans-serif"${s.family === 'sans-serif' ? ' selected' : ''}>Sans serif</option><option value="serif"${s.family === 'serif' ? ' selected' : ''}>Serif</option><option value="monospace"${s.family === 'monospace' ? ' selected' : ''}>Monospace</option></select></div><div class="field"><label for="text-size">Size (pt)</label><input id="text-size" type="number" min="6" max="96" step=".5" value="${s.size || 12}"></div></div><div class="field"><label for="text-color">Text color</label><input id="text-color" type="color" value="${s.color || '#292b3d'}"></div><button class="button primary full" id="apply-text">${icon('check')}${editing ? 'Apply changes' : 'Add text'}</button>${editing ? `<button class="button danger-ghost full" id="delete-text">${icon('trash')}${s.scan ? 'Erase this area' : 'Delete this text'}</button>` : ''}<div class="inline-note">${icon('info')}<span>${note}</span></div>`;
  } else if (state.tool === 'date' && state.pendingDate) {
    heading = inspectorHeader('Stamp the date.', 'One click puts it on the page, where you click.', 'calendar', 'DATE READY');
    body = `<div class="tool-callout">${icon('calendar')}<h3>${escapeHTML(state.pendingDate.text)}</h3><p>Click on the page to place it. It is written as real text, so it can be selected and searched — and it works on a scan, where there is nothing to edit.</p></div><button class="button secondary full" id="date-change">${icon('calendar')}Change the date</button><button class="button ghost full" id="date-cancel">Stop placing dates</button><div class="inline-note">${icon('info')}<span>${state.pendingDate.size} pt · placed in the colour you chose. Choose another tool to stop.</span></div>`;
  } else if (state.view === 'document') {
    heading = inspectorHeader('The page furniture.', 'Headers, watermarks, numbers, bookmarks, attachments and file size.', 'layers', 'DOCUMENT TOOLS');
    body = renderDocumentTools();
  } else if (state.tool === 'stamp' && state.pendingStamp) {
    heading = inspectorHeader('Mark the document.', 'One click puts the stamp where you click.', 'shield', 'STAMP READY');
    body = `<div class="tool-callout">${icon('shield')}<h3>${escapeHTML(state.pendingStamp.text)}</h3><p>Click on the page to place it. The stamp is drawn into the page, in the colour you chose${state.pendingStamp.date ? ', with today’s date underneath' : ''}.</p></div><button class="button secondary full" id="stamp-change">${icon('shield')}Choose another stamp</button><button class="button ghost full" id="stamp-stop">Stop stamping</button>`;
  } else if (state.tool === 'view') {
    heading = inspectorHeader('Just the document.', 'Open for reading. Nothing is armed until you choose a tool.', 'eye', 'READING VIEW');
    body = `<div class="tool-callout"><span class="callout-shortcut">Esc</span>${icon('eye')}<h3>Reading view</h3><p>The page is shown as it is: no text boxes, no cursors, nothing waiting to be clicked. Pick a tool in the toolbar to change something, or double-click any line to edit it straight away.</p></div>${scannedNotice()}${d.canEdit ? quickTools() : ''}${documentStats()}${d.canEdit ? '' : '<div class="notice">This PDF restricts editing. Reopen it with the owner password to make changes.</div>'}`;
  } else if (state.tool === 'comment') {
    heading = inspectorHeader('Leave a little context.', 'Click a point on the page, then write your comment.', 'comment', 'PDF ANNOTATIONS');
    body = `<div class="tool-callout">${icon('comment')}<h3>Click to add a comment</h3><p>Comments are stored inside the PDF and travel with your exported copy.</p></div><div class="section-label">ON THIS PAGE</div>${annotationList()}`;
  } else if (state.tool === 'highlight') {
    heading = inspectorHeader('Make the important stand out.', 'Drag across a sentence or region to add a PDF highlight.', 'highlight', 'PDF ANNOTATIONS');
    body = `<div class="tool-callout">${icon('highlight')}<h3>Drag to highlight</h3><p>A translucent highlight is added to your document, without altering its text.</p></div><div class="field"><label for="highlight-color">Highlight color</label><input id="highlight-color" type="color" value="#f5ce58"></div><div class="section-label">ON THIS PAGE</div>${annotationList()}`;
  } else {
    heading = inspectorHeader('Make it yours.', 'A few thoughtful edits can make all the difference.', 'edit', 'EDIT PDF');
    const callout = state.tool === 'text' ? {icon:'text',title:'Draw a text area',text:'Drag a rectangle on the page, then enter your text in this panel.',shortcut:'T'} : state.tool === 'view' ? {icon:'eye',title:'Reading view',text:'Nothing is armed. Choose a tool to change the document.',shortcut:'Esc'} : state.tool === 'select' ? {icon:'select',title:'Choose your next move',text:'Select an embedded image, or switch to Edit text to change the words on this page.',shortcut:'V'} : {icon:'edit',title:'Edit text, right here.',text:'Click any text on the page. Adjust the wording, size, and color, then apply your changes.',shortcut:'E'};
    body = `<div class="tool-callout"><span class="callout-shortcut">${callout.shortcut}</span>${icon(callout.icon)}<h3>${callout.title}</h3><p>${callout.text}</p></div>${scannedNotice()}${!d.canEdit ? '<div class="notice">This PDF restricts editing. Reopen it with the owner password to make changes.</div>' : ''}${quickTools()}${documentStats()}`;
  }
  const markup = heading + `<div class="inspector-content">${body}</div>` + privacyCard();
  // Rebuilding identical markup destroys and recreates the panel, and a press
  // that lands mid-rebuild is silently lost: the press and the release end up
  // on different nodes, so the browser never fires a click. The panel is
  // rendered twice on every page change — once straight away, once when the
  // page image and its content arrive — so this is not a rare coincidence.
  // Skipping the rebuild also stops the flicker and keeps anything typed into
  // the panel from being wiped by an unrelated re-render.
  if (markup === inspectorMarkup) return;
  inspectorMarkup = markup;
  pane.innerHTML = markup;
  bindInspector();
}
function annotationList() {
  const annotations = state.content?.annotations || [];
  return annotations.length ? `<div class="annotation-list">${annotations.map(a => `<div class="annotation-card"><span class="annotation-title">${icon(a.type === 'Highlight' ? 'highlight' : 'comment')}${escapeHTML(a.type)} · ${escapeHTML(a.author)}</span><p>${escapeHTML(a.content || 'Highlighted area')}</p><button class="icon-button" data-delete-annotation="${a.xref}" title="Remove annotation" aria-label="Remove annotation">${icon('close')}</button></div>`).join('')}</div>` : '<div class="empty-state">No annotations here yet. Add a highlight or a comment to get started.</div>';
}
function bind(id, event, callback) { const element = $('#' + id); if (element) element.addEventListener(event, callback); }function bindRange(prefix) {
  bind(`${prefix}-range`, 'change', () => { $(`#${prefix}-custom-field`).hidden = $(`#${prefix}-range`).value !== 'custom'; });
}
function bindInspector() {
  const pane = $('#inspector');
  $$('[data-quick]', pane).forEach(button => button.addEventListener('click', () => chooseTool(button.dataset.quick)));
  $$('[data-doc-tool]', pane).forEach(button => button.addEventListener('click', () => openDocumentTool(button.dataset.docTool)));
  $$('[data-format]', pane).forEach(button => button.addEventListener('click', () => { state.convertFormat = button.dataset.format; renderInspector(); }));
  $$('[data-match]', pane).forEach(button => button.addEventListener('click', () => {
    state.searchIndex = Number(button.dataset.match);
    setPage(state.searchMatches[state.searchIndex].page);
  }));
  $$('[data-delete-annotation]', pane).forEach(button => button.addEventListener('click', () => {
    perform({action:'delete_annotation',page:state.page,xref:Number(button.dataset.deleteAnnotation)}, 'Removing annotation…').then(() => toast('Annotation removed')).catch(showError);
  }));
  bind('clear-search','click', () => { clearSearch(); renderInspector(); renderOverlay(); });
  bind('apply-text','click', applyText);
  bind('delete-text','click', deleteSelectedText);
  for (const [id,key] of [['edit-text-value','text'],['text-font','family'],['text-size','size'],['text-color','color']]) {
    bind(id,'input', event => {
      const value = key === 'size' ? Number(event.target.value) : event.target.value;
      if (state.selection) state.selection[key] = value;
      if (!state.inline) return;
      // Keep the on-page editor and this panel showing the same edit.
      if (key === 'text') $('#inline-text').textContent = value;
      else state.inline[key] = value;
      if (key === 'family') $('#inline-family').value = value;
      if (key === 'size') $('#inline-size').value = value;
      if (key === 'color') $('#inline-color').value = value;
      renderInlineEditor();
    });
  }
  bind('cancel-image','click', () => { state.pendingImage = null; state.tool = 'view'; renderToolbar(); renderInspector(); renderOverlay(); });
  // From "this page is a scan" to editable text in one press.
  bind('scan-this-page','click', makePageEditable);
  bind('date-change','click', showDateDialog);
  bind('stamp-change','click', showStampDialog);
  bind('stamp-stop','click', () => chooseTool('view'));
  bind('date-cancel','click', () => chooseTool('view'));
  bind('replace-image','click', async () => {
    if (await confirmDialog('Replace this image?', 'Every use of this embedded image will be updated, including appearances on other pages.', 'Choose replacement')) {
      state.imageReplaceXref = state.selection.xref;
      $('#image-input').value = ''; $('#image-input').click();
    }
  });
  bind('delete-image','click', async () => {
    if (await confirmDialog('Delete this image?', 'This removes every use of this embedded image in the PDF. It is not a substitute for confidential-data redaction.', 'Delete image', true)) {
      perform({action:'delete_image',page:state.page,xref:state.selection.xref}, 'Removing image…').then(() => toast('Image removed')).catch(showError);
    }
  });
  bind('convert-export','click', async () => {
    try { await exportDocument(state.convertFormat, readExportOptions('convert',state.convertFormat)); } catch (error) { showError(error); }
  });
  bindRange('convert'); bindRange('ocr');
  bind('protect-export','click', async () => {
    try {
      await exportDocument('protected', {openPassword:$('#open-password').value,ownerPassword:$('#owner-password').value,
        allowPrinting:$('#allow-print').checked,allowCopying:$('#allow-copy').checked,allowEditing:$('#allow-edit').checked});
      $('#open-password').value = ''; $('#owner-password').value = '';
    } catch (error) { showError(error); }
  });
  bind('start-redact','click', () => chooseTool('redact'));
  bind('apply-redaction','click', applyRedaction);
  bind('field-type','change', event => {
    state.fieldType = event.target.value;
    state.tool = 'field-' + state.fieldType;
    $('#field-choices-wrap').hidden = state.fieldType !== 'dropdown';
    $('#field-date-wrap').hidden = state.fieldType !== 'date';
    renderToolbar(); renderOverlay();
  });
  bind('field-date-format','change', event => { state.dateFormat = event.target.value; });
  bind('field-name','input', event => {
    // Typing a name before drawing the area is the natural order, and the panel
    // is re-rendered the moment a rectangle is drawn. Without a draft on the
    // state the name typed first would be thrown away and replaced by the
    // generated default.
    state.fieldNameDraft = event.target.value;
    if (state.selection) state.selection.fieldName = event.target.value;
  });
  bind('create-field','click', () => {
    const payload = {action:'add_field', page:state.page, rect:state.selection.rect, name:$('#field-name').value,
      type:$('#field-type').value, dateFormat:$('#field-date-format')?.value,
      choices:$('#field-choices').value.split('\n').map(x => x.trim()).filter(Boolean)};
    perform(payload,'Creating form field…').then(() => { state.fieldNameDraft = ''; state.tool = 'fill'; renderToolbar(); renderInspector(); renderOverlay(); toast('Fillable field created'); }).catch(showError);
  });
  $$('[data-field-xref]', pane).forEach(input => {
    const remember = () => {
      state.formDraft[input.dataset.fieldXref] =
        input.type === 'checkbox' ? (input.checked ? 'Yes' : 'Off') : input.value;
    };
    input.addEventListener('input', remember);
    input.addEventListener('change', remember);
  });
  bind('save-form-values','click', () => {
    const values = {};
    $$('[data-field-xref]', pane).forEach(input => { values[input.dataset.fieldXref] = input.type === 'checkbox' ? input.checked : input.value; });
    perform({action:'fill_forms',values},'Updating form fields…').then(() => toast('Form values applied to the PDF')).catch(showError);
  });  bind('new-text-field','click', () => chooseTool('field-text'));
  bind('form-signature','click', showSignatureDialog);
  bind('ocr-setup','click', showDependencies);
  bind('run-ocr','click', async () => {
    try {
      const pages = readPageRange('ocr');
      const language = $('#ocr-language').value.trim();
      if (pages.length > 20) throw new Error('Select 20 or fewer pages per OCR run.');
      if (await confirmDialog('Make these pages searchable?', 'The selected pages will be replaced with searchable 200-DPI raster copies. Annotations and form appearances are flattened; editable form fields on those pages are removed.', 'Run local OCR')) {
        const result = await busy('Recognizing text locally…', () => api(docPath('/ocr'), {method:'POST',json:{pages,language}}), isHostedPreview ? 'OCR runs in this hosted workspace. Use non-sensitive files.' : 'This can take a minute per page. No cloud service is used.');
        await adoptDocument(result); toast('OCR complete. Your selected pages are searchable.');
      }
    } catch (error) { showError(error); }
  });
  // ---- AI reading
  bind('ai-connect','click', showConnectModelDialog);
  bind('ai-summarise','click', runAiSummary);
  bind('ai-propose','click', runAiForm);
  bind('ai-add-fields','click', applyAiFields);
  bindRange('ai');
  const aiSentences = $('#ai-sentences');
  if (aiSentences) aiSentences.addEventListener('change', () => { state.ai.sentences = Number(aiSentences.value); });
  // The draft is kept in state but the panel is not re-rendered on every
  // keystroke, so the caret stays where it is while somebody types a prompt.
  const aiPrompt = $('#ai-prompt');
  if (aiPrompt) aiPrompt.addEventListener('input', () => { state.ai.prompt = aiPrompt.value; });
  bind('organizer-select-all','click', () => handleAction('select-all'));
  bind('organizer-clear','click', () => { state.selectedPages.clear(); renderToolbar(); renderInspector(); renderOrganizer(); });
  bind('organizer-extract','click', () => handleAction('extract-pages'));
}

async function perform(payload, title = 'Updating your PDF…', options = {}) {
  if (!state.doc) return;
  const result = await busy(title, () => api(docPath('/operation'), {method:'POST',json:payload}));
  state.lastExport = null;
  await adoptDocument(result, options);
  return result;
}
async function applyText() {
  if (!state.selection) return;
  const s = state.selection;
  const payload = {action:state.tool === 'edit' ? 'replace_text' : 'add_text',page:state.page,rect:s.rect,
    text:$('#edit-text-value').value,size:Number($('#text-size').value),color:$('#text-color').value,family:$('#text-font').value};
  if (state.tool === 'edit') { payload.rotation = s.rotation || 0; payload.expand = true; }
  try { await perform(payload,'Applying your text…'); toast('Text updated. Save when you’re ready.'); }
  catch (error) { showError(error); }
}
async function deleteSelectedText() {
  const s = state.selection;
  if (!s || state.tool !== 'edit') return;
  if (!await confirmDialog('Delete this text?', 'The selected text is removed from the working copy. The rest of the page layout is unchanged, and undo stays available until you redact.', 'Delete text', true)) return;
  try {
    await perform({action:'replace_text',page:state.page,rect:s.rect,text:'',size:s.size || 12,
      color:s.color || '#292b3d',family:s.family || 'sans-serif',rotation:s.rotation || 0,expand:false},
      'Removing the selected text…');
    toast('Text removed from the PDF');
  } catch (error) { showError(error); }
}
async function applyRedaction() {
  if (!state.selection) return;
  const rect = [...state.selection.rect], fill = $('#redact-color').value;
  if (!await confirmDialog('Permanently redact this area?', 'Underlying text, image pixels, and intersecting graphics are removed. Overlapping fields/comments, document attachments, and metadata are also removed. Undo history is cleared. Nothing is written to disk until you save.', 'Remove permanently', true)) return;
  try { await perform({action:'redact',page:state.page,rect,color:fill},'Removing sensitive content…'); toast('Content removed and undo history cleared. Export the redacted copy.'); }
  catch (error) { showError(error); }
}

/* Direct-edit controls. The toolbar lives inside the editor wrapper, so it stays
   upright even when the text itself is rotated. */
$('#inline-apply').addEventListener('click', () => commitInlineEdit());
$('#inline-cancel').addEventListener('click', cancelInlineEdit);
$('#inline-delete').addEventListener('click', () => commitInlineEdit({remove:true}));
$('#inline-size').addEventListener('input', event => {
  if (!state.inline) return;
  const value = Number(event.target.value);
  if (!Number.isFinite(value) || value < 6 || value > 96) return;
  state.inline.size = value;
  if (state.selection) state.selection.size = value;
  renderInlineEditor();
});
$('#inline-color').addEventListener('input', event => {
  if (!state.inline) return;
  state.inline.color = event.target.value;
  if (state.selection) state.selection.color = event.target.value;
  renderInlineEditor();
});
$('#inline-family').addEventListener('change', event => {
  if (!state.inline) return;
  state.inline.family = event.target.value;
  if (state.selection) state.selection.family = event.target.value;
  renderInlineEditor();
});
$('#inline-text').addEventListener('input', () => {
  if (!state.inline) return;
  const value = inlineText();
  if (state.selection) state.selection.text = value;
  const field = $('#edit-text-value');
  if (field) field.value = value;
  renderInlineEditor();
});
$('#inline-text').addEventListener('keydown', event => {
  // Page-level shortcuts stay out of the way while someone is typing on the page.
  event.stopPropagation();
  if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); commitInlineEdit(); return; }
  if (event.key === 'Escape') { event.preventDefault(); cancelInlineEdit(); return; }
  if ((event.key === 'Delete' || event.key === 'Backspace') && (event.ctrlKey || event.metaKey)) {
    event.preventDefault(); commitInlineEdit({remove:true});
  }
});
// Pressing anywhere outside the editable box finishes the edit, so the page
// behaves like a text editor rather than a form that needs a Save button.
document.addEventListener('pointerdown', event => {
  if (!state.inline) return;
  if (event.target.closest('#inline-editor')) return;
  if (event.target.closest('#apply-text') || event.target.closest('#delete-text')) return;
  state.lastInlineCommit = performance.now();
  commitInlineEdit();
  if (event.target.closest('#page-overlay')) { event.preventDefault(); event.stopPropagation(); }
}, true);

let pointerStart = null;
function pagePoint(event) {
  const box = $('#pdf-page').getBoundingClientRect(), p = state.doc.pages[state.page];
  return {x:Math.max(0,Math.min(p.width,(event.clientX-box.left)/box.width*p.width)),y:Math.max(0,Math.min(p.height,(event.clientY-box.top)/box.height*p.height))};
}
function pointRect(start, end) { return [Math.min(start.x,end.x),Math.min(start.y,end.y),Math.max(start.x,end.x),Math.max(start.y,end.y)]; }
$('#page-overlay').addEventListener('pointerdown', event => {
  if (!state.doc || state.busy || event.button !== 0 || event.target.closest('button')) return;
  if (state.tool === 'comment') { showCommentDialog(pagePoint(event)); return; }
  // A date is placed where it is clicked, not dragged into a box.
  if (state.tool === 'date') { placeDate(pagePoint(event)); return; }
  if (state.tool === 'stamp') { placeStamp(pagePoint(event)); return; }
  // Any field tool draws a rectangle, including the date field — which sets
  // `field-date` and would be silently ignored by a fixed list of names.
  const draws = ['text','image','signature','highlight','redact','link'].includes(state.tool)
    || state.tool.startsWith('field-')
    // A page with no text layer cannot be clicked into, so the text tool draws.
    || (state.tool === 'edit' && pageHasNoText());
  if (!draws) {
    state.selection = null; renderOverlay(); renderInspector(); return;
  }
  if (['image','signature'].includes(state.tool) && !state.pendingImage) return;
  pointerStart = pagePoint(event);
  $('#page-overlay').setPointerCapture(event.pointerId);
  $('#selection-box').hidden = false;
  $('#selection-box').className = 'selection-box' + (state.tool === 'redact' ? ' redaction' : '');
  $('#selection-box').style.cssText = overlayPosition([pointerStart.x,pointerStart.y,pointerStart.x+1,pointerStart.y+1]);
  event.preventDefault();
});
$('#page-overlay').addEventListener('pointermove', event => {
  if (!pointerStart) return;
  $('#selection-box').style.cssText = overlayPosition(pointRect(pointerStart,pagePoint(event)));
});
$('#page-overlay').addEventListener('pointerup', async event => {
  if (!pointerStart) return;
  const rect = pointRect(pointerStart,pagePoint(event));
  pointerStart = null;
  if ($('#page-overlay').hasPointerCapture(event.pointerId)) $('#page-overlay').releasePointerCapture(event.pointerId);
  if (rect[2]-rect[0] < 4 || rect[3]-rect[1] < 4) { $('#selection-box').hidden = true; return; }
  try {
    if (state.tool === 'highlight') {
      const chosenColor = $('#highlight-color')?.value || '#f5ce58';
      await perform({action:'highlight',page:state.page,rect,color:chosenColor},'Adding highlight…'); toast('Highlight added');
    } else if (['image','signature'].includes(state.tool)) {
      const wasSignature = state.tool === 'signature';
      const form = new FormData(); form.append('file',state.pendingImage); form.append('page',String(state.page)); form.append('rect',JSON.stringify(rect));
      const result = await busy(wasSignature ? 'Adding your signature…' : 'Placing your image…', () => api(docPath('/image'), {method:'POST',body:form}));
      state.pendingImage = null; state.tool = state.view === 'forms' ? 'fill' : 'view';
      await adoptDocument(result); toast(wasSignature ? 'Visual signature added' : 'Image inserted');
    } else if (state.tool === 'link') {
      showLinkDialog(rect);
    } else {
      state.selection = {kind:state.tool.startsWith('field-') ? 'field' : 'area',rect,text:'',size:12,color:'#292b3d',family:'sans-serif',
        scan: state.tool === 'edit' && pageHasNoText()};
      renderOverlay(); renderInspector();
      $('#edit-text-value')?.focus();
    }
  } catch (error) { showError(error); $('#selection-box').hidden = true; }
});
$('#page-overlay').addEventListener('pointercancel', () => { pointerStart = null; $('#selection-box').hidden = true; });
// Double-clicking text anywhere on the page starts a direct edit, whatever tool
// is active, which is the fastest way into the text.
$('#page-overlay').addEventListener('dblclick', event => {
  if (!state.doc || state.busy || !state.doc.canEdit || !state.doc.canCopy) return;
  const runIndex = runIndexAtPoint(pagePoint(event));
  if (runIndex < 0) return;
  event.preventDefault();
  openInlineEdit(runIndex);
});

// #modal is one element reused by every dialog. That has one sharp edge:
// closing an already-open dialog queues its `close` event, and the queue is not
// flushed until the *next* dialog is already on screen — where that event is
// indistinguishable from the new dialog being dismissed. A confirmation could
// therefore answer itself the instant it appeared. So a close is only believed
// when the dialog is genuinely shut, and a dialog that gets replaced is told
// directly instead of waiting for an event that no longer means anything.
let modalDismiss = null;
function onModalDismiss(handler) { modalDismiss = handler; }
$('#modal').addEventListener('close', () => {
  const dialog = $('#modal');
  if (dialog.open) return;
  const handler = modalDismiss;
  modalDismiss = null;
  if (handler) handler();
});

function openModal(title, subtitle, body, footer = '', width = 490) {
  const dialog = $('#modal');
  const outgoing = modalDismiss;
  modalDismiss = null;
  if (dialog.open) dialog.close();
  dialog.style.width = `${width}px`;
  $('#modal-content').innerHTML = `<div class="modal-header"><div><h2>${escapeHTML(title)}</h2><p>${escapeHTML(subtitle)}</p></div><button class="icon-button" data-close aria-label="Close dialog">${icon('close')}</button></div><div class="modal-body">${body}<div id="modal-error" class="field-error" role="alert"></div></div>${footer ? `<div class="modal-footer">${footer}</div>` : ''}`;
  $$('[data-close]',dialog).forEach(button => button.addEventListener('click', () => dialog.close()));
  dialog.showModal();
  // Whatever was showing is over now, even though its close event is still in
  // the queue and will arrive after this point.
  if (outgoing) outgoing();
  return dialog;
}
function modalError(error) { if ($('#modal-error')) $('#modal-error').textContent = error.message; }
function confirmDialog(title, description, confirmLabel = 'Continue', danger = false) {
  return new Promise(resolve => {
    // Nothing reaches the disk on its own any more: a change is written only
    // when Save or Save as is pressed, so every confirmation can say so.
    const dialog = openModal(title, 'Nothing is written to disk until you save.', `<p class="confirm-description">${escapeHTML(description)}</p>`, `<button class="button secondary" data-close>Cancel</button><button class="button ${danger ? 'danger' : 'primary'}" id="confirm-action">${escapeHTML(confirmLabel)}</button>`);
    let resolved = false;
    const finish = value => { if (resolved) return; resolved = true; resolve(value); };
    $('#confirm-action').addEventListener('click', () => { dialog.close(); finish(true); });
    // Dismissed, or replaced by another dialog: either way the answer is no.
    onModalDismiss(() => finish(false));
    if (danger) $('[data-close]',dialog).focus();
  });
}
// Opening or switching no longer closes anything: documents stay open, so
// nothing is lost and there is nothing to warn about. Only actually closing a
// document with unsaved changes needs saying out loud.
// Three answers, not two: a person who meant to save should not have to cancel
// the close, save, and start over.
function askSaveBeforeClose(name) {
  return new Promise(resolve => {
    const canSave = desktopApp() && state.doc?.canSave !== undefined;
    const dialog = openModal('Save your changes?', 'Nothing is written to disk until you save.',
      `<p class="confirm-description">“${escapeHTML(name)}” has changes that are not in a file yet — neither saved nor exported. Save them before closing it?</p>`
      + (canSave ? '' : '<div class="inline-note">' + icon('info') + '<span>Saving needs the desktop application. In this browser preview the document can only be exported.</span></div>'),
      `<button class="button secondary" data-close>Cancel</button>`
      + `<button class="button ${canSave ? 'danger-ghost' : 'danger'}" id="close-without-saving">Close without saving</button>`
      + (canSave ? '<button class="button primary" id="save-and-close">Save and close</button>' : ''));
    let resolved = false;
    const finish = value => { if (resolved) return; resolved = true; resolve(value); };
    $('#save-and-close')?.addEventListener('click', () => { dialog.close(); finish('save'); });
    $('#close-without-saving').addEventListener('click', () => { dialog.close(); finish('discard'); });
    onModalDismiss(() => finish('cancel'));
  });
}

// True when the document may be closed: saved, discarded on purpose, or not
// dirty in the first place.
async function confirmClose() {
  if (!isDirty()) return true;
  const choice = await askSaveBeforeClose(state.doc.name);
  if (choice === 'cancel') return false;
  if (choice === 'save') return saveDocument();
  return true;
}

async function confirmPreviewUpload() {
  if (!isHostedPreview || state.previewAcknowledged) return true;
  const accepted = await confirmDialog('Hosted preview, not the offline app.',
    'This demo sends uploaded files to the hosted workspace for processing. Use only sample or non-sensitive files. For confidential documents, run the desktop application locally.',
    'Use non-sensitive files');
  state.previewAcknowledged = accepted;
  return accepted;
}
async function uploadFile(file, password = '') {
  const form = new FormData(); form.append('file',file); form.append('password',password);
  return busy(/\.(docx?|xlsx?|pptx?|od[tsp])$/i.test(file.name) ? 'Converting your document locally…' : 'Opening your document…', () => api('/documents/upload',{method:'POST',body:form}));
}
// In the desktop shell the native dialog is tried first, because it returns a
// path — and a path is what Save needs to write back to. If the dialog cannot
// be shown at all the ordinary file picker still opens; a dialog the person
// cancelled does nothing at all.
async function openFilePicker() {
  if (desktopApp() && window.pywebview?.api?.choose_open_path) {
    const chosen = await choosePath('open');
    if (chosen.path) { openLocalPath(chosen.path); return; }
    if (chosen.cancelled) return;
  }
  $('#file-input').value=''; $('#file-input').click();
}
async function openFile(file) {
  if (!file) return;
  if (!await confirmPreviewUpload()) return;
  try {
    const info = await uploadFile(file);
    state.view = 'edit'; state.tool = 'view';
    await adoptDocument(info,{page:0}); setView('edit');
    toast(`Opened ${file.name}`);
  } catch (error) {
    if (error.code === 'password_required') showPasswordDialog(file);
    else showError(error);
  }
}
function showPasswordDialog(file) {
  const dialog = openModal('A little extra protection.', `Enter the password for ${file.name}.`, '<div class="field"><label for="unlock-password">PDF password</label><input id="unlock-password" type="password" autocomplete="current-password" placeholder="Opening or owner password"></div><div class="inline-note">'+icon('lock')+'<span>An owner password is needed for actions restricted by the document owner.</span></div>', '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="unlock-document">Unlock PDF</button>');
  const submit = async () => {
    try {
      const info = await uploadFile(file,$('#unlock-password').value);
      dialog.close(); state.tool = 'view';
      await adoptDocument(info,{page:0}); setView('edit'); toast('PDF unlocked');
    } catch (error) { modalError(error); }
  };
  $('#unlock-document').addEventListener('click',submit);
  $('#unlock-password').addEventListener('keydown',event => { if (event.key === 'Enter') submit(); });
  $('#unlock-password').focus();
}
async function newDocument() {
  const dialog = openModal('A fresh page.', 'Create a blank A4 PDF and start adding content.', '<div class="field"><label for="new-document-name">Document name</label><input id="new-document-name" value="Untitled.pdf" maxlength="180"></div>', '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="create-document">Create PDF</button>');
  $('#create-document').addEventListener('click',async () => {
    try {
      let name = $('#new-document-name').value.trim() || 'Untitled.pdf';
      if (!/\.pdf$/i.test(name)) name += '.pdf';
      const info = await busy('Creating a blank PDF…',() => api('/documents/create',{method:'POST',json:{name}}));
      dialog.close(); state.tool = 'text';
      await adoptDocument(info,{page:0}); setView('edit'); chooseTool('text'); toast('Your blank PDF is ready');
    } catch (error) { modalError(error); }
  });
  $('#new-document-name').select();
}
function showAddPages() {
  if (!state.doc) return;
  const dialog = openModal('Room for one more.', 'Add pages without changing the original source files.', `<div class="guide-grid"><button class="guide-card" id="insert-blank-page"><strong>${icon('plus')}Blank page</strong><p>Add a blank A4 page after page ${state.page + 1}.</p></button><button class="guide-card" id="merge-from-files"><strong>${icon('merge')}From files</strong><p>Combine PDFs, images, Office documents, or local HTML into this document.</p></button></div><div class="inline-note">${icon('info')}<span>Office conversion requires LibreOffice. A password-protected file can be unlocked in the merge window.</span></div>`);
  $('#insert-blank-page').addEventListener('click',() => {
    dialog.close();
    perform({action:'insert_blank',position:state.page+1},'Adding a blank page…',{page:state.page+1}).then(() => toast('Blank page added')).catch(showError);
  });
  // Both routes into combining files land in the same window, so there is one
  // place where the order, the page selection and any password are handled.
  $('#merge-from-files').addEventListener('click',() => { dialog.close(); showMergeDialog({destination:'append'}); });
}

// ---------------------------------------------------------------- combining
// Combining used to happen invisibly: files were appended in whatever order the
// file picker returned, with no way to see what was coming in, drop a mistake,
// take only part of a source document, or unlock a protected file. One window
// now handles all of it, reached from the Merge button, the "From files" card
// above, and dropping several files onto the window.

const MERGE_ACCEPT = '.pdf,.png,.jpg,.jpeg,.webp,.tif,.tiff,.bmp,.docx,.xlsx,.pptx,.doc,.xls,.ppt,.odt,.ods,.odp,.html,.htm,.txt,.md';
let mergeState = null;
// #modal is one element reused by every dialog, so anything attached to the
// dialog itself outlives the window that added it, and a close() from the
// previous dialog arrives *after* the next one is on screen — where it looks
// exactly like that dialog being dismissed. The abort controller drops a
// window's listeners when the next one opens, and the `dialog.open` check in
// the close handler ignores a close that belongs to an earlier dialog.
let mergeAbort = null;

function mergeSize(bytes) {
  if (!bytes) return '0 KB';
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
const mergeStem = name => String(name || 'Document').replace(/\.pdf$/i,'');

// Counts what a page selection will actually contribute, so the total on the
// button is the truth rather than the file's full length. A selection that
// cannot be read is reported rather than guessed at: showing "5 pages" for a
// range the engine is about to refuse would be worse than showing nothing.
// The engine still re-checks every selection; this is only for the count.
function mergeRangeCount(item) {
  if (!item.readable) return { pages: 0, error: '' };
  const spec = String(item.range || '').replace(/\s/g,'');
  if (!spec || spec.toLowerCase() === 'all') return { pages: item.pages, error: '' };
  const picked = new Set();
  for (const part of spec.split(',')) {
    const match = /^(\d+)(?:-(\d+))?$/.exec(part);
    if (!match) return { pages: 0, error: 'use numbers such as 1-3, 5, or leave it blank for all' };
    const first = Number(match[1]), last = Number(match[2] || match[1]);
    if (first < 1 || last < first) return { pages: 0, error: 'use ranges like 1-3, with the smaller page first' };
    if (last > item.pages) return { pages: 0, error: `it only has ${item.pages} ${item.pages === 1 ? 'page' : 'pages'}` };
    for (let n = first;n <= last;n++) picked.add(n);
  }
  return { pages: picked.size, error: '' };
}
const mergeTotalPages = () => (mergeState?.items || []).reduce((sum,item) => sum + mergeRangeCount(item).pages,0);

function mergePickFiles() {
  const input = document.createElement('input');
  input.type = 'file'; input.multiple = true; input.accept = MERGE_ACCEPT;
  input.addEventListener('change',() => mergeAddFiles([...input.files]));
  input.click();
}

async function mergeAddFiles(files) {
  if (!files?.length || !mergeState) return;
  if (!await confirmPreviewUpload()) return;
  const form = new FormData();
  files.forEach(file => form.append('files',file,file.name));
  let result;
  try {
    // The engine reads each file to report its page count and whether it is
    // locked, without storing anything. Page counts are readable even in an
    // encrypted PDF, which is what lets a locked file still show its size.
    result = await busy('Reading the files you chose…',() => api('/documents/inspect',{method:'POST',body:form}));
  } catch (error) { modalError(error); return; }
  result.files.forEach((info,index) => mergeState.items.push({
    file: files[index], name: info.name, pages: info.pages, size: info.size,
    kind: info.kind, encrypted: info.encrypted, locked: info.locked,
    readable: info.readable, error: info.error, password: '', range: '',
  }));
  renderMerge();
}

function mergeRowHTML(item, index, last) {
  const blocked = !item.readable || (item.locked && !item.password);
  // An open document is marked, because it behaves differently from a file in
  // one visible way: it is already unlocked, so it never asks for a password.
  const facts = item.readable
    ? `${item.pages} ${item.pages === 1 ? 'page' : 'pages'} · ${mergeSize(item.size)}${item.open ? ' · already open' : ''}${item.locked ? ' · password needed' : ''}`
    : item.error;
  // A one-page source has nothing to choose from, so the range box only appears
  // where it can actually do something.
  const rangeBox = item.readable && item.pages > 1
    ? `<div class="field merge-range"><label for="merge-range-${index}">Pages</label><input id="merge-range-${index}" data-merge-range="${index}" value="${escapeHTML(item.range)}" placeholder="all" autocomplete="off" aria-label="Pages to take from ${escapeHTML(item.name)}"></div>`
    : '';
  const passwordBox = item.readable && item.locked
    ? `<div class="field merge-password"><label for="merge-password-${index}">Password</label><input id="merge-password-${index}" data-merge-password="${index}" type="password" value="${escapeHTML(item.password)}" autocomplete="off" aria-label="Password for ${escapeHTML(item.name)}"></div>`
    : '';
  return `<div class="merge-row${blocked ? ' blocked' : ''}" data-merge-row="${index}">
    <div class="merge-row-top">
      <span class="merge-index">${index + 1}</span>
      <div class="merge-facts">
        <strong title="${escapeHTML(item.name)}">${escapeHTML(item.name)}</strong>
        <span>${escapeHTML(facts)}</span>
      </div>
      <div class="merge-move">
        <button class="icon-button small" data-merge-move="${index}" data-merge-step="-1" title="Move up" aria-label="Move ${escapeHTML(item.name)} up"${index === 0 ? ' disabled' : ''}>${icon('up')}</button>
        <button class="icon-button small" data-merge-move="${index}" data-merge-step="1" title="Move down" aria-label="Move ${escapeHTML(item.name)} down"${index === last ? ' disabled' : ''}>${icon('down-arrow')}</button>
        <button class="icon-button small" data-merge-remove="${index}" title="Remove" aria-label="Remove ${escapeHTML(item.name)}">${icon('trash')}</button>
      </div>
    </div>
    ${rangeBox || passwordBox ? `<div class="merge-row-fields">${rangeBox}${passwordBox}</div>` : ''}
  </div>`;
}

function mergeTargetHTML() {
  if (!state.doc) {
    return `<div class="field"><label for="merge-name">New PDF name</label><input id="merge-name" value="${escapeHTML(mergeState.name)}" autocomplete="off"></div>
      <div class="inline-note">${icon('info')}<span>No document is open, so the combined file becomes a new one.</span></div>`;
  }
  const total = state.doc.pageCount;
  const option = (value, letter, title, desc) => `<button class="format-option${mergeState.destination === value ? ' active' : ''}" data-merge-target="${value}"><span class="format-letter">${letter}</span><span><span class="format-name">${escapeHTML(title)}</span><span class="format-desc">${escapeHTML(desc)}</span></span><span class="radio-dot"></span></button>`;
  return `<div class="section-label">Where the pages go</div>
    <div class="format-list merge-targets">
      ${option('append','+','Add to the end',`After page ${total} of ${state.doc.name}`)}
      ${option('insert','^','Insert inside it',`Choose the page they go in front of`)}
      ${option('new','N','Make a new PDF',`Leaves ${state.doc.name} untouched`)}
    </div>
    <div class="field" id="merge-position-wrap"${mergeState.destination === 'insert' ? '' : ' hidden'}><label for="merge-position">Insert before page</label><input id="merge-position" type="number" min="1" max="${total + 1}" value="${Math.min(mergeState.position + 1,total + 1)}" autocomplete="off"></div>
    <div class="field" id="merge-name-wrap"${mergeState.destination === 'new' ? '' : ' hidden'}><label for="merge-name">New PDF name</label><input id="merge-name" value="${escapeHTML(mergeState.name)}" autocomplete="off"></div>`;
}

function mergeReadiness() {
  const items = mergeState?.items || [];
  if (!items.length) return {ok:false, reason:'Choose the files you want to combine.'};
  const unreadable = items.find(item => !item.readable);
  if (unreadable) return {ok:false, reason:`Remove ${unreadable.name}: it cannot be read.`};
  const broken = items.find(item => mergeRangeCount(item).error);
  if (broken) return {ok:false, reason:`Check the pages for ${broken.name}: ${mergeRangeCount(broken).error}.`};
  const locked = items.find(item => item.locked && !item.password);
  if (locked) return {ok:false, reason:`Enter the password for ${locked.name}.`};
  // The destination decides whether a document can be one of its own sources,
  // and it can change after the document was added, so this is checked here
  // rather than only when the Add button was pressed.
  const self = items.find(item => item.documentId && state.doc && item.documentId === state.doc.id
                                  && mergeState.destination !== 'new');
  if (self) return {ok:false, reason:`${self.name} is the document you are combining into. Choose "Make a new PDF" instead.`};
  if (mergeState.destination === 'new' && !mergeState.name.trim()) return {ok:false, reason:'Give the new PDF a name.'};
  return {ok:true, reason:''};
}

// Kept separate from renderMerge so typing in a page box can refresh the total
// without rebuilding the rows, which would take the caret out of the box.
// "Sources" rather than "files" once an open document is in the list, because
// calling a document you already have open a file would be wrong.
function mergeCountLabel(items) {
  const open = items.some(item => item.open);
  return `${items.length} ${open ? (items.length === 1 ? 'source' : 'sources') : (items.length === 1 ? 'file' : 'files')}`;
}
function renderMergeSummary() {
  if (!mergeState) return;
  const readiness = mergeReadiness();
  const pages = mergeTotalPages();
  const summary = $('#merge-summary');
  if (summary) {
    summary.textContent = readiness.ok
      ? `${mergeCountLabel(mergeState.items)} · ${pages} ${pages === 1 ? 'page' : 'pages'} will be combined`
      : readiness.reason;
    summary.classList.toggle('blocked',!readiness.ok);
  }
  const run = $('#merge-run');
  if (run) { run.disabled = !readiness.ok; run.textContent = pages ? `Combine ${pages} ${pages === 1 ? 'page' : 'pages'}` : 'Combine'; }
}

function renderMerge() {
  if (!mergeState) return;
  const rows = $('#merge-rows');
  if (!rows) return;
  rows.innerHTML = mergeState.items.length
    ? mergeState.items.map((item,index) => mergeRowHTML(item,index,mergeState.items.length - 1)).join('')
    : `<div class="empty-state">Nothing to combine yet. Choose the PDFs, images or Office files you want in one document, then set the order.</div>`;
  const target = $('#merge-target');
  if (target) target.innerHTML = mergeTargetHTML();
  // The open-document list is rendered separately: it is outside the rows, so
  // refreshing it cannot take the caret out of a half-typed page range.
  renderMergeOpenDocuments();
  renderMergeSummary();
  bindMerge();
}

function bindMerge() {
  const dialog = $('#modal');
  $$('[data-merge-move]',dialog).forEach(button => button.addEventListener('click',() => {
    const index = Number(button.dataset.mergeMove), step = Number(button.dataset.mergeStep);
    const target = index + step;
    if (target < 0 || target >= mergeState.items.length) return;
    [mergeState.items[index],mergeState.items[target]] = [mergeState.items[target],mergeState.items[index]];
    renderMerge();
  }));
  $$('[data-merge-remove]',dialog).forEach(button => button.addEventListener('click',() => {
    mergeState.items.splice(Number(button.dataset.mergeRemove),1);
    renderMerge();
  }));
  // Values are kept in state as they are typed. Reordering or removing rebuilds
  // the rows, and without this the half-typed page range would be thrown away.
  $$('[data-merge-range]',dialog).forEach(input => input.addEventListener('input',() => {
    mergeState.items[Number(input.dataset.mergeRange)].range = input.value;
    renderMergeSummary();
  }));
  $$('[data-merge-password]',dialog).forEach(input => {
    input.addEventListener('input',() => {
      mergeState.items[Number(input.dataset.mergePassword)].password = input.value;
      renderMergeSummary();
    });
    // Rebuilt once the field is left, so the row stops saying a password is
    // needed and the list shows the file as ready.
    input.addEventListener('change',() => {
      mergeState.items[Number(input.dataset.mergePassword)].password = input.value;
      renderMerge();
    });
  });
  $$('[data-merge-target]',dialog).forEach(button => button.addEventListener('click',() => {
    mergeState.destination = button.dataset.mergeTarget;
    renderMerge();
  }));
  // One delegated listener for the open-document list, which is re-rendered on
  // its own as documents open and close and as the destination changes.
  const openDocs = $('#merge-open-docs');
  if (openDocs) openDocs.addEventListener('click',event => {
    if (event.target.closest('[data-merge-all]')) { mergeAddAllOpenDocuments(); return; }
    const button = event.target.closest('[data-merge-doc]');
    if (button && !button.disabled) mergeAddOpenDocument(button.dataset.mergeDoc);
  });
  const name = $('#merge-name');
  if (name) name.addEventListener('input',() => {
    mergeState.name = name.value;
    renderMergeSummary();
  });
  const position = $('#merge-position');
  if (position) position.addEventListener('input',() => {
    const total = state.doc ? state.doc.pageCount : 0;
    mergeState.position = Math.max(0,Math.min(Number(position.value || 1) - 1,total));
  });
}

function showMergeDialog({ files = [], destination = '', restore = null } = {}) {
  mergeState = restore || {
    items: [],
    destination: destination || (state.doc ? 'append' : 'new'),
    position: state.doc ? state.doc.pageCount : 0,
    name: state.doc ? `${mergeStem(state.doc.name)} combined.pdf` : 'Combined.pdf',
    // Documents already open in the workspace are offered beside files from
    // disk, so nothing has to be found and uploaded twice.
    openDocs: [], openDocsLoading: true, openDocsError: '',
  };
  // The window's own listeners all hang off one controller, so opening it again
  // drops the previous set instead of stacking a new one on top.
  mergeAbort?.abort();
  mergeAbort = new AbortController();
  const { signal } = mergeAbort;
  const dialog = openModal('Combine documents.','Bring several PDFs, images or Office files together into one document.',
    `<div id="merge-open-docs"></div>
     <div class="merge-add"><button class="button secondary" id="merge-add-files">${icon('plus')}Choose files</button><span>or drop them anywhere in this window</span></div>
     <div id="merge-rows" class="merge-rows"></div>
     <div id="merge-target"></div>
     <div class="inline-note" id="merge-summary"></div>`,
    `<button class="button secondary" data-close>Cancel</button><button class="button primary" id="merge-run" disabled>Combine</button>`,560);
  $('#merge-add-files').addEventListener('click',mergePickFiles);
  $('#merge-run').addEventListener('click',mergeRun);
  // Dropping straight onto the window is the fastest way in, so it is accepted
  // while the window is open too. The drop is stopped here as well as handled,
  // or the window-level handler would open a second copy of this dialog.
  ['dragenter','dragover'].forEach(type => dialog.addEventListener(type,event => {
    if (!event.dataTransfer?.types.includes('Files')) return;
    event.preventDefault(); event.stopPropagation(); dialog.classList.add('dropping');
  },{signal}));
  ['dragleave','drop'].forEach(type => dialog.addEventListener(type,event => {
    if (!event.dataTransfer?.types.includes('Files')) return;
    event.preventDefault(); event.stopPropagation();
    dialog.classList.remove('dropping');
    if (type === 'drop') mergeAddFiles([...event.dataTransfer.files]);
  },{signal}));
  onModalDismiss(() => { mergeState = null; mergeAbort?.abort(); });
  renderMerge();
  mergeLoadOpenDocuments();
  if (files.length) mergeAddFiles(files);
}

// ------------------------------------------------- documents already open
// The workspace holds a handful of documents at once. Listing them here means
// combining two of them is one click rather than "find it on disk again".
async function mergeLoadOpenDocuments() {
  const window_ = mergeState;                 // identity of the window asking
  if (!window_) return;
  try {
    const result = await api('/documents');
    if (mergeState !== window_) return;       // a different window opened since
    window_.openDocs = result.documents || [];
  } catch (error) {
    if (mergeState !== window_) return;
    window_.openDocs = [];
    window_.openDocsError = error.message;
  }
  window_.openDocsLoading = false;
  renderMergeOpenDocuments();
}

// Why a document cannot be added, or '' when it can. The destination is part of
// the answer: a document cannot be combined into itself, but it can be used to
// build a new PDF, which is a different operation on different bytes.
function mergeDocBlocked(item) {
  if (!item.readable) return item.error || 'This document cannot be read.';
  if (state.doc && item.id === state.doc.id && mergeState.destination !== 'new') {
    return `${item.name} is the document you are combining into. Choose "Make a new PDF" to include it.`;
  }
  if (!item.canAssemble) return `The PDF owner has restricted page assembly in ${item.name}.`;
  return '';
}

function mergeOpenDocumentsHTML() {
  const docs = mergeState?.openDocs || [];
  if (mergeState?.openDocsLoading) return `<div class="merge-open-note">Looking for documents you already have open…</div>`;
  if (mergeState?.openDocsError) return `<div class="merge-open-note">${escapeHTML(mergeState.openDocsError)}</div>`;
  if (!docs.length) {
    return `<div class="merge-open-note">No other document is open. Anything you open appears here, ready to combine without hunting for it on disk again.</div>`;
  }
  const addable = docs.filter(item => !mergeDocBlocked(item)
    && !(mergeState.items || []).some(existing => existing.documentId === item.id));
  const head = `<div class="section-label merge-open-head"><span>Already open in KADOMA</span>${addable.length > 1
    ? `<button class="button ghost small" data-merge-all>Add all ${addable.length}</button>` : ''}</div>`;
  return head + `<div class="merge-open">${docs.map(item => {
    const blocked = mergeDocBlocked(item);
    const current = !!state.doc && item.id === state.doc.id;
    const facts = item.readable
      ? `${item.pageCount} ${item.pageCount === 1 ? 'page' : 'pages'} · ${mergeSize(item.size)}${current ? ' · the document you are working in' : ''}`
      : escapeHTML(item.error || 'cannot be read');
    return `<div class="merge-open-row${current ? ' current' : ''}">
      <div class="merge-open-facts"><strong title="${escapeHTML(item.name)}">${escapeHTML(item.name)}</strong><span>${facts}</span></div>
      <button class="button secondary small" data-merge-doc="${escapeHTML(item.id)}" title="${escapeHTML(blocked || `Add ${item.name} to the list`)}"${blocked ? ' disabled' : ''}>${icon('plus')}Add</button>
    </div>`;
  }).join('')}</div>`;
}

function renderMergeOpenDocuments() {
  const holder = $('#merge-open-docs');
  if (holder) holder.innerHTML = mergeOpenDocumentsHTML();
}

function mergeAddOpenDocument(id, { quiet = false } = {}) {
  const item = (mergeState?.openDocs || []).find(doc => doc.id === id);
  if (!item) return false;
  const blocked = mergeDocBlocked(item);
  if (blocked) { modalError(new Error(blocked)); return false; }
  if (mergeState.items.some(existing => existing.documentId === id)) {
    if (!quiet) modalError(new Error(`${item.name} is already in the list.`));
    return false;
  }
  mergeState.items.push({
    documentId: id, open: true, name: item.name, pages: item.pageCount, size: item.size,
    kind: 'pdf', encrypted: item.encrypted, locked: false, readable: true, error: '',
    password: '', range: '',
  });
  if (!quiet) renderMerge();
  return true;
}

// Every open document that can be a source, in one press. The one being merged
// into is left out when the destination cannot take it, which is why the count
// on the button is worked out rather than assumed.
function mergeAddAllOpenDocuments() {
  const addable = (mergeState?.openDocs || []).filter(item => !mergeDocBlocked(item)
    && !mergeState.items.some(existing => existing.documentId === item.id));
  if (!addable.length) {
    modalError(new Error('Every document that can be added is already in the list.'));
    return;
  }
  let added = 0;
  addable.forEach(item => { if (mergeAddOpenDocument(item.id, {quiet: true})) added += 1; });
  renderMerge();
  if (added < addable.length) {
    modalError(new Error(`Added ${added} of ${addable.length}; the list holds 20 sources.`));
  }
}

async function mergeRun() {
  const readiness = mergeReadiness();
  if (!readiness.ok) { modalError(new Error(readiness.reason)); return; }
  // Everything is read out of the window up front, because asking about unsaved
  // edits closes this window and it may not come back.
  const items = mergeState.items.slice();
  const destination = mergeState.destination;
  const chosenName = mergeState.name.trim();
  const position = mergeState.position;
  const form = new FormData();
  // The order is carried explicitly, because a source can be either an upload or
  // a document the app already has open, and the two cannot be interleaved by
  // position in a multipart body. `sources` is the running order; `files` holds
  // only the uploads, which `sources` refers to by index.
  const sources = [];
  let uploaded = 0;
  items.forEach(item => {
    if (item.documentId) {
      sources.push({kind:'document', id:item.documentId});
    } else {
      sources.push({kind:'file', index:uploaded});
      form.append('files',item.file,item.name);
      uploaded++;
    }
  });
  form.append('sources',JSON.stringify(sources));
  form.append('passwords',JSON.stringify(items.map(item => item.password)));
  form.append('ranges',JSON.stringify(items.map(item => item.range)));
  const total = items.reduce((sum,item) => sum + item.pages,0);
  const label = `${total} ${total === 1 ? 'page' : 'pages'}`;
  const buildNew = destination === 'new' || !state.doc;
  if (buildNew) {
    // One dialog at a time: this window closes before the new document is
    // built. The document that is open stays open behind it, so there is
    // nothing to warn about and nothing to hand back.
    $('#modal').close();
    form.append('name',chosenName);
  }
  try {
    if (buildNew) {
      const info = await busy('Combining your files locally…',() => api('/documents/combine',{method:'POST',body:form}));
      await adoptDocument(info,{page:0}); setView('edit');
      toast(`${mergeCountLabel(items)} combined into ${info.name}`);
      return;
    }
    const append = destination === 'append';
    form.append('position',JSON.stringify(append ? null : position));
    const firstNewPage = append ? state.doc.pageCount : position;
    const info = await busy('Combining your files locally…',() => api(docPath('/merge'),{method:'POST',body:form}));
    $('#modal').close();
    await adoptDocument(info,{page:firstNewPage});
    // The point of combining is to look at the result, so the view follows it.
    setView('edit');
    scrollPageIntoView(firstNewPage);
    toast(`${label} added ${append ? 'to the end' : `at page ${firstNewPage + 1}`}`);
  } catch (error) {
    // The window is gone by now in the appending path, so the failure has to be
    // reported somewhere it can actually be seen.
    if ($('#modal')?.open) modalError(error); else showError(error);
  }
}

function readPageRange(prefix) {
  const selected = $(`#${prefix}-range`)?.value || 'all';
  if (selected === 'current') return [state.page];
  if (selected === 'all') return Array.from({length:state.doc.pageCount}, (_,i)=>i);
  const raw = $(`#${prefix}-custom`).value.replace(/\s/g,'');
  if (!raw || !/^[0-9,-]+$/.test(raw)) throw new Error('Enter a page range, such as 1-3, 5.');
  const pages = [];
  for (const part of raw.split(',')) {
    const match = /^(\d+)(?:-(\d+))?$/.exec(part);
    if (!match) throw new Error('Use page numbers separated by commas, or inclusive ranges.');
    const first = Number(match[1]), last = Number(match[2] || match[1]);
    if (first < 1 || last > state.doc.pageCount || last < first) throw new Error(`Choose pages between 1 and ${state.doc.pageCount}, in increasing ranges.`);
    for (let n = first;n <= last;n++) if (!pages.includes(n-1)) pages.push(n-1);
  }
  return pages;
}
function readExportOptions(prefix, format) {
  const options = {pages:readPageRange(prefix)};
  if (format === 'xlsx') options.tableStrategy = $(`#${prefix}-table`).value;
  if (format === 'images') { options.imageFormat = $(`#${prefix}-image-format`).value; options.dpi = Number($(`#${prefix}-dpi`).value); }
  return options;
}
function filenameFromResponse(response, fallback) {
  const disposition = response.headers.get('Content-Disposition') || '';
  const encoded = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
  if (encoded) { try { return decodeURIComponent(encoded[1]); } catch {} }
  return /filename="([^"]+)"/.exec(disposition)?.[1] || fallback;
}
// Saving a produced file, the same way for every feature that makes one: through
// the desktop shell's own save dialog when it exists, otherwise a normal
// download. Export and split both come through here so they cannot drift.
async function saveBlob(blob, name) {
  if (window.pywebview?.api?.save_bytes) {
    const encoded = await new Promise((resolve,reject) => {
      const reader = new FileReader(); reader.onload = () => resolve(reader.result.split(',')[1]); reader.onerror = reject; reader.readAsDataURL(blob);
    });
    const result = await window.pywebview.api.save_bytes(name,encoded);
    if (result.error) throw new Error(result.error);
    return result.saved;
  }
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a'); anchor.href=url; anchor.download=name; document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
  return true;
}
// ------------------------------------------------------------------- saving
// Save writes over the file the document was opened from. Save as asks for a
// destination first, and the document follows that path from then on. Both are
// done by the engine, which writes beside the destination and moves the
// finished file into place — a half-written PDF can never replace a good one.
async function choosePath(kind, name = '') {
  const bridge = window.pywebview?.api;
  if (!bridge) return { unsupported: true };
  try {
    return kind === 'save'
      ? await bridge.choose_save_path(name)
      : await bridge.choose_open_path();
  } catch {
    return { error: 'The file dialog could not be opened.' };
  }
}

function showSaveNeedsDesktop() {
  const dialog = openModal('Saving needs the desktop app.',
    'This is the browser preview, so KADOMA cannot write to a file on your disk.',
    '<p class="confirm-description">The desktop application saves over the file you opened and remembers where it is. Here, the same document can be downloaded as a copy.</p>',
    '<button class="button secondary" data-close>Close</button><button class="button primary" id="save-export-instead">Export a copy</button>');
  $('#save-export-instead').addEventListener('click', () => { dialog.close(); showExportDialog(); });
}

async function saveDocument({ as = false } = {}) {
  if (!state.doc) return false;
  if (!desktopApp()) { showSaveNeedsDesktop(); return false; }
  // A document with no file behind it has nothing to write over: ask where the
  // copy should go rather than refusing the press.
  if (!as && !state.doc.canSave) return saveDocument({ as: true });
  let path = null;
  if (as) {
    const chosen = await choosePath('save', state.doc.name);
    if (chosen.cancelled) return false;
    if (!chosen.path) { toast(chosen.error || 'The file dialog could not be opened.', true); return false; }
    path = chosen.path;
  }
  try {
    const result = await busy(as ? 'Saving your copy…' : 'Saving your document…', () => api(
      docPath(as ? '/save-as' : '/save'),
      { method: 'POST', json: as ? { path } : {} }));
    await adoptDocument(result.document, { page: state.page });
    toast(as ? `Saved as ${result.name}` : `Saved to ${result.name}`);
    return true;
  } catch (error) {
    showError(error);
    return false;
  }
}

async function exportDocument(format = 'pdf', options = {}) {
  if (!state.doc) return false;
  const saved = await busy('Preparing your export…', async () => {
    const response = await api(docPath('/export/' + format),{method:'POST',json:options,raw:true});
    return saveBlob(await response.blob(), filenameFromResponse(response,'KADOMA-PDF-export.' + format));
  });
  if (saved) {
    if (format === 'pdf' && (!options.pages || (options.pages.length === state.doc.pageCount && options.pages.every((n,i)=>n===i)))) state.lastExport = state.doc.revision;
    updateHeader(); toast(format === 'protected' ? 'Encrypted PDF copy exported' : 'Your copy has been exported');
  }
  return saved;
}
function showExportDialog(initialFormat = 'pdf', initialPages = null) {
  if (!state.doc) return;
  let format = initialFormat;
  const dialog = openModal('Ready for what’s next.', 'Export a copy. Choose a new name to preserve your original.', `<div id="export-formats">${formatOptions(format,true)}</div><div id="export-options">${rangeFields('export')}${exportSettings(format,'export')}</div><div class="notice purple" id="export-notice">${escapeHTML(formatNotice(format))}</div>`, `<button class="button secondary" data-close>Cancel</button><button class="button primary" id="start-export">${icon('download')}Export copy</button>`,540);
  function bindOptions() {
    bindRange('export');
    if (initialPages) {
      $('#export-range').value='custom'; $('#export-custom-field').hidden=false;
      $('#export-custom').value=initialPages.map(n=>n+1).join(', ');
    }
  }
  bindOptions();
  $$('[data-format]',dialog).forEach(button => button.addEventListener('click',() => {
    format=button.dataset.format;
    $$('[data-format]',dialog).forEach(item=>item.classList.toggle('active',item.dataset.format===format));
    $('#export-options').innerHTML=rangeFields('export')+exportSettings(format,'export');
    $('#export-notice').textContent=formatNotice(format);
    bindOptions();
  }));
  $('#start-export').addEventListener('click',async () => {
    try {
      const saved=await exportDocument(format,readExportOptions('export',format));
      if (saved) dialog.close();
    } catch (error) { modalError(error); }
  });
}

// ------------------------------------------------------------------ splitting
// Splitting is the mirror of combining, and is built the same way: one window
// that shows exactly what is about to be produced before anything is written.
// The plan comes from the engine (`/split/plan`) rather than being counted here,
// so the file names on screen are the file names that get saved — and a range
// the engine would refuse is refused before the button is pressed, not after.

const SPLIT_MODES = [
  {id:'chunks', letter:'N', title:'Every few pages', desc:'Equal blocks — 10 pages each, for example'},
  {id:'parts',  letter:'F', title:'A number of files', desc:'Divided as evenly as the page count allows'},
  {id:'ranges', letter:'R', title:'Your own page ranges', desc:'One file for each range you type'},
];
let splitState = null;
let splitAbort = null;
let splitTimer = null;

function splitOptionsHTML() {
  if (!splitState) return '';
  if (splitState.mode === 'chunks') {
    return `<div class="field"><label for="split-size">Pages in each file</label><input id="split-size" type="number" min="1" max="${state.capabilities.maxPages || 500}" value="${escapeHTML(String(splitState.size))}" autocomplete="off"><p class="help-text">Use 1 to get one PDF per page, or a larger number to group pages together.</p></div>`;
  }
  if (splitState.mode === 'parts') {
    return `<div class="field"><label for="split-parts">Number of files</label><input id="split-parts" type="number" min="2" max="${state.doc.pageCount}" value="${escapeHTML(String(splitState.parts))}" autocomplete="off"><p class="help-text">Between 2 and ${state.doc.pageCount} for a ${state.doc.pageCount}-page document. Longer parts come first.</p></div>`;
  }
  return `<div class="field"><label for="split-ranges">One range per file</label><input id="split-ranges" value="${escapeHTML(splitState.ranges)}" placeholder="e.g. 1-3, 4-6, 7-10" autocomplete="off"><p class="help-text">Page numbers, commas and inclusive ranges. Each comma-separated range becomes its own file.</p></div>`;
}
// The values are read back out of the window rather than only from state, so
// what is sent is what is on screen. State keeps them so switching between the
// three modes and back does not throw away a half-typed number.
function splitReadOptions() {
  const options = {mode: splitState.mode};
  if (splitState.mode === 'chunks') options.size = Math.trunc(Number($('#split-size')?.value));
  else if (splitState.mode === 'parts') options.parts = Math.trunc(Number($('#split-parts')?.value));
  else options.ranges = $('#split-ranges')?.value ?? '';
  return options;
}
function scheduleSplitRefresh() { clearTimeout(splitTimer); splitTimer = setTimeout(splitRefresh, 220); }

function renderSplitPlan(plan) {
  const rows = $('#split-rows');
  if (rows) rows.innerHTML = plan.parts.map(part => `<div class="split-row"><span class="split-index">${part.index}</span><div class="split-facts"><strong title="${escapeHTML(part.name)}">${escapeHTML(part.name)}</strong><span>${part.pages === 1 ? '1 page' : `${part.pages} pages`} · ${part.first === part.last ? `page ${part.first}` : `pages ${part.first}–${part.last}`}</span></div></div>`).join('');
  const summary = $('#split-summary'), run = $('#split-run');
  if (summary) {
    const files = `${plan.fileCount} ${plan.fileCount === 1 ? 'file' : 'files'}`;
    const pages = `${plan.pageTotal} ${plan.pageTotal === 1 ? 'page' : 'pages'}`;
    // A range that leaves pages out is allowed — extracting part of a document
    // is a real thing to want — but it is said out loud rather than passed over.
    const gap = plan.omitted.length ? ` · pages ${plan.omittedLabel} are in no part` : '';
    summary.textContent = `${files} · ${pages} · ${plan.archive ? 'one ZIP archive' : 'one PDF'}${gap}`;
    summary.classList.remove('blocked');
    summary.classList.toggle('warn', plan.omitted.length > 0);
  }
  if (run) {
    run.disabled = false;
    run.textContent = plan.fileCount === 1 ? 'Create 1 file' : `Create ${plan.fileCount} files`;
  }
}

async function splitRefresh() {
  if (!splitState) return;
  const summary = $('#split-summary'), run = $('#split-run');
  if (!summary || !run) return;
  // Answers can arrive out of order while somebody types, so a reply is only
  // believed if it belongs to the newest request.
  const generation = ++splitState.generation;
  summary.classList.remove('blocked','warn');
  summary.textContent = 'Working out the parts…';
  run.disabled = true;
  let plan;
  try {
    plan = await api(docPath('/split/plan'),{method:'POST',json:splitReadOptions()});
  } catch (error) {
    if (!splitState || generation !== splitState.generation) return;
    splitState.plan = null;
    if ($('#split-rows')) $('#split-rows').innerHTML = '';
    summary.textContent = error.message;
    summary.classList.add('blocked');
    return;
  }
  if (!splitState || generation !== splitState.generation) return;
  splitState.plan = plan;
  renderSplitPlan(plan);
}

function bindSplitOptions() {
  const keep = (id, key) => {
    const input = $('#' + id);
    if (input) input.addEventListener('input', () => { splitState[key] = input.value; scheduleSplitRefresh(); });
  };
  keep('split-size','size');
  keep('split-parts','parts');
  keep('split-ranges','ranges');
}

async function splitRun() {
  const plan = splitState?.plan;
  if (!plan) return;
  const options = splitReadOptions();
  try {
    const saved = await busy('Splitting your document…', async () => {
      const response = await api(docPath('/split'),{method:'POST',json:options,raw:true});
      return saveBlob(await response.blob(), filenameFromResponse(response,'KADOMA-PDF-split.zip'));
    });
    if (saved) {
      $('#modal').close();
      toast(plan.fileCount === 1 ? 'Your split file has been saved' : `${plan.fileCount} files saved`);
    }
  } catch (error) {
    // The window may already be gone, so the failure has to land somewhere it
    // can actually be seen.
    if ($('#modal')?.open) modalError(error); else showError(error);
  }
}

function showSplitDialog() {
  if (!state.doc) return;
  if (!state.doc.canAssemble) { toast('The PDF owner has restricted page assembly, so this document cannot be split.',true); return; }
  splitState = {mode:'chunks', size:1, parts:2, ranges:'', plan:null, generation:0};
  splitAbort?.abort();
  splitAbort = new AbortController();
  const modes = SPLIT_MODES.map(mode => `<button class="format-option${splitState.mode === mode.id ? ' active' : ''}" data-split-mode="${mode.id}"><span class="format-letter">${mode.letter}</span><span><span class="format-name">${escapeHTML(mode.title)}</span><span class="format-desc">${escapeHTML(mode.desc)}</span></span><span class="radio-dot"></span></button>`).join('');
  const dialog = openModal('Divide it up.', `Break ${state.doc.name} into several files. Nothing in the open document changes.`,
    `<div class="section-label">How the cuts are decided</div><div class="format-list merge-targets" id="split-modes">${modes}</div><div id="split-options">${splitOptionsHTML()}</div><div id="split-rows" class="merge-rows split-rows"></div><div class="inline-note" id="split-summary"></div>`,
    `<button class="button secondary" data-close>Cancel</button><button class="button primary" id="split-run" disabled>Create</button>`,560);
  $$('[data-split-mode]',dialog).forEach(button => button.addEventListener('click',() => {
    splitState.mode = button.dataset.splitMode;
    $$('[data-split-mode]',dialog).forEach(item => item.classList.toggle('active',item.dataset.splitMode === splitState.mode));
    $('#split-options').innerHTML = splitOptionsHTML();
    bindSplitOptions();
    splitRefresh();
  }));
  $('#split-run').addEventListener('click',splitRun);
  onModalDismiss(() => { splitState = null; clearTimeout(splitTimer); splitAbort?.abort(); });
  bindSplitOptions();
  splitRefresh();
}

async function handleAction(action) {
  if (!state.doc) return;
  let pages = [...state.selectedPages].sort((a,b)=>a-b);
  try {
    if (action==='select-all') {
      if (state.selectedPages.size===state.doc.pageCount) state.selectedPages.clear();
      else state.selectedPages=new Set(Array.from({length:state.doc.pageCount},(_,i)=>i));
      renderToolbar(); renderInspector(); renderOrganizer(); return;
    }
    if (!pages.length) return;
    if (action==='rotate-pages') { await perform({action:'rotate',pages,angle:90},'Rotating pages…'); toast('Selected pages rotated'); }
    else if (action==='duplicate-pages') {
      if (state.doc.formCount && !await confirmDialog('Duplicate selected pages?', 'Copies will be added to the end. Form fields are copied with unique names so their values stay independent of the originals.', 'Duplicate pages')) return;
      const oldCount=state.doc.pageCount;
      await perform({action:'duplicate',pages},'Duplicating pages…',{selected:pages.map((_,i)=>oldCount+i)}); toast('Page copies added to the end');
    } else if (action==='delete-pages') {
      if (pages.length >= state.doc.pageCount) throw new Error('Keep at least one page in the document.');
      if (!await confirmDialog(`Remove ${pages.length} ${pages.length===1?'page':'pages'}?`,'The selected pages will be removed from this working copy. You can undo this before applying a redaction.','Delete pages',true)) return;
      await perform({action:'delete_pages',pages},'Removing pages…',{page:0,selected:[]}); toast('Selected pages removed');
    } else if (action==='extract-pages') showExportDialog('pdf',pages);
  } catch (error) { showError(error); }
}
function showPageActions(page) {
  const dialog=openModal(`Page ${page+1}`, 'Page tools apply to the working copy only.', `<div class="guide-grid"><button class="guide-card" id="one-page-rotate"><strong>${icon('rotate')}Rotate</strong><p>Rotate 90° clockwise.</p></button><button class="guide-card" id="one-page-export"><strong>${icon('download')}Export</strong><p>Export only this page.</p></button><button class="guide-card" id="one-page-duplicate"><strong>${icon('copy')}Duplicate</strong><p>Copy this page to the end.</p></button><button class="guide-card" id="one-page-delete"><strong>${icon('trash')}Remove</strong><p>Delete this page from the copy.</p></button></div>`);
  $('#one-page-export').addEventListener('click',()=>{dialog.close();showExportDialog('pdf',[page]);});
  for (const [id,action] of [['one-page-rotate','rotate-pages'],['one-page-duplicate','duplicate-pages'],['one-page-delete','delete-pages']]) {
    $('#' + id).addEventListener('click',()=>{dialog.close();state.selectedPages=new Set([page]);handleAction(action);});
  }
}
function showCommentDialog(point) {
  const dialog=openModal('A note worth keeping.', `Add a PDF comment on page ${state.page+1}.`, '<div class="field"><label for="comment-value">Your comment</label><textarea id="comment-value" rows="5" placeholder="Leave a little context…" maxlength="3000"></textarea></div>', '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="add-comment">Add comment</button>');
  $('#add-comment').addEventListener('click',async()=>{
    try {
      const text=$('#comment-value').value;
      await perform({action:'comment',page:state.page,x:point.x,y:point.y,text},'Adding comment…'); dialog.close(); toast('Comment added to the PDF');
    } catch(error){modalError(error);}
  });
  $('#comment-value').focus();
}

// ------------------------------------------------------------- protection
// A password is a thing you set, not a field you happen to notice in a panel.
// This is the prompt the Protect card and the toolbar button open; the panel
// behind it keeps the same action available with the permissions spelled out.
function showProtectDialog() {
  const d = state.doc;
  if (!d) return;
  if (!d.owner) { toast('This PDF restricts changes. Reopen it with the owner password first.', true); return; }
  const body = `
    <div class="field"><label for="protect-open">Opening password</label>
      <div class="password-row"><input id="protect-open" type="password" autocomplete="new-password" placeholder="At least 6 characters"><button type="button" class="icon-button small" id="protect-reveal" title="Show the passwords" aria-label="Show the passwords">${icon('eye')}</button></div>
      <p class="help-text">Anyone who opens the file needs this one.</p></div>
    <div class="field"><label for="protect-confirm">Type it again</label><input id="protect-confirm" type="password" autocomplete="new-password" placeholder="The same opening password"></div>
    <div class="field"><label for="protect-owner">Owner password</label><input id="protect-owner" type="password" autocomplete="new-password" placeholder="At least 8 characters, and different"><p class="help-text">Controls the permissions below. Keep it somewhere separate.</p></div>
    <div class="section-label">ALLOW IN THE PROTECTED COPY</div>
    <label class="check-row"><input id="protect-allow-print" type="checkbox" checked><span>Printing</span></label>
    <label class="check-row"><input id="protect-allow-copy" type="checkbox"><span>Copying text and images</span></label>
    <label class="check-row"><input id="protect-allow-edit" type="checkbox"><span>Editing, annotations and form filling</span></label>
    <p class="field-error" id="protect-error"></p>
    <div class="inline-note">${icon('info')}<span>AES-256. The password is applied to a copy — this document stays open and unprotected until you save or export it. There is no way to recover the password.</span></div>`;
  const footer = `<button class="button secondary" data-close>Cancel</button><button class="button primary" id="protect-run" disabled>${icon('lock')}Protect a copy</button>`;
  const dialog = openModal('Set a password.', 'Encrypt an exported copy so it asks for a password before it opens.', body, footer, 540);
  const values = {open: '', confirm: '', owner: '', touched: false};
  const problems = () => {
    const list = [];
    if (values.open.length < 6) list.push('The opening password needs at least 6 characters.');
    if (values.confirm !== values.open) list.push('The two opening passwords do not match.');
    if (values.owner.length < 8) list.push('The owner password needs at least 8 characters.');
    if (values.owner && values.owner === values.open) list.push('The owner password must be different from the opening password.');
    return list;
  };
  const check = () => {
    const list = problems();
    const error = $('#protect-error');
    // Nothing is red before the first keystroke: an empty form is not a mistake.
    if (error) error.textContent = values.touched ? (list[0] || '') : '';
    const button = $('#protect-run');
    if (button) button.disabled = list.length > 0;
    return list.length === 0;
  };
  const bind = (selector, key) => $(selector)?.addEventListener('input', event => {
    values[key] = event.target.value; values.touched = true; check();
  });
  bind('#protect-open', 'open');
  bind('#protect-confirm', 'confirm');
  bind('#protect-owner', 'owner');
  $('#protect-reveal')?.addEventListener('click', () => {
    const showing = $('#protect-open').type === 'text';
    ['#protect-open', '#protect-confirm', '#protect-owner'].forEach(selector => {
      const field = $(selector); if (field) field.type = showing ? 'password' : 'text';
    });
  });
  $('#protect-run')?.addEventListener('click', async () => {
    if (!check()) return;
    const saved = await exportDocument('protected', {
      openPassword: values.open, ownerPassword: values.owner,
      allowPrinting: $('#protect-allow-print').checked,
      allowCopying: $('#protect-allow-copy').checked,
      allowEditing: $('#protect-allow-edit').checked,
    });
    if (saved) dialog.close();
  });
  $('#protect-open')?.focus();
  check();
}

// ------------------------------------------------------------ document tools
// Watermark, header and footer, numbering, crop, bookmarks, attachments and
// compression: the page furniture a PDF application is expected to have once it
// can edit pages at all. One view, one dialog each, one request each.
const DOC_TOOLS = [
  {id:'watermark',     label:'Watermark',      icon:'layers',     hint:'Faint text or a logo across pages.'},
  {id:'header_footer', label:'Header & footer', icon:'text',       hint:'Margin text with {page}, {date} and {filename}.'},
  {id:'numbering',     label:'Page numbers',   icon:'pages',      hint:'Page numbers, or Bates stamps for legal work.'},
  {id:'crop',          label:'Crop pages',     icon:'fit',        hint:'Trim margins off one page or all of them.'},
  {id:'bookmarks',     label:'Bookmarks',      icon:'pin',        hint:'Build the outline from the document’s headings.'},
  {id:'attachments',   label:'Attachments',    icon:'folder',     hint:'Files carried inside the PDF itself.'},
  {id:'compress',      label:'Reduce size',    icon:'down-arrow', hint:'Smaller file: images, fonts and leftovers.'},
  {id:'resize',        label:'Page size',      icon:'fit',        hint:'Resize the paper, and scale what is on it.'},
  {id:'compare',       label:'Compare',        icon:'copy',       hint:'See what changed between two versions.'},
];

function renderDocumentTools() {
  return `<div class="doc-tools">${DOC_TOOLS.map(tool => `<button class="doc-tool" data-doc-tool="${tool.id}">${icon(tool.icon)}<span class="doc-tool-text"><strong>${escapeHTML(tool.label)}</strong><span>${escapeHTML(tool.hint)}</span></span></button>`).join('')}</div>
    <div class="inline-note">${icon('info')}<span>Headers, footers and numbers are written into the page as real text — they can be selected, searched and copied. A watermark is drawn on top of the content, not behind it. Everything here can be undone.</span></div>`;
}

// Which pages a dialog applies to. Null means every page.
function pageChoiceHTML(id, label = 'Pages') {
  return `<div class="field"><label for="${id}">${label}</label>
    <select id="${id}"><option value="all">All pages</option><option value="current">This page (${state.page + 1})</option><option value="custom">A range…</option></select>
    <input id="${id}-range" placeholder="e.g. 1-3, 5" hidden autocomplete="off"><p class="help-text" id="${id}-error"></p></div>`;
}
function wirePageChoice(id) {
  const select = $(`#${id}`);
  const range = $(`#${id}-range`);
  if (!select || !range) return;
  select.addEventListener('change', () => { range.hidden = select.value !== 'custom'; if (!range.hidden) range.focus(); });
}
function pageChoiceValue(id) {
  const select = $(`#${id}`);
  if (!select || select.value === 'all') return null;
  if (select.value === 'current') return [state.page];
  const parsed = parsePageRange($(`#${id}-range`).value, state.doc.pageCount);
  if (!parsed) throw new Error('Use page numbers and ranges, like 1-3, 5.');
  return parsed;
}

async function runDocumentTool(payload, title, options = {}) {
  if (!state.doc) return null;
  const result = await busy(title, () => api(docPath('/operation'), { method: 'POST', json: payload }));
  if (typeof result.pageCount === 'number') await adoptDocument(result, options);
  return result;
}

function openDocumentTool(id) {
  if (!state.doc) return;
  if (!state.doc.canEdit) { toast('This PDF restricts editing. Reopen it with the owner password.', true); return; }
  if (id === 'watermark') return showWatermarkDialog();
  if (id === 'header_footer') return showHeaderFooterDialog();
  if (id === 'numbering') return showNumberingDialog();
  if (id === 'crop') return showCropDialog();
  if (id === 'bookmarks') return showBookmarksDialog();
  if (id === 'attachments') return showAttachmentsDialog();
  if (id === 'compress') return showCompressDialog();
  if (id === 'resize') return showResizeDialog();
  if (id === 'compare') return showCompareDialog();
}

function showWatermarkDialog() {
  const body = `
    <div class="field"><label for="wm-kind">Watermark</label><select id="wm-kind"><option value="text">Text</option><option value="image">An image or logo</option></select></div>
    <div id="wm-text-wrap">
      <div class="field"><label for="wm-text">Text</label><input id="wm-text" value="DRAFT" maxlength="120" autocomplete="off"></div>
      <div class="field-row"><div class="field"><label for="wm-size">Size (pt)</label><input id="wm-size" type="number" min="6" max="300" value="54"></div>
        <div class="field"><label for="wm-color">Colour</label><input id="wm-color" type="color" value="#7a7a7a"></div></div>
    </div>
    <div id="wm-image-wrap" hidden>
      <div class="field"><label for="wm-image">Image</label><input id="wm-image" type="file" accept="image/*">
        <p class="help-text">A PNG with transparency works best. Its own transparency is kept.</p></div>
      <div class="field"><label for="wm-scale">Size on the page</label><select id="wm-scale"><option value="0.25">Quarter of the width</option><option value="0.4" selected>40% of the width</option><option value="0.6">60% of the width</option><option value="0.85">Most of the width</option></select></div>
    </div>
    <div class="field-row"><div class="field"><label for="wm-opacity">Opacity</label><input id="wm-opacity" type="number" min="0.02" max="1" step="0.01" value="0.12"></div>
      <div class="field"><label for="wm-rotation">Rotation (°)</label><input id="wm-rotation" type="number" min="-90" max="90" step="15" value="45"></div></div>
    <div class="field"><label for="wm-layout">Placement</label><select id="wm-layout"><option value="center">Across the middle</option><option value="tile">Tiled over the page</option><option value="top">Near the top</option><option value="bottom">Near the bottom</option></select></div>
    ${pageChoiceHTML('wm-pages')}
    <p class="field-error" id="wm-error"></p>`;
  const dialog = openModal('Mark every page.', 'A watermark is drawn over the content, faint enough to read through.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="wm-run">Add the watermark</button>', 540);
  wirePageChoice('wm-pages');
  $('#wm-kind').addEventListener('change', event => {
    const image = event.target.value === 'image';
    $('#wm-text-wrap').hidden = image;
    $('#wm-image-wrap').hidden = !image;
  });
  $('#wm-run').addEventListener('click', async () => {
    const error = $('#wm-error');
    error.textContent = '';
    const kind = $('#wm-kind').value;
    let payload = {action:'watermark', kind, pages: pageChoiceValue('wm-pages'),
      opacity: Number($('#wm-opacity').value), rotation: Number($('#wm-rotation').value),
      layout: $('#wm-layout').value};
    try {
      if (kind === 'text') {
        if (!$('#wm-text').value.trim()) throw new Error('Write the watermark text first.');
        Object.assign(payload, {text: $('#wm-text').value, size: Number($('#wm-size').value), color: $('#wm-color').value});
      } else {
        const file = $('#wm-image').files[0];
        if (!file) throw new Error('Choose an image for the watermark.');
        payload.image = await fileToBase64(file);
        payload.scale = Number($('#wm-scale').value);
      }
    } catch (problem) { error.textContent = problem.message; return; }
    try {
      await runDocumentTool(payload, 'Adding the watermark…');
      dialog.close();
      toast(`Watermark added${payload.pages ? ` to ${payload.pages.length} page(s)` : ' to every page'}`);
    } catch (problem) { error.textContent = problem.message || 'The watermark could not be added.'; }
  });
}

function showHeaderFooterDialog() {
  const tokenHint = 'Tokens: {page}, {pages}, {date}, {filename}, {title}, {bates}.';
  const body = `
    <div class="section-label">HEADER</div>
    <div class="field-row"><div class="field"><label for="hf-hl">Left</label><input id="hf-hl" autocomplete="off"></div>
      <div class="field"><label for="hf-hc">Centre</label><input id="hf-hc" autocomplete="off" placeholder="{title}"></div></div>
    <div class="field"><label for="hf-hr">Right</label><input id="hf-hr" autocomplete="off"></div>
    <div class="section-label">FOOTER</div>
    <div class="field-row"><div class="field"><label for="hf-fl">Left</label><input id="hf-fl" autocomplete="off" placeholder="{filename}"></div>
      <div class="field"><label for="hf-fc">Centre</label><input id="hf-fc" autocomplete="off"></div></div>
    <div class="field"><label for="hf-fr">Right</label><input id="hf-fr" autocomplete="off" placeholder="Page {page} of {pages}"></div>
    <div class="field-row"><div class="field"><label for="hf-size">Font size (pt)</label><input id="hf-size" type="number" min="6" max="24" value="9"></div>
      <div class="field"><label for="hf-color">Colour</label><input id="hf-color" type="color" value="#555555"></div></div>
    <div class="field-row"><div class="field"><label for="hf-margin">Margin (pt)</label><input id="hf-margin" type="number" min="10" max="120" value="36"></div>
      <div class="field"><label for="hf-date">Date used for {date}</label><input id="hf-date" type="date"></div></div>
    ${pageChoiceHTML('hf-pages')}
    <label class="check-row"><input id="hf-skip" type="checkbox"><span>Leave the first page alone<span><small>Useful when page one is a cover.</small></span></span></label>
    <p class="field-error" id="hf-error"></p>
    <div class="inline-note">${icon('info')}<span>${tokenHint} The text is written into the page, so it can be selected and searched.</span></div>`;
  const dialog = openModal('Set the margins to work.', 'Header and footer text, with tokens for the page number, date and file name.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="hf-run">Write it in</button>', 560);
  wirePageChoice('hf-pages');
  $('#hf-run').addEventListener('click', async () => {
    const payload = {action:'header_footer', pages: pageChoiceValue('hf-pages'),
      header_left: $('#hf-hl').value, header_center: $('#hf-hc').value, header_right: $('#hf-hr').value,
      footer_left: $('#hf-fl').value, footer_center: $('#hf-fc').value, footer_right: $('#hf-fr').value,
      size: Number($('#hf-size').value), color: $('#hf-color').value, margin: Number($('#hf-margin').value),
      skipFirst: $('#hf-skip').checked, date: $('#hf-date').value || undefined, name: state.doc.name};
    try {
      await runDocumentTool(payload, 'Writing the header and footer…');
      dialog.close();
      toast('Header and footer written');
    } catch (problem) { $('#hf-error').textContent = problem.message || 'That could not be written.'; }
  });
}

function showNumberingDialog() {
  const body = `
    <div class="field"><label for="num-mode">Kind</label><select id="num-mode"><option value="page">Page numbers</option><option value="bates">Bates numbering</option></select></div>
    <div id="num-page-wrap"><div class="field"><label for="num-format">Format</label><input id="num-format" value="Page {page} of {pages}" autocomplete="off"><p class="help-text">Tokens: {page}, {pages}, {date}, {filename}, {title}.</p></div></div>
    <div id="num-bates-wrap" hidden><div class="field"><label for="num-prefix">Bates prefix</label><input id="num-prefix" value="ABC-" autocomplete="off" maxlength="60"><p class="help-text">The number is zero-padded to the width below and printed after the prefix.</p></div></div>
    <div class="field-row"><div class="field"><label for="num-start">First number</label><input id="num-start" type="number" min="1" value="1"></div>
      <div class="field"><label for="num-digits">Digits</label><input id="num-digits" type="number" min="1" max="12" value="6"></div></div>
    <div class="field"><label for="num-position">Where</label><select id="num-position">
      <option value="footer_center">Bottom centre</option><option value="footer_right">Bottom right</option><option value="footer_left">Bottom left</option>
      <option value="header_center">Top centre</option><option value="header_right">Top right</option><option value="header_left">Top left</option></select></div>
    <div class="field-row"><div class="field"><label for="num-size">Font size (pt)</label><input id="num-size" type="number" min="6" max="24" value="9"></div>
      <div class="field"><label for="num-color">Colour</label><input id="num-color" type="color" value="#555555"></div></div>
    ${pageChoiceHTML('num-pages')}
    <label class="check-row"><input id="num-skip" type="checkbox"><span>Leave the first page alone</span></label>
    <p class="field-error" id="num-error"></p>`;
  const dialog = openModal('Number the pages.', 'Page numbers, or Bates stamps for documents that need them.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="num-run">Add the numbers</button>', 540);
  wirePageChoice('num-pages');
  $('#num-mode').addEventListener('change', event => {
    const bates = event.target.value === 'bates';
    $('#num-page-wrap').hidden = bates;
    $('#num-bates-wrap').hidden = !bates;
    if (bates && $('#num-digits').value === '6') $('#num-digits').value = '6';
  });
  $('#num-run').addEventListener('click', async () => {
    const mode = $('#num-mode').value;
    const payload = {action:'numbering', mode, pages: pageChoiceValue('num-pages'),
      position: $('#num-position').value, start: Number($('#num-start').value),
      digits: Number($('#num-digits').value), size: Number($('#num-size').value),
      color: $('#num-color').value, skipFirst: $('#num-skip').checked, name: state.doc.name};
    if (mode === 'page') payload.format = $('#num-format').value;
    else payload.prefix = $('#num-prefix').value;
    try {
      const result = await runDocumentTool(payload, 'Numbering the pages…');
      dialog.close();
      toast(`Numbers written on ${result.result?.written ?? 0} page(s)`);
    } catch (problem) { $('#num-error').textContent = problem.message || 'That could not be numbered.'; }
  });
}

function showCropDialog() {
  const body = `
    <p class="confirm-description">Cropping changes the page box; it does not delete anything. The content outside the new edge is hidden, and can be brought back by cropping with negative margins.</p>
    <div class="field"><label for="crop-unit">Units</label><select id="crop-unit"><option value="mm">Millimetres</option><option value="pt">Points</option><option value="in">Inches</option></select></div>
    <div class="field-row"><div class="field"><label for="crop-top">Top</label><input id="crop-top" type="number" min="0" step="1" value="10"></div>
      <div class="field"><label for="crop-bottom">Bottom</label><input id="crop-bottom" type="number" min="0" step="1" value="10"></div></div>
    <div class="field-row"><div class="field"><label for="crop-left">Left</label><input id="crop-left" type="number" min="0" step="1" value="10"></div>
      <div class="field"><label for="crop-right">Right</label><input id="crop-right" type="number" min="0" step="1" value="10"></div></div>
    ${pageChoiceHTML('crop-pages')}
    <p class="field-error" id="crop-error"></p>`;
  const dialog = openModal('Trim the edges.', 'Cut equal margins off the page box.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="crop-run">Crop</button>', 500);
  wirePageChoice('crop-pages');
  $('#crop-run').addEventListener('click', async () => {
    const payload = {action:'crop', unit: $('#crop-unit').value, pages: pageChoiceValue('crop-pages'),
      top: Number($('#crop-top').value), bottom: Number($('#crop-bottom').value),
      left: Number($('#crop-left').value), right: Number($('#crop-right').value)};
    try {
      const result = await runDocumentTool(payload, 'Cropping…');
      dialog.close();
      toast(`Cropped ${result.result?.pages ?? 0} page(s)`);
    } catch (problem) { $('#crop-error').textContent = problem.message || 'That could not be cropped.'; }
  });
}

async function showBookmarksDialog() {
  let listing;
  try { listing = (await api(docPath('/operation'), {method:'POST', json:{action:'bookmarks', mode:'list'}})).result.bookmarks; }
  catch (problem) { showError(problem); return; }
  const rows = () => listing.length
    ? listing.map((entry, index) => `<div class="list-row"><span class="list-main"><b>${'· '.repeat(Math.max(0, entry.level - 1))}${escapeHTML(entry.title)}</b><small>Page ${entry.page}</small></span>
        <button class="icon-button small" data-bookmark-remove="${index}" title="Remove this bookmark" aria-label="Remove ${escapeHTML(entry.title)}">${icon('close')}</button></div>`).join('')
    : '<div class="empty-state">No bookmarks yet. Generate them from the headings, or add one below.</div>';
  const body = () => `<p class="confirm-description">Bookmarks are the outline a reader shows down the side of the page. Generating them reads the type sizes: the biggest text becomes level one.</p>
    <div class="section-label">IN THIS DOCUMENT</div><div class="bookmark-list" id="bookmark-list">${rows()}</div>
    <div class="field"><label for="bookmark-title">Add a bookmark</label><div class="field-row"><input id="bookmark-title" placeholder="Title" autocomplete="off"><input id="bookmark-page" type="number" min="1" max="${state.doc.pageCount}" value="${state.page + 1}" aria-label="Page"></div></div>
    <div class="inline-actions"><button class="button secondary" id="bookmark-auto">${icon('spark')}Generate from headings</button><button class="button secondary" id="bookmark-add">${icon('plus')}Add</button></div>
    <p class="field-error" id="bookmark-error"></p>`;
  const dialog = openModal('Give the document an outline.', 'Bookmarks let a reader jump to a section.', body(),
    '<button class="button secondary" data-close>Done</button><button class="button ghost" id="bookmark-clear">Remove all</button>', 540);

  const refresh = () => {
    const host = $('#bookmark-list');
    if (host) host.innerHTML = rows();
    wireRows();
  };
  const apply = async payload => {
    try {
      const result = await runDocumentTool({action:'bookmarks', ...payload}, 'Updating the bookmarks…');
      listing = result.result.bookmarks;
      refresh();
      toast(`${listing.length} bookmark(s)`);
    } catch (problem) { $('#bookmark-error').textContent = problem.message || 'That did not work.'; }
  };
  function wireRows() {
    $$('[data-bookmark-remove]').forEach(button => button.addEventListener('click', () => {
      const index = Number(button.dataset.bookmarkRemove);
      const remaining = listing.filter((_, position) => position !== index);
      apply({mode:'set', bookmarks: remaining});
    }));
  }
  wireRows();
  $('#bookmark-auto').addEventListener('click', () => apply({mode:'auto', levels:2}));
  $('#bookmark-clear').addEventListener('click', () => apply({mode:'clear'}));
  $('#bookmark-add').addEventListener('click', () => {
    const title = $('#bookmark-title').value.trim();
    if (!title) { $('#bookmark-error').textContent = 'Give the bookmark a title.'; return; }
    const page = Math.max(1, Math.min(state.doc.pageCount, Number($('#bookmark-page').value) || 1));
    apply({mode:'set', bookmarks: [...listing, {level:1, title, page}]});
  });
}

async function showAttachmentsDialog() {
  let listing;
  const load = async () => (await api(docPath('/operation'), {method:'POST', json:{action:'attachments', mode:'list'}})).result.attachments;
  try { listing = await load(); } catch (problem) { showError(problem); return; }
  const rows = () => listing.length
    ? listing.map(entry => `<div class="list-row"><span class="list-main"><b>${escapeHTML(entry.name)}</b><small>${readableSize(entry.size)}${entry.description ? ' · ' + escapeHTML(entry.description) : ''}</small></span>
        <button class="icon-button small" data-attach-get="${escapeHTML(entry.name)}" title="Save this attachment" aria-label="Save ${escapeHTML(entry.name)}">${icon('download')}</button>
        <button class="icon-button small" data-attach-del="${escapeHTML(entry.name)}" title="Remove this attachment" aria-label="Remove ${escapeHTML(entry.name)}">${icon('close')}</button></div>`).join('')
    : '<div class="empty-state">No files attached. A PDF can carry a spreadsheet, a source image or a contract behind it.</div>';
  const body = () => `<p class="confirm-description">Attachments travel inside the PDF: the file is embedded, not linked, so it survives being emailed.</p>
    <div class="section-label">ATTACHED FILES</div><div class="attachment-list" id="attachment-list">${rows()}</div>
    <div class="field"><label for="attach-file">Attach a file</label><input id="attach-file" type="file"></div>
    <div class="field"><label for="attach-desc">Description (optional)</label><input id="attach-desc" maxlength="200" autocomplete="off"></div>
    <button class="button secondary full" id="attach-run">${icon('plus')}Attach</button>
    <p class="field-error" id="attach-error"></p>`;
  const dialog = openModal('Keep the paperwork together.', 'Files carried inside the PDF.', body(),
    '<button class="button secondary" data-close>Done</button>', 540);
  const refresh = () => { const host = $('#attachment-list'); if (host) host.innerHTML = rows(); wire(); };
  function wire() {
    $$('[data-attach-get]').forEach(button => button.addEventListener('click', async () => {
      try {
        const result = await api(docPath('/operation'), {method:'POST', json:{action:'attachments', mode:'extract', name: button.dataset.attachGet}});
        await saveBlob(base64ToBlob(result.result.data), result.result.name);
      } catch (problem) { $('#attach-error').textContent = problem.message || 'That could not be saved.'; }
    }));
    $$('[data-attach-del]').forEach(button => button.addEventListener('click', async () => {
      try {
        const result = await runDocumentTool({action:'attachments', mode:'delete', name: button.dataset.attachDel}, 'Removing the attachment…');
        listing = result.result.attachments; refresh();
      } catch (problem) { $('#attach-error').textContent = problem.message || 'That could not be removed.'; }
    }));
  }
  wire();
  $('#attach-run').addEventListener('click', async () => {
    const file = $('#attach-file').files[0];
    if (!file) { $('#attach-error').textContent = 'Choose a file to attach.'; return; }
    try {
      const result = await runDocumentTool({action:'attachments', mode:'add', name: file.name,
        data: await fileToBase64(file), description: $('#attach-desc').value}, 'Attaching the file…');
      listing = result.result.attachments;
      $('#attach-file').value = ''; $('#attach-desc').value = '';
      refresh();
      toast(`${file.name} attached`);
    } catch (problem) { $('#attach-error').textContent = problem.message || 'That could not be attached.'; }
  });
}

function showCompressDialog() {
  const body = `
    <p class="confirm-description">Three things make a PDF large: images at a resolution nobody can see, fonts carrying glyphs the document never uses, and objects left behind by earlier edits. All three are dealt with here.</p>
    <div class="field"><label for="compress-quality">Image quality</label><select id="compress-quality">
      <option value="85">High — photographs stay sharp</option><option value="72" selected>Balanced — the usual choice</option><option value="55">Small — for email and screen reading</option></select></div>
    <div class="field"><label for="compress-dpi">Image resolution</label><select id="compress-dpi">
      <option value="300">300 dpi — print</option><option value="150" selected>150 dpi — screen and ordinary printing</option><option value="96">96 dpi — smallest</option></select></div>
    <div class="inline-note">${icon('info')}<span>The image step is the only lossy one, and it is undone by the document's own undo, not by re-running this.</span></div>
    <p class="field-error" id="compress-error"></p>`;
  const dialog = openModal('Make the file smaller.', 'Re-save the document with the fat taken out.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="compress-run">Reduce the size</button>', 520);
  $('#compress-run').addEventListener('click', async () => {
    const before = state.doc.size;
    try {
      const result = await runDocumentTool({action:'compress', quality: Number($('#compress-quality').value),
        dpi: Number($('#compress-dpi').value)}, 'Reducing the file size…');
      dialog.close();
      const after = result.size ?? state.doc.size;
      const saved = before - after;
      toast(saved > 0
        ? `Smaller by ${readableSize(saved)} — ${readableSize(before)} → ${readableSize(after)}`
        : `Already lean: ${readableSize(before)} → ${readableSize(after)}`);
    } catch (problem) { $('#compress-error').textContent = problem.message || 'That could not be reduced.'; }
  });
}

// ------------------------------------------------------------------- stamps
// The standard marks, in the colours people expect: "Confidential" in green
// reads as a mistake, so the colour comes with the label.
const STAMPS = [
  {label:'Approved', colour:'#1e7a3c'},
  {label:'Reviewed', colour:'#1f5c8a'},
  {label:'Draft', colour:'#8a6d1f'},
  {label:'Confidential', colour:'#b3261e'},
  {label:'Final', colour:'#1e7a3c'},
  {label:'For Public Release', colour:'#1f5c8a'},
  {label:'Void', colour:'#b3261e'},
];

function showStampDialog() {
  const d = state.doc;
  if (!d?.canEdit) { toast('This PDF restricts editing. Reopen it with the owner password.', true); return; }
  const body = `
    <div class="field"><label for="stamp-label">Stamp</label><select id="stamp-label">
      ${STAMPS.map(stamp => `<option value="${stamp.label}">${stamp.label}</option>`).join('')}
      <option value="Custom">Custom text…</option></select></div>
    <div class="field" id="stamp-text-wrap" hidden><label for="stamp-text">Your text</label>
      <input id="stamp-text" maxlength="60" autocomplete="off" placeholder="Returned for revision"></div>
    <div class="field-row"><div class="field"><label for="stamp-size">Size (pt)</label>
      <input id="stamp-size" type="number" min="8" max="72" value="20"></div>
      <div class="field"><label for="stamp-color">Colour</label><input id="stamp-color" type="color" value="#1e7a3c"></div></div>
    <label class="check-row"><input id="stamp-date" type="checkbox" checked><span>Include today’s date<span><small>Printed small under the label.</small></span></span></label>
    <div class="inline-note">${icon('info')}<span>Next you click on the page where the stamp should go. It is drawn on top of the content, in the page itself.</span></div>`;
  const dialog = openModal('Mark the document.', 'A bordered stamp, placed where you click.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="stamp-arm">Place the stamp</button>', 520);
  const label = $('#stamp-label');
  label.addEventListener('change', () => {
    const custom = label.value === 'Custom';
    $('#stamp-text-wrap').hidden = !custom;
    const preset = STAMPS.find(stamp => stamp.label === label.value);
    if (preset) $('#stamp-color').value = preset.colour;
    if (custom) $('#stamp-text').focus();
  });
  $('#stamp-arm').addEventListener('click', () => {
    const custom = label.value === 'Custom';
    const text = custom ? $('#stamp-text').value.trim() : label.value;
    if (!text) { modalError(new Error('Write the stamp text first.')); return; }
    state.pendingStamp = {label: label.value, text, size: Number($('#stamp-size').value) || 20,
      color: $('#stamp-color').value, date: $('#stamp-date').checked};
    state.tool = 'stamp';
    state.selection = null;
    dialog.close();
    renderToolbar(); renderInspector(); renderOverlay();
    toast('Click on the page where the stamp should go');
  });
}

async function placeStamp(point) {
  const d = state.doc, pending = state.pendingStamp;
  if (!d || !pending) return;
  const page = d.pages[state.page];
  try {
    await perform({action:'stamp', page:state.page, x: Math.max(4, point.x), y: Math.max(4, point.y),
      label: pending.label, text: pending.text, size: pending.size, color: pending.color,
      date: pending.date}, 'Placing the stamp…');
    toast(`“${pending.text}” stamped`);
  } catch (error) { showError(error); }
}

// -------------------------------------------------------------------- links
function showLinkDialog(rect) {
  let listing = [];
  const rows = () => listing.length
    ? listing.map(entry => `<div class="list-row"><span class="list-main"><b>${escapeHTML(entry.label)}</b><small>${entry.kind === 'web' ? 'Web link' : entry.kind === 'page' ? 'Goes to a page' : 'Link'}</small></span>
        <button class="icon-button small" data-link-remove="${entry.index}" title="Remove this link" aria-label="Remove ${escapeHTML(entry.label)}">${icon('close')}</button></div>`).join('')
    : '<div class="empty-state">No links on this page yet.</div>';
  const body = `<p class="confirm-description">The box you drew becomes a link. A web link opens a browser; a page link jumps inside this document.</p>
    <div class="field"><label for="link-kind">Kind</label><select id="link-kind"><option value="uri">A web address</option><option value="goto">A page in this document</option></select></div>
    <div class="field" id="link-url-wrap"><label for="link-url">Address</label><input id="link-url" placeholder="https://example.com" autocomplete="off"></div>
    <div class="field" id="link-page-wrap" hidden><label for="link-page">Go to page</label><input id="link-page" type="number" min="1" max="${state.doc.pageCount}" value="1"></div>
    <button class="button primary full" id="link-add">${icon('plus')}Add this link</button>
    <div class="section-label" style="margin-top:18px">LINKS ON THIS PAGE</div>
    <div class="bookmark-list" id="link-list">${rows()}</div>
    <p class="field-error" id="link-error"></p>`;
  const dialog = openModal('Make it clickable.', 'Add a web or page link over the area you drew.', body,
    '<button class="button secondary" data-close>Done</button>', 520);
  const refresh = () => { const host = $('#link-list'); if (host) host.innerHTML = rows(); wire(); };
  const load = async () => {
    const result = await api(docPath('/operation'), {method:'POST', json:{action:'links', mode:'list', page:state.page}});
    listing = result.result.links;
    refresh();
  };
  function wire() {
    $$('[data-link-remove]').forEach(button => button.addEventListener('click', async () => {
      try {
        const result = await runDocumentTool({action:'links', mode:'remove', page:state.page,
          index:Number(button.dataset.linkRemove)}, 'Removing the link…');
        listing = result.result.links; refresh();
      } catch (problem) { $('#link-error').textContent = problem.message || 'That link could not be removed.'; }
    }));
  }
  $('#link-kind').addEventListener('change', event => {
    const web = event.target.value === 'uri';
    $('#link-url-wrap').hidden = !web;
    $('#link-page-wrap').hidden = web;
  });
  $('#link-add').addEventListener('click', async () => {
    const kind = $('#link-kind').value;
    const payload = {action:'links', mode:'add', page:state.page, rect, kind};
    if (kind === 'uri') payload.url = $('#link-url').value;
    else payload.target = Number($('#link-page').value);
    try {
      const result = await runDocumentTool(payload, 'Adding the link…');
      listing = result.result.links;
      refresh();
      toast('Link added');
    } catch (problem) { $('#link-error').textContent = problem.message || 'That link could not be added.'; }
  });
  load().catch(showError);
}

// -------------------------------------------------------------- page size
function showResizeDialog() {
  const page = state.doc.pages[state.page];
  const body = `
    <p class="confirm-description">The current page is ${Math.round(page.width)} × ${Math.round(page.height)} points. Resizing changes the paper; scaling moves and shrinks what is printed on it so the page still looks like itself.</p>
    <div class="field"><label for="resize-size">New page size</label><select id="resize-size">
      <option value="A4">A4 — 210 × 297 mm</option><option value="Letter">Letter — 8.5 × 11 in</option>
      <option value="A3">A3 — 297 × 420 mm</option><option value="A5">A5 — 148 × 210 mm</option>
      <option value="Legal">Legal — 8.5 × 14 in</option><option value="Tabloid">Tabloid — 11 × 17 in</option>
      <option value="Custom">Custom…</option></select></div>
    <div class="field-row" id="resize-custom" hidden>
      <div class="field"><label for="resize-width">Width</label><input id="resize-width" type="number" min="36" value="210"></div>
      <div class="field"><label for="resize-height">Height</label><input id="resize-height" type="number" min="36" value="297"></div>
    </div>
    <div class="field" id="resize-unit-wrap" hidden><label for="resize-unit">Units</label>
      <select id="resize-unit"><option value="mm">Millimetres</option><option value="pt">Points</option><option value="in">Inches</option></select></div>
    <label class="check-row"><input id="resize-scale" type="checkbox" checked><span>Scale the content to fit<span><small>Off keeps the text at its size and changes only the paper — content may be cut off or sit in a corner.</small></span></span></label>
    ${pageChoiceHTML('resize-pages')}
    <p class="field-error" id="resize-error"></p>`;
  const dialog = openModal('Change the paper.', 'Every page, or the ones you choose.', body,
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="resize-run">Resize</button>', 520);
  wirePageChoice('resize-pages');
  $('#resize-size').addEventListener('change', event => {
    const custom = event.target.value === 'Custom';
    $('#resize-custom').hidden = !custom;
    $('#resize-unit-wrap').hidden = !custom;
  });
  $('#resize-run').addEventListener('click', async () => {
    const payload = {action:'resize', size: $('#resize-size').value, scale: $('#resize-scale').checked,
      pages: pageChoiceValue('resize-pages')};
    if (payload.size === 'Custom') {
      payload.width = Number($('#resize-width').value);
      payload.height = Number($('#resize-height').value);
      payload.unit = $('#resize-unit').value;
    }
    try {
      const result = await runDocumentTool(payload, 'Resizing the pages…');
      dialog.close();
      const info = result.result || {};
      toast(`Resized ${info.pages ?? 0} page(s) to ${Math.round(info.width)} × ${Math.round(info.height)} pt`);
    } catch (problem) { $('#resize-error').textContent = problem.message || 'That could not be resized.'; }
  });
}

// ---------------------------------------------------------------- compare
async function showCompareDialog() {
  const others = (state.openDocs || []).filter(doc => doc.id !== state.doc.id);
  const body = `<p class="confirm-description">This compares the words on each page, not the pixels. It says which pages differ and what was added or removed — not whether a moved paragraph is the same paragraph.</p>
    ${others.length ? `<div class="field"><label for="compare-open">Compare with a document that is open</label>
      <select id="compare-open"><option value="">Choose…</option>${others.map(doc => `<option value="${escapeHTML(doc.id)}">${escapeHTML(doc.name)}</option>`).join('')}</select></div>
      <div class="section-label">OR</div>` : ''}
    <div class="field"><label for="compare-file">Compare with a file</label><input id="compare-file" type="file" accept="application/pdf,.pdf"></div>
    <button class="button primary full" id="compare-run">Compare</button>
    <p class="field-error" id="compare-error"></p>
    <div id="compare-report"></div>`;
  const dialog = openModal('What changed?', 'Two versions of the same document, side by side in words.', body,
    '<button class="button secondary" data-close>Done</button>', 560);

  $('#compare-run').addEventListener('click', async () => {
    const chosen = $('#compare-open')?.value || '';
    const file = $('#compare-file').files[0];
    const error = $('#compare-error');
    const report = $('#compare-report');
    error.textContent = '';
    if (!chosen && !file) { error.textContent = 'Choose an open document or a file to compare with.'; return; }
    report.innerHTML = '';
    try {
      let result;
      if (file) {
        const form = new FormData();
        form.append('file', file);
        result = await busy('Comparing…', () => api(docPath('/compare-file'), {method:'POST', body:form}));
      } else {
        result = await busy('Comparing…', () => api(docPath('/compare'), {method:'POST', json:{document: chosen}}));
      }
      report.innerHTML = compareReportHTML(result);
      wireReport(result);
    } catch (problem) { error.textContent = problem.message || 'The comparison could not be run.'; }
  });

  function compareReportHTML(result) {
    if (result.identical) {
      return `<div class="notice purple">${icon('check')}<strong>No differences in the text.</strong>${result.total} page${result.total === 1 ? '' : 's'} compared; every one reads the same.</div>`;
    }
    const rows = result.pages.filter(page => page.status !== 'same').map(page => {
      const badge = page.status === 'changed' ? 'Changed' : page.status === 'added' ? 'Only in the second' : 'Only in the first';
      const detail = page.status === 'changed'
        ? `<span class="diff-add">+${page.addedCount}</span> <span class="diff-remove">−${page.removedCount}</span>`
        : '';
      const words = page.status === 'changed'
        ? `<small>${page.removed.slice(0, 6).map(w => `<s>${escapeHTML(w)}</s>`).join(' ')} ${page.added.slice(0, 6).map(w => `<b>${escapeHTML(w)}</b>`).join(' ')}</small>`
        : '';
      return `<button class="list-row" data-goto-page="${page.page}"><span class="list-main"><b>Page ${page.page} · ${badge}</b>${words}</span>${detail}</button>`;
    }).join('');
    return `<div class="section-label">${result.differing} OF ${result.total} PAGES DIFFER</div><div class="bookmark-list">${rows}</div>`;
  }

  function wireReport(result) {
    $$('[data-goto-page]').forEach(button => button.addEventListener('click', () => {
      const page = Number(button.dataset.gotoPage) - 1;
      dialog.close();
      if (page < state.doc.pageCount) setPage(page);
    }));
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new Error('That file could not be read.'));
    reader.readAsDataURL(file);
  });
}

function base64ToBlob(encoded) {
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return new Blob([bytes], {type: 'application/octet-stream'});
}

// --------------------------------------------------------------- date stamping
// A date you choose, written into the page as real text. Not a picture, not an
// annotation: it is laid out with the same text engine as Add text, so it can
// be selected, searched and copied in any reader afterwards.
function showDateDialog() {
  const d = state.doc;
  if (!d) return;
  if (!d.canEdit) { toast('This PDF restricts editing. Reopen it with the owner password.', true); return; }
  const formats = ['YYYY-MM-DD', 'DD/MM/YYYY', 'MM/DD/YYYY', 'DD.MM.YYYY'];
  const today = formatDateValue(new Date(), 'YYYY-MM-DD');
  const body = `
    <div class="field"><label for="date-value">Date</label>
      <div class="date-row"><input id="date-value" value="${today}" data-date-format="YYYY-MM-DD" autocomplete="off" aria-describedby="date-help">
        <button type="button" class="icon-button small date-picker-button" data-calendar="date-value" title="Pick a date from a calendar" aria-label="Pick a date from a calendar">${icon('calendar')}</button></div>
      <p class="help-text" id="date-help">Type it or pick it from the calendar.</p></div>
    <div class="field"><label for="date-format">Format</label><select id="date-format">${formats.map(f => `<option value="${f}">${f}</option>`).join('')}</select></div>
    <div class="field-row"><div class="field"><label for="date-size">Size (pt)</label><input id="date-size" type="number" min="6" max="96" step=".5" value="12"></div>
      <div class="field"><label for="date-color">Colour</label><input id="date-color" type="color" value="#292b3d"></div></div>
    <p class="field-error" id="date-error"></p>
    <div class="inline-note">${icon('info')}<span>Next you click on the page where the date should go. It is written as text, so it can be selected and searched — and it works on a scan, where there is no text to edit.</span></div>`;
  const footer = `<button class="button secondary" data-close>Cancel</button><button class="button primary" id="date-place">${icon('calendar')}Place the date</button>`;
  const dialog = openModal('Place a date.', 'Write the date you choose into the page.', body, footer, 520);

  const field = $('#date-value');
  const current = () => {
    const text = field.value.trim();
    const date = parseDateValue(text, field.dataset.dateFormat);
    return date ? formatDateValue(date, field.dataset.dateFormat) : null;
  };
  const check = () => {
    const error = $('#date-error');
    const ok = current() !== null;
    if (error) error.textContent = ok ? '' : `That is not a date in the ${field.dataset.dateFormat} format.`;
    const button = $('#date-place');
    if (button) button.disabled = !ok;
    return ok;
  };
  field.addEventListener('input', check);
  // Changing the format keeps the date, not the string: 03/04/2026 means the
  // third of April in one format and the fourth of March in another, and
  // silently keeping the digits would change which day gets stamped.
  $('#date-format').addEventListener('change', event => {
    const was = field.dataset.dateFormat;
    const date = parseDateValue(field.value, was);
    field.dataset.dateFormat = event.target.value;
    field.placeholder = event.target.value;
    if (date) field.value = formatDateValue(date, event.target.value);
    check();
  });
  $('#date-place').addEventListener('click', () => {
    if (!check()) return;
    const date = parseDateValue(field.value, field.dataset.dateFormat);
    state.pendingDate = {
      text: formatDateValue(date, field.dataset.dateFormat),
      size: Math.max(6, Math.min(96, Number($('#date-size').value) || 12)),
      color: $('#date-color').value,
    };
    state.tool = 'date';
    state.selection = null;
    dialog.close();
    renderToolbar(); renderInspector(); renderOverlay();
    toast('Click on the page where the date should go');
  });
  field.focus();
  field.select();
  check();
}

// One click, one date. The box is measured from the text so the date is laid
// out at the size that was chosen instead of shrinking to fit a guess.
async function placeDate(point) {
  const d = state.doc, pending = state.pendingDate;
  if (!d || !pending) return;
  const page = d.pages[state.page];
  const size = pending.size;
  const width = Math.min(page.width - 4, Math.max(60, pending.text.length * size * .78 + 14));
  const left = Math.max(2, Math.min(point.x, page.width - width - 2));
  const top = Math.max(2, Math.min(point.y - size, page.height - size * 2 - 2));
  const rect = [left, top, left + width, top + size * 1.9];
  try {
    await perform({action:'add_text', page:state.page, rect, text:pending.text, size,
      color:pending.color, family:'sans-serif'}, 'Placing the date…');
    toast(`“${pending.text}” placed — select it like any other text`);
  } catch (error) { showError(error); }
}

function showSignatureDialog() {
  if (!state.doc?.canEdit) { toast('This PDF does not permit adding a signature.',true); return; }
  let mode='type',drawing=false,hasInk=false,lastPoint=null;
  const dialog=openModal('Make your mark.', 'Create a visual signature, then place it on your PDF.', '<div class="signature-tabs"><button class="signature-tab active" data-sign-mode="type">Type your name</button><button class="signature-tab" data-sign-mode="draw">Draw a signature</button></div><div class="field" id="signature-name-wrap"><label for="signature-name">Full name</label><input id="signature-name" placeholder="Your name" autocomplete="name"></div><canvas class="signature-preview" id="signature-canvas" width="800" height="290" aria-label="Signature drawing area"></canvas><div class="signature-helper"><span id="signature-helper-text">A preview of your visual signature.</span><button class="button ghost" id="signature-clear">Clear</button></div><div class="notice purple">This creates a signature image. It is not a certificate-based digital signature, and does not verify the signer’s identity.</div>', '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="use-signature">Use signature</button>');
  const canvas=$('#signature-canvas'),ctx=canvas.getContext('2d');
  const clear=()=>{ctx.clearRect(0,0,canvas.width,canvas.height);hasInk=false;};
  const typePreview=()=>{
    clear(); const name=$('#signature-name').value.trim();
    if (!name) return;
    const size=Math.min(63, 700 / Math.max(name.length*.55,1));
    ctx.font=`italic ${size}px "Segoe Script", "Apple Chancery", "Brush Script MT", cursive`;
    ctx.fillStyle='#363047';ctx.textBaseline='middle';ctx.fillText(name,45,145,700);hasInk=true;
  };
  const position=event=>{const box=canvas.getBoundingClientRect();return {x:(event.clientX-box.left)/box.width*canvas.width,y:(event.clientY-box.top)/box.height*canvas.height};};
  $$('[data-sign-mode]',dialog).forEach(button=>button.addEventListener('click',()=>{
    mode=button.dataset.signMode;
    $$('[data-sign-mode]',dialog).forEach(b=>b.classList.toggle('active',b===button));
    $('#signature-name-wrap').hidden=mode==='draw';
    $('#signature-helper-text').textContent=mode==='draw'?'Draw with your mouse, trackpad, or touchscreen.':'A preview of your visual signature.';
    clear();if(mode==='type')typePreview();
  }));
  $('#signature-name').addEventListener('input',typePreview);
  $('#signature-clear').addEventListener('click',()=>{clear();if(mode==='type')$('#signature-name').value='';});
  canvas.addEventListener('pointerdown',event=>{if(mode!=='draw')return;drawing=true;lastPoint=position(event);canvas.setPointerCapture(event.pointerId);});
  canvas.addEventListener('pointermove',event=>{
    if(!drawing)return;const point=position(event);ctx.strokeStyle='#363047';ctx.lineWidth=3.4;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(lastPoint.x,lastPoint.y);ctx.lineTo(point.x,point.y);ctx.stroke();lastPoint=point;hasInk=true;
  });
  canvas.addEventListener('pointerup',()=>{drawing=false;});canvas.addEventListener('pointercancel',()=>{drawing=false;});
  $('#use-signature').addEventListener('click',()=>{
    if(!hasInk){modalError(new Error('Type your name or draw a signature first.'));return;}
    canvas.toBlob(blob=>{
      if(!blob){modalError(new Error('The signature image could not be created.'));return;}
      state.pendingImage=new File([blob],'Signature.png',{type:'image/png'});state.tool='signature';state.selection=null;
      clearSearch();dialog.close();renderToolbar();renderInspector();renderOverlay();toast('Drag an area on the page to place your signature');
    },'image/png');
  });
  $('#signature-name').focus();
}

function showDependencies() {
  openModal('Offline engines. Optional power.', 'Core PDF editing works without these external applications.', `<h3 class="guide-heading">Office documents → PDF</h3><p class="confirm-description">Install LibreOffice on your computer. KADOMA detects the standard Windows and macOS install locations. Complex Office layouts should be checked after conversion.</p><div class="code-line">Optional override: PAPERDESK_LIBREOFFICE</div><h3 class="guide-heading">Scans → searchable text</h3><p class="confirm-description">Install Tesseract OCR and the language packs you need. On Windows, add its folder to PATH or use the usual Program Files location. On a Mac with Homebrew:</p><div class="code-line">brew install tesseract tesseract-lang</div><div class="code-line" style="margin-top:8px">Optional override: PAPERDESK_TESSERACT</div><div class="notice purple">Restart KADOMA after installation. Use eng for English, ara for Arabic, or eng+ara for both when those packs are installed.</div>`, '<button class="button primary" data-close>Got it</button>',540);
}
function showShortcuts() {
  const rows=[['Open a file','Ctrl / ⌘ O'],['Save over this file','Ctrl / ⌘ S'],['Save as a new file','Ctrl / ⌘ Shift S'],['Export a copy','Export button'],['Print preview','Ctrl / ⌘ P'],['Find in document','Ctrl / ⌘ F'],['Undo','Ctrl / ⌘ Z'],['Redo','Ctrl / ⌘ Shift Z'],['Edit text in place','Double-click the text'],['Apply / cancel an in-place edit','Enter / Esc'],['New line in the box','Shift + Enter'],['Select / Edit text','V / E'],['Add text / Highlight','T / H'],['Add comment / Redact','C / R'],['Previous / Next page','Page Up / Page Down']];
  openModal('A faster flow.', 'Keyboard shortcuts for your offline workspace.', `<div class="shortcut-list">${rows.map(([name,key])=>`<div class="shortcut-row"><span>${name}</span><kbd>${key}</kbd></div>`).join('')}</div>`, '<button class="button primary" data-close>Back to work</button>');
}
function showGuide() {
  openModal('Meet your new paper trail.', 'KADOMA PDF 0.28.2 — a practical, offline PDF workspace.', `<div class="guide-grid"><div class="guide-card"><strong>${icon('save')}Save, and Save as</strong><p><b>Save</b> writes over the file you opened, in one press, and the header says whether there is anything unsaved. <b>Save as</b> puts the copy wherever you choose and the document follows it from then on. A file that changed on disk since it was opened is never overwritten without saying so.</p></div><div class="guide-card"><strong>${icon('layers')}A menu across the top</strong><p>The view tabs and the panel switches are in a bar across the top, and the bar folds away with one press. The page starts at the left edge of the window: nothing sits beside it that you did not ask for.</p></div><div class="guide-card"><strong>${icon('fit')}The page as large as it will go</strong><p><b>Fit width</b> now genuinely fills the width — it used to stop at 125%, which left a quarter of the window empty on an ordinary screen. The page is drawn at the size it is shown, so it stays sharp when it is large, and the zoom controls still override the fit at any time.</p></div><div class="guide-card"><strong>${icon('layers')}Several documents at once</strong><p>Opening a document no longer closes the one before it. The workspace keeps the last few open, and the button beside the document name lists them: switch between them, or close one. A document that is open can be combined without being found on disk again.</p></div><div class="guide-card"><strong>${icon('pin')}A panel you can put away</strong><p>The tools panel can stay pinned open, or auto-hide to a narrow rail and come back when you hover it or press its tab. It floats over the page, so looking at the tools never moves what you are reading.</p></div><div class="guide-card"><strong>${icon('edit')}Edit in place</strong><p>Click a line of text and type over it. Enter applies, Esc cancels, and clearing the box deletes the line. Longer text grows into free space; paragraph reflow is not supported.</p></div><div class="guide-card"><strong>${icon('merge')}Merge & organize</strong><p>Combine several PDFs, images or Office files into one — including documents you already have open, which are listed first with an <b>Add all</b> button — in the order you choose, taking only some pages from a source if you like. Then rotate, duplicate, reorder or delete pages.</p></div><div class="guide-card"><strong>${icon('split')}Split it up</strong><p>Break one PDF into several files: equal blocks of pages, a chosen number of files, or your own page ranges. The window lists every file it is about to create before you press the button.</p></div><div class="guide-card"><strong>${icon('lock')}Protect & redact</strong><p>AES-256 password protection and actual content removal. Redaction clears the working undo history.</p></div><div class="guide-card"><strong>${icon('form')}Forms & signatures</strong><p>Create and fill text, date, checkbox, and dropdown fields. Date fields open a calendar to pick from. Add typed or drawn visual signatures.</p></div><div class="guide-card"><strong>${icon('convert')}Convert & recognize</strong><p>Export text, tables, slide images, and page images. Office import and OCR use optional local engines.</p></div><div class="guide-card"><strong>${icon('print')}Print & clear</strong><p>Send every page straight to a printer at print quality, and empty a filled-in form in one step. Neither is ever part of a printout.</p></div></div><div class="notice purple"><strong>Honest boundaries.</strong>No cloud synchronization, online review sharing, remote signature tracking, AI assistant, or certificate-based signing is included in this offline version. Text editing works one visual line at a time.</div><div class="inline-note">${icon('shield')}<span>${isHostedPreview ? 'Hosted preview: uploads are sent to this workspace. Use non-sensitive files; native desktop builds process locally. ' : ''}Files and undo snapshots stay in memory until you close the document or the application. Nothing is written to disk until you press Save, Save as, or export a copy. Temporary Office/OCR files are deleted when their operation completes.</span></div><button class="button secondary full" id="guide-dependencies">Optional engine setup</button><button class="button ghost full" id="guide-shortcuts">Keyboard shortcuts</button>`, '<button class="button primary" data-close>Let’s get to work</button>',620);
  $('#guide-dependencies').addEventListener('click',showDependencies);
  $('#guide-shortcuts').addEventListener('click',showShortcuts);
}

let searchTimeout;
$('#document-search').addEventListener('input',event=>{
  clearTimeout(searchTimeout);
  const query=event.target.value.trim();
  const generation=++state.searchGeneration;
  if(!query){clearSearch();renderInspector();renderOverlay();return;}
  searchTimeout=setTimeout(async()=>{
    if(!state.doc)return;
    try{
      const result=await api(docPath('/search?q='+encodeURIComponent(query)));
      if(generation!==state.searchGeneration)return;
      state.searchQuery=query;state.searchMatches=result.matches;state.searchIndex=0;state.selection=null;
      if(result.matches.length){await setPage(result.matches[0].page);}else{renderInspector();renderOverlay();}
    }catch(error){showError(error);}
  },240);
});
$('#document-search').addEventListener('keydown',event=>{
  if(event.key==='Escape'){clearSearch();renderInspector();renderOverlay();event.target.blur();}
  if(event.key==='Enter'&&state.searchMatches.length){
    state.searchIndex=(state.searchIndex+(event.shiftKey?-1:1)+state.searchMatches.length)%state.searchMatches.length;
    setPage(state.searchMatches[state.searchIndex].page);
  }
});

// Application actions and file pickers.
$$('#navigation [data-view]').forEach(button=>button.addEventListener('click',()=>setView(button.dataset.view)));
$('#logo-home').addEventListener('click',event=>{event.preventDefault();setView('home');});
// Right-clicking the page itself offers the same page menu as a thumbnail.
$('#canvas-scroll').addEventListener('scroll', () => {
  cancelAnimationFrame(scrollSyncFrame);
  scrollSyncFrame = requestAnimationFrame(syncPageToScroll);
}, {passive: true});
$('#canvas-scroll').addEventListener('contextmenu', event => {
  if (!state.doc || state.view !== 'edit') return;
  pageContextMenu(event, state.page);
});
$('#open-document').addEventListener('click',openFilePicker);
$('#file-input').addEventListener('change',event=>openFile(event.target.files[0]));
$('#merge-document').addEventListener('click',()=>showMergeDialog());
$('#split-document').addEventListener('click',showSplitDialog);
// The panel pin and its rail tab are static markup, so they are bound once here
// rather than on every panel re-render.
$('#inspector-pin').addEventListener('click',toggleInspectorPin);
// The menu bar: fold it away, and choose which panels the page shares its width
// with.
$('#menu-collapse').addEventListener('click',toggleMenu);
$('#toggle-thumbnails').addEventListener('click',toggleThumbnails);
$('#toggle-tools').addEventListener('click',toggleTools);
$('#toggle-rail').addEventListener('click',toggleRail);
$('#toggle-focus').addEventListener('click',toggleFocus);
$('#inspector-tab').addEventListener('click',() => setInspectorPeek(!state.inspectorPeek));
// A sticky reveal is put back by clicking anywhere else, or by Escape. Capture
// phase so it happens before the click does anything else.
document.addEventListener('pointerdown',event => {
  if (!state.inspectorPeek) return;
  if ($('#inspector-rail')?.contains(event.target)) return;
  setInspectorPeek(false);
},true);
document.addEventListener('keydown',event => { if (event.key === 'Escape') { setInspectorPeek(false); closeDocMenu(); } });
// Keyboard reach: tabbing into the rail brings the panel out, and leaving it
// puts it back. The rail tab is deliberately excluded, because focusing it is
// the first half of clicking it, and the click is what decides the state.
$('#inspector-rail').addEventListener('focusin',event => {
  if (!state.inspectorPinned && event.target.id !== 'inspector-tab') setInspectorPeek(true);
});
$('#inspector-rail').addEventListener('focusout',event => {
  if (state.inspectorPinned || $('#inspector-rail').contains(event.relatedTarget)) return;
  setInspectorPeek(false);
});
// The open-documents switcher. Its menu is a body-level popover, so it is put
// away by anything that would leave it stranded: a click elsewhere, Escape, a
// scroll, or the window changing size.
$('#doc-switcher').addEventListener('click',event => { event.stopPropagation(); toggleDocMenu(); });
document.addEventListener('pointerdown',event => {
  if (!docMenu) return;
  if (docMenu.contains(event.target) || event.target.closest('#doc-switcher')) return;
  closeDocMenu();
},true);
window.addEventListener('resize',closeDocMenu);
window.addEventListener('blur',closeDocMenu);
$('#image-input').addEventListener('change',async event=>{
  const file=event.target.files[0];if(!file)return;
  if(!await confirmPreviewUpload())return;
  if(state.imageReplaceXref!==null){
    const form=new FormData();form.append('file',file);form.append('page',String(state.page));form.append('xref',String(state.imageReplaceXref));
    try{const result=await busy('Replacing the embedded image…',()=>api(docPath('/image'),{method:'POST',body:form}));state.imageReplaceXref=null;await adoptDocument(result);toast('Embedded image replaced');}
    catch(error){state.imageReplaceXref=null;showError(error);}return;
  }
  if(!state.doc.canEdit){toast('This PDF does not permit inserting images.',true);return;}
  state.pendingImage=file;state.tool='image';state.selection=null;clearSearch();renderToolbar();renderInspector();renderOverlay();toast('Drag an area on the page to place your image');
});
$('#new-document').addEventListener('click',newDocument);
$('#export-document').addEventListener('click',()=>showExportDialog());
$('#save-document').addEventListener('click',()=>saveDocument().catch(showError));
$('#save-as-document').addEventListener('click',()=>saveDocument({as:true}).catch(showError));
$('#add-pages').addEventListener('click',showAddPages);
$('#help-button').addEventListener('click',showGuide);
$('#keyboard-button').addEventListener('click',showShortcuts);
$('#theme-button').addEventListener('click',toggleTheme);
$('#home-search').addEventListener('input',()=>renderHome());
$('#share-document').addEventListener('click',shareDocument);
$('#print-document').addEventListener('click',()=>showPrintPreview());
$('#clear-fields').addEventListener('click',clearFilledFields);
$('#default-app-button').addEventListener('click',showDefaultAppDialog);
$('#undo').addEventListener('click',()=>perform({action:'undo'},'Undoing the last edit…').catch(showError));
$('#redo').addEventListener('click',()=>perform({action:'redo'},'Restoring your edit…').catch(showError));
$('#previous-page').addEventListener('click',()=>setPage(state.page-1));
$('#next-page').addEventListener('click',()=>setPage(state.page+1));
$('#current-page').addEventListener('change',event=>{const page=Number(event.target.value)-1;if(Number.isInteger(page)&&page>=0&&page<state.doc.pageCount)setPage(page);else updateHeader();});
$('#zoom-select').addEventListener('change',event=>{state.zoom=event.target.value;applyZoom();});
function changeZoom(direction){
  const sizes=[.5,.75,1,1.25,1.5,2,2.5,3];
  const current=['fit','page'].includes(state.zoom)?$('#paper').clientWidth/state.doc.pages[state.page].width:Number(state.zoom);
  const next=direction>0?sizes.find(z=>z>current+.02):[...sizes].reverse().find(z=>z<current-.02);
  if(next){state.zoom=String(next);applyZoom();}
}
$('#zoom-out').addEventListener('click',()=>changeZoom(-1));$('#zoom-in').addEventListener('click',()=>changeZoom(1));
new ResizeObserver(()=>{if(state.view!=='pages')applyZoom();}).observe($('#canvas-area'));

document.addEventListener('keydown',event=>{
  if(state.busy||$('#modal').open||!state.doc)return;
  if(event.target.isContentEditable)return;   // the on-page editor owns its own keys
  const command=event.ctrlKey||event.metaKey;
  const key=event.key.toLowerCase();
  if(command&&key==='o'){event.preventDefault();openFilePicker();return;}
  if(command&&key==='s'){event.preventDefault();saveDocument({as:event.shiftKey}).catch(showError);return;}
  if(command&&key==='p'){event.preventDefault();showPrintPreview();return;}
  if(command&&key==='f'){event.preventDefault();$('#document-search').focus();$('#document-search').select();return;}
  const typing=event.target.matches('input,textarea,select')||event.target.isContentEditable;
  if(command&&key==='z'&&!typing){event.preventDefault();const action=event.shiftKey?'redo':'undo';if(state.doc[action==='undo'?'canUndo':'canRedo'])perform({action},'Updating history…').catch(showError);return;}
  if(command&&key==='y'&&!typing){event.preventDefault();if(state.doc.canRedo)perform({action:'redo'},'Restoring your edit…').catch(showError);return;}
  if(typing||command||event.altKey)return;
  if(event.key==='PageDown'){event.preventDefault();setPage(state.page+1);}
  if(event.key==='PageUp'){event.preventDefault();setPage(state.page-1);}
  if(event.key==='Escape'){state.selection=null;state.pendingImage=null;pointerStart=null;clearSearch();state.tool='view';renderToolbar();renderInspector();renderOverlay();}
  const shortcuts={v:'select',e:'edit',t:'text',h:'highlight',c:'comment',r:'redact'};
  if(shortcuts[key]){
    if(key==='r'){setView('protect');chooseTool('redact');}
    else{if(state.view!=='edit')setView('edit');if(state.doc.canEdit||['v','h','c'].includes(key))chooseTool(shortcuts[key]);}
  }
});

let dragDepth=0;
document.addEventListener('dragenter',event=>{
  if(event.dataTransfer?.types.includes('Files')){event.preventDefault();dragDepth++;$('#drop-overlay').hidden=false;}
});
document.addEventListener('dragover',event=>{if(event.dataTransfer?.types.includes('Files'))event.preventDefault();});
document.addEventListener('dragleave',event=>{if(event.dataTransfer?.types.includes('Files')){dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)$('#drop-overlay').hidden=true;}});
document.addEventListener('drop',event=>{
  if(!event.dataTransfer?.files.length)return;event.preventDefault();dragDepth=0;$('#drop-overlay').hidden=true;
  const files=[...event.dataTransfer.files];
  // One file is almost always "open this"; several is almost always "put these
  // together", so the merge window opens with them already listed and in order.
  if(files.length===1)openFile(files[0]);
  else showMergeDialog({files});
});

// ---------------------------------------------------------------- sharing
// Everything below reaches outside the browser sandbox (clipboard, file
// manager, mail client, registry), so it only runs in the desktop shell. The
// engine refuses the same calls in a browser preview; this is the matching
// guard on the interface side.
function desktopApp() { return !!state.capabilities.desktop; }

// ------------------------------------------------------- date fields + calendar
// The calendar is built here rather than pulled from a library: the app ships
// with no runtime CDN and no external requests, and a date picker is small
// enough to own outright.
const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];
const WEEKDAY_NAMES = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

function formatDateValue(date, format) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  if (format === 'DD/MM/YYYY') return `${day}/${month}/${year}`;
  if (format === 'MM/DD/YYYY') return `${month}/${day}/${year}`;
  if (format === 'DD.MM.YYYY') return `${day}.${month}.${year}`;
  return `${year}-${month}-${day}`;
}

function parseDateValue(text, format) {
  const parts = String(text || '').match(/\d+/g);
  if (!parts || parts.length < 3) return null;
  let year, month, day;
  if (format === 'DD/MM/YYYY' || format === 'DD.MM.YYYY') [day, month, year] = parts;
  else if (format === 'MM/DD/YYYY') [month, day, year] = parts;
  else [year, month, day] = parts;
  year = Number(year); month = Number(month); day = Number(day);
  if (year < 100) year += 2000;
  const date = new Date(year, month - 1, day);
  // Reject anything the Date object silently rolled over, such as 31/02.
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return date;
}

function calendarHTML(view, selected) {
  const year = view.getFullYear(), month = view.getMonth();
  const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7; // Monday-first
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();
  let cells = '';
  for (let i = 0; i < firstWeekday; i++) cells += '<span class="calendar-blank"></span>';
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    const classes = ['calendar-day'];
    if (selected && date.toDateString() === selected.toDateString()) classes.push('selected');
    if (date.toDateString() === today.toDateString()) classes.push('today');
    cells += `<button type="button" class="${classes.join(' ')}" data-day="${day}" aria-label="${formatDateValue(date, 'YYYY-MM-DD')}"${selected && date.toDateString() === selected.toDateString() ? ' aria-current="date"' : ''}>${day}</button>`;
  }
  return `<div class="calendar" role="dialog" aria-label="Choose a date">
    <div class="calendar-head">
      <button type="button" class="icon-button small" data-calendar-step="-1" aria-label="Previous month"><svg class="flipped"><use href="#i-chevron"/></svg></button>
      <span class="calendar-title" aria-live="polite">${MONTH_NAMES[month]} ${year}</span>
      <button type="button" class="icon-button small" data-calendar-step="1" aria-label="Next month"><svg><use href="#i-chevron"/></svg></button>
    </div>
    <div class="calendar-grid calendar-weekdays">${WEEKDAY_NAMES.map(n => `<span>${n}</span>`).join('')}</div>
    <div class="calendar-grid">${cells}</div>
    <div class="calendar-foot">
      <button type="button" class="button ghost small" data-calendar-today>Today</button>
      <button type="button" class="button ghost small" data-calendar-clear>Clear</button>
    </div>
  </div>`;
}

function closeCalendars() {
  $$('.calendar').forEach(node => node.remove());
  $$('.date-picker-button[aria-expanded]').forEach(node => node.setAttribute('aria-expanded', 'false'));
}

// The popover is positioned against the viewport rather than nested inside the
// field, because the inspector is a scrolling panel and a nested popover would
// be clipped whenever the field sits near the bottom.
//
// It is attached to the open <dialog> when there is one. A dialog lives in the
// browser's top layer, and anything appended to <body> is painted underneath
// it — visible but unclickable, with the dialog swallowing every press. That is
// exactly what happened the first time a calendar was opened inside a prompt.
function openCalendar(button) {
  const input = $(`#${button.dataset.calendar}`);
  if (!input) return;
  const wasOpen = button.getAttribute('aria-expanded') === 'true';
  closeCalendars();
  if (wasOpen) return;
  const format = input.dataset.dateFormat || 'YYYY-MM-DD';
  let selected = parseDateValue(input.value, format);
  let view = selected ? new Date(selected) : new Date();
  const holder = document.createElement('div');
  holder.innerHTML = calendarHTML(view, selected);
  const node = holder.firstElementChild;
  (document.querySelector('dialog[open]') || document.body).append(node);
  button.setAttribute('aria-expanded', 'true');
  const place = () => {
    const anchor = button.getBoundingClientRect();
    const size = node.getBoundingClientRect();
    const left = Math.max(8, Math.min(anchor.left, window.innerWidth - size.width - 8));
    const above = anchor.top - size.height - 6;
    // Flip above the button when there is not enough room underneath it.
    node.style.left = `${left}px`;
    node.style.top = `${above > 8 ? above : anchor.bottom + 6}px`;
  };
  const redraw = () => { node.innerHTML = calendarHTML(view, selected); wire(node); place(); };
  function wire(scope) {
    // Every control inside the popover stops its own click from bubbling. Moving
    // between months replaces the popover's markup, which detaches the element
    // the click started on, and a detached node no longer has a `.calendar`
    // ancestor to find — the page-level listener would then read the click as
    // "somewhere else" and close the calendar that was just redrawn.
    $$('[data-calendar-step]', scope).forEach(step => step.addEventListener('click', event => {
      event.stopPropagation();
      view = new Date(view.getFullYear(), view.getMonth() + Number(step.dataset.calendarStep), 1);
      redraw();
    }));
    $$('[data-day]', scope).forEach(day => day.addEventListener('click', event => {
      event.stopPropagation();
      const picked = new Date(view.getFullYear(), view.getMonth(), Number(day.dataset.day));
      input.value = formatDateValue(picked, format);
      input.dispatchEvent(new Event('input', {bubbles:true}));
      closeCalendars();
    }));
    const today = $('[data-calendar-today]', scope);
    if (today) today.addEventListener('click', event => {
      event.stopPropagation();
      input.value = formatDateValue(new Date(), format);
      input.dispatchEvent(new Event('input', {bubbles:true}));
      closeCalendars();
    });
    const clear = $('[data-calendar-clear]', scope);
    if (clear) clear.addEventListener('click', event => {
      event.stopPropagation();
      input.value = '';
      input.dispatchEvent(new Event('input', {bubbles:true}));
      closeCalendars();
    });
  }
  wire(node);
  place();
}

// Clicking anywhere else closes the calendar, and Escape closes it too.
document.addEventListener('click', event => {
  const button = event.target.closest('[data-calendar]');
  if (button) { openCalendar(button); return; }
  if (!event.target.closest('.calendar')) closeCalendars();
});
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeCalendars(); });
// A viewport-anchored popover would drift away from its field while the panel
// scrolls, so any scroll closes it instead of leaving it pointing at nothing.
window.addEventListener('scroll', closeCalendars, true);
window.addEventListener('resize', closeCalendars);

async function shareDocument() {
  if (!state.doc) return;
  if (!desktopApp()) {
    toast('Sending and sharing are available in the desktop application.', true);
    return;
  }
  let prepared;
  try {
    prepared = await busy('Preparing your document…',
      () => api('/share/prepare', {method:'POST', json:{document:state.doc.id}}));
  } catch (error) { showError(error); return; }
  state.share = prepared;
  showShareDialog();
}

function showShareDialog() {
  const item = state.share;
  if (!item) return;
  const safeName = escapeHTML(item.name);
  const body = `
    <div class="share-file">
      <div class="share-file-icon">${icon('file')}</div>
      <div class="share-file-text"><strong>${safeName}</strong><span>${readableSize(item.size)} · placed in the share folder</span></div>
    </div>
    <div class="share-grid">
      <div class="field"><label for="share-to">Send to (optional)</label><input id="share-to" type="email" autocomplete="off" placeholder="name@example.com"></div>
      <div class="field"><label for="share-subject">Subject (optional)</label><input id="share-subject" type="text" autocomplete="off" placeholder="PDF: ${safeName}"></div>
    </div>
    <div class="field"><label for="share-body">Message</label><textarea id="share-body" rows="3" maxlength="2000" autocomplete="off" spellcheck="true">${escapeHTML(item.defaultBody || 'Please see the attached file')}</textarea><p class="help-text">This is the body of the draft. Edit it here; the PDF is attached either way.</p></div>
    <div class="share-actions">
      <button class="share-option" id="share-email-attach">${icon('file')}<strong>New email with this PDF attached</strong><span>Opens a blank message in your mail program with the PDF on it — type the recipient, then Send</span></button>
      <button class="share-option" id="share-email-draft">${icon('comment')}<strong>Open a draft without the file</strong><span>For a mail program that refuses attachments; the PDF is copied to your clipboard</span></button>
      <button class="share-option" id="share-copy">${icon('copy')}<strong>Copy the file</strong><span>Paste it straight into any email, chat or folder</span></button>
      <button class="share-option" id="share-reveal">${icon('folder')}<strong>Show it in its folder</strong><span>Drag it into anything you like</span></button>
    </div>
    <p class="share-note">${icon('shield')}<span>KADOMA never sends anything and stores no mail password. Your own email program sends the message, and only when you press Send. A plain “mailto” link cannot carry an attachment, which is why the first option asks your mail program to compose a new message with the PDF already on it. The recipient box is left empty on purpose — who gets it is your decision.</span></p>`;
  const dialog = openModal('Send or share this PDF',
    'The file is written to a temporary share folder first — your original is untouched.',
    body, '<button class="button secondary" data-close>Close</button>', 620);
  const details = () => ({
    path: item.path,
    to: $('#share-to')?.value.trim() || '',
    subject: $('#share-subject')?.value.trim() || '',
    body: $('#share-body')?.value ?? '',
  });
  // `target` is the clicked button (an element) so the handler can use
  // event.currentTarget; a selector string is also accepted for convenience.
  const run = async (target, work, done) => {
    const node = typeof target === 'string' ? $(target) : target;
    if (!node) return;
    node.disabled = true;
    try { const result = await work(); if (result?.ok === false) toast(result.error, true); else done(result); }
    catch (error) { modalError(error); }
    finally { node.disabled = false; }
  };
  $('#share-email-attach').addEventListener('click', event => run(event.currentTarget, async () => {
    const {to, subject, body, path} = details();
    return api('/share/email', {method:'POST', json:{path, to, subject, body, attach:true}});
  }, result => toast(result.note || 'An email draft with the file attached was opened')));
  $('#share-email-draft').addEventListener('click', event => run(event.currentTarget, async () => {
    const {to, subject, body, path} = details();
    return api('/share/email', {method:'POST', json:{path, to, subject, body, attach:false}});
  }, result => toast(result.note || 'Your email program was opened')));
  $('#share-copy').addEventListener('click', event => run(event.currentTarget,
    async () => api('/share/clipboard', {method:'POST', json:{path:details().path}}),
    () => toast('The PDF file is on your clipboard — paste it anywhere')));
  $('#share-reveal').addEventListener('click', event => run(event.currentTarget,
    async () => api('/share/reveal', {method:'POST', json:{path:details().path}}),
    () => toast('Opened the share folder')));
}

// ------------------------------------------------------------------ printing
// Printing sends the document to a printer directly: the pages are rendered at
// print resolution and handed to the spooler, so no other PDF application is
// opened — which matters because KADOMA may itself be the default .pdf app,
// and asking the system to "print this PDF" would then loop back here.
//
// Nothing belonging to the interface can reach the paper: only the rendered
// page images are sent, so the toolbar, the side panels and these buttons are
// structurally incapable of appearing in a printout.
//
// Ctrl/⌘ P and the Print button open a preview rather than firing a job at
// whatever printer happens to be default. The preview is the sheet, not the
// page: its paper size and its margins come from the chosen printer, and the
// page is drawn inside them at the scale the print path uses. Choosing another
// printer redraws it, because another printer may load another paper size.
let printJob = null;

async function showPrintPreview() {
  if (!state.doc) return;
  if (!desktopApp()) { toast('Printing is available in the desktop application.', true); return; }
  let status;
  try { status = await api('/system/print'); }
  catch (error) { showError(error); return; }

  const methods = status.methods || {};
  const installed = methods.printers || [];
  const printable = installed.filter(item => item.printable);
  const chosen = (printable.find(item => item.default) || printable[0] || {}).name || '';
  printJob = {
    printer: chosen,
    // What to print, how many times, and which of the chosen pages is on
    // screen. The page arrows move inside the selection, so a range of three
    // pages is three pages to step through, not the whole document.
    mode: 'all', range: '', copies: 1, collate: true, index: 0, pages: null,
    url: null, generation: 0, settings: null,
  };

  // A driver that saves to a file is not a printer, and saying so here is more
  // useful than listing it and failing when it is chosen.
  const skipped = methods.savesToFile && methods.printer
    ? `“${methods.printer}” saves to a file instead of printing, so it is not offered.`
    : '';
  const note = printable.length
    ? 'Pages are sent at 200 DPI, fitted to the paper and orientation you choose here. Duplex, quality and trays come from Printer properties.'
    : (skipped || 'No printer is installed on this computer yet. Install one, or set a real printer as your default, then try again.');

  const body = `
    <div class="print-preview">
      <div class="print-stage">
        <img id="print-preview-image" alt="The page as it will be printed" draggable="false">
        <div class="print-stage-note" id="print-stage-note">Drawing the page…</div>
      </div>
      <aside class="print-side">
        ${printable.length ? `
        <div class="field"><label for="print-target">Printer</label><select id="print-target">${printable.map(item => `<option value="${escapeHTML(item.name)}"${item.name === chosen ? ' selected' : ''}>${escapeHTML(item.name)}${item.default ? ' (default)' : ''}</option>`).join('')}</select></div>
        <div class="field-row">
          <div class="field"><label for="print-paper">Paper</label><select id="print-paper" disabled><option>Reading the printer…</option></select></div>
          <div class="field"><label for="print-orientation">Orientation</label><select id="print-orientation" disabled><option value="auto">Auto · follow the page</option><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></div>
        </div>
        <div class="field"><label for="print-duplex">Sides</label><select id="print-duplex" disabled><option value="simplex">One-sided</option><option value="long">Two-sided · flip on the long edge</option><option value="short">Two-sided · flip on the short edge</option></select></div>
        <button class="button secondary full print-properties" id="print-properties">${icon('settings')}Printer properties…</button>
        <p class="help-text print-settings-note" id="print-settings-note">Reading the printer’s paper…</p>
        <div class="field"><label for="print-range-mode">Pages</label><select id="print-range-mode"><option value="all">All pages</option><option value="current">Current page (${state.page + 1})</option><option value="custom">A range…</option></select></div>
        <div class="field" id="print-range-wrap" hidden><label for="print-range">Pages to print</label><input id="print-range" placeholder="e.g. 1-3, 5" autocomplete="off"><p class="help-text" id="print-range-error"></p></div>
        <div class="field"><label for="print-copies">Copies</label><input id="print-copies" type="number" min="1" max="99" step="1" value="1"></div>
        <div class="field"><label for="print-collate">Order of copies</label><select id="print-collate" disabled><option value="true">Collated · 1, 2, 3</option><option value="false">Uncollated · 1, 1, 1</option></select><p class="help-text" id="print-collate-hint">Collated puts a complete set in each copy. Uncollated stacks every copy of page 1, then page 2.</p></div>` : ''}
        <div class="print-page-row">
          <button class="icon-button small" id="print-prev-page" aria-label="Previous page"><svg class="flipped"><use href="#i-chevron"/></svg></button>
          <span id="print-page-label">Page 1 of 1</span>
          <button class="icon-button small" id="print-next-page" aria-label="Next page"><svg><use href="#i-chevron"/></svg></button>
        </div>
        <p class="help-text">${escapeHTML(note)}</p>
        ${skipped && printable.length ? `<p class="help-text print-warning">${escapeHTML(skipped)}</p>` : ''}
      </aside>
    </div>`;
  const footer = `<button class="button secondary" data-close>Cancel</button><button class="button secondary" id="print-export">${icon('download')}Export instead</button>${printable.length ? `<button class="button primary" id="print-go">${icon('print')}Print</button>` : ''}`;

  const dialog = openModal('Print preview', 'This is the sheet the printer will produce.', body, footer, 860);
  const image = $('#print-preview-image');
  image.addEventListener('load', () => image.classList.add('ready'));

  $('#print-target')?.addEventListener('change', event => {
    printJob.printer = event.target.value;
    // Another printer may take another set of papers, so the list is read
    // again rather than carried over from the previous one.
    loadPrintPapers().then(drawPrintPreview);
  });
  $('#print-paper')?.addEventListener('change', applyPrintSettings);
  $('#print-orientation')?.addEventListener('change', applyPrintSettings);
  $('#print-duplex')?.addEventListener('change', applyPrintSettings);
  $('#print-prev-page')?.addEventListener('click', () => turnPrintPage(-1));
  $('#print-next-page')?.addEventListener('click', () => turnPrintPage(1));
  $('#print-range-mode')?.addEventListener('change', event => {
    printJob.mode = event.target.value;
    $('#print-range-wrap').hidden = printJob.mode !== 'custom';
    if (printJob.mode === 'custom') $('#print-range').focus();
    refreshPrintSelection();
  });
  $('#print-range')?.addEventListener('input', event => {
    printJob.range = event.target.value;
    refreshPrintSelection();
  });
  $('#print-copies')?.addEventListener('input', event => {
    printJob.copies = Math.max(1, Math.min(99, Number(event.target.value) || 1));
    syncPrintOrder();
  });
  $('#print-collate')?.addEventListener('change', event => {
    printJob.collate = event.target.value === 'true';
    syncPrintOrder();
  });
  $('#print-properties')?.addEventListener('click', openPrinterProperties);
  $('#print-export').addEventListener('click', () => { dialog.close(); showExportDialog(); });
  $('#print-go')?.addEventListener('click', async () => {
    if (!printJob?.pages?.length) return;
    const { printer, pages, copies, collate } = printJob;
    dialog.close();
    await printDocument({ printer, pages, copies, collate });
  });
  // The preview is a blob held by this page, so it is released when the window
  // goes away rather than left for the browser to reclaim. The job is captured
  // rather than read back: this handler runs when the *next* window opens, and
  // by then `printJob` may already belong to that window — which is exactly how
  // the first version of this left a blank preview behind a working dialog.
  const job = printJob;
  onModalDismiss(() => {
    if (job.url) URL.revokeObjectURL(job.url);
    if (printJob === job) printJob = null;
  });
  refreshPrintSelection();
  // The sheet has to be the sheet that will be printed, so the defaults are
  // applied as soon as the driver's list arrives: A4 when it is offered, and
  // the orientation of the page on screen.
  loadPrintPapers().then(applyPrintSettings);
}

// "1-3, 5" -> [0,1,2,4]. Null when the text cannot be read as pages of this
// document, which is what disables the Print button.
function parsePageRange(text, count) {
  const parts = String(text).split(',').map(part => part.trim()).filter(Boolean);
  if (!parts.length) return null;
  const out = [];
  for (const part of parts) {
    const match = part.match(/^(\d+)\s*(?:[-–]\s*(\d+))?$/);
    if (!match) return null;
    const first = Number(match[1]);
    const last = match[2] ? Number(match[2]) : first;
    if (first < 1 || last < first || last > count) return null;
    for (let n = first; n <= last; n += 1) if (!out.includes(n - 1)) out.push(n - 1);
  }
  return out;
}

// The collate choice only means something with more than one copy, so it is
// disabled at one rather than quietly doing nothing.
// The order, spelled out with the real page numbers: "1, 2, 3, 1, 2, 3" is
// easier to check than a description of it. Long jobs are cut short.
function printOrderPreview() {
  const pages = printJob.pages || [];
  const order = [];
  if (printJob.collate) {
    // A complete set per copy: 1, 2, 3 then 1, 2, 3.
    for (let copy = 0; copy < printJob.copies; copy += 1) order.push(...pages);
  } else {
    // A stack of each page: 1, 1, 2, 2, 3, 3.
    pages.forEach(page => {
      for (let copy = 0; copy < printJob.copies; copy += 1) order.push(page);
    });
  }
  const shown = order.slice(0, 12).map(page => page + 1);
  return shown.join(', ') + (order.length > shown.length ? ` … (${order.length} sheets)` : '');
}

function syncPrintOrder() {
  const control = $('#print-collate');
  if (!control || !printJob) return;
  const many = printJob.copies > 1;
  control.disabled = !many;
  control.value = String(printJob.collate);
  const hint = $('#print-collate-hint');
  if (hint) {
    hint.textContent = many
      ? printOrderPreview()
      : 'One copy, so collating makes no difference.';
  }
  refreshPrintLabel();
}

function printSelection() {
  const count = state.doc.pageCount;
  if (printJob.mode === 'current') return [Math.min(state.page, count - 1)];
  if (printJob.mode === 'custom') return parsePageRange(printJob.range, count);
  return Array.from({ length: count }, (_, index) => index);
}

// Recomputes what will be printed, then brings the sheet, the page label and
// the button in line with it.
// "Print 3 pages × 2 copies" — the number of sheets, then how many times.
function refreshPrintLabel() {
  if (!printJob) return;
  const button = $('#print-go');
  if (!button) return;
  const pages = printJob.pages;
  button.disabled = !pages;
  if (!pages) { button.innerHTML = `${icon('print')}Print`; return; }
  const sheets = `Print ${pages.length} ${pages.length === 1 ? 'page' : 'pages'}`;
  const copies = printJob.copies > 1 ? ` × ${printJob.copies} copies` : '';
  button.innerHTML = `${icon('print')}${sheets}${copies}`;
}

function refreshPrintSelection() {
  if (!printJob || !state.doc) return;
  const pages = printSelection();
  printJob.pages = pages;
  const error = $('#print-range-error');
  if (error) error.textContent = pages ? '' : 'Use page numbers and ranges, like 1-3, 5.';
  refreshPrintLabel();
  if (!pages) return;
  if (printJob.index >= pages.length) printJob.index = 0;
  const label = $('#print-page-label');
  if (label) {
    label.textContent = pages.length === 1
      ? `Page ${pages[0] + 1} of ${state.doc.pageCount}`
      : `Page ${pages[printJob.index] + 1} of ${state.doc.pageCount} · ${printJob.index + 1} of ${pages.length} selected`;
  }
  const prev = $('#print-prev-page');
  const next = $('#print-next-page');
  if (prev) prev.disabled = printJob.index <= 0;
  if (next) next.disabled = printJob.index >= pages.length - 1;
  syncPrintOrder();
  drawPrintPreview();
}

// The driver's own dialog: paper size, orientation, duplex and quality are its
// business, and it already knows how to ask for them.
async function openPrinterProperties() {
  if (!printJob?.printer) return;
  const note = $('#print-settings-note');
  try {
    const result = await busy('Waiting for the printer settings…',
      () => api('/system/print/preferences', {method: 'POST', json: {printer: printJob.printer}}));
    if (!result || result.cancelled) return;
    printJob.settings = result;
    // The dialog can change the paper as well, so both controls are re-read
    // rather than left showing what they showed before it was opened.
    await loadPrintPapers();
    drawPrintPreview();
  } catch (error) {
    if (note) note.textContent = error.message || 'The printer settings could not be opened.';
  }
}

// ------------------------------------------------- paper size and orientation
// The list comes from the driver, not from this file: a printer that has never
// heard of A3 should not be offered it. The choice is written into the driver's
// own settings block, which is what the preview draws and what the job uses —
// one setting, one sheet, so the two cannot disagree.
async function loadPrintPapers() {
  const select = $('#print-paper');
  const orientation = $('#print-orientation');
  const duplex = $('#print-duplex');
  const note = $('#print-settings-note');
  if (!printJob?.printer || !select) return;
  const job = printJob;
  select.disabled = true;
  if (orientation) orientation.disabled = true;
  if (duplex) duplex.disabled = true;
  try {
    const info = await api('/system/print/papers?printer=' + encodeURIComponent(job.printer));
    // The window may have been closed, or the printer changed, while this was
    // in flight; the answer would then belong to a dialog that is gone.
    if (printJob !== job) return;
    const papers = info.papers || [];
    select.innerHTML = papers.length
      ? papers.map(paper => `<option value="${paper.id}">${escapeHTML(paper.name)}</option>`).join('')
      : '<option value="">Driver default</option>';
    const settings = info.settings || {};
    if (papers.some(paper => paper.id === settings.paperId)) select.value = String(settings.paperId);
    select.disabled = !papers.length;

    // Orientation starts on Auto, which follows the page being previewed.
    if (orientation) {
      orientation.value = job.orientationMode || 'auto';
      orientation.disabled = !papers.length;
    }

    // Two-sided is offered when the driver says it can do it, and says so
    // plainly when it cannot rather than failing at the spooler.
    const modes = info.duplex || ['simplex'];
    if (duplex) {
      const twoSided = modes.includes('long') || modes.includes('short');
      duplex.innerHTML = '<option value="simplex">One-sided</option>' +
        (modes.includes('long') ? '<option value="long">Two-sided · flip on the long edge</option>' : '') +
        (modes.includes('short') ? '<option value="short">Two-sided · flip on the short edge</option>' : '');
      duplex.value = settings.duplex || 'simplex';
      if (!twoSided) duplex.value = 'simplex';
      duplex.disabled = !twoSided;
      job.twoSidedOffered = twoSided;
    }
    if (note) {
      note.textContent = !papers.length
        ? 'This printer does not report its paper sizes, so its own settings decide.'
        : (job.twoSidedOffered
            ? 'Paper, orientation and sides are set here. Quality and trays come from Printer properties.'
            : 'Paper and orientation are set here. This printer does not report two-sided printing; quality and trays come from Printer properties.');
    }
  } catch (error) {
    if (printJob !== job) return;
    select.innerHTML = '<option value="">Driver default</option>';
    if (note) note.textContent = error.message || 'The paper sizes could not be read.';
  }
}

// What orientation to ask for. Auto follows the page on screen, so a landscape
// page is not printed small and sideways on a portrait sheet.
function printOrientationForPage() {
  const mode = $('#print-orientation')?.value || printJob?.orientationMode || 'auto';
  if (mode !== 'auto') return mode;
  const page = state.doc?.pages?.[printJob?.pages?.[printJob?.index ?? 0] ?? 0];
  if (!page) return null;
  return page.width > page.height ? 'landscape' : 'portrait';
}

async function applyPrintSettings() {
  if (!printJob?.printer) return;
  const job = printJob;
  const paperSelect = $('#print-paper');
  const orientationSelect = $('#print-orientation');
  const duplexSelect = $('#print-duplex');
  const note = $('#print-settings-note');
  job.orientationMode = orientationSelect?.value || 'auto';
  let paper = Number(paperSelect?.value) || null;
  // The first apply of a dialog puts the paper on A4 — the size the request
  // asked for — unless the driver does not offer it. After that the select is
  // the only thing that decides, so a deliberate choice is never overridden.
  if (!job.paperApplied) {
    const a4 = [...(paperSelect?.options || [])].find(option => option.textContent.trim() === 'A4');
    if (a4) paper = Number(a4.value);
  }
  job.paperApplied = true;
  const orientation = printOrientationForPage();
  const duplex = duplexSelect && !duplexSelect.disabled ? duplexSelect.value : null;
  try {
    const result = await api('/system/print/settings', {method: 'POST',
      json: {printer: job.printer, paper, orientation, duplex}});
    if (printJob !== job) return;
    job.settings = result;
    // The driver may have corrected what it was given, so the select follows
    // the answer rather than showing the request.
    if (paperSelect && !paperSelect.disabled && result.paperId) {
      const match = [...paperSelect.options].find(option => Number(option.value) === result.paperId);
      if (match) paperSelect.value = match.value;
    }
    if (note) {
      const sheet = result.sheet?.available
        ? ` — ${Math.round(result.sheet.width)} × ${Math.round(result.sheet.height)} pt`
        : '';
      const sides = result.duplex === 'long' ? ' · two-sided (long edge)'
        : result.duplex === 'short' ? ' · two-sided (short edge)' : '';
      note.textContent = `${result.paper} · ${result.orientation}${sides}${sheet}`;
    }
    drawPrintPreview();
  } catch (error) {
    if (note) note.textContent = error.message || 'Those printer settings were refused.';
  }
}

function turnPrintPage(step) {
  if (!printJob?.pages?.length) return;
  const next = printJob.index + step;
  if (next < 0 || next >= printJob.pages.length) return;
  printJob.index = next;
  refreshPrintSelection();
  // Auto orientation follows the page, so turning the page can turn the sheet.
  const wanted = printOrientationForPage();
  if (wanted && printJob.settings && wanted !== printJob.settings.orientation) {
    applyPrintSettings();
  }
}

async function drawPrintPreview() {
  if (!printJob || !state.doc) return;
  const image = $('#print-preview-image');
  const note = $('#print-stage-note');
  if (!image || !note) return;
  // The job is captured before the first await. The window can be closed while
  // the image is in flight, and reading `printJob` afterwards then throws on
  // null — which is exactly what happened the first time this was written.
  const job = printJob;
  const generation = ++job.generation;
  note.hidden = false;
  note.textContent = 'Drawing the page…';
  image.classList.remove('ready');
  const page = job.pages?.[job.index] ?? 0;
  const query = `document=${encodeURIComponent(state.doc.id)}&page=${page}` +
                `&printer=${encodeURIComponent(job.printer)}`;
  try {
    const response = await api('/system/print/preview?' + query, {raw:true});
    const blob = await response.blob();
    // A second request may have been started while this one was in flight —
    // a fast click through the pages would otherwise land out of order.
    if (printJob !== job || generation !== job.generation) return;
    if (job.url) URL.revokeObjectURL(job.url);
    job.url = URL.createObjectURL(blob);
    image.src = job.url;
    note.hidden = true;
  } catch (error) {
    if (printJob !== job || generation !== job.generation) return;
    note.textContent = 'The preview could not be drawn: ' + (error.message || 'unknown error');
    image.removeAttribute('src');
  }
}

async function printDocument({ printer = null, pages = null, copies = 1, collate = true } = {}) {
  if (!state.doc) return;
  if (!desktopApp()) { toast('Printing is available in the desktop application.', true); return; }
  const sheets = (pages ? pages.length : state.doc.pageCount) * copies;
  try {
    const result = await busy(`Sending ${sheets} ${sheets === 1 ? 'sheet' : 'sheets'} to ${printer || 'the printer'}…`,
      () => api('/system/print', {method:'POST', json:{document:state.doc.id, printer, pages, copies, collate}, timeout: 180000}),
      'The printer is working through the job. Nothing leaves this computer.');
    const count = Number(result.pages) || state.doc.pageCount;
    toast(`Sent ${count} ${count === 1 ? 'page' : 'pages'} to ${result.printer}${copies > 1 ? ` (${copies} copies, ${collate ? 'collated' : 'uncollated'})` : ''}`);
  } catch (error) {
    if (error.code === 'print_failed') {
      // The job reached the printer and was refused there — out of paper, not
      // ready, the wrong driver. Say so and put the preview back up, because
      // the next thing to try is usually another printer.
      toast(error.message, true);
      showPrintPreview();
    } else showError(error);
  }
}

// ------------------------------------------------------------- prepare form
// The file leaves this application, so the fields have to work everywhere: they
// are ordinary AcroForm widgets, and a date field carries the same two
// JavaScript actions Acrobat writes for its own date picker. Nothing here
// depends on KADOMA being the program that opens the result.
const FORM_KIND_NAMES = {text: 'Text', date: 'Date', checkbox: 'Checkbox'};

async function showPrepareFormDialog() {
  if (!state.doc) { toast('Open a document first.', true); return; }
  let scan;
  try {
    scan = await busy('Looking for places to fill in…',
      () => api(docPath('/prepare-form/scan'), {method: 'POST'}));
  } catch (error) { showError(error); return; }
  const found = scan.candidates || [];
  const rows = found.map((item, index) => `
    <label class="check-row form-candidate">
      <input type="checkbox" data-candidate="${index}" checked>
      <span><b>${escapeHTML(item.label)}</b><small>${FORM_KIND_NAMES[item.kind] || 'Text'} · page ${item.page + 1}</small></span>
    </label>`).join('');
  const body = found.length
    ? `<p class="confirm-description">${found.length} place${found.length === 1 ? '' : 's'} in this document look like something to fill in. Each becomes a real PDF field, so anybody can type in it — with or without KADOMA. Date fields carry the format Acrobat uses, so Acrobat offers its own date picker.</p>
       <div class="candidate-list">${rows}</div>
       <div class="inline-note">${icon('info')}<span>Found by looking for runs of underscores, drawn boxes, and labels that end in a colon. Untick anything that is not a field.</span></div>`
    : `<p class="confirm-description">Nothing here looks like a place to fill in. This looks for runs of underscores, drawn boxes, and labels that end in a colon.</p>
       <p class="confirm-description">You can still add a field by hand: choose <b>Text field</b> or <b>Date field</b> in the toolbar and draw it on the page.</p>`;
  const footer = found.length
    ? '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="prepare-run">Add the fields</button>'
    : '<button class="button secondary" data-close>Close</button>';
  const dialog = openModal('Prepare this form.', 'Fields anyone can fill in, in any PDF reader.', body, footer, 560);
  $('#prepare-run')?.addEventListener('click', async () => {
    const chosen = $$('#modal [data-candidate]:checked')
      .map(input => found[Number(input.dataset.candidate)])
      .filter(Boolean);
    if (!chosen.length) { toast('Choose at least one place to put a field.', true); return; }
    try {
      await perform({action: 'prepare_form', fields: chosen}, 'Adding the fields…');
      dialog.close();
      toast(`${chosen.length} field${chosen.length === 1 ? '' : 's'} added — anybody can fill them in now`);
    } catch (error) { modalError(error); }
  });
}

// ------------------------------------------------------------ clearing a form
// Clear empties what was filled in — text, dates, checkboxes and dropdown
// choices — and leaves the fields themselves, and the rest of the page, exactly
// where they are. It goes through the normal edit path, so undo restores it.
async function clearFilledFields() {
  if (!state.doc) return;
  if (!state.doc.formCount) { toast('This document has no form fields to clear.'); return; }
  const plural = state.doc.formCount === 1 ? 'field' : 'fields';
  if (!await confirmDialog('Clear everything filled in?',
    `Every filled-in text, date, checkbox and dropdown value in this document is emptied. The ${state.doc.formCount} ${plural} stay on the page, page content is untouched, and you can undo this until you export.`,
    'Clear the values')) return;
  try {
    await perform({action:'clear_fields'}, 'Clearing the filled-in values…');
    toast('Filled-in values cleared');
  } catch (error) { showError(error); }
}

// ------------------------------------------------- opening files the OS hands us
// Double-clicking a PDF starts the app (or hands the path to the running copy).
// The path is queued by the shell and drained here.
let openingQueuedFile = false;
async function openLocalPath(path, password = '') {
  try {
    const info = await busy('Opening your document…',
      () => api('/documents/open-path', {method:'POST', json:{path, password}}));
    state.view = 'edit';
    state.tool = 'view';
    await adoptDocument(info, {page:0});
    setView('edit');
    toast(`Opened ${info.name}`);
  } catch (error) {
    if (error.code === 'password_required') showLocalPasswordDialog(path);
    else showError(error);
  }
}
function showLocalPasswordDialog(path) {
  const name = path.split(/[\\/]/).pop() || 'this document';
  const dialog = openModal('A little extra protection.', `Enter the password for ${name}.`,
    '<div class="field"><label for="local-password">PDF password</label><input id="local-password" type="password" autocomplete="current-password" placeholder="Opening or owner password"></div>',
    '<button class="button secondary" data-close>Cancel</button><button class="button primary" id="local-unlock">Unlock PDF</button>');
  $('#local-unlock').addEventListener('click', async () => {
    try {
      const info = await busy('Unlocking…', () => api('/documents/open-path',
        {method:'POST', json:{path, password:$('#local-password').value}}));
      dialog.close();
      await adoptDocument(info, {page:0});
      setView('edit');
      toast(`Opened ${info.name}`);
    } catch (error) { modalError(error); }
  });
}
async function pollPendingOpen() {
  if (!desktopApp() || openingQueuedFile) return;
  try {
    const {items} = await api('/system/pending-open');
    if (!items?.length) return;
    openingQueuedFile = true;
    try {
      for (const item of items) {
        if (item.action === 'combine' && item.paths?.length) await combineFromShell(item.paths);
        else if (item.path) await openLocalPath(item.path);
      }
    } finally { openingQueuedFile = false; }
  } catch {}
}

// One click in Explorer, one document here. The files are read by the local
// service — the page never sees a path it could not already open — and the
// result arrives as an ordinary working document, ready to save.
async function combineFromShell(paths) {
  const info = await busy(`Combining ${paths.length} files…`,
    () => api('/system/combine-paths', {method:'POST', json:{paths}}));
  await adoptDocument(info, {page:0});
  setView('edit');
  toast(`Combined ${paths.length} files into ${info.name}`);
}

// ------------------------------------------------- being the default PDF app
async function showDefaultAppDialog() {
  if (!desktopApp()) {
    toast('Setting the default PDF app is available in the desktop application.', true);
    return;
  }
  let status;
  try { status = await api('/system/default-app'); }
  catch (error) { showError(error); return; }
  const state_ = status.isDefault
    ? `<div class="inline-note ok">${icon('check')}<span>KADOMA is currently the default PDF app.</span></div>`
    : `<div class="inline-note">${icon('info')}<span>KADOMA is not the default yet.${
        status.currentHandler ? ` “${escapeHTML(status.currentHandler)}” is handling PDFs at the moment.` : ''}</span></div>`;
  const body = `
    ${state_}
    <p class="confirm-description">Open PDFs by double-clicking them, straight into KADOMA.</p>
    <div class="inline-note warn">${icon('shield')}<span><strong>Windows will not let any app claim the default silently.</strong> That protection exists to stop programs hijacking your file types, so KADOMA registers itself as a PDF handler and then opens the Settings page where you confirm it. That confirmation step is yours to make.</span></div>
    ${status.supported ? '' : `<div class="inline-note">${icon('warning')}<span>Automatic registration is implemented for Windows. On macOS the app declares the PDF type in its own bundle, so KADOMA appears in “Open With” automatically.</span></div>`}`;
  const footer = `${status.registered ? '<button class="button secondary" id="unregister-app">Remove the registration</button>' : ''}<button class="button secondary" id="open-settings">Open Settings</button><button class="button primary" id="register-app">${icon('check')}Register KADOMA</button>`;
  const dialog = openModal('Make KADOMA PDF your PDF app',
    'No administrator rights are needed — this is registered for your user account only.', body, footer, 560);
  $('#register-app')?.addEventListener('click', async () => {
    try {
      const result = await api('/system/default-app', {method:'POST', json:{action:'register'}});
      if (!result.ok) { modalError(new Error(result.error || 'Registration failed.')); return; }
      toast('Registered. Choose KADOMA in the Settings page that just opened.');
      if (result.settings && result.settings.ok === false) toast(result.settings.error, true);
      dialog.close();
      showDefaultAppDialog();
    } catch (error) { modalError(error); }
  });
  $('#unregister-app')?.addEventListener('click', async () => {
    try {
      await api('/system/default-app', {method:'POST', json:{action:'unregister'}});
      toast('The KADOMA registration was removed');
      dialog.close();
    } catch (error) { modalError(error); }
  });
  $('#open-settings')?.addEventListener('click', async () => {
    try { await api('/system/default-app', {method:'POST', json:{action:'settings'}}); }
    catch (error) { modalError(error); }
  });
}

async function initialize(){
  applyInspectorMode();
  applyPanelLayout();
  // The tool list is built once: it is the same list the home screen shows, and
  // it does not depend on which document is open.
  renderToolRail();
  try{
    state.capabilities=await api('/health');
    await refreshAiStatus();
    await refreshOpenDocuments();
    // The application starts with nothing open: no sample document is shipped
    // or loaded. Home is the map of the tools, and a document arrives when one
    // is opened, created or dropped.
    setView('home');
    $('#status-text').textContent=isHostedPreview?'Hosted demo: files are processed in this workspace, not on your computer':'All processing happens on your device';
    if (state.capabilities.desktop) {
      // A double-clicked PDF can arrive at any moment once this is the default app.
      setInterval(pollPendingOpen, 1500);
      pollPendingOpen();
    }
    if (state.capabilities.rtlQuality === 'approximate') {
      console.info('KADOMA: Arabic text renders correctly, but this computer has no font that ' +
                   'reads Arabic back perfectly. Noto Sans Arabic is being used as a fallback.');
    }
  }catch(error){
    $('#document-name').textContent='Your workspace needs a restart.';
    $('#document-details').textContent='The local engine could not start';showError(error);
  }
}
initialize();
