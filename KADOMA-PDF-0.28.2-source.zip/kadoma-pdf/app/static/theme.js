// Runs before the page is parsed, so a dark-theme launch never flashes white.
// This is the only thing KADOMA stores on the machine: one key, holding
// "light" or "dark". Nothing about a document, a person or a session is here.
(function () {
  var stored = null;
  try { stored = window.localStorage.getItem('kadoma.theme'); } catch (error) { /* storage unavailable */ }
  // Dark is the default, not the system's preference: a PDF viewer is mostly a
  // white page, and a dark surround keeps the eye on the page instead of on the
  // window. A stored choice always wins, so switching to light sticks.
  var dark = stored !== 'light';
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
