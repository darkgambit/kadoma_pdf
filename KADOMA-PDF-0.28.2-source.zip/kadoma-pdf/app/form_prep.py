"""Turn a flat PDF into one that anybody can fill in.

The file matters more than the application here: every field this module adds is
a real AcroForm widget, so a person with Acrobat, Preview, a browser or a phone
can type into it without KADOMA installed.

Dates get the two JavaScript actions Acrobat itself uses — a keystroke check and
a format — so Acrobat offers its own date picker on the field. Readers without
Acrobat show a text box, which still takes a typed date; nothing here depends on
KADOMA being the reader.

Finding the places to put a field is a set of honest, simple rules, not a model:

* a run of three or more underscores is a place to write;
* a box character (☐ □ ❑) is a checkbox;
* a line that is only "Label:" with nothing after it gets a field beside it,
  a date field when the label mentions a date.

Anything it gets wrong, the person can delete or add by hand in the Forms view.
"""
from __future__ import annotations

import re

import pymupdf as fitz

UNDERSCORES = re.compile(r'_{3,}')
BOX_CHARACTERS = '\u2610\u25a1\u2751\u25fb\u2b1c'
# "Label:" and nothing else on the line.
LABEL_ONLY = re.compile(r'^\s*([A-Za-z][A-Za-z0-9 .,&\'/-]{0,60}):\s*$')
DATE_WORDS = re.compile(r'\b(date|dated|dob|birth|expiry|expires|expiration)\b', re.I)
MAX_FIELDS = 80

# The same labels the engine and the Forms view use, and the Acrobat syntax
# for each of them. The private key keeps KADOMA's own calendar working; the
# /AA actions are what make Acrobat offer its date picker.
DEFAULT_DATE_FORMAT = 'YYYY-MM-DD'
ACROBAT_FORMATS = {
    'YYYY-MM-DD': 'yyyy-mm-dd',
    'DD/MM/YYYY': 'dd/mm/yyyy',
    'MM/DD/YYYY': 'mm/dd/yyyy',
    'DD.MM.YYYY': 'dd.mm.yyyy',
}


def _label_for(text: str) -> str:
    cleaned = re.sub(r'\s+', ' ', text or '').strip(' .:_')
    return cleaned[:60] or 'Field'


def _slug(text: str) -> str:
    cleaned = re.sub(r'[^A-Za-z0-9]+', '_', text or '').strip('_')
    return cleaned[:40] or 'field'


def _glyph_box(span: dict, index: int, length: int) -> list[float]:
    """Approximate box of characters [index, index+length) inside a span."""
    x0, y0, x1, y1 = span['bbox']
    total = max(1, len(span.get('text', '')))
    width = (x1 - x0) / total
    return [x0 + width * index, y0, x0 + width * (index + length), y1]


def scan(doc: fitz.Document) -> list[dict]:
    """Where a form should go, page by page. Read-only."""
    found: list[dict] = []

    def add(page_index, rect, kind, label, source):
        left, top, right, bottom = [round(value, 1) for value in rect]
        if right - left < 6 or bottom - top < 4:
            return
        for existing in found:
            if existing['page'] == page_index and abs(existing['rect'][0] - left) < 3 \
                    and abs(existing['rect'][1] - top) < 3:
                return
        if len(found) >= MAX_FIELDS:
            return
        found.append({'page': page_index, 'rect': [left, top, right, bottom], 'kind': kind,
                      'label': label, 'foundBy': source})

    for page_index, page in enumerate(doc):
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines', []):
                spans = line.get('spans', [])
                if not spans:
                    continue
                text = ''.join(span.get('text', '') for span in spans)
                line_rect = fitz.Rect(line['bbox'])

                for span in spans:
                    span_text = span.get('text', '')
                    if not span_text:
                        continue

                    for match in UNDERSCORES.finditer(span_text):
                        box = _glyph_box(span, match.start(), len(match.group()))
                        # A rule is thin; give the field a usable height.
                        box[1] = box[1] - 2
                        box[3] = min(line_rect.y1 + 2, box[3] + 3)
                        before = text[:text.find(match.group())].strip(' .:')
                        add(page_index, box, 'text', _label_for(before) if before else 'Text', 'rule')

                    for position, character in enumerate(span_text):
                        if character in BOX_CHARACTERS:
                            box = _glyph_box(span, position, 1)
                            size = max(box[3] - box[1], 8)
                            before = text[:text.find(character)].strip(' .:')
                            add(page_index, [box[0], box[1], box[0] + size, box[1] + size],
                                'checkbox', _label_for(before) if before else 'Checkbox', 'box')

                label = LABEL_ONLY.match(text)
                if label and not UNDERSCORES.search(text):
                    title = label.group(1).strip()
                    kind = 'date' if DATE_WORDS.search(title) else 'text'
                    # The field starts where the label ends and runs to the right
                    # margin, or 140 pt, whichever is further.
                    start = max(span['bbox'][2] for span in spans) + 6
                    end = max(start + 90, min(line_rect.x1, start + 140))
                    add(page_index, [start, line_rect.y0, end, line_rect.y1], kind,
                        _label_for(title), 'label')

        # A drawn square is the other way a form says "tick here": word
        # processors draw the box rather than typing a character for it.
        for drawing in page.get_drawings():
            box = drawing['rect']
            width, height = box.width, box.height
            if not (5 <= width <= 18 and 5 <= height <= 18):
                continue
            if abs(width - height) > 3:
                continue
            add(page_index, [box.x0, box.y0, box.x1, box.y1], 'checkbox', 'Checkbox', 'drawn box')

    return found


def date_actions(date_format: str = DEFAULT_DATE_FORMAT) -> str:
    """The /AA dictionary Acrobat uses for a date field.

    Written as raw PDF syntax because PyMuPDF has no API for additional
    actions. The keystroke check rejects nonsense as it is typed; the format
    action is what makes Acrobat show its calendar button.
    """
    fmt = date_format.replace('\\', '').replace('(', '').replace(')', '').replace('"', '')
    keystroke = 'AFDate_KeystrokeEx\\("%s"\\)' % fmt
    formatter = 'AFDate_FormatEx\\("%s"\\)' % fmt
    return ('<< /K << /S /JavaScript /JS (%s) >> /F << /S /JavaScript /JS (%s) >> >>'
            % (keystroke, formatter))


def attach_date_actions(doc: fitz.Document, name: str, date_format: str = DEFAULT_DATE_FORMAT) -> bool:
    """Give the field called `name` Acrobat's date behaviour. True when applied."""
    acrobat = ACROBAT_FORMATS.get(date_format, ACROBAT_FORMATS[DEFAULT_DATE_FORMAT])
    widget = None
    for page in doc:
        for candidate in page.widgets() or []:
            if candidate.field_name == name:
                widget = candidate
                break
        if widget is not None:
            break
    if widget is None:
        return False
    try:
        doc.xref_set_key(widget.xref, 'AA', date_actions(acrobat))
        return True
    except Exception:
        return False


def unique_name(base: str, taken: set[str]) -> str:
    name = _slug(base)
    if name not in taken:
        return name
    suffix = 2
    while f'{name}_{suffix}' in taken:
        suffix += 1
    return f'{name}_{suffix}'


def apply(doc: fitz.Document, fields: list[dict], create_field,
          date_format: str = DEFAULT_DATE_FORMAT) -> list[str]:
    """Create the widgets. `create_field` is the engine's own field builder.

    Passed in rather than imported so this module and the engine cannot end up
    importing each other, and so a field made here is the same field the Forms
    view makes — same font, same colours, same private date keys.
    """
    taken = {widget.field_name for page in doc for widget in (page.widgets() or [])}
    created: list[str] = []
    for item in fields[:MAX_FIELDS]:
        try:
            page_index = int(item['page'])
            rect = fitz.Rect(item['rect'])
        except (KeyError, TypeError, ValueError):
            continue
        if not 0 <= page_index < len(doc):
            continue
        kind = item.get('kind') if item.get('kind') in ('text', 'date', 'checkbox') else 'text'
        label = str(item.get('label') or 'Field')[:60]
        name = unique_name(label, taken)
        chosen = date_format if kind == 'date' else None
        create_field(doc, doc[page_index], rect, name, kind, label=label, date_format=chosen)
        taken.add(name)
        if kind == 'date':
            attach_date_actions(doc, name, date_format)
        created.append(name)
    if created:
        # Whatever made these fields, they are only usable once the document
        # carries the resources a reader regenerates them from.
        ensure_acroform(doc)
    return created


# --------------------------------------------------------------------------
# What a reader needs before it will let anybody type.
#
# A widget with a rectangle, a name and an appearance is enough for Chrome and
# for MuPDF, which is why the fields looked finished. Acrobat is stricter: it
# regenerates a field's appearance from the field's own /DA using the fonts in
# the document-wide /AcroForm /DR. A file with no /DR has a /DA that names a
# font nothing can resolve, so the field cannot be typed into at all — the box
# is there, the cursor never arrives. /P is the other one: without it the
# widget does not say which page it belongs to, and a reader that trusts the
# annotation over the page tree cannot place the field.
#
# So every field-creating path ends here, and this is idempotent: it writes the
# same resources whether it runs once or eighty times.

# The three fonts every Acrobat form has. Helvetica is the default appearance
# font, ZapfDingbats draws the checkbox tick, Times is offered because the field
# editor can name it.
DEFAULT_RESOURCES = (
    ('Helv', '<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>'),
    ('ZaDb', '<</Type/Font/Subtype/Type1/BaseFont/ZapfDingbats>>'),
    ('TiRo', '<</Type/Font/Subtype/Type1/BaseFont/Times-Roman/Encoding/WinAnsiEncoding>>'),
)


def _widget_pairs(doc: fitz.Document) -> list[tuple[int, int]]:
    """(page xref, widget xref) for every field in the document."""
    pairs = []
    for page in doc:
        for widget in page.widgets() or []:
            pairs.append((page.xref, widget.xref))
    return pairs


def _existing_field_xrefs(doc: fitz.Document) -> list[int]:
    # A key *path*: the AcroForm may be an inline dictionary in the catalog or an
    # indirect object, and "AcroForm/Fields" resolves both without caring which.
    kind, value = doc.xref_get_key(doc.pdf_catalog(), 'AcroForm/Fields')
    if kind != 'array':
        return []
    return [int(part) for part in re.findall(r'(\d+)\s+0\s+R', value)]


def ensure_acroform(doc: fitz.Document) -> dict:
    """Make the form usable outside this application. Safe to call repeatedly."""
    pairs = _widget_pairs(doc)
    if not pairs:
        return {'widgets': 0, 'resources': False}
    for page_xref, widget_xref in pairs:
        # A widget that does not name its page is an annotation floating free.
        doc.xref_set_key(widget_xref, 'P', f'{page_xref} 0 R')

    # The field list is the truth: every widget on every page, in page order,
    # plus anything already listed that is not on a page we can see.
    seen: list[int] = []
    for _page, widget_xref in pairs:
        if widget_xref not in seen:
            seen.append(widget_xref)
    for xref in _existing_field_xrefs(doc):
        if xref not in seen:
            seen.append(xref)
    fields = '[' + ' '.join(f'{xref} 0 R' for xref in seen) + ']'
    resources = '<</Font<<' + ''.join(f'/{name}{body}' for name, body in DEFAULT_RESOURCES) + '>>>>'

    kind, value = doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')
    if kind == 'xref':
        # An indirect AcroForm may carry keys this module knows nothing about
        # (/CO, /SigFlags, /XFA). Set the keys we own and leave the rest alone.
        acro = int(value.split()[0])
        doc.xref_set_key(acro, 'Fields', fields)
        doc.xref_set_key(acro, 'DR', resources)
        doc.xref_set_key(acro, 'DA', '(/Helv 0 Tf 0 g)')
        doc.xref_set_key(acro, 'NeedAppearances', 'false')
        return {'widgets': len(pairs), 'resources': True}

    if kind == 'dict' and '/XFA' in value:
        # A dynamic XFA form is driven by its own XML; rewriting the AcroForm
        # around it would break the document rather than fix the fields.
        return {'widgets': len(pairs), 'resources': False, 'xfa': True}

    doc.xref_set_key(doc.pdf_catalog(), 'AcroForm',
                     f'<</Fields{fields}/DR{resources}'
                     f'/DA(/Helv 0 Tf 0 g)/NeedAppearances false>>')
    return {'widgets': len(pairs), 'resources': True}
