"""The one exception the engine raises on purpose.

It lives in its own module so the document tools can raise it without importing
the engine that calls them — a circular import that Python would only reveal at
run time, on whichever tool happened to be used first.
"""


class PDFError(Exception):
    def __init__(self, message: str, status: int = 422, code: str = "invalid_request"):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code
