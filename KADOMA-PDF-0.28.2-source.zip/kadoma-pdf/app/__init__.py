"""KADOMA PDF: an offline-first, cross-platform PDF workspace."""
__version__ = "0.28.2"
