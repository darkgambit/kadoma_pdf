"""Right-to-left text support: detection, normalisation, and font selection.

Three separate problems have to be solved for Arabic/Hebrew to work in a PDF
editor, and they are easy to confuse:

1. **Shaping.** Arabic letters change shape with their neighbours, and text runs
   right to left. MuPDF does this correctly *only* through the HTML/Story layout
   path (`insert_htmlbox`). `TextWriter`/`insert_text` write glyphs one by one in
   the order given, which produces disconnected letters in the wrong order — so
   RTL text must never take that path.

2. **Reading it back.** After shaping, MuPDF stores *presentation forms*
   (U+FB50-FEFF) rather than the logical base letters the user typed. So text
   read out of the document must be normalised back with NFKC, or the user would
   open a line of Arabic and find a different string than they typed.

3. **Font choice.** The base-14 PDF fonts have no Arabic glyphs at all. A font
   must be embedded. Which font matters more than it looks: MuPDF derives the
   reverse Unicode mapping (ToUnicode) from the font itself, and some fonts map
   their ligature glyphs back to the *wrong* characters. Measured on this
   machine, with "مرحبا بالعالم":

       Arial, Tahoma ............ exact
       Noto Sans Arabic (static) . the lam-alef ligature came back as U+029C
       Noto Naskh Arabic ......... lam-alef came back as U+01C4
       Amiri ..................... unusable (Ethiopic/Syriac codepoints)

   A font that renders beautifully but reads back as garbage is worse than no
   font at all, because the damage only appears when the user edits the line
   again. So `choose_font()` does not trust a hard-coded list: it *measures*
   candidates by inserting a probe string and reading it back.
"""
from __future__ import annotations

import unicodedata
from pathlib import Path

# Arabic, Syriac, Thaana, NKo, Samaritan, Mandaic, Hebrew, Arabic Extended,
# Arabic Supplement, Arabic Presentation Forms A/B, plus the historic RTL planes.
RTL_RANGES = (
    (0x0590, 0x05FF),   # Hebrew
    (0x0600, 0x06FF),   # Arabic
    (0x0700, 0x074F),   # Syriac
    (0x0750, 0x077F),   # Arabic Supplement
    (0x0780, 0x07BF),   # Thaana
    (0x07C0, 0x07FF),   # NKo
    (0x0800, 0x083F),   # Samaritan
    (0x0840, 0x085F),   # Mandaic
    (0x08A0, 0x08FF),   # Arabic Extended-A
    (0xFB1D, 0xFB4F),   # Hebrew presentation forms
    (0xFB50, 0xFDFF),   # Arabic presentation forms A
    (0xFE70, 0xFEFF),   # Arabic presentation forms B
    (0x10800, 0x10FFF),  # Cypriot, Phoenician, Kharoshthi, ...
    (0x1E800, 0x1EFFF),  # Mende Kikakui, Adlam
)
# Only these two blocks are produced by shaping, so only these need converting
# back. Normalising anything else would quietly rewrite text the user did not
# ask us to touch (ligatures such as "fi", full-width forms, superscripts).
_PRESENTATION_RANGES = ((0xFB50, 0xFDFF), (0xFE70, 0xFEFF))

BUNDLED_FONT = Path(__file__).resolve().parent / 'static' / 'fonts' / 'NotoSansArabic-Regular.ttf'

# System fonts, best-measured first. Arial and Tahoma are the two that were
# verified to round-trip Arabic exactly, so they lead on every platform.
_SYSTEM_CANDIDATES = (
    # Windows
    r'C:\Windows\Fonts\arial.ttf',
    r'C:\Windows\Fonts\tahoma.ttf',
    r'C:\Windows\Fonts\segoeui.ttf',
    r'C:\Windows\Fonts\DUBAI-REGULAR.TTF',
    r'C:\Windows\Fonts\micross.ttf',
    r'C:\Windows\Fonts\calibri.ttf',
    # macOS
    '/System/Library/Fonts/Supplemental/Arial.ttf',
    '/Library/Fonts/Arial.ttf',
    '/System/Library/Fonts/Supplemental/Tahoma.ttf',
    '/System/Library/Fonts/GeezaPro.ttc',
    '/System/Library/Fonts/Supplemental/GeezaPro.ttc',
    # Linux
    '/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf',
    '/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/truetype/kacst/KacstOne.ttf',
    '/usr/share/fonts/truetype/freefont/FreeSerif.ttf',
)

# A probe built from the parts most likely to break: a lam-alef ligature (لا),
# joining letters, a letter that only takes a final form, and Arabic-Indic
# digits. Deliberately Arabic-only: a dedicated Arabic font such as the bundled
# Noto Sans Arabic carries no Latin glyphs at all, and requiring them would
# disqualify it even though MuPDF substitutes Latin from another font anyway.
PROBE = 'لا مرحبا ٢٠٤٨'
_FONT_CACHE: dict = {}


def is_rtl(text: str) -> bool:
    """True when the text contains any right-to-left character."""
    for char in text or '':
        point = ord(char)
        for low, high in RTL_RANGES:
            if low <= point <= high:
                return True
    return False


def rtl_ratio(text: str) -> float:
    """Share of non-space characters that are RTL. Used to pick alignment."""
    letters = [c for c in (text or '') if not c.isspace()]
    if not letters:
        return 0.0
    rtl = sum(1 for c in letters if is_rtl(c))
    return rtl / len(letters)


def logical(text: str) -> str:
    """Convert shaped presentation forms back to the letters the user typed.

    Applied only when presentation forms are actually present, so ordinary text
    is returned untouched and no unrelated character is silently rewritten.
    """
    if not text:
        return text
    for char in text:
        point = ord(char)
        for low, high in _PRESENTATION_RANGES:
            if low <= point <= high:
                return unicodedata.normalize('NFKC', text)
    return text


_SPACE_LIKE = '\u00a0\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000'


def search_key(text: str) -> str:
    """Comparison form of a string, for matching only — never for display.

    Three normalisations are needed, each for a measured reason:

    * presentation forms back to logical letters (see `logical`);
    * Arabic-Indic (U+0660) and Extended/Persian (U+06F0) digits folded to
      ASCII. A font may map the same digit glyph to either block, so the digits
      a document reads back can differ from the ones the user typed — without
      folding, searching for "٢٠٤٨" would not find the stored "۲۰٤۸";
    * no-break and typographic spaces folded to a plain space, because shaped
      text extracts with U+00A0 between words.
    """
    out = []
    for char in logical(text or ''):
        point = ord(char)
        if 0x0660 <= point <= 0x0669:
            out.append(chr(ord('0') + point - 0x0660))
        elif 0x06F0 <= point <= 0x06F9:
            out.append(chr(ord('0') + point - 0x06F0))
        elif char in _SPACE_LIKE:
            out.append(' ')
        else:
            out.append(char)
    return ' '.join(''.join(out).split()).casefold()


def font_candidates() -> list[Path]:
    """Every font worth trying, system fonts first, bundled font last."""
    found = [Path(p) for p in _SYSTEM_CANDIDATES if Path(p).is_file()]
    if BUNDLED_FONT.is_file():
        found.append(BUNDLED_FONT)
    return found


def _measure(font_path: Path) -> tuple[int, int]:
    """(correct, wrong) characters after inserting PROBE and reading it back.

    Returns (0, 0) when the font cannot be loaded or lacks the glyphs.
    """
    try:
        import pymupdf
    except ImportError:  # pragma: no cover - engine always has pymupdf
        return (0, 0)
    try:
        font = pymupdf.Font(fontfile=str(font_path))
        needed = {ord(c) for c in PROBE if c.strip()}
        if not all(font.has_glyph(p) for p in needed):
            return (0, 0)
        doc = pymupdf.open()
        try:
            page = doc.new_page(width=400, height=120)
            css = (f"@font-face{{font-family:probe;src:url({font_path.name});}}"
                   "div{font-family:probe;font-size:16pt;}")
            page.insert_htmlbox(pymupdf.Rect(20, 20, 380, 100),
                                f'<div dir="rtl">{PROBE}</div>',
                                css=css, archive=pymupdf.Archive(str(font_path.parent)),
                                scale_low=0.2)
            read_back = logical(page.get_text()).replace('\xa0', ' ').strip()
        finally:
            doc.close()
    except Exception:
        return (0, 0)
    # Arabic-Indic digits are normalised to ASCII before comparing, because a
    # font may legitimately pick a different digit variant and that is not the
    # corruption we are hunting for.
    def fold(value: str) -> str:
        out = []
        for char in value:
            point = ord(char)
            if 0x0660 <= point <= 0x0669 or 0x06F0 <= point <= 0x06F9:
                out.append(chr(ord('0') + (point - 0x0660 if point < 0x06F0 else point - 0x06F0)))
            elif char in ' \n\t':
                out.append(' ')
            else:
                out.append(char)
        return ' '.join(''.join(out).split())

    expected, actual = fold(PROBE), fold(read_back)
    # Count positions that survive a simple alignment; the probe is short enough
    # that a straight index walk is a fair score.
    correct = sum(1 for a, b in zip(expected, actual) if a == b)
    wrong = max(len(expected), len(actual)) - correct
    return (correct, wrong)


def choose_font(force: bool = False) -> dict:
    """Pick the Arabic-capable font with the most faithful round-trip.

    The result is cached: measuring costs a handful of milliseconds per
    candidate, and the answer cannot change while the process runs.
    """
    if not force and _FONT_CACHE:
        return _FONT_CACHE
    best: dict | None = None
    for path in font_candidates():
        correct, wrong = _measure(path)
        if correct == 0:
            continue
        candidate = {'path': str(path), 'name': path.name, 'correct': correct,
                     'wrong': wrong, 'exact': wrong == 0, 'bundled': path == BUNDLED_FONT}
        if best is None or (candidate['wrong'], not candidate['exact']) < (best['wrong'], not best['exact']):
            best = candidate
        if candidate['exact']:
            break
    if best is None:
        best = {'path': None, 'name': None, 'correct': 0, 'wrong': 0, 'exact': False,
                'bundled': False, 'quality': 'none'}
    else:
        best['quality'] = 'exact' if best['exact'] else 'approximate'
    _FONT_CACHE.clear()
    _FONT_CACHE.update(best)
    return best


def font_archive():
    """(archive, css_family_url) for the chosen font, or (None, None)."""
    chosen = choose_font()
    if not chosen['path']:
        return None, None
    import pymupdf
    path = Path(chosen['path'])
    return pymupdf.Archive(str(path.parent)), path.name
