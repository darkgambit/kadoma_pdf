"""Making KADOMA a candidate PDF handler, and detecting whether it is one.

**What is possible, and what is not.** Since Windows 8, an application cannot
silently make itself the default handler for a file type. The choice lives in
`UserChoice`, which is protected by a per-user hash; anything that writes it
directly is discarded, and the "default browser"-style hijacking that used to be
common is exactly what that protection exists to stop. So this module does the
two things that *are* legitimate:

1. registers KADOMA as a handler, per user, with no administrator rights —
   so it appears in "Open with", and in Settings > Default apps;
2. offers to open the Windows Settings page where the user picks it.

Nothing here pretends the second step is automatic. `set_default` returns
`confirmed: False` and the interface says so.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

IS_WINDOWS = sys.platform == 'win32'
IS_MAC = sys.platform == 'darwin'

PROG_ID = 'KADOMA.Document.pdf'
APP_KEY = 'KADOMA.exe'
FRIENDLY_NAME = 'KADOMA PDF'
DESCRIPTION = 'KADOMA PDF — offline PDF studio'
EXTENSION = '.pdf'

# The Explorer entry that combines the files you selected. It lives under
# SystemFileAssociations rather than under KADOMA's own ProgID so it shows up
# whether or not KADOMA is the default handler — the point is that it is there
# when the files are selected, not that the app has been made default.
COMBINE_VERB = 'KADOMACombine'
COMBINE_LABEL = 'Combine with KADOMA PDF'
COMBINE_KEY = rf'Software\Classes\SystemFileAssociations\{EXTENSION}\shell\{COMBINE_VERB}'


def _quote(path: str) -> str:
    return f'"{path}"'


def _script_path() -> Path | None:
    """The entry script, when the app is running from source rather than frozen."""
    candidate = Path(sys.argv[0] or '')
    try:
        resolved = candidate.resolve()
    except (OSError, ValueError):
        return None
    if resolved.is_file() and resolved.suffix.lower() == '.py':
        return resolved
    fallback = Path(__file__).resolve().parents[1] / 'desktop.py'
    return fallback if fallback.is_file() else None


def executable() -> str:
    """Path to the program the registry should point at.

    In a frozen build `sys.executable` is the application itself. From source it
    is the Python interpreter, so the entry script is added as its first
    argument — otherwise double-clicking a PDF would start an interpreter with
    nothing to run.
    """
    if getattr(sys, 'frozen', False):
        return sys.executable
    script = _script_path()
    return f'{sys.executable} "{script}"' if script else sys.executable


def icon_path() -> str:
    """The icon lives in the executable, so this is a path and not a command."""
    return sys.executable if getattr(sys, 'frozen', False) else str(Path(__file__).resolve().parents[1] / 'assets' / 'KADOMA.ico')


def command_line() -> str:
    """The shell command Windows runs for an associated file. `%1` is the path."""
    if getattr(sys, 'frozen', False):
        return f'{_quote(sys.executable)} "%1"'
    script = _script_path()
    if not script:
        return f'{_quote(sys.executable)} "%1"'
    return f'{_quote(sys.executable)} "{script}" "%1"'


def combine_command() -> str:
    """What Explorer runs for the menu entry.

    `%*` is every selected file, so one entry combines any number of them in a
    single click. The count and the sizes are checked again inside the app —
    a command line is not a promise about what it was given.
    """
    if getattr(sys, 'frozen', False):
        return f'{_quote(sys.executable)} --combine %*'
    script = _script_path()
    if not script:
        return f'{_quote(sys.executable)} --combine %*'
    return f'{_quote(sys.executable)} "{script}" --combine %*'


def register_context_menu() -> dict:
    """Add "Combine with KADOMA PDF" to the right-click menu for .pdf files.

    Per user, no administrator rights, and idempotent — it runs at every start
    so an uninstalled-then-reinstalled copy puts it back. `MultiSelectModel` is
    what makes the entry appear at all when more than one file is selected;
    without it Explorer hides the verb the moment a second file is picked.
    """
    if not IS_WINDOWS:
        return {'ok': False, 'supported': False}
    try:
        classes = _winreg().HKEY_CURRENT_USER
        _set_default(classes, COMBINE_KEY, COMBINE_LABEL)
        _set_value(classes, COMBINE_KEY, 'Icon', f'{icon_path()},0')
        _set_value(classes, COMBINE_KEY, 'MultiSelectModel', 'Player')
        _set_default(classes, COMBINE_KEY + r'\command', combine_command())
        return {'ok': True, 'supported': True, 'command': combine_command()}
    except Exception as exc:  # noqa: BLE001 - a locked-down policy is not fatal
        return {'ok': False, 'supported': True, 'error': f'{type(exc).__name__}'}


def context_menu_registered() -> bool:
    if not IS_WINDOWS:
        return False
    try:
        with _winreg().OpenKey(_winreg().HKEY_CURRENT_USER, COMBINE_KEY):
            return True
    except OSError:
        return False


def read_documents(paths: list) -> list[tuple[bytes, str]]:
    """Read the files the shell handed over, refusing anything that is not a PDF.

    The paths come from Explorer, so they are real paths the user selected — but
    a command line can be typed by hand, so nothing here trusts the extension
    alone: every file is opened and its first bytes checked for the PDF header.
    """
    from .engine import MAX_UPLOAD
    from .errors import PDFError

    if not isinstance(paths, list) or not paths:
        raise PDFError('Choose one or more PDF files to combine.')

    documents: list[tuple[bytes, str]] = []
    total = 0
    for raw in paths:
        if not isinstance(raw, str):
            raise PDFError('That is not a file path.')
        path = Path(raw)
        if not path.is_file():
            raise PDFError(f'{path.name} is no longer there.')
        size = path.stat().st_size
        total += size
        if total > MAX_UPLOAD:
            raise PDFError(f'Those files together are over {MAX_UPLOAD // (1024 * 1024)} MB.',
                           413, 'file_too_large')
        data = path.read_bytes()
        if not data.startswith(b'%PDF-'):
            raise PDFError(f'{path.name} is not a PDF file.')
        documents.append((data, path.name))
    return documents


def supported() -> bool:
    return IS_WINDOWS or IS_MAC


def _winreg():
    import winreg
    return winreg


def _set_default(root, subkey: str, value: str):
    """Create `subkey` and set its (Default) value."""
    winreg = _winreg()
    with winreg.CreateKeyEx(root, subkey, 0, winreg.KEY_SET_VALUE) as handle:
        winreg.SetValueEx(handle, None, 0, winreg.REG_SZ, value)


def _set_value(root, subkey: str, name: str, value: str):
    """Create `subkey` and set a *named* value inside it.

    Kept separate from _set_default because the two are easy to confuse, and
    confusing them produces keys that exist but mean nothing to Windows —
    e.g. an OpenWithProgids entry written as the default value is simply ignored.
    """
    winreg = _winreg()
    with winreg.CreateKeyEx(root, subkey, 0, winreg.KEY_SET_VALUE) as handle:
        winreg.SetValueEx(handle, name, 0, winreg.REG_SZ, value)


def register() -> dict:
    """Register as a PDF handler for the current user. No admin rights needed."""
    if not IS_WINDOWS:
        return {'ok': False, 'supported': False,
                'error': 'Automatic registration is implemented for Windows. '
                         'On macOS the app declares the file type in its own bundle.'}
    winreg = _winreg()
    try:
        classes = winreg.HKEY_CURRENT_USER
        exe, command, icon = executable(), command_line(), icon_path()

        # 1. The ProgID that describes "a PDF opened by KADOMA".
        _set_default(classes, rf'Software\Classes\{PROG_ID}', 'PDF Document')
        _set_default(classes, rf'Software\Classes\{PROG_ID}\DefaultIcon', f'{icon},0')
        _set_default(classes, rf'Software\Classes\{PROG_ID}\shell\open\command', command)

        # 2. Offer it in the .pdf "Open with" list without touching the default.
        #    This must be a named value whose name is the ProgID.
        _set_value(classes, rf'Software\Classes\{EXTENSION}\OpenWithProgids', PROG_ID, '')

        # 3. Register the executable itself so it is a known application.
        app = rf'Software\Classes\Applications\{APP_KEY}'
        _set_default(classes, app, FRIENDLY_NAME)
        _set_default(classes, rf'{app}\DefaultIcon', f'{icon},0')
        _set_default(classes, rf'{app}\shell\open\command', command)

        # 4. Capabilities + RegisteredApplications is what makes the app appear
        #    in Settings > Default apps as a choosable PDF handler. The mapping is
        #    named by extension and valued with the ProgID.
        capabilities = r'Software\KADOMA\Capabilities'
        _set_default(classes, capabilities, 'KADOMA PDF')
        _set_default(classes, capabilities + r'\ApplicationName', FRIENDLY_NAME)
        _set_default(classes, capabilities + r'\ApplicationDescription', DESCRIPTION)
        _set_value(classes, capabilities + r'\FileAssociations', EXTENSION, PROG_ID)
        _set_value(classes, r'Software\RegisteredApplications', 'KADOMA PDF', capabilities)
        return {'ok': True, 'supported': True, 'confirmed': False, 'command': command,
                'progId': PROG_ID,
                'note': ('KADOMA is now offered as a PDF handler. Windows requires you to '
                         'confirm the default yourself — opening Settings next.')}
    except PermissionError:
        return {'ok': False, 'supported': True,
                'error': 'Windows refused the change. Registration only needs your own user '
                         'account; a locked-down policy may be blocking it.'}
    except Exception as exc:
        return {'ok': False, 'supported': True, 'error': f'Registration failed ({type(exc).__name__}).'}


def _delete_tree(root, path: str) -> bool:
    """Delete a registry key and everything beneath it.

    Windows refuses to delete a key that still has subkeys, so removing
    `...\\Capabilities` alone silently fails while `ApplicationName` and
    `FileAssociations` remain under it. Walking the tree is the only reliable
    way to leave no trace behind.
    """
    winreg = _winreg()
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as handle:
            children, index = [], 0
            while True:
                try:
                    children.append(winreg.EnumKey(handle, index))
                except OSError:
                    break
                index += 1
    except OSError:
        return False
    for child in children:
        _delete_tree(root, path + '\\' + child)
    try:
        winreg.DeleteKey(root, path)
        return True
    except OSError:
        return False


def unregister() -> dict:
    """Remove every key register() created, leaving other handlers untouched."""
    if not IS_WINDOWS:
        return {'ok': False, 'supported': False, 'error': 'Only implemented for Windows.'}
    winreg = _winreg()
    removed, failed = [], []

    def drop(path: str, name: str | None = None):
        if name is None:
            if _delete_tree(winreg.HKEY_CURRENT_USER, path):
                removed.append(path)
            elif _key_exists(path):
                failed.append(path)
            return
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as handle:
                winreg.DeleteValue(handle, name)
            removed.append(f'{path}\\{name}')
        except FileNotFoundError:
            pass
        except OSError:
            failed.append(f'{path}\\{name}')

    def _key_exists(path: str) -> bool:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path):
                return True
        except OSError:
            return False

    drop(COMBINE_KEY)
    drop(rf'Software\Classes\{PROG_ID}')
    drop(rf'Software\Classes\{EXTENSION}\OpenWithProgids', PROG_ID)
    drop(rf'Software\Classes\Applications\{APP_KEY}')
    drop(r'Software\KADOMA\Capabilities')
    drop(r'Software\KADOMA')
    drop(r'Software\RegisteredApplications', 'KADOMA PDF')
    return {'ok': not failed, 'removed': removed, 'failed': failed}


def status() -> dict:
    """Is KADOMA registered, and is it currently the default for .pdf?"""
    if not IS_WINDOWS:
        return {'supported': False, 'registered': False, 'isDefault': False}
    winreg = _winreg()
    registered = False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, rf'Software\Classes\{PROG_ID}') as handle:
            winreg.QueryValueEx(handle, None)
        registered = True
    except OSError:
        registered = False

    is_default, current = False, None
    try:
        # This is the only place Windows records the user's actual choice, and
        # it is readable even though it is not writable by us.
        path = (r'Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts'
                rf'\{EXTENSION}\UserChoice')
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path) as handle:
            current = winreg.QueryValueEx(handle, 'ProgId')[0]
            is_default = current == PROG_ID
    except OSError:
        pass
    return {'supported': True, 'registered': registered, 'isDefault': is_default,
            'currentHandler': current, 'progId': PROG_ID,
            'command': command_line(), 'appearsInOpenWith': registered,
            'contextMenu': context_menu_registered(), 'contextMenuCommand': combine_command()}


def open_settings() -> dict:
    """Open the Windows page where the user confirms the default themselves."""
    if IS_WINDOWS:
        try:
            # Windows 11 accepts the app name as a hint and opens that app's page.
            os.startfile(f'ms-settings:defaultapps?registeredAppUser={FRIENDLY_NAME}')
            return {'ok': True, 'target': 'ms-settings:defaultapps'}
        except Exception:
            try:
                os.startfile('ms-settings:defaultapps')
                return {'ok': True, 'target': 'ms-settings:defaultapps'}
            except Exception:
                return {'ok': False, 'error': 'Windows Settings could not be opened.'}
    if IS_MAC:
        try:
            subprocess.Popen(['open', 'x-apple.systempreferences:com.apple.preference.extensions'])
            return {'ok': True, 'target': 'System Settings'}
        except Exception:
            return {'ok': False, 'error': 'System Settings could not be opened.'}
    return {'ok': False, 'error': 'Opening the default-apps settings is implemented for Windows and macOS.'}
