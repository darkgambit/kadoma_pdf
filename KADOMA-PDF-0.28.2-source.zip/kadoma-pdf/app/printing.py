"""Direct printing, without depending on another PDF reader being installed.

The obvious approach — hand the file to the operating system's "print" verb — has
a trap that only shows up once this application is the default PDF handler: the
verb is resolved through the file association, so if KADOMA owns `.pdf` and
defines no print verb, printing the document would either fail or start
KADOMA again. Neither is acceptable, and the second one is an infinite loop.

So on Windows the pages are rendered here and sent straight to the printer
through the GDI print API. That cannot recurse, needs no other application, and
is genuinely "print to the default printer" rather than "ask something else to
print". On macOS and Linux the PDF is piped to the CUPS client (`lpr`/`lp`),
which is the normal local print path there.

Rendering happens at print resolution rather than reusing the screen image, so a
printed page is not limited to screen quality.
"""
from __future__ import annotations

import ctypes
import struct
import subprocess
import sys
from ctypes import wintypes
from pathlib import Path

IS_WINDOWS = sys.platform == 'win32'
IS_MAC = sys.platform == 'darwin'
IS_LINUX = sys.platform.startswith('linux')

# Print at this resolution unless the page is enormous. 200 DPI is a normal
# office print quality and matches the resolution the OCR path already uses.
PRINT_DPI = 200
MAX_PRINT_PIXELS = 40_000_000


def supported() -> bool:
    return IS_WINDOWS or IS_MAC or IS_LINUX


# --------------------------------------------------------------- Windows GDI

class _DOCINFOW(ctypes.Structure):
    _fields_ = [('cbSize', ctypes.c_int),
                ('lpszDocName', ctypes.c_wchar_p),
                ('lpszOutput', ctypes.c_wchar_p),
                ('lpszDatatype', ctypes.c_wchar_p),
                ('fwType', ctypes.c_ulong)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [('biSize', wintypes.DWORD), ('biWidth', ctypes.c_long),
                ('biHeight', ctypes.c_long), ('biPlanes', wintypes.WORD),
                ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', ctypes.c_long),
                ('biYPelsPerMeter', ctypes.c_long), ('biClrUsed', wintypes.DWORD),
                ('biClrImportant', wintypes.DWORD)]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [('bmiHeader', _BITMAPINFOHEADER), ('bmiColors', wintypes.DWORD * 3)]


HORZRES, VERTRES = 8, 10
PHYSICALWIDTH, PHYSICALHEIGHT = 110, 111
PHYSICALOFFSETX, PHYSICALOFFSETY = 112, 113
DIB_RGB_COLORS = 0
SRCCOPY = 0x00CC0020


def default_printer() -> str | None:
    """Name of the default printer, or None when the machine has none."""
    if not IS_WINDOWS:
        return None
    try:
        spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
        spool.GetDefaultPrinterW.argtypes = [wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        spool.GetDefaultPrinterW.restype = wintypes.BOOL
        size = wintypes.DWORD(0)
        spool.GetDefaultPrinterW(None, ctypes.byref(size))
        if not size.value:
            return None
        buffer = ctypes.create_unicode_buffer(size.value)
        if not spool.GetDefaultPrinterW(buffer, ctypes.byref(size)):
            return None
        return buffer.value or None
    except Exception:
        return None


class _PRINTER_INFO_2W(ctypes.Structure):
    _fields_ = [
        ('pServerName', wintypes.LPWSTR), ('pPrinterName', wintypes.LPWSTR),
        ('pShareName', wintypes.LPWSTR), ('pPortName', wintypes.LPWSTR),
        ('pDriverName', wintypes.LPWSTR), ('pComment', wintypes.LPWSTR),
        ('pLocation', wintypes.LPWSTR), ('pDevMode', ctypes.c_void_p),
        ('pSepFile', wintypes.LPWSTR), ('pPrintProcessor', wintypes.LPWSTR),
        ('pDatatype', wintypes.LPWSTR), ('pParameters', wintypes.LPWSTR),
        ('pSecurityDescriptor', ctypes.c_void_p), ('Attributes', wintypes.DWORD),
        ('Priority', wintypes.DWORD), ('DefaultPriority', wintypes.DWORD),
        ('StartTime', wintypes.DWORD), ('UntilTime', wintypes.DWORD),
        ('Status', wintypes.DWORD), ('cJobs', wintypes.DWORD),
        ('AveragePPM', wintypes.DWORD),
    ]


def printer_details(printer: str) -> tuple[str, str]:
    """(port, driver) for a printer, or ('', '') when it cannot be queried.

    GetPrinterW wants a handle from OpenPrinterW, not a printer name — passing
    the name fails with ERROR_INVALID_HANDLE, which is easy to mistake for the
    printer not existing.
    """
    if not IS_WINDOWS or not printer:
        return '', ''
    handle = ctypes.c_void_p()
    try:
        spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
        spool.OpenPrinterW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
        spool.OpenPrinterW.restype = wintypes.BOOL
        spool.GetPrinterW.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p,
                                      wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        spool.GetPrinterW.restype = wintypes.BOOL
        spool.ClosePrinter.argtypes = [ctypes.c_void_p]
        if not spool.OpenPrinterW(printer, ctypes.byref(handle), None):
            return '', ''
        needed = wintypes.DWORD(0)
        spool.GetPrinterW(handle, 2, None, 0, ctypes.byref(needed))
        if not needed.value:
            return '', ''
        buffer = ctypes.create_string_buffer(needed.value)
        if not spool.GetPrinterW(handle, 2, ctypes.cast(buffer, ctypes.c_void_p),
                                 needed.value, ctypes.byref(needed)):
            return '', ''
        info = ctypes.cast(buffer, ctypes.POINTER(_PRINTER_INFO_2W)).contents
        return (info.pPortName or ''), (info.pDriverName or '')
    except Exception:
        return '', ''
    finally:
        if handle:
            try:
                ctypes.WinDLL('winspool.drv', use_last_error=True).ClosePrinter(handle)
            except Exception:
                pass


def saves_to_a_file(printer: str) -> bool:
    """True when this printer cannot print without asking where to save.

    "Microsoft Print to PDF", "Microsoft XPS Document Writer" and friends are
    really file exporters. A GDI job sent to one of them pops up a Save dialog
    and blocks until somebody answers it — which, from the server's point of
    view, is a request that never returns. They are detected by their port,
    which is the reliable signal ("PORTPROMPT:" asks for a filename, "FILE:"
    writes to a file), rather than by guessing from the driver's name.
    """
    port, driver = printer_details(printer)
    if port and (port.upper().startswith('PORTPROMPT') or port.upper().startswith('FILE:')):
        return True
    # The name and driver are checked even when a port was found. A printer on
    # an ordinary-looking port can still be a sink: OneNote's driver reports
    # `nul:`, which is not a filename prompt but is not paper either, and the
    # earlier version returned "printable" for it without ever looking at the
    # name.
    lowered = ' '.join((printer or '', driver or '')).lower()
    return any(marker in lowered for marker in
               ('print to pdf', 'xps', 'onenote', 'fax', 'print to file'))


class _PRINTER_INFO_4W(ctypes.Structure):
    _fields_ = [('pPrinterName', wintypes.LPWSTR),
                ('pServerName', wintypes.LPWSTR),
                ('Attributes', wintypes.DWORD)]


PRINTER_ENUM_LOCAL = 0x00000002
PRINTER_ENUM_CONNECTIONS = 0x00000004



# ------------------------------------------------------- printer preferences
# The driver's own settings dialog, not a copy of it. Paper size, orientation,
# duplex, quality and the rest differ on every driver, so the only honest way to
# offer all of them is to ask the driver — a hand-built dialog would silently do
# nothing on half the printers in the world.

_DEVMODES: dict[str, ctypes.Array] = {}

DM_IN_BUFFER = 8
DM_OUT_BUFFER = 2
DM_PROMPT = 4
IDOK, IDCANCEL = 1, 2

_PAPERS = {1: 'Letter', 5: 'Legal', 8: 'A3', 9: 'A4', 11: 'A5', 13: 'B5',
           14: 'Folio', 43: 'A4 (small)', 256: 'Custom'}


def printer_preferences(printer: str | None = None, prompt: bool = True) -> dict:
    """Open the printer driver's own settings dialog, and keep what it returns.

    `prompt=False` only reads the current settings — that is how the plumbing is
    tested without a person to click OK. The chosen block is kept for the rest of
    the session and handed to `CreateDC` on the next job.
    """
    printer = printer or (default_printer() if IS_WINDOWS else None)
    if not IS_WINDOWS or not printer:
        return {'ok': False, 'error': 'Printer settings are only available in the Windows desktop application.'}
    spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
    handle = ctypes.c_void_p()
    spool.OpenPrinterW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
    spool.OpenPrinterW.restype = wintypes.BOOL
    spool.ClosePrinter.argtypes = [ctypes.c_void_p]
    spool.DocumentPropertiesW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.LPCWSTR,
                                          ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD]
    spool.DocumentPropertiesW.restype = ctypes.c_long
    try:
        if not spool.OpenPrinterW(printer, ctypes.byref(handle), None):
            return {'ok': False, 'error': f'"{printer}" could not be opened.'}
        size = spool.DocumentPropertiesW(None, handle, printer, None, None, 0)
        if size <= 0:
            return {'ok': False, 'error': f'"{printer}" did not report a settings block.'}
        buffer = ctypes.create_string_buffer(size)
        if spool.DocumentPropertiesW(None, handle, printer, buffer, None, DM_OUT_BUFFER) < 0:
            return {'ok': False, 'error': f'"{printer}" did not return its current settings.'}
        if prompt:
            code = spool.DocumentPropertiesW(None, handle, printer, buffer, buffer,
                                             DM_IN_BUFFER | DM_OUT_BUFFER | DM_PROMPT)
            if code == IDCANCEL:
                return {'ok': True, 'cancelled': True, 'printer': printer}
            if code < 0:
                return {'ok': False, 'error': f'"{printer}" refused to open its settings dialog.'}
        _DEVMODES[printer] = buffer
        orientation, paper, _length, _width, _scale, copies = struct.unpack_from('<hhhhhh', buffer, 76)
        return {'ok': True, 'cancelled': False, 'printer': printer,
                'paper': _PAPERS.get(paper, f'Paper {paper}'), 'paperId': paper,
                'orientation': 'landscape' if orientation == 2 else 'portrait',
                'copies': copies or 1}
    except Exception as exc:
        return {'ok': False, 'error': f'The printer settings could not be opened: {exc}.'}
    finally:
        if handle:
            try:
                spool.ClosePrinter(handle)
            except Exception:
                pass


def preferences_summary(printer: str | None = None) -> dict | None:
    """What the driver last reported, without opening anything."""
    buffer = _DEVMODES.get(printer or '')
    if buffer is None:
        return None
    orientation, paper, _length, _width, _scale, copies = struct.unpack_from('<hhhhhh', buffer, 76)
    duplex = struct.unpack_from('<h', buffer, 94)[0]
    return {'paper': _PAPERS.get(paper, f'Paper {paper}'), 'paperId': paper,
            'orientation': 'landscape' if orientation == 2 else 'portrait',
            'duplex': DUPLEX_NAMES.get(duplex, 'simplex'),
            'copies': copies or 1}


def duplex_options(printer: str | None = None) -> list[str]:
    """Which two-sided modes this driver says it can do.

    Asked rather than assumed: a driver that only staples or only does simplex
    should not be offered long-edge binding that it will silently ignore.
    """
    printer = printer or (default_printer() if IS_WINDOWS else None)
    if not IS_WINDOWS or not printer:
        return ['simplex']
    port, _driver = printer_details(printer)
    try:
        spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
        spool.DeviceCapabilitiesW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.WORD,
                                              ctypes.c_void_p, ctypes.c_void_p]
        spool.DeviceCapabilitiesW.restype = ctypes.c_int
        mask = spool.DeviceCapabilitiesW(printer, port, DC_DUPLEX, None, None)
        if mask <= 0:
            return ['simplex']
        found = [DUPLEX_NAMES[value] for value in (1, 2, 3) if mask & value]
        return found or ['simplex']
    except Exception:
        return ['simplex']


# The paper sizes this driver can actually take, asked rather than assumed. A
# hand-written list would offer A3 to a printer that has never heard of it, and
# the driver would then quietly print on whatever it had loaded.
DC_PAPERS, DC_PAPERNAMES, DC_DUPLEX = 2, 16, 7
DM_ORIENTATION, DM_PAPERSIZE, DM_DUPLEX = 0x00000001, 0x00000002, 0x00001000
PAPER_NAMES_LENGTH = 64
DUPLEX_NAMES = {1: 'simplex', 2: 'long', 3: 'short'}


def papers(printer: str | None = None) -> list[dict]:
    """[{'id': 9, 'name': 'A4'}, …] for the sizes this printer reports."""
    printer = printer or (default_printer() if IS_WINDOWS else None)
    if not IS_WINDOWS or not printer:
        return []
    port, _driver = printer_details(printer)
    try:
        spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
        spool.DeviceCapabilitiesW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.WORD,
                                              ctypes.c_void_p, ctypes.c_void_p]
        spool.DeviceCapabilitiesW.restype = ctypes.c_int
        count = spool.DeviceCapabilitiesW(printer, port, DC_PAPERS, None, None)
        if count <= 0:
            return []
        ids = (wintypes.WORD * count)()
        if spool.DeviceCapabilitiesW(printer, port, DC_PAPERS,
                                     ctypes.cast(ids, ctypes.c_void_p), None) <= 0:
            return []
        names = ctypes.create_unicode_buffer(PAPER_NAMES_LENGTH * count)
        if spool.DeviceCapabilitiesW(printer, port, DC_PAPERNAMES,
                                     ctypes.cast(names, ctypes.c_void_p), None) <= 0:
            return []
        found = []
        for index in range(count):
            label = names[PAPER_NAMES_LENGTH * index:PAPER_NAMES_LENGTH * (index + 1)]
            label = label.split('\x00')[0].strip()
            if label:
                found.append({'id': int(ids[index]), 'name': label})
        return found
    except Exception:
        return []


def apply_settings(printer: str | None = None, paper: int | None = None,
                   orientation: str | None = None, duplex: str | None = None) -> dict:
    """Set the paper, the orientation and the sides in the driver's settings block.

    The block is handed to the driver afterwards with DM_IN_BUFFER|DM_OUT_BUFFER,
    which is the documented way to have it validate and correct what it was
    given — a printer that cannot do landscape on an envelope answers with the
    settings it will actually use, rather than printing something unexpected.
    """
    printer = printer or (default_printer() if IS_WINDOWS else None)
    if not IS_WINDOWS or not printer:
        return {'ok': False, 'error': 'Printer settings are only available in the Windows desktop application.'}
    if orientation is not None and orientation not in ('portrait', 'landscape'):
        return {'ok': False, 'error': 'Choose portrait or landscape.'}
    if duplex is not None and duplex not in ('simplex', 'long', 'short'):
        return {'ok': False, 'error': 'Choose one-sided or two-sided printing.'}
    if paper is not None:
        try:
            paper = int(paper)
        except (TypeError, ValueError):
            return {'ok': False, 'error': 'That paper size is not a number.'}
        if paper <= 0:
            return {'ok': False, 'error': 'Choose a paper size.'}
    if paper is None and orientation is None and duplex is None:
        return {'ok': True, 'printer': printer, **(preferences_summary(printer) or {})}

    if printer not in _DEVMODES:
        opened = printer_preferences(printer, prompt=False)
        if not opened.get('ok'):
            return opened
    buffer = _DEVMODES[printer]
    try:
        fields = struct.unpack_from('<I', buffer, 72)[0]
        if orientation is not None:
            struct.pack_into('<H', buffer, 76, 2 if orientation == 'landscape' else 1)
            fields |= DM_ORIENTATION
        if paper is not None:
            struct.pack_into('<H', buffer, 78, paper)
            fields |= DM_PAPERSIZE
        if duplex is not None:
            struct.pack_into('<h', buffer, 94, {'simplex': 1, 'long': 2, 'short': 3}[duplex])
            fields |= DM_DUPLEX
        struct.pack_into('<I', buffer, 72, fields)
    except struct.error:
        return {'ok': False, 'error': 'The printer settings block was not readable.'}

    handle = ctypes.c_void_p()
    spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
    try:
        spool.OpenPrinterW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p]
        spool.OpenPrinterW.restype = wintypes.BOOL
        spool.DocumentPropertiesW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.LPCWSTR,
                                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD]
        spool.DocumentPropertiesW.restype = ctypes.c_long
        if not spool.OpenPrinterW(printer, ctypes.byref(handle), None):
            return {'ok': False, 'error': f'"{printer}" could not be opened.'}
        if spool.DocumentPropertiesW(None, handle, printer, buffer, buffer,
                                     DM_IN_BUFFER | DM_OUT_BUFFER) < 0:
            return {'ok': False, 'error': f'"{printer}" refused those settings.'}
        return {'ok': True, 'printer': printer, **(preferences_summary(printer) or {})}
    except Exception as exc:
        return {'ok': False, 'error': f'The printer settings could not be changed: {exc}.'}
    finally:
        if handle:
            try:
                spool.ClosePrinter(handle)
            except Exception:
                pass


def printers() -> list[dict]:
    """Every printer installed for this user, flagged with whether it can print.

    Level 4 is used deliberately: it returns names and nothing else, so it is
    fast and never opens a device. The `printable` flag matters because a
    machine whose default printer is "Microsoft Print to PDF" would otherwise
    look like a machine that cannot print at all.
    """
    if not IS_WINDOWS:
        return []
    try:
        spool = ctypes.WinDLL('winspool.drv', use_last_error=True)
        spool.EnumPrintersW.argtypes = [wintypes.DWORD, wintypes.LPWSTR, wintypes.DWORD,
                                        ctypes.c_void_p, wintypes.DWORD,
                                        ctypes.POINTER(wintypes.DWORD),
                                        ctypes.POINTER(wintypes.DWORD)]
        spool.EnumPrintersW.restype = wintypes.BOOL
        flags = PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS
        needed = wintypes.DWORD(0)
        returned = wintypes.DWORD(0)
        spool.EnumPrintersW(flags, None, 4, None, 0, ctypes.byref(needed), ctypes.byref(returned))
        if not needed.value:
            return []
        buffer = ctypes.create_string_buffer(needed.value)
        if not spool.EnumPrintersW(flags, None, 4, ctypes.cast(buffer, ctypes.c_void_p),
                                   needed.value, ctypes.byref(needed), ctypes.byref(returned)):
            return []
        array = ctypes.cast(buffer, ctypes.POINTER(_PRINTER_INFO_4W))
        names = [array[index].pPrinterName for index in range(returned.value)]
    except Exception:
        return []
    default = default_printer()
    found = []
    for name in names:
        if not name:
            continue
        found.append({'name': name, 'default': name == default,
                      'printable': not saves_to_a_file(name)})
    found.sort(key=lambda item: (not item['default'], not item['printable'], item['name'].lower()))
    return found


def _dib_bytes(samples: bytes, width: int, height: int) -> bytes:
    """Turn a PyMuPDF RGB pixmap into the rows a 24-bit DIB expects.

    Two differences matter here, and both of them showed up as something other
    than a clean error:

    * Channel order. A 24-bit `BI_RGB` DIB stores pixels as BGR, but PyMuPDF
      hands back RGB, so red and blue arrived on paper swapped.
    * Row padding. A DIB pads every row to a multiple of four bytes; PyMuPDF
      writes exactly `width * 3` with none. For a page whose rendered width is
      not a multiple of four pixels — A4 at 200 DPI renders 1654 px, so 4962
      bytes a row — the driver read three bytes past the end of every row and
      faulted inside itself, reporting "access violation reading 0x...".
      That made printing A4, the most common paper size there is, fail outright.
      US Letter happens to render 1700 px wide, which is already aligned, and
      that is the only reason this stayed hidden.
    """
    row = width * 3
    padded = (row + 3) & ~3
    buffer = bytearray(samples)
    # Swap R and B in place. The right-hand slices are copies, so the two
    # assignments do not interfere with each other.
    buffer[0::3], buffer[2::3] = buffer[2::3], buffer[0::3]
    if padded != row:
        out = bytearray(padded * height)
        for y in range(height):
            out[y * padded:y * padded + row] = buffer[y * row:(y + 1) * row]
        buffer = out
    return bytes(buffer)


def _render_pages(data: bytes, dpi: int = PRINT_DPI, pages: list[int] | None = None):
    """[(width, height, dib_bytes)] for the chosen pages, at print resolution."""
    import pymupdf as fitz
    sheets = []
    with fitz.open(stream=data, filetype='pdf') as doc:
        chosen = range(len(doc)) if pages is None else pages
        for index in chosen:
            page = doc[index]
            # Keep the raster inside a sane memory budget on very large pages.
            scale = dpi / 72.0
            if page.rect.width * page.rect.height * scale * scale > MAX_PRINT_PIXELS:
                scale = (MAX_PRINT_PIXELS / (page.rect.width * page.rect.height)) ** .5
            pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), colorspace=fitz.csRGB, alpha=False)
            sheets.append((pixmap.width, pixmap.height,
                           _dib_bytes(pixmap.samples, pixmap.width, pixmap.height)))
    return sheets


def _print_windows(data: bytes, name: str, printer: str | None = None,
                   output: str | None = None, pages: list[int] | None = None,
                   copies: int = 1, collate: bool = True) -> dict:
    """Render every page and draw it on the printer device context.

    `output` writes the job to a file instead of a printer. That exists so the
    printing path can be verified on a machine with no paper — the Windows
    "Microsoft Print to PDF" driver accepts it and produces a real document.
    """
    printer = printer or default_printer()
    if not printer:
        return {'ok': False, 'error': 'No printer is installed, so there is nothing to print to.'}
    try:
        gdi32 = ctypes.WinDLL('gdi32', use_last_error=True)
        gdi32.CreateDCW.argtypes = [wintypes.LPCWSTR] * 3 + [ctypes.c_void_p]
        gdi32.CreateDCW.restype = ctypes.c_void_p
        gdi32.GetDeviceCaps.argtypes = [ctypes.c_void_p, ctypes.c_int]
        gdi32.GetDeviceCaps.restype = ctypes.c_int
        gdi32.StartDocW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_DOCINFOW)]
        gdi32.StartDocW.restype = ctypes.c_int
        gdi32.StartPage.argtypes = [ctypes.c_void_p]
        gdi32.EndPage.argtypes = [ctypes.c_void_p]
        gdi32.EndDoc.argtypes = [ctypes.c_void_p]
        gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
        # StretchDIBits, not SetDIBitsToDevice: the latter blits the bitmap at
        # its own size and ignores the destination rectangle, so a page printed
        # through it comes out unscaled in the corner of the sheet.
        gdi32.StretchDIBits.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_void_p, ctypes.POINTER(_BITMAPINFO), wintypes.UINT, wintypes.DWORD]
        gdi32.StretchDIBits.restype = ctypes.c_int

        # A DEVMODE chosen in the driver's own preferences dialog is honoured
        # here; without one the driver's current defaults are used.
        devmode = _DEVMODES.get(printer)
        hdc = gdi32.CreateDCW('WINSPOOL', printer, None,
                              ctypes.cast(devmode, ctypes.c_void_p) if devmode else None)
        if not hdc:
            return {'ok': False, 'error': f'The printer "{printer}" could not be opened.'}
        try:
            printable_w = gdi32.GetDeviceCaps(hdc, HORZRES)
            printable_h = gdi32.GetDeviceCaps(hdc, VERTRES)
            offset_x = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETX)
            offset_y = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETY)
            if printable_w <= 0 or printable_h <= 0:
                return {'ok': False, 'error': f'The printer "{printer}" reported no printable area.'}

            info = _DOCINFOW()
            info.cbSize = ctypes.sizeof(_DOCINFOW)
            info.lpszDocName = name or 'KADOMA PDF document'
            info.lpszOutput = output or None
            if gdi32.StartDocW(hdc, ctypes.byref(info)) <= 0:
                return {'ok': False, 'error': f'The print job was refused by "{printer}".'}

            try:
                rendered = _render_pages(data, pages=pages)
                # The driver is handed the sheets in the order they must come
                # out, so collated and uncollated differ only in this list.
                sheets = [rendered[index] for index in
                          sheet_order(range(len(rendered)), copies, collate)]
                for width, height, samples in sheets:
                    if gdi32.StartPage(hdc) <= 0:
                        raise OSError('the printer rejected a page')
                    # Fit the whole page inside the printable area and centre it.
                    scale = min(printable_w / width, printable_h / height)
                    draw_w, draw_h = max(1, int(width * scale)), max(1, int(height * scale))
                    x = offset_x + (printable_w - draw_w) // 2
                    y = offset_y + (printable_h - draw_h) // 2
                    header = _BITMAPINFO()
                    header.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
                    header.bmiHeader.biWidth = width
                    # Negative height selects a top-down bitmap, which is the
                    # order PyMuPDF produces; without it the page prints mirrored.
                    header.bmiHeader.biHeight = -height
                    header.bmiHeader.biPlanes = 1
                    header.bmiHeader.biBitCount = 24
                    header.bmiHeader.biCompression = 0  # BI_RGB
                    buffer = ctypes.create_string_buffer(samples, len(samples))
                    drawn = gdi32.StretchDIBits(hdc, x, y, draw_w, draw_h, 0, 0, width, height,
                                                buffer, ctypes.byref(header), DIB_RGB_COLORS, SRCCOPY)
                    if drawn <= 0:
                        raise OSError('the page could not be drawn')
                    gdi32.EndPage(hdc)
                if gdi32.EndDoc(hdc) <= 0:
                    return {'ok': False, 'error': 'The print job could not be completed.'}
            except Exception as exc:
                gdi32.EndDoc(hdc)
                return {'ok': False, 'error': f'The document could not be printed: {exc}.'}
        finally:
            gdi32.DeleteDC(hdc)
    except Exception as exc:
        return {'ok': False, 'error': f'Printing failed: {exc}.'}
    return {'ok': True, 'printer': printer, 'pages': len(sheets), 'copies': copies,
            'collated': collate}


# ------------------------------------------------------------- macOS / Linux

def _print_cups(data: bytes, name: str, printer: str | None = None,
                pages: list[int] | None = None, copies: int = 1,
                collate: bool = True) -> dict:
    command = ['lpr'] if IS_MAC else ['lp']
    if printer:
        command += ['-P', printer]
    if copies > 1:
        command += (['-#', str(copies)] if IS_MAC else ['-n', str(copies)])
        # CUPS collates by default; say so either way rather than relying on it.
        command += ['-o', 'Collate=' + ('True' if collate else 'False')]
    if pages is not None:
        data = _subset(data, pages)
    if name:
        command += ['-t', name]
    try:
        finished = subprocess.run(command, input=data, capture_output=True, timeout=120)
    except FileNotFoundError:
        return {'ok': False, 'error': f'The print command ({command[0]}) is not installed.'}
    except Exception as exc:
        return {'ok': False, 'error': f'Printing failed: {exc}.'}
    if finished.returncode != 0:
        detail = (finished.stderr or b'').decode('utf-8', 'replace').strip()
        return {'ok': False, 'error': detail or 'The print command failed.'}
    return {'ok': True, 'printer': printer or 'default', 'pages': None}


# ------------------------------------------------------------------ interface

def page_count(data: bytes) -> int:
    import pymupdf as fitz
    with fitz.open(stream=data, filetype='pdf') as doc:
        return len(doc)


def page_list(pages, count: int) -> list[int]:
    """The page indices to print, from whatever the interface sent.

    `None` means every page. A list is checked page by page, because printing
    the wrong pages is not something the person can undo — the paper is already
    out of the printer.
    """
    if pages is None:
        return list(range(count))
    if not isinstance(pages, list) or not pages:
        raise ValueError('Choose at least one page to print.')
    chosen: list[int] = []
    for index in pages:
        if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < count:
            raise ValueError('A page in that range is not in this document.')
        if index not in chosen:
            chosen.append(index)
    return chosen


def sheet_order(pages: list[int], copies: int, collate: bool = True) -> list[int]:
    """Which pages, in which order, for the requested number of copies.

    Collated is 1, 2, 3 then 1, 2, 3 — each copy is a complete set. Uncollated
    is 1, 1, 1 then 2, 2, 2 — a stack of each page, which is what you want when
    the copies are going to be split up and handed out page by page. The
    difference only exists when there is more than one copy.
    """
    if copies <= 1:
        return list(pages)
    if collate:
        return list(pages) * copies
    return [page for page in pages for _ in range(copies)]


def _subset(data: bytes, pages: list[int]) -> bytes:
    """A PDF containing only those pages, in that order."""
    import pymupdf as fitz
    with fitz.open(stream=data, filetype='pdf') as source:
        if len(pages) == len(source):
            return data
        out = fitz.open()
        try:
            for index in pages:
                out.insert_pdf(source, from_page=index, to_page=index)
            return out.tobytes(garbage=4, deflate=True)
        finally:
            out.close()


def print_pdf(data: bytes, name: str = 'KADOMA PDF document', printer: str | None = None,
              output: str | None = None, pages: list[int] | None = None,
              copies: int = 1, collate: bool = True) -> dict:
    """Send a PDF straight to a printer. Nothing is shown and nothing is asked.

    `pages` selects the sheets (0-based) and `copies` repeats them. A copy count
    is drawn as repeated pages inside one job rather than set on the driver, so
    the order on paper is the order on screen — collated (1, 2, 3 / 1, 2, 3) or
    uncollated (1, 1, 1 / 2, 2, 2), as asked.
    """
    if not data:
        return {'ok': False, 'error': 'There is nothing to print.'}
    if not isinstance(copies, int) or isinstance(copies, bool) or not 1 <= copies <= 99:
        return {'ok': False, 'error': 'Choose between 1 and 99 copies.'}
    try:
        count = page_count(data)
    except Exception:
        # Not a readable PDF. Leave the page list alone and let the print path
        # report the real problem — refusing here would hide it behind a page
        # error, and the file-only-printer guard below still has to run.
        count = None
    if count is not None:
        try:
            chosen = page_list(pages, count)
        except ValueError as exc:
            return {'ok': False, 'error': str(exc)}
    else:
        chosen = pages
    if IS_WINDOWS:
        target = printer or default_printer()
        # Without this guard the request would hang on a Save dialog that the
        # user cannot even see, because it belongs to another process.
        if target and not output and saves_to_a_file(target):
            return {'ok': False, 'printer': target, 'savesToFile': True,
                    'error': f'"{target}" saves to a file instead of printing, so it would ask '
                             f'you for a filename and wait. Set a real printer as your default '
                             f'printer, or use Export to save a PDF.'}
        return _print_windows(data, name, target, output, chosen, copies, collate)
    if IS_MAC or IS_LINUX:
        if output:
            # Only the Windows driver supports redirecting a job to a file.
            return {'ok': False, 'error': 'Printing to a file is only supported on Windows.'}
        return _print_cups(data, name, printer, chosen, copies, collate)
    return {'ok': False, 'error': 'Printing is not supported on this platform.'}


# ------------------------------------------------------------------- preview
# A preview is only worth showing if it is the sheet the printer will produce,
# so it is built from the printer's own paper size and printable area rather
# than from the page alone. Where there is no printer to ask — or the platform
# is not Windows — the page is shown on its own proportions and the interface
# says the margins are an estimate.

LOGPIXELSX, LOGPIXELSY = 88, 90


def paper(printer: str | None = None) -> dict:
    """The sheet this printer will use, in points, and where it can put ink.

    `available` is false when there is no printer to ask. That is not an error:
    the preview falls back to the page's own size, and the interface says so
    rather than inventing margins.
    """
    printer = printer or (default_printer() if IS_WINDOWS else None)
    blank = {'available': False, 'printer': printer}
    if not IS_WINDOWS or not printer:
        return blank
    hdc = None
    try:
        gdi32 = ctypes.WinDLL('gdi32', use_last_error=True)
        gdi32.CreateDCW.argtypes = [wintypes.LPCWSTR] * 3 + [ctypes.c_void_p]
        gdi32.CreateDCW.restype = ctypes.c_void_p
        gdi32.GetDeviceCaps.argtypes = [ctypes.c_void_p, ctypes.c_int]
        gdi32.GetDeviceCaps.restype = ctypes.c_int
        gdi32.DeleteDC.argtypes = [ctypes.c_void_p]
        # A DEVMODE chosen in the driver's own preferences dialog is honoured
        # here; without one the driver's current defaults are used.
        devmode = _DEVMODES.get(printer)
        hdc = gdi32.CreateDCW('WINSPOOL', printer, None,
                              ctypes.cast(devmode, ctypes.c_void_p) if devmode else None)
        if not hdc:
            return blank
        dpi_x = gdi32.GetDeviceCaps(hdc, LOGPIXELSX) or 96
        dpi_y = gdi32.GetDeviceCaps(hdc, LOGPIXELSY) or 96
        width = gdi32.GetDeviceCaps(hdc, PHYSICALWIDTH)
        height = gdi32.GetDeviceCaps(hdc, PHYSICALHEIGHT)
        printable_w = gdi32.GetDeviceCaps(hdc, HORZRES)
        printable_h = gdi32.GetDeviceCaps(hdc, VERTRES)
        left = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETX)
        top = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETY)
        if min(width, height, printable_w, printable_h) <= 0:
            return blank
        return {'available': True, 'printer': printer,
                'width': width * 72 / dpi_x, 'height': height * 72 / dpi_y,
                'printable': {'x': left * 72 / dpi_x, 'y': top * 72 / dpi_y,
                              'width': printable_w * 72 / dpi_x,
                              'height': printable_h * 72 / dpi_y}}
    except Exception:
        return blank
    finally:
        if hdc:
            try:
                ctypes.WinDLL('gdi32', use_last_error=True).DeleteDC(hdc)
            except Exception:
                pass


def preview_png(data: bytes, page_index: int = 0, printer: str | None = None,
                dpi: int = 96) -> bytes:
    """One page, drawn on a sheet of the printer's paper, as a PNG.

    The page is rasterised exactly as printing rasterises it — same colours,
    same annotations — and placed inside the printable area at the same scale
    the print path uses. What the preview shows is what the printer is handed,
    including the margins it cannot reach.
    """
    import pymupdf as fitz
    sheet = paper(printer)
    with fitz.open(stream=data, filetype='pdf') as source:
        if not 0 <= page_index < len(source):
            raise ValueError('That page is not in this document.')
        page = source[page_index]
        out = fitz.open()
        try:
            if sheet['available']:
                target = out.new_page(width=sheet['width'], height=sheet['height'])
                area = fitz.Rect(sheet['printable']['x'], sheet['printable']['y'],
                                 sheet['printable']['x'] + sheet['printable']['width'],
                                 sheet['printable']['y'] + sheet['printable']['height'])
                area = area & target.rect
                if area.is_empty:
                    area = target.rect
            else:
                target = out.new_page(width=page.rect.width, height=page.rect.height)
                area = target.rect
            pixmap = page.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), colorspace=fitz.csRGB,
                                     alpha=False, annots=True)
            # Fit the whole page inside the printable area and centre it, which
            # is what the printer driver is asked to do with the bitmap.
            ratio = min(area.width / page.rect.width, area.height / page.rect.height)
            draw_w, draw_h = page.rect.width * ratio, page.rect.height * ratio
            box = fitz.Rect(area.x0 + (area.width - draw_w) / 2,
                            area.y0 + (area.height - draw_h) / 2,
                            area.x0 + (area.width + draw_w) / 2,
                            area.y0 + (area.height + draw_h) / 2)
            target.insert_image(box, pixmap=pixmap)
            return target.get_pixmap(dpi=dpi, alpha=False).tobytes('png')
        finally:
            out.close()


def methods() -> dict:
    """What printing can do on this machine, so the interface can be honest."""
    printer = default_printer() if IS_WINDOWS else None
    to_file = bool(printer) and saves_to_a_file(printer)
    available = printers()
    return {
        'print': supported() and not to_file,
        'printer': printer,
        'printers': available,
        'canPrint': any(item['printable'] for item in available) if available else supported(),
        'savesToFile': to_file,
        'via': 'gdi' if IS_WINDOWS else ('lpr' if IS_MAC else 'lp'),
        'dpi': PRINT_DPI,
        'note': 'Pages are rendered at print resolution and sent directly to the printer. '
                'No other PDF application is involved.',
    }
