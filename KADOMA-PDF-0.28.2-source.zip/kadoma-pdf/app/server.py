"""Local-only HTTP transport shared by the desktop shell and development preview."""
from __future__ import annotations

import hmac
import json
import logging
import threading
from pathlib import Path
from urllib.parse import quote, urlsplit

from fastapi import Body, FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from . import ai, printing, share, shell_integration
from .engine import (Engine, MAX_SPLIT_FILES, MAX_UPLOAD, PDFError,
                     capabilities, safe_name)

BASE = Path(__file__).resolve().parent
engine = Engine()
app = FastAPI(title='KADOMA PDF local engine', docs_url=None, redoc_url=None, openapi_url=None)
app.state.token = None  # Set to a random capability token by desktop.py.
app.state.desktop = False
app.state.capabilities = capabilities()
# Set by the desktop shell to step out of the way of a window the person has to
# use (mail compose, a printer driver dialog, Explorer, Windows Settings).
# None in a browser preview, where there is no native window to move.
app.state.release_front = None
# Files handed to the app by the operating system (a double-clicked PDF). The
# desktop shell fills this in; the interface drains it.
app.state.pending_open = []
app.state.pending_lock = threading.Lock()
# A model connection, if somebody makes one. Held here for the session and never
# written to disk; nothing is sent anywhere until it is configured.
app.state.ai = ai.ModelConfig()


@app.middleware('http')
async def local_security(request: Request, call_next):
    if request.url.path.startswith('/api/'):
        origin = request.headers.get('origin')
        host = request.headers.get('host', '')
        if origin and urlsplit(origin).netloc.lower() != host.lower():
            return JSONResponse({'detail': 'Cross-origin access is not allowed.', 'code': 'origin_denied'}, status_code=403)
        if app.state.desktop and request.client and request.client.host not in ('127.0.0.1', '::1'):
            return JSONResponse({'detail': 'The desktop engine only accepts local connections.'}, status_code=403)
        if app.state.token:
            provided = request.headers.get('authorization', '')
            if not hmac.compare_digest(provided, 'Bearer ' + app.state.token):
                return JSONResponse({'detail': 'This request is not authorized.', 'code': 'unauthorized'}, status_code=401)
        try:
            content_length = int(request.headers.get('content-length', '0'))
        except ValueError:
            return JSONResponse({'detail': 'Invalid request length.'}, status_code=400)
        if content_length > MAX_UPLOAD + 2 * 1024 * 1024:
            limit = MAX_UPLOAD // (1024 * 1024)
            return JSONResponse({'detail': f'Requests are limited to {limit} MB.', 'code': 'file_too_large'}, status_code=413)
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    # pywebview builds its trusted native API functions with new Function.
    # Allow that only in the authenticated loopback desktop shell. Browser
    # previews keep strict script policy and cannot run injected/evaluated JS.
    script_policy = "'self' 'unsafe-eval'" if app.state.desktop else "'self'"
    response.headers['Content-Security-Policy'] = f"default-src 'self'; script-src {script_policy}; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'"
    if request.url.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store'
    return response


@app.exception_handler(PDFError)
async def pdf_error(request: Request, exc: PDFError):
    return JSONResponse({'detail': exc.message, 'code': exc.code}, status_code=exc.status)


@app.exception_handler(ai.AIError)
async def ai_error(request: Request, exc: ai.AIError):
    return JSONResponse({'detail': exc.message, 'code': exc.code}, status_code=exc.status)


@app.exception_handler(Exception)
async def internal_error(request: Request, exc: Exception):
    # Do not put document contents or passwords into logs or error responses.
    logging.getLogger('kadoma').error('Local engine error (%s)', type(exc).__name__)
    return JSONResponse({'detail': 'The PDF engine could not complete this action. The previous document has been kept unchanged.',
                         'code': 'engine_error'}, status_code=500)


async def read_upload(file: UploadFile) -> tuple[bytes, str]:
    parts, total = [], 0
    try:
        while chunk := await file.read(1024 * 1024):
            total += len(chunk)
            if total > MAX_UPLOAD:
                raise PDFError(f'Files are limited to {MAX_UPLOAD // (1024 * 1024)} MB.', 413, 'file_too_large')
            parts.append(chunk)
        return b''.join(parts), safe_name(file.filename or 'Untitled.pdf')
    finally:
        await file.close()


@app.get('/')
def index():
    return FileResponse(BASE / 'static' / 'index.html')


@app.get('/api/health')
def health():
    # `desktop` is resolved per request: capabilities() is computed at import
    # time, before the desktop shell has had a chance to mark itself.
    return {**app.state.capabilities, 'desktop': bool(app.state.desktop),
            'printSupported': printing.supported(),
            'dateFields': True,
            # Combining files: how many at once, and whether part of a source
            # document can be selected rather than all of it.
            'combine': True, 'mergeRanges': True,
            # Splitting the open document: the ways the cuts can be decided, and
            # how many files one split may produce.
            'split': True, 'splitModes': ['chunks', 'parts', 'ranges'],
            'maxSplitFiles': MAX_SPLIT_FILES}


@app.post('/api/documents/create')
def create(options: dict = Body(default={})):
    return engine.blank(safe_name(options.get('name', 'Untitled.pdf')))


@app.post('/api/documents/{ident}/compare')
def compare_with_open(ident: str, payload: dict = Body(default={})):
    """Compare the open document with another one that is already open."""
    return engine.compare_documents(ident, payload.get('document'), payload)


@app.post('/api/documents/{ident}/compare-file')
async def compare_with_file(ident: str, file: UploadFile = File(...), password: str = Form(default='')):
    """Compare against a file that is not open.

    The uploaded document is loaded, compared and closed again in the same
    request: a comparison should not leave a tab behind, and it must not change
    which document the person is working on.
    """
    data, name = await read_upload(file)
    info = await run_in_threadpool(engine.load, data, name, password)
    try:
        return await run_in_threadpool(engine.compare_documents, ident, info['id'])
    finally:
        engine.close(info['id'])


@app.post('/api/documents/upload')
async def upload(file: UploadFile = File(...), password: str = Form(default='')):
    data, name = await read_upload(file)
    return await run_in_threadpool(engine.load, data, name, password)


def _json_list(raw: str, label: str) -> list:
    try:
        value = json.loads(raw)
    except (ValueError, TypeError) as exc:
        raise PDFError(f'Invalid {label}.') from exc
    if not isinstance(value, list):
        raise PDFError(f'Invalid {label}.')
    return value


async def _merge_payload(files: list[UploadFile], passwords: str, ranges: str,
                         sources_raw: list | None = None):
    """Validate a combine request and read every upload into memory.

    Shared by merging into a document and building a new one, so both reject
    the same oversized or malformed requests in the same way. When an ordered
    source list is supplied the uploads may legitimately be empty, because every
    source can be a document already open in the workspace.
    """
    if sources_raw is None and not files:
        raise PDFError('Choose one or more files to combine.')
    uploads = [await read_upload(file) for file in files]
    keys = _json_list(passwords, 'password list')
    if any(not isinstance(key, str) for key in keys):
        raise PDFError('Invalid password list.')
    specs = _json_list(ranges, 'page selection')
    if any(not isinstance(spec, (str, list)) for spec in specs):
        raise PDFError('Invalid page selection.')
    if sources_raw is not None:
        return _resolve_sources(uploads, sources_raw, keys, specs)
    return uploads, keys, specs


def _source_list(raw: str | None) -> list | None:
    """Parse the ordered source list the merge window sends, if it sent one."""
    if raw is None:
        return None
    try:
        value = json.loads(raw)
    except (ValueError, TypeError) as exc:
        raise PDFError('Invalid source list.') from exc
    if not isinstance(value, list):
        raise PDFError('Invalid source list.')
    return value


def _resolve_sources(uploads: list[tuple[bytes, str]], entries: list, keys: list, specs: list):
    """Put the sources in the order the window listed them.

    A source is either one of the uploaded files or a document already open in
    the workspace. The open ones are turned into the same ``(bytes, name)``
    shape an upload has, which keeps the merge itself on one code path with one
    set of permission checks and one password rule for both kinds.
    """
    files, passwords, ranges = [], [], []
    for position, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise PDFError('Invalid source list.')
        key = keys[position] if position < len(keys) else ''
        spec = specs[position] if position < len(specs) else ''
        if entry.get('kind') == 'document':
            ident = entry.get('id')
            if not isinstance(ident, str) or not ident:
                raise PDFError('Invalid source list.')
            try:
                data, name, stored = engine.source_of(ident)
            except PDFError as exc:
                raise PDFError(f'A document in the list is no longer open: {exc.message}',
                               409, 'document_not_found') from exc
            files.append((data, name))
            passwords.append(stored)
        elif entry.get('kind') == 'file':
            index = entry.get('index')
            if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(uploads):
                raise PDFError('Invalid source list.')
            files.append(uploads[index])
            passwords.append(key)
        else:
            raise PDFError('Invalid source list.')
        ranges.append(spec)
    if not files:
        raise PDFError('Choose one or more files to combine.')
    return files, passwords, ranges


@app.post('/api/documents/inspect')
async def inspect(files: list[UploadFile] = File(...), passwords: str = Form(default='[]')):
    """Describe the chosen files so the merge list can show what they contain."""
    uploads = [await read_upload(file) for file in files]
    keys = _json_list(passwords, 'password list')
    if any(not isinstance(key, str) for key in keys):
        raise PDFError('Invalid password list.')
    return {'files': await run_in_threadpool(engine.inspect_files, uploads, keys)}


@app.post('/api/documents/combine')
async def combine(files: list[UploadFile] = File(default=[]), passwords: str = Form(default='[]'),
                  ranges: str = Form(default='[]'), name: str = Form(default='Combined.pdf'),
                  sources: str | None = Form(default=None)):
    """Build a new document out of several files or open documents."""
    uploads, keys, specs = await _merge_payload(files, passwords, ranges, _source_list(sources))
    return await run_in_threadpool(engine.combine, uploads, keys, safe_name(name), specs)


@app.get('/api/documents')
def open_documents():
    """Every document open in the workspace.

    The merge window lists these so a document that is already open can be
    combined without being found on disk and uploaded again.
    """
    return {'documents': engine.open_documents()}


@app.get('/api/documents/{ident}')
def metadata(ident: str):
    return engine.meta(ident)


@app.delete('/api/documents/{ident}')
def close(ident: str):
    engine.close(ident)
    return {'closed': True}


@app.get('/api/documents/{ident}/pages/{page}/render')
def render(ident: str, page: int, scale: float = 1.35, revision: int = 0):
    return Response(engine.render(ident, page, scale), media_type='image/png')


@app.get('/api/documents/{ident}/pages/{page}/content')
def content(ident: str, page: int):
    return engine.content(ident, page)


@app.get('/api/documents/{ident}/search')
def search(ident: str, q: str = ''):
    return {'matches': engine.search(ident, q)}


@app.post('/api/documents/{ident}/prepare-form/scan')
def prepare_form_scan(ident: str):
    """What the document offers as a place to fill in, before anything changes."""
    return engine.scan_form(ident)


@app.post('/api/documents/{ident}/operation')
def operation(ident: str, payload: dict = Body(...)):
    return engine.operation(ident, payload)


@app.post('/api/documents/{ident}/image')
async def insert_image(ident: str, file: UploadFile = File(...), page: int = Form(...),
                       rect: str = Form(default='null'), xref: int | None = Form(default=None)):
    data, _ = await read_upload(file)
    try:
        selected_rect = json.loads(rect)
    except (ValueError, TypeError) as exc:
        raise PDFError('Select a valid image area.') from exc
    return await run_in_threadpool(engine.insert_image, ident, page, data, selected_rect, xref)


@app.post('/api/documents/{ident}/merge')
async def merge(ident: str, files: list[UploadFile] = File(default=[]), passwords: str = Form(default='[]'),
                ranges: str = Form(default='[]'), position: str = Form(default='null'),
                sources: str | None = Form(default=None)):
    uploads, keys, specs = await _merge_payload(files, passwords, ranges, _source_list(sources))
    try:
        start = json.loads(position)
    except (ValueError, TypeError) as exc:
        raise PDFError('Invalid insert position.') from exc
    if start is not None and (isinstance(start, bool) or not isinstance(start, int) or start < 0):
        raise PDFError('Invalid insert position.')
    return await run_in_threadpool(engine.merge, ident, uploads, keys, start, specs)


@app.post('/api/documents/{ident}/split/plan')
def split_plan(ident: str, payload: dict = Body(default={})):
    """Describe the files a split would produce, so the window can show them.

    The interface asks this as the settings change rather than working the
    counts out itself, which keeps the preview and the result identical.
    """
    return engine.split_plan(ident, payload if isinstance(payload, dict) else {})


@app.post('/api/documents/{ident}/split')
def split_document(ident: str, payload: dict = Body(default={})):
    """Write the open document out as several files, or one for a single part."""
    data, name, mime = engine.split(ident, payload if isinstance(payload, dict) else {})
    ascii_name = name.encode('ascii', errors='replace').decode('ascii').replace('"', '_')
    disposition = f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{quote(name)}'
    return Response(data, media_type=mime, headers={'Content-Disposition': disposition})


@app.post('/api/documents/{ident}/ocr')
def ocr(ident: str, payload: dict = Body(default={})):
    return engine.ocr(ident, payload.get('pages'), payload.get('language', 'eng'))


def require_desktop():
    """Refuse anything that reaches outside the browser sandbox.

    Sharing touches the clipboard, the file manager and the mail client, and
    opening a path reads the user's disk. None of that belongs in a browser
    preview, so these routes exist only in the authenticated desktop shell.
    """
    if not app.state.desktop:
        raise PDFError('This action is only available in the desktop application.',
                       403, 'desktop_only')


def yield_front():
    """Let an external window come to the front before we ask for it.

    KADOMA is topmost so a page stays readable, but a topmost window sits above
    a compose window or a printer driver dialog too. Called immediately before
    handing off to something the person must type into. A failure here must
    never stop the actual action — a window that cannot be moved is an
    inconvenience, not a reason to refuse to open the mail client.
    """
    callback = getattr(app.state, 'release_front', None)
    if callable(callback):
        try:
            return callback()
        except Exception:  # noqa: BLE001 - best effort, never the main action
            return False
    return False


@app.get('/api/share/methods')
def share_methods():
    return {'desktop': bool(app.state.desktop), 'methods': share.methods()}


@app.post('/api/share/prepare')
def share_prepare(payload: dict = Body(default={})):
    require_desktop()
    ident = payload.get('document')
    if not ident:
        raise PDFError('Open a document first.', 409, 'no_document')
    options = payload.get('options') if isinstance(payload.get('options'), dict) else {}
    data, name, _mime = engine.export(ident, 'pdf', options)
    return share.prepare(data, name)


@app.post('/api/share/reveal')
def share_reveal(payload: dict = Body(default={})):
    require_desktop()
    yield_front()  # Explorer is the window the person wants to look at.
    return share.reveal(payload.get('path'))


@app.post('/api/share/clipboard')
def share_clipboard(payload: dict = Body(default={})):
    require_desktop()
    return share.copy_file(payload.get('path'))


@app.post('/api/share/email')
def share_email(payload: dict = Body(default={})):
    require_desktop()
    path = payload.get('path')
    to = payload.get('to') if isinstance(payload.get('to'), str) else ''
    subject = payload.get('subject') if isinstance(payload.get('subject'), str) else ''
    body = payload.get('body') if isinstance(payload.get('body'), str) else ''
    if len(to) > 320 or len(subject) > 300 or len(body) > 4000:
        raise PDFError('That email is too long.', 422, 'email_too_long')
    # The compose window belongs to the mail client, can take seconds to appear,
    # and stays open while an address is typed. It must be able to come forward.
    yield_front()
    if payload.get('attach'):
        return share.mail_with_attachment(path, to, subject, body)
    return share.mail_draft(path, to, subject, body)


@app.get('/api/system/print')
def print_status():
    """What printing can do here, so the interface can say so before you press it."""
    methods = printing.methods()
    return {'desktop': bool(app.state.desktop), 'methods': methods,
            'printer': methods.get('printer') if app.state.desktop else None}


@app.post('/api/system/print')
def print_document(payload: dict = Body(default={})):
    """Send the document straight to a printer.

    The pages are rendered and printed here rather than handed to another
    application, so this still works when KADOMA itself owns the `.pdf`
    association — and it can never start a second copy of KADOMA.
    """
    require_desktop()
    ident = payload.get('document')
    if not ident:
        raise PDFError('Open a document first.', 409, 'no_document')
    options = payload.get('options') if isinstance(payload.get('options'), dict) else {}
    printer = payload.get('printer') if isinstance(payload.get('printer'), str) else None
    pages = payload.get('pages')
    copies = payload.get('copies', 1)
    collate = payload.get('collate', True)
    if pages is not None and not isinstance(pages, list):
        raise PDFError('Choose the pages to print.', 422, 'invalid_pages')
    if not isinstance(collate, bool):
        raise PDFError('Choose collated or uncollated copies.', 422, 'invalid_collate')
    data, name, _mime = engine.export(ident, 'pdf', options)
    result = printing.print_pdf(data, name, printer, pages=pages, copies=copies, collate=collate)
    if not result.get('ok'):
        raise PDFError(result.get('error') or 'The document could not be printed.',
                       409, 'print_failed')
    return result


@app.post('/api/system/print/preferences')
def print_preferences(payload: dict = Body(default={})):
    """Open the printer driver's own settings dialog.

    Paper size, orientation, duplex and quality are the driver's business, so
    the dialog is the driver's too — the choice is kept for the rest of the
    session and handed to the next job. This blocks until the dialog is closed,
    which is why it is a separate request from printing.
    """
    require_desktop()
    printer = payload.get('printer') if isinstance(payload.get('printer'), str) else None
    # The driver's dialog is a separate top-level window; it has to be visible.
    yield_front()
    result = printing.printer_preferences(printer)
    if not result.get('ok'):
        raise PDFError(result.get('error') or 'The printer settings could not be opened.',
                       409, 'print_preferences_failed')
    return result


@app.get('/api/system/print/papers')
def print_papers(printer: str | None = None):
    """The paper sizes this printer accepts, and what it is set to now.

    Asked of the driver rather than offered from a fixed list: a printer that
    has never heard of A3 should not be offered it, and a driver that supports
    forty sizes knows their names better than this application does.
    """
    require_desktop()
    return {'printer': printer, 'papers': printing.papers(printer),
            'settings': printing.preferences_summary(printer),
            'duplex': printing.duplex_options(printer),
            'sheet': printing.paper(printer)}


@app.post('/api/system/print/settings')
def print_settings(payload: dict = Body(default={})):
    """Paper size and orientation, applied to the driver's own settings block.

    These are the two the preview cannot show honestly without: the sheet it
    draws is the printer's paper, so changing the paper has to change the
    sheet. Everything else — duplex, quality, trays — stays in the driver's
    dialog, where the driver can describe its own options.
    """
    require_desktop()
    printer = payload.get('printer') if isinstance(payload.get('printer'), str) else None
    duplex = payload.get('duplex') if isinstance(payload.get('duplex'), str) else None
    result = printing.apply_settings(printer, payload.get('paper'), payload.get('orientation'), duplex)
    if not result.get('ok'):
        raise PDFError(result.get('error') or 'Those printer settings were refused.',
                       409, 'print_settings_failed')
    return {**result, 'sheet': printing.paper(result.get('printer') or printer)}


@app.get('/api/system/print/preview')
def print_preview(document: str = '', page: int = 0, printer: str | None = None):
    """One page, drawn on a sheet of the printer's paper, as a PNG.

    Built from the same bytes and the same raster the print path uses, so the
    preview cannot disagree with the paper. The paper size and margins come
    from the printer itself, which is why the printer is part of the request.
    """
    require_desktop()
    if not document:
        raise PDFError('Open a document first.', 409, 'no_document')
    data, _name, _mime = engine.export(document, 'pdf')
    try:
        image = printing.preview_png(data, page, printer)
    except ValueError as exc:
        raise PDFError(str(exc), 404, 'page_not_found') from exc
    return Response(image, media_type='image/png', headers={'Cache-Control': 'no-store'})


@app.get('/api/system/default-app')
def default_app_status():
    return {'desktop': bool(app.state.desktop), **shell_integration.status()}


@app.get('/api/system/pending-open')
def pending_open():
    """Drain the queue of work the operating system asked us to do.

    Two kinds arrive here: a file to open, and a set of files to combine (the
    right-click entry). Returning and clearing in one call means nothing is ever
    done twice.
    """
    if not app.state.desktop:
        return {'items': []}
    with app.state.pending_lock:
        items, app.state.pending_open = list(app.state.pending_open), []
    return {'items': items}


@app.post('/api/system/combine-paths')
def combine_paths(payload: dict = Body(default={})):
    """Combine files by path, for the Explorer menu entry.

    Desktop only: a browser has no business reading arbitrary paths, and the
    loopback token is what stops anything else from asking. The files are read,
    checked for a PDF header, and handed to the same engine call the merge
    window uses — so a combination from Explorer and one from the window cannot
    behave differently.
    """
    require_desktop()
    paths = payload.get('paths')
    documents = shell_integration.read_documents(paths)
    # Named after the folder they came from, which is usually what they are:
    # a month of invoices, a set of scans, one job.
    folder = Path(paths[0]).resolve().parent.name if isinstance(paths, list) and paths else ''
    name = safe_name(f'{folder}.pdf') if folder else 'Combined.pdf'
    return engine.combine(documents, ['' for _ in documents], name, [])


@app.post('/api/system/default-app')
def default_app_action(payload: dict = Body(default={})):
    require_desktop()
    action = payload.get('action')
    if action == 'register':
        result = shell_integration.register()
        if result.get('ok'):
            # Registration alone cannot make it the default; the user confirms.
            yield_front()  # Windows Settings is where the confirmation happens.
            result['settings'] = shell_integration.open_settings()
        return result
    if action == 'unregister':
        return shell_integration.unregister()
    if action == 'settings':
        yield_front()
        return shell_integration.open_settings()
    raise PDFError('Choose a valid action.')


# ------------------------------------------------------------------ reading it
# Two ways to read a document: the offline analysis in app/ai.py, which never
# leaves this computer, and an optional model that somebody connected themselves.
# The interface must always say which one produced what it is showing.

def _document_text(ident: str, pages=None) -> str:
    """The document's text, through the same export path the Convert view uses.

    Reading the text is a copy, so the engine's own permission check applies and
    a document that forbids copying is refused here rather than quietly read.
    """
    data, _name, _mime = engine.export(ident, 'txt', {'pages': pages})
    return data.decode('utf-8', 'replace')


@app.get('/api/ai/status')
def ai_status():
    """What the AI panel may show. The key itself is never included."""
    return {'offline': True, 'modes': ['offline', 'model'], 'maxFields': ai.MAX_FIELDS,
            'maxSentences': 12, 'model': app.state.ai.public()}


@app.post('/api/ai/configure')
def ai_configure(payload: dict = Body(default={})):
    """Connect a model, or disconnect the one that is connected.

    The key is kept in memory for the session only. Nothing is written to disk,
    which is the same rule every other preference in this application follows.
    """
    mode = payload.get('mode', 'off')
    if mode == 'off':
        app.state.ai = ai.ModelConfig()
        return ai_status()
    if mode != 'model':
        raise PDFError('Choose whether to use a connected model or stay offline.')
    endpoint = payload.get('endpoint') if isinstance(payload.get('endpoint'), str) else ''
    model = payload.get('model') if isinstance(payload.get('model'), str) else ''
    # A key that is not sent at all keeps the one already held, so the interface
    # never has to ask for a key it has already been given.
    raw_key = payload.get('apiKey')
    key = raw_key.strip() if isinstance(raw_key, str) else app.state.ai.api_key
    if max(len(endpoint), len(model), len(key)) > 400:
        raise PDFError('That connection detail is too long.')
    # Checked here rather than at the first summary, so a mistyped address is
    # reported while the person is still looking at the field they typed it in.
    ai.chat_url(endpoint)
    if not model.strip():
        raise PDFError('Enter the model name the endpoint expects, such as gpt-4o-mini.')
    app.state.ai = ai.ModelConfig(endpoint=endpoint.strip(), model=model.strip(), api_key=key.strip())
    return ai_status()


@app.post('/api/documents/{ident}/ai/summary')
def ai_summary(ident: str, payload: dict = Body(default={})):
    """Summarise the document: offline by extraction, or through the model."""
    mode = payload.get('mode', 'offline')
    if mode not in ('offline', 'model'):
        raise PDFError('Choose the offline summary or the connected model.')
    try:
        limit = max(1, min(int(payload.get('sentences', 5)), 12))
    except (TypeError, ValueError) as exc:
        raise PDFError('Choose how many sentences the summary should have.') from exc
    text = _document_text(ident, payload.get('pages'))
    if mode == 'offline':
        result = ai.summarize(text, limit)
        return {'mode': 'offline', 'model': None, 'summary': result['summary'],
                'keywords': result['keywords'], 'sentences': result['sentences'],
                'selected': result['selected'], 'sentenceCount': result['sentenceCount'],
                'wordCount': result['wordCount']}
    config = app.state.ai
    summary = ai.model_summary(config, text, limit)
    return {'mode': 'model', 'model': config.model, 'summary': summary,
            'keywords': ai.keywords(text), 'sentences': [], 'selected': 0,
            'sentenceCount': len(ai.sentences(text)), 'wordCount': ai.word_count(text)}


@app.post('/api/documents/{ident}/ai/form')
def ai_form(ident: str, payload: dict = Body(default={})):
    """Propose form fields from a prompt. Nothing is added until it is applied."""
    prompt = payload.get('prompt') if isinstance(payload.get('prompt'), str) else ''
    if len(prompt) > 2000:
        raise PDFError('That prompt is too long. Keep it under 2,000 characters.')
    mode = payload.get('mode', 'offline')
    if mode not in ('offline', 'model'):
        raise PDFError('Choose the offline parser or the connected model.')
    if mode == 'offline':
        return {'mode': 'offline', 'model': None, 'fields': ai.parse_form_prompt(prompt)}
    config = app.state.ai
    return {'mode': 'model', 'model': config.model,
            'fields': ai.model_fields(config, prompt, _document_text(ident))}


@app.post('/api/documents/open-path')
def open_path(payload: dict = Body(default={})):
    """Open a file the operating system handed us — a double-clicked PDF."""
    require_desktop()
    raw = payload.get('path')
    if not isinstance(raw, str) or not raw.strip():
        raise PDFError('No file was given.')
    target = Path(raw)
    try:
        if not target.is_file():
            raise PDFError('That file could not be found.', 404, 'file_not_found')
        if target.stat().st_size > MAX_UPLOAD:
            raise PDFError(f'Files are limited to {MAX_UPLOAD // (1024 * 1024)} MB.', 413, 'file_too_large')
        data = target.read_bytes()
    except PermissionError as exc:
        raise PDFError('That file could not be read.') from exc
    except OSError as exc:
        raise PDFError('That file could not be read.') from exc
    password = payload.get('password') if isinstance(payload.get('password'), str) else ''
    return engine.load(data, safe_name(target.name), password, path=target)


@app.post('/api/documents/{ident}/save')
def save_document(ident: str):
    """Write the document over the file it was opened from.

    Only the desktop shell can do this: a browser has no way to write to an
    arbitrary path, and the preview must not pretend otherwise.
    """
    require_desktop()
    return engine.save(ident)


@app.post('/api/documents/{ident}/save-as')
def save_document_as(ident: str, payload: dict = Body(default={})):
    """Write a copy to the path the person chose, and follow it from then on.

    The path comes from a native Save dialog in the desktop shell. It is
    validated by the engine (absolute, a .pdf name, an existing folder) rather
    than trusted.
    """
    require_desktop()
    path = payload.get('path')
    if not isinstance(path, str) or not path.strip():
        raise PDFError('Choose where to save the file.', 422, 'invalid_path')
    return engine.save(ident, path)


@app.post('/api/documents/{ident}/export/{format}')
def export(ident: str, format: str, options: dict = Body(default={})):
    data, name, mime = engine.export(ident, format, options)
    ascii_name = name.encode('ascii', errors='replace').decode('ascii').replace('"', '_')
    disposition = f'attachment; filename="{ascii_name}"; filename*=UTF-8\'\'{quote(name)}'
    return Response(data, media_type=mime, headers={'Content-Disposition': disposition})


app.mount('/static', StaticFiles(directory=BASE / 'static'), name='static')
