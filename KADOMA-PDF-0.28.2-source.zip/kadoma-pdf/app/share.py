"""Sharing a finished PDF: reveal it, copy it, or start an email with it.

Everything here touches the *local operating system*, so every entry point is
refused unless the app is running as the authenticated desktop shell. A browser
preview has no business reaching into the user's clipboard or mail client.

An important limitation, stated plainly because it is easy to promise more than
is delivered: a `mailto:` link **cannot carry an attachment**. RFC 6068 defines
no attachment parameter, and no mail client honours one. So there are two real
ways to email a document from here:

* `mail_draft()` opens the user's own mail client with the subject and body
  filled in. The file is placed on the clipboard and revealed in its folder, so
  attaching it is one paste or one drag.
* `mail_with_attachment()` opens a **compose window** in the user's own mail
  client with the PDF already attached and the recipient left empty, so the
  person sending it chooses who gets it.

The second one asks the mail client to compose the message rather than handing
it a finished `.eml`. A `.eml` opens in Outlook as a *received* message — a
read-only view with no recipient field — which is not a draft anybody can send.
Simple MAPI and the client's own command line both give a real compose window.

Neither sends anything by itself. Nothing leaves the machine unless the user
presses Send in their own client — this application has no mail credentials and
never asks for any.
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import tempfile
import webbrowser
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import quote

IS_WINDOWS = sys.platform == 'win32'
IS_MAC = sys.platform == 'darwin'
IS_LINUX = sys.platform.startswith('linux')

SHARE_DIR_NAME = 'KADOMA Share'


def share_dir() -> Path:
    """Stable folder for documents that have been prepared for sharing.

    Deliberately stable rather than random: if a user is asked to attach a file
    from their mail client, the path has to stay put long enough to find it.
    """
    target = Path(tempfile.gettempdir()) / SHARE_DIR_NAME
    target.mkdir(parents=True, exist_ok=True)
    return target


def _safe_stem(name: str) -> str:
    keep = [c for c in (name or 'document') if c.isalnum() or c in ' ._-']
    stem = ''.join(keep).strip().rstrip('.') or 'document'
    return stem[:120]


def prepare(data: bytes, name: str) -> dict:
    """Write an export into the share folder and describe it."""
    target = share_dir() / _safe_stem(name)
    if target.suffix.lower() != '.pdf':
        target = target.with_suffix('.pdf')
    target.write_bytes(data)
    return {'path': str(target), 'name': target.name, 'size': len(data),
            # What the draft says before anybody edits it. The dialog shows this
            # and sends it back, so there is one sentence, in one place.
            'defaultBody': DEFAULT_BODY}


def inside_share(path: str) -> Path | None:
    """Resolve `path`, but only if it is a file this module created.

    The path comes back from the interface, so it is treated as untrusted:
    without this check a crafted request could ask the desktop shell to reveal,
    copy or attach any file on the machine.
    """
    try:
        candidate = Path(path).resolve()
        root = share_dir().resolve()
    except (OSError, ValueError, TypeError):
        return None
    if candidate.parent != root or not candidate.is_file():
        return None
    return candidate


def reveal(path: str) -> dict:
    """Show the file in the system file manager, with the file selected."""
    target = inside_share(path)
    if not target:
        return {'ok': False, 'error': 'That file is not in the share folder.'}
    try:
        if IS_WINDOWS:
            # explorer returns a non-zero exit code even on success, so it is
            # deliberately not checked here.
            subprocess.Popen(['explorer', '/select,', str(target)])
        elif IS_MAC:
            subprocess.Popen(['open', '-R', str(target)])
        else:
            subprocess.Popen(['xdg-open', str(target.parent)])
        return {'ok': True}
    except Exception:
        return {'ok': False, 'error': 'The file manager could not be opened.'}


def copy_file(path: str) -> dict:
    """Put the file itself on the clipboard, as a pasteable file."""
    target = inside_share(path)
    if not target:
        return {'ok': False, 'error': 'That file is not in the share folder.'}
    if IS_WINDOWS:
        return _copy_file_windows(target)
    if IS_MAC:
        try:
            script = f'set the clipboard to (POSIX file "{target}")'
            subprocess.run(['osascript', '-e', script], check=True,
                           capture_output=True, timeout=15)
            return {'ok': True}
        except Exception:
            return {'ok': False, 'error': 'The clipboard could not be updated.'}
    return _copy_file_linux(target)


def _copy_file_windows(target: Path) -> dict:
    """CF_HDROP clipboard payload: the Windows "copy file" clipboard format.

    ctypes is used rather than a helper program so the build keeps no extra
    dependency. Every handle type is declared explicitly, because on 64-bit
    Python an undeclared return value is truncated to 32 bits and the handle
    silently becomes invalid.
    """
    try:
        import ctypes
        from ctypes import wintypes
    except ImportError:
        return {'ok': False, 'error': 'The clipboard is unavailable.'}

    GMEM_MOVEABLE, CF_HDROP = 0x0002, 15
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    user32 = ctypes.WinDLL('user32', use_last_error=True)

    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
    user32.OpenClipboard.argtypes = [ctypes.c_void_p]
    user32.EmptyClipboard.argtypes = []

    class DROPFILES(ctypes.Structure):
        _fields_ = [('pFiles', wintypes.DWORD), ('pt', wintypes.POINT),
                    ('fNC', wintypes.BOOL), ('fWide', wintypes.BOOL)]

    # A file list is double-null terminated and stored as UTF-16.
    payload = (str(target) + '\0\0').encode('utf-16-le')
    offset = ctypes.sizeof(DROPFILES)
    handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, offset + len(payload))
    if not handle:
        return {'ok': False, 'error': 'The clipboard could not be updated.'}
    pointer = kernel32.GlobalLock(handle)
    if not pointer:
        kernel32.GlobalFree(handle)
        return {'ok': False, 'error': 'The clipboard could not be updated.'}
    try:
        header = DROPFILES(pFiles=offset, fNC=False, fWide=True)
        ctypes.memmove(pointer, ctypes.byref(header), offset)
        ctypes.memmove(pointer + offset, payload, len(payload))
    finally:
        kernel32.GlobalUnlock(handle)

    if not user32.OpenClipboard(None):
        kernel32.GlobalFree(handle)
        return {'ok': False, 'error': 'Another program is holding the clipboard.'}
    try:
        user32.EmptyClipboard()
        if not user32.SetClipboardData(CF_HDROP, handle):
            kernel32.GlobalFree(handle)
            return {'ok': False, 'error': 'The clipboard could not be updated.'}
        # Ownership passed to the clipboard; freeing it here would corrupt the data.
    finally:
        user32.CloseClipboard()
    return {'ok': True}


def _copy_file_linux(target: Path) -> dict:
    """xclip/xsel can carry a file list as text/uri-list. Best effort only."""
    uri = target.as_uri()
    for command in (['xclip', '-selection', 'clipboard', '-t', 'text/uri-list'],
                    ['xsel', '--clipboard', '--input']):
        try:
            process = subprocess.Popen(command, stdin=subprocess.PIPE)
            process.communicate(uri.encode(), timeout=10)
            if process.returncode == 0:
                return {'ok': True}
        except Exception:
            continue
    return {'ok': False, 'error': 'Install xclip or xsel to copy files to the clipboard.'}


# What the draft says when nobody typed anything. One sentence, because a
# message with the file already attached needs no introduction — and it is
# the body the request asked for, word for word.
DEFAULT_BODY = "Please see the attached file"


def mailto_url(to: str = '', subject: str = '', body: str = '') -> str:
    query = []
    if subject:
        query.append('subject=' + quote(subject))
    if body:
        query.append('body=' + quote(body))
    # Note the absence of an attachment parameter: mailto has no such thing.
    return 'mailto:' + quote(to or '') + ('?' + '&'.join(query) if query else '')


def open_url(url: str) -> dict:
    try:
        if IS_WINDOWS:
            os.startfile(url)  # noqa: S606 - deliberate hand-off to the OS
        else:
            webbrowser.open(url)
        return {'ok': True}
    except Exception:
        return {'ok': False, 'error': 'No email program is configured for this action.'}


def mail_draft(path: str, to: str = '', subject: str = '', body: str = '') -> dict:
    """Open the user's mail client with a pre-filled draft.

    The file is also copied to the clipboard and revealed in its folder, so the
    attachment is one paste away — the honest workaround for mailto having no
    attachment support.
    """
    target = inside_share(path)
    if not target:
        return {'ok': False, 'error': 'That file is not in the share folder.'}
    if not subject:
        subject = f'PDF: {target.name}'
    if not body:
        body = DEFAULT_BODY
    result = open_url(mailto_url(to, subject, body))
    if not result.get('ok'):
        return result
    copied = copy_file(str(target))
    revealed = reveal(str(target))
    return {'ok': True, 'copied': bool(copied.get('ok')), 'revealed': bool(revealed.get('ok')),
            'attachmentSupported': False,
            'note': ('Your mail program cannot be given the file automatically, so it has been '
                     'copied to the clipboard and shown in its folder — paste or drag it in.')}


def eml_bytes(target: Path, to: str = '', subject: str = '', body: str = '') -> bytes:
    """Build a complete MIME message with the PDF attached.

    Separated from the sending step so the message can be built and inspected
    without a mail client being launched as a side effect.
    """
    message = EmailMessage()
    message['Subject'] = subject or f'PDF: {target.name}'
    if to:
        message['To'] = to
    message.set_content(body or DEFAULT_BODY)
    message.add_attachment(target.read_bytes(), maintype='application',
                           subtype='pdf', filename=target.name)
    return message.as_bytes()


# ------------------------------------------------------------- compose window
# The mail client is asked to *compose* a message with the file attached, and
# the recipient is left empty unless one was typed: the point is that the person
# sending it chooses who gets it.
#
# Simple MAPI would be the general way to do this, and it was tried first. It is
# not used because it cannot be trusted: on a machine whose default client is a
# Store app, MAPISendMail neither opens a window nor returns — it blocks. That is
# indistinguishable from a compose window somebody is slowly typing an address
# into, so the code cannot tell success from a hang, and a hang reported as
# success is worse than no feature. The clients' own command lines do return,
# and what they do is visible.

def _find_mail_program(*names: str) -> str | None:
    """Where a known mail client is installed, or None. No PATH guessing."""
    roots = [os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'),
             os.environ.get('ProgramW6432'), '/Applications']
    for name in names:
        for root in roots:
            if not root:
                continue
            candidate = Path(root) / name
            if candidate.exists():
                return str(candidate)
    return None


def outlook_command(exe: str, target: Path, to: str = '', subject: str = '',
                    body: str = '') -> list[str]:
    """The argument list Outlook needs for a message with the file attached.

    `/m` takes a mailto-style string and its query is what fills the subject and
    the body. An **empty address in front of the query** is accepted and leaves
    the To box empty, which is the whole point: the person sending the message
    chooses the recipient, and the message still says what it has to say.
    """
    query = (f'subject={quote(subject or f"PDF: {target.name}")}'
             f'&body={quote(body or DEFAULT_BODY)}')
    return [exe, '/c', 'ipm.note', '/m', f'{to}?{query}', '/a', str(target)]


def compose_with_outlook(target: Path, to: str = '', subject: str = '', body: str = '') -> dict:
    """Outlook's own command line: /c composes, /a attaches, /m fills the rest."""
    exe = _find_mail_program(r'Microsoft Office\root\Office16\OUTLOOK.EXE',
                             r'Microsoft Office\Office16\OUTLOOK.EXE',
                             r'Microsoft Office\root\Office15\OUTLOOK.EXE')
    if not exe:
        return {'ok': False, 'how': 'outlook'}
    try:
        subprocess.Popen(outlook_command(exe, target, to, subject, body))
        return {'ok': True, 'how': 'outlook'}
    except Exception:
        return {'ok': False, 'how': 'outlook'}


def compose_with_thunderbird(target: Path, to: str = '', subject: str = '', body: str = '') -> dict:
    exe = _find_mail_program('Mozilla Thunderbird/thunderbird.exe', 'Thunderbird.app/Contents/MacOS/thunderbird')
    if not exe:
        return {'ok': False, 'how': 'thunderbird'}
    parts = [f"to='{to}'" if to else '',
             f"subject='{subject or f'PDF: {target.name}'}'",
             f"body='{body or DEFAULT_BODY}'",
             f"attachment='{target}'"]
    try:
        subprocess.Popen([exe, '-compose', ','.join(part for part in parts if part)])
        return {'ok': True, 'how': 'thunderbird'}
    except Exception:
        return {'ok': False, 'how': 'thunderbird'}


def mail_with_attachment(path: str, to: str = '', subject: str = '', body: str = '') -> dict:
    """Open a compose window with the PDF already attached.

    Tried in order: Outlook's command line, then Thunderbird's. Each one gives a
    real message being written, with an empty recipient unless one was typed.
    Only if neither is installed does it fall back to writing an `.eml` — which
    most clients show as a received message rather than a draft, but which at
    least carries the file and can be forwarded.
    """
    target = inside_share(path)
    if not target:
        return {'ok': False, 'error': 'That file is not in the share folder.'}

    for attempt in (compose_with_outlook, compose_with_thunderbird):
        result = attempt(target, to, subject, body)
        if result.get('ok'):
            return {'ok': True, 'attachmentSupported': True, 'how': result['how'],
                    'note': ('A new message opened with the PDF attached. Choose the recipient '
                             'and press Send — nothing has been sent yet.')}

    try:
        draft = target.with_suffix('.eml')
        draft.write_bytes(eml_bytes(target, to, subject, body))
    except Exception:
        return {'ok': False, 'error': 'The email draft could not be created.'}
    opened = open_url(str(draft)) if IS_WINDOWS else _open_path(draft)
    if not opened.get('ok'):
        return {'ok': False, 'error': 'The email draft was created but no mail program opened it.',
                'path': str(draft)}
    return {'ok': True, 'attachmentSupported': True, 'draft': str(draft), 'how': 'eml',
            'note': ('A draft with the PDF attached was handed to your mail program. If it opens '
                     'as a message rather than a draft, press Reply or Forward to address it.')}


def _open_path(target: Path) -> dict:
    try:
        if IS_MAC:
            subprocess.Popen(['open', str(target)])
        else:
            subprocess.Popen(['xdg-open', str(target)])
        return {'ok': True}
    except Exception:
        return {'ok': False, 'error': 'No program is registered for this file type.'}


def methods() -> dict:
    """What sharing can actually do on this machine, so the interface can be honest."""
    return {
        'reveal': IS_WINDOWS or IS_MAC or IS_LINUX,
        'copyFile': IS_WINDOWS or IS_MAC or bool(_has_linux_clipboard()),
        'mailDraft': IS_WINDOWS or IS_MAC or IS_LINUX,
        'mailAttachment': IS_WINDOWS or IS_MAC or IS_LINUX,
        'folder': str(share_dir()),
    }


def _has_linux_clipboard() -> str | None:
    from shutil import which
    return which('xclip') or which('xsel')
