# Acrobat Pro, and what KADOMA does instead

This is a comparison of **capabilities**, not of code. It was written from
Acrobat Pro's public tool set — the same list Adobe publishes and the same one a
person sees in *All tools* — and from what KADOMA can do offline today.

It is deliberately **not** an analysis of the installer that was added to this
workspace. That package is an unofficial Acrobat Pro DC 2024 build with a `Crack`
folder in it, and taking it apart would mean reverse-engineering commercial
software, which its licence forbids and which is not needed: the feature list is
public, and every tool here is written from scratch against PyMuPDF.

## What Acrobat Pro has, and where KADOMA stands

| Acrobat tool | KADOMA | Notes |
|---|---|---|
| **Watermark** | **Yes** | Text or image, opacity, any angle, centre/tile/top/bottom, page range. |
| **Header & footer** | **Yes** | Six slots, `{page} {pages} {date} {filename} {title} {bates}` tokens, first-page skip. |
| **Page numbers / Bates** | **Yes** | Page format or Bates prefix with padded digits and a starting number. |
| **Crop pages** | **Yes** | Millimetres, points or inches, per side, any page range. |
| **Bookmarks** | **Yes** | List, add, remove, clear, and generate from the document's own headings. |
| **Attachments** | **Yes** | Add, list, extract and remove files embedded in the PDF. |
| **Compress / reduce size** | **Yes** | Image downsampling and re-encoding, font subsetting, object cleanup. |
| **Stamps** | **Yes** | Approved, Reviewed, Draft, Confidential, Final, For Public Release, Void — or your own text, placed where you click, with an optional date. |
| **Links** | **Yes** | Drag a box, then point it at a web address or another page in the document. Listed per page, removable one at a time. |
| **Page size (resize)** | **Yes** | A3 to Tabloid or a custom size in mm/pt/in, with the content scaled to fit — including form fields, comments and links. |
| **Edit PDF (text and images)** | **Yes** | Click a line and type; replace or delete images. Scans via drag-over-ink or OCR. |
| **Organize pages** | **Yes** | Rotate, delete, extract, duplicate, reorder, split, merge; odd/even selection. |
| **Forms** | **Yes** | Text, date (with a calendar), checkbox, dropdown; fill and clear. |
| **Sign** | **Partly** | A visual signature image. **Not** certificate-based signing, and no signature requests — both need a PKI and a server. |
| **Protect (passwords, permissions)** | **Yes** | AES-256, separate opening and owner passwords, printing/copying/editing permissions. |
| **Redact** | **Yes** | Real content removal, including image pixels, hidden attachments and metadata. |
| **OCR** | **Yes** | Local Tesseract, per page, with the page made editable afterwards. |
| **Export to Word/Excel/PowerPoint/images/text** | **Yes** | Local, best-effort; complex layouts need checking. |
| **Create PDF from Office** | **Yes** | Via a local LibreOffice if one is installed. |
| **Print** | **Yes** | Page range, copies, collated or not, the driver's own settings. |
| **Search, read, tabs** | **Yes** | Including several documents open at once. |
| **Compare documents** | **Yes, in words** | Page by page, word by word: which pages differ, and what was added or removed on them. **Not** a pixel comparison — it will not tell you that a moved paragraph is the same paragraph. |
| **Fill & Sign (form field autofill)** | **No** | KADOMA fills real fields; it does not guess where a signature goes. |
| **Action Wizard / batch processing** | **No** | A scripted sequence over many files. The tools are here; the sequencer is not. |
| **PDF/A, PDF/X, preflight** | **No** | Standards conformance checking is a large, separate subject. |
| **Portfolios** | **Partly** | Attachments carry files; a portfolio with a layout is not implemented. |
| **Measure, 3D, geospatial, multimedia** | **No** | Out of scope for an offline document editor. |
| **Cloud: sharing, review, e-signature requests, Document Cloud** | **No, deliberately** | KADOMA is offline by design. Nothing leaves the computer, and there is no account. |
| **Adobe Sensei / AI assistant** | **No cloud AI** | There is offline reading (summaries, form-field proposals) with no network. |

## What this release adds

Version 0.23 closes the four gaps the previous comparison listed first. Every one
of them was missing, and every one of them is now in the same module
(`app/document_tools.py`), behind the same request path, tested the same way.

1. **Stamps** — seven standard marks plus your own text, drawn where you click
   with an optional date underneath. The label is real text, so it can be
   selected and searched, and the stamp is pulled back onto the page if it would
   have hung over the edge.
2. **Links** — drag a box on the page, then point it at a web address or a page
   in the same document. The page's links are listed with a remove button each.
   An address that is not an address is refused with a reason instead of being
   written into the file.
3. **Page size** — A3, A4, A5, Letter, Legal, Tabloid, or a custom size in
   millimetres, points or inches, on all pages or a range. With scaling on, the
   content is multiplied into the new box **and** every form field, comment and
   link is moved with it; a signature field that stayed behind would point at
   blank paper.
4. **Compare** — two open documents or a file from disk, compared page by page
   and word by word. It reports which pages differ, how many words were added and
   removed on each, and lets you jump to the page. It compares text, not pixels,
   and says so in the dialog.

The seven tools from 0.22 are unchanged: watermark, header & footer, numbering
and Bates, crop, bookmarks, attachments, and reduce size.

## What is honestly still missing

- **Certificate-based signatures.** A real one needs a key store and a trust
  chain; a visual signature is not the same thing and is labelled as such.
- **Batch actions.** Applying a watermark to forty files means forty dialogs.
- **PDF/A and preflight.** Conformance is not a checkbox.
- **A visual (pixel) document comparison.** The comparison here is of words. A
  layout diff would need a rendering comparison that can explain itself, and a
  moved paragraph would show up as two changes rather than none.
- **Anything that needs a server.** Review, sharing, signature requests, cloud
  storage. KADOMA's whole claim is that it does not do that.
