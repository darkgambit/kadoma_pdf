"""The window's close question, without a window.

The rule is one line — ask only when the page says there is unsaved work — but
it is the difference between a quiet close and losing somebody's edits, so it is
tested rather than assumed. The dialog itself needs a human; the decision does
not.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import desktop
from desktop import DesktopBridge, closing_would_lose_work  # noqa: E402


class FakeWindow:
    def __init__(self):
        self.destroyed = 0

    def destroy(self):
        self.destroyed += 1


def test_a_fresh_window_does_not_ask_before_closing():
    bridge = DesktopBridge()
    assert closing_would_lose_work(bridge) is False


def test_the_page_saying_there_are_changes_makes_closing_ask():
    bridge = DesktopBridge()
    bridge.set_unsaved(True)
    assert closing_would_lose_work(bridge) is True
    bridge.set_unsaved(False)
    assert closing_would_lose_work(bridge) is False


def test_a_second_answer_re_arms_the_question():
    # After the person cancels the prompt the window stays open; pressing close
    # again must ask again rather than refuse silently.
    bridge = DesktopBridge()
    bridge._asking = True
    bridge.set_unsaved(True)
    assert bridge._asking is False


def test_quitting_from_the_page_clears_the_flag_and_closes_the_window():
    bridge = DesktopBridge()
    window = FakeWindow()
    bridge._window = window
    bridge.set_unsaved(True)
    result = bridge.quit_app()
    assert result == {'ok': True}
    assert window.destroyed == 1
    assert closing_would_lose_work(bridge) is False, 'closing again would ask a second time'


def test_quitting_without_a_window_does_not_raise():
    # The browser preview and the tests call the same bridge with no window.
    bridge = DesktopBridge()
    bridge._window = None
    assert bridge.quit_app() == {'ok': True}


# ------------------------------------------------------------- how it opens
# A source guard, and only that: the real check was done against the running
# window (IsZoomed and WS_EX_TOPMOST read from the shell), which cannot be done
# in a test without opening a window on whoever runs it. This catches the flags
# being deleted, not the window being wrong.

def test_the_window_opens_maximized_and_in_front():
    source = Path(__file__).resolve().parents[1] / 'desktop.py'
    text = source.read_text(encoding='utf-8')
    window = text.split('webview.create_window(', 1)[1].split('bridge._window', 1)[0]
    assert 'maximized=True' in window, window
    assert 'on_top=True' in window, window
    # The WebView2 backend ignores maximized=True, so the shell has to ask again
    # once the page has loaded — asking earlier leaves the window minimized.
    assert 'window.events.loaded += on_shown' in text, text[-800:]
    assert 'window.maximize()' in text


# ------------------------------------------------- the queue between launches

def test_the_queue_keeps_the_kind_and_the_order_of_the_work(tmp_path, monkeypatch):
    """A second launch hands its work to the running window through files.

    Two kinds go through the same queue — a file to open, a selection to combine
    — and the timestamp in the file name is what keeps them in the order they
    were asked for. Getting that wrong would combine a selection that was made
    before the file that was double-clicked afterwards.
    """
    monkeypatch.setattr(desktop, 'pending_dir', lambda: tmp_path)
    desktop.queue_open(r'C:/one.pdf')
    desktop.queue_combine([r'C:/two.pdf', r'C:/three.pdf'])
    desktop.queue_open(r'C:/four.pdf')

    items = desktop.take_pending()
    assert [item['action'] for item in items] == ['open', 'combine', 'open'], items
    assert items[0]['path'] == r'C:/one.pdf'
    assert items[1]['paths'] == [r'C:/two.pdf', r'C:/three.pdf']
    assert items[2]['path'] == r'C:/four.pdf'
    # Consumed once: a second read finds nothing.
    assert desktop.take_pending() == []


def test_a_damaged_queue_file_is_skipped_not_fatal(tmp_path, monkeypatch):
    monkeypatch.setattr(desktop, 'pending_dir', lambda: tmp_path)
    (tmp_path / '0001-aaaa.combine').write_text('not json', encoding='utf-8')
    (tmp_path / '0002-bbbb.open').write_text(r'C:/fine.pdf', encoding='utf-8')
    items = desktop.take_pending()
    assert items == [{'action': 'open', 'path': r'C:/fine.pdf'}], items
