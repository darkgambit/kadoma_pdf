from fastapi.testclient import TestClient
import pymupdf as fitz
import pytest
from app import __version__
from support.demo_document import make_demo
from app.server import app, engine


@pytest.fixture
def client():
    engine.documents.clear()
    app.state.token = None
    app.state.desktop = False
    with TestClient(app, raise_server_exceptions=True) as client:
        yield client
    app.state.token = None
    app.state.desktop = False
    engine.documents.clear()


def open_demo(client):
    """Open the fixture report through the upload endpoint.

    The application no longer ships a sample document, so a test that needs one
    uploads it — which is also the path a real file takes.
    """
    response = client.post('/api/documents/upload',
                           files={'file': ('Quarterly performance.pdf', make_demo(), 'application/pdf')})
    assert response.status_code == 200, response.text
    # The response, not the parsed body: every call site follows with .json(),
    # exactly as it did against the old endpoint.
    return response

def test_health_static_fonts_and_demo(client):
    health = client.get('/api/health')
    assert health.status_code == 200 and health.json()['offline']
    assert health.json()['ai'] is True and health.json()['cloud'] is False
    assert health.json()['aiOffline'] is True and health.json()['aiCloud'] is False
    assert client.get('/').status_code == 200
    assert client.get('/static/app.js').status_code == 200
    assert client.get('/static/fonts/Inter.woff2').status_code == 200
    document = open_demo(client).json()
    ident = document['id']
    assert document['pageCount'] == 4
    response = client.get(f'/api/documents/{ident}/pages/0/render?scale=.2')
    assert response.status_code == 200 and response.content.startswith(b'\x89PNG')
    assert response.headers['cache-control'] == 'no-store'
    assert client.get(f'/api/documents/{ident}/pages/0/content').json()['spans']


def test_upload_export_and_operation(client):
    document = client.post('/api/documents/create',json={'name':'Test.pdf'}).json()
    ident = document['id']
    response = client.post(f'/api/documents/{ident}/operation',json={'action':'add_text','page':0,'rect':[40,40,320,100],'text':'API editing works','size':16})
    assert response.status_code == 200 and response.json()['modified']
    response = client.post(f'/api/documents/{ident}/export/pdf',json={})
    assert response.status_code == 200
    assert 'attachment;' in response.headers['content-disposition']
    raw = response.content
    uploaded = client.post('/api/documents/upload',files={'file':('copied.pdf',raw,'application/pdf')})
    assert uploaded.status_code == 200
    new_id = uploaded.json()['id']
    assert client.get(f'/api/documents/{new_id}/search?q=API').json()['matches']
    assert client.delete(f'/api/documents/{new_id}').status_code == 200
    assert client.get(f'/api/documents/{new_id}').status_code == 404


def test_one_page_export_is_named_after_that_page(client):
    # "Copy this page to a file" asks for one page; the file that comes back is
    # named after the page, not after the whole document.
    document = open_demo(client).json()
    ident = document['id']
    response = client.post(f'/api/documents/{ident}/export/pdf', json={'pages': [2]})
    assert response.status_code == 200
    disposition = response.headers['content-disposition']
    assert 'page-003.pdf' in disposition, disposition
    with fitz.open(stream=response.content, filetype='pdf') as copy:
        assert len(copy) == 1, 'the copy is not a single page'
    # The whole document keeps its own name.
    whole = client.post(f'/api/documents/{ident}/export/pdf', json={})
    assert 'Quarterly performance.pdf' in whole.headers['content-disposition']


def test_validation_unknown_pdf_and_invalid_page(client):
    response = client.post('/api/documents/upload',files={'file':('broken.pdf',b'not pdf','application/pdf')})
    assert response.status_code == 422
    doc = client.post('/api/documents/create',json={}).json()
    ident = doc['id']
    assert client.get(f'/api/documents/{ident}/pages/5/content').status_code == 404
    assert client.post(f'/api/documents/{ident}/operation',json={'action':'invented'}).status_code in (404,422)
    assert client.post(f'/api/documents/{ident}/operation',json={'action':'rotate','pages':[False]}).status_code == 422


def test_desktop_token_and_origin_protection(client):
    app.state.token = 'a-real-test-capability'
    assert client.get('/api/health').status_code == 401
    headers={'Authorization':'Bearer a-real-test-capability'}
    assert client.get('/api/health',headers=headers).status_code == 200
    headers['Origin']='https://attacker.example'
    assert client.get('/api/health',headers=headers).status_code == 403
    headers['Origin']='http://testserver'
    assert client.get('/api/health',headers=headers).status_code == 200


def test_encrypted_upload_prompts_and_export_keeps_encryption(client):
    doc = open_demo(client).json()
    data = client.post(f"/api/documents/{doc['id']}/export/protected",json={'openPassword':'readpass','ownerPassword':'ownerpass'}).content
    response = client.post('/api/documents/upload',files={'file':('protected.pdf',data,'application/pdf')})
    assert response.status_code == 401 and response.json()['code'] == 'password_required'
    response = client.post('/api/documents/upload',files={'file':('protected.pdf',data,'application/pdf')},data={'password':'readpass'})
    assert response.status_code == 200
    assert not response.json()['canEdit']


def test_huge_request_rejected_before_processing(client):
    # Above the 500 MB working-document limit, so this is refused before the
    # body is read rather than after half a gigabyte has arrived.
    response = client.post('/api/documents/create',headers={'content-length':str(600*1024*1024)},content=b'{}')
    assert response.status_code == 413


def test_direct_edit_runs_delete_and_expand_through_the_api(client):
    document = open_demo(client).json()
    ident = document['id']
    content = client.get(f'/api/documents/{ident}/pages/0/content').json()
    assert content['runs'], 'the API must expose editable text runs'
    run = next(r for r in content['runs'] if r['text'] == 'Quarterly')
    assert run['family'] == 'sans-serif' and run['spanCount'] >= 1
    response = client.post(f'/api/documents/{ident}/operation',
                           json={'action': 'replace_text', 'page': 0, 'rect': run['rect'],
                                 'text': 'Quarterly performance summary', 'size': run['size'],
                                 'color': run['color'], 'family': run['family'],
                                 'rotation': run['rotation'], 'expand': True})
    assert response.status_code == 200 and response.json()['modified']
    matches = client.get(f'/api/documents/{ident}/search?q=Quarterly%20performance%20summary').json()['matches']
    assert matches
    # An empty replacement removes the text instead of being rejected.
    other = next(r for r in client.get(f'/api/documents/{ident}/pages/1/content').json()['runs']
                 if 'NL-2048-9931' in r['text'])
    assert client.post(f'/api/documents/{ident}/operation',
                       json={'action': 'replace_text', 'page': 1, 'rect': other['rect'], 'text': ''}).status_code == 200
    assert not client.get(f'/api/documents/{ident}/search?q=NL-2048-9931').json()['matches']
    # New text still requires actual content.
    assert client.post(f'/api/documents/{ident}/operation',
                       json={'action': 'add_text', 'page': 0, 'rect': [40, 40, 300, 80], 'text': ''}).status_code == 422


def test_desktop_bridge_csp_not_enabled_in_browser_preview(client):
    preview=client.get('/').headers['content-security-policy']
    assert "'unsafe-eval'" not in preview
    app.state.desktop=True
    desktop=client.get('/').headers['content-security-policy']
    assert "script-src 'self' 'unsafe-eval'" in desktop
    app.state.desktop=False


# ------------------------------------------- sharing and default-app endpoints

@pytest.fixture
def desktop():
    """A desktop-shell client. The loopback guard reads the peer address, so the
    test client has to present itself as coming from this machine."""
    engine.documents.clear()
    app.state.token = None
    app.state.desktop = True
    app.state.pending_open = []
    with TestClient(app, raise_server_exceptions=True,
                    client=('127.0.0.1', 50000)) as client:
        yield client
    app.state.token = None
    app.state.desktop = False
    app.state.pending_open = []
    engine.documents.clear()


def test_health_reports_rtl_and_desktop_capabilities(client):
    health = client.get('/api/health').json()
    assert health['rtlText'] is True
    assert health['rtlQuality'] in ('exact', 'approximate')
    # Compared with the package rather than a literal: the health endpoint must
    # report the version the code actually is, and a hardcoded string would go
    # stale the moment either side changed.
    assert health['version'] == __version__
    # A browser preview is not the desktop shell, and must say so.
    assert health['desktop'] is False


def test_share_and_default_app_endpoints_are_desktop_only_in_preview(client):
    """These reach the clipboard, the mail client and the registry, so a hosted
    preview must never expose them."""
    for path in ('/api/share/prepare', '/api/share/reveal',
                 '/api/share/clipboard', '/api/share/email',
                 '/api/system/default-app', '/api/documents/open-path',
                 '/api/system/combine-paths'):
        response = client.post(path, json={'document': 'x', 'path': 'x', 'action': 'register'})
        assert response.status_code == 403, path
        assert response.json()['code'] == 'desktop_only', path
    # The read-only status calls stay available so the interface can explain itself.
    assert client.get('/api/share/methods').json()['desktop'] is False
    assert client.get('/api/system/default-app').json()['desktop'] is False
    assert client.get('/api/system/pending-open').json() == {'items': []}


def test_share_prepare_exports_the_document_into_the_share_folder(desktop):
    document = open_demo(desktop).json()
    prepared = desktop.post('/api/share/prepare', json={'document': document['id']})
    assert prepared.status_code == 200, prepared.text
    info = prepared.json()
    assert info['name'].endswith('.pdf')
    assert info['size'] > 1000
    from pathlib import Path
    from app import share
    assert Path(info['path']).parent == share.share_dir()
    assert Path(info['path']).read_bytes().startswith(b'%PDF')


def test_share_prepare_requires_a_document(desktop):
    response = desktop.post('/api/share/prepare', json={})
    assert response.status_code == 409
    assert response.json()['code'] == 'no_document'


def test_share_actions_refuse_a_path_from_outside_the_share_folder(desktop):
    """The path travels from the browser, so it is untrusted input."""
    for path in ('/api/share/reveal', '/api/share/clipboard', '/api/share/email'):
        response = desktop.post(path, json={'path': r'C:\Windows\win.ini'})
        assert response.status_code == 200, path
        assert response.json()['ok'] is False, path
        assert 'share folder' in response.json()['error'], path


def test_share_email_rejects_an_oversized_message(desktop):
    document = open_demo(desktop).json()
    info = desktop.post('/api/share/prepare', json={'document': document['id']}).json()
    response = desktop.post('/api/share/email',
                            json={'path': info['path'], 'subject': 'x' * 500})
    assert response.status_code == 422
    assert response.json()['code'] == 'email_too_long'


def test_default_app_status_reports_the_current_handler(desktop):
    status = desktop.get('/api/system/default-app').json()
    assert status['desktop'] is True
    assert 'registered' in status and 'currentHandler' in status
    # Registration must never be reported as done just because it was asked for.
    assert status['isDefault'] in (True, False)


def test_pending_open_is_drained_exactly_once(desktop):
    """A double-clicked file must be opened once, not once per poll."""
    app.state.pending_open[:] = [{'action': 'open', 'path': r'C:\Users\Public\Downloads\report.pdf'}]
    first = desktop.get('/api/system/pending-open').json()
    assert first['items'] == [{'action': 'open', 'path': r'C:\Users\Public\Downloads\report.pdf'}]
    assert desktop.get('/api/system/pending-open').json()['items'] == []


def test_the_queue_carries_both_kinds_of_work(desktop):
    """Opening a file and combining a selection arrive down the same queue, in
    the order they were asked for, and each is drained once."""
    app.state.pending_open[:] = [
        {'action': 'open', 'path': r'C:\one.pdf'},
        {'action': 'combine', 'paths': [r'C:\two.pdf', r'C:\three.pdf']},
    ]
    items = desktop.get('/api/system/pending-open').json()['items']
    assert [item['action'] for item in items] == ['open', 'combine']
    assert items[1]['paths'] == [r'C:\two.pdf', r'C:\three.pdf']
    assert desktop.get('/api/system/pending-open').json()['items'] == []


def test_open_path_rejects_a_missing_file(desktop):
    response = desktop.post('/api/documents/open-path',
                            json={'path': r'C:\definitely\not\here.pdf'})
    assert response.status_code == 404
    assert response.json()['code'] == 'file_not_found'


def test_open_path_needs_a_real_path(desktop):
    for payload in ({}, {'path': ''}, {'path': '   '}, {'path': 42}):
        response = desktop.post('/api/documents/open-path', json=payload)
        assert response.status_code == 422, payload
        assert response.json()['code'] == 'invalid_request', payload



def test_health_reports_printing_and_date_fields(client):
    health = client.get('/api/health').json()
    assert health['printSupported'] is True
    assert health['dateFields'] is True


def test_printing_endpoints_are_desktop_only_in_preview(client):
    """Printing reaches the spooler, so a hosted preview must not offer it."""
    response = client.post('/api/system/print', json={'document': 'x'})
    assert response.status_code == 403
    assert response.json()['code'] == 'desktop_only'
    # The preview is part of the same shell, for the same reason.
    preview = client.get('/api/system/print/preview', params={'document': 'x', 'page': 0})
    assert preview.status_code == 403
    assert preview.json()['code'] == 'desktop_only'
    # The read-only status call stays available so the interface can explain
    # why the button is unavailable instead of failing silently.
    status = client.get('/api/system/print').json()
    assert status['desktop'] is False
    assert status['printer'] is None
    assert set(status['methods']) >= {'print', 'printer', 'printers', 'canPrint', 'savesToFile', 'via'}


def test_print_status_reports_the_methods_on_the_desktop(desktop):
    status = desktop.get('/api/system/print').json()
    assert status['desktop'] is True
    methods = status['methods']
    assert methods['via'] in ('gdi', 'lpr', 'lp')
    assert isinstance(methods['printers'], list)
    assert isinstance(methods['canPrint'], bool)
    # The printer named here is the one a job would actually go to.
    assert status['printer'] == methods['printer']


def test_print_refuses_without_a_document(desktop):
    response = desktop.post('/api/system/print', json={})
    assert response.status_code == 409
    assert response.json()['code'] == 'no_document'


def test_print_preview_is_a_png_of_the_chosen_page(desktop):
    document = open_demo(desktop).json()
    response = desktop.get('/api/system/print/preview',
                           params={'document': document['id'], 'page': 1})
    assert response.status_code == 200
    assert response.headers['content-type'] == 'image/png'
    assert response.headers['cache-control'] == 'no-store'
    assert response.content.startswith(b'\x89PNG')
    import pymupdf as fitz
    with fitz.open(stream=response.content, filetype='png') as image:
        assert image[0].rect.height > image[0].rect.width, 'the preview is not a portrait sheet'


def test_print_preview_refuses_what_it_cannot_draw(desktop):
    document = open_demo(desktop).json()
    ident = document['id']
    # A page that is not in the document is a 404 with a reason, not a blank
    # image that looks like an empty page.
    missing = desktop.get('/api/system/print/preview',
                          params={'document': ident, 'page': 99})
    assert missing.status_code == 404
    assert missing.json()['code'] == 'page_not_found'
    # No document at all.
    assert desktop.get('/api/system/print/preview').status_code == 409


def test_a_date_field_round_trips_through_the_api(client):
    document = client.post('/api/documents/create', json={'name':'Date test.pdf'}).json()
    ident = document['id']
    created = client.post(f'/api/documents/{ident}/operation',
                          json={'action':'add_field','page':0,'type':'date','name':'due',
                                'rect':[50,50,250,80],'dateFormat':'DD/MM/YYYY'})
    assert created.status_code == 200, created.text
    widget = client.get(f'/api/documents/{ident}/pages/0/content').json()['widgets'][0]
    assert widget['kind'] == 'date' and widget['dateFormat'] == 'DD/MM/YYYY'

    refused = client.post(f'/api/documents/{ident}/operation',
                          json={'action':'fill_forms','values':{str(widget['xref']):'sometime'}})
    assert refused.status_code == 422
    assert 'date' in refused.json()['detail'].lower()

    filled = client.post(f'/api/documents/{ident}/operation',
                         json={'action':'fill_forms','values':{str(widget['xref']):'5/3/2027'}})
    assert filled.status_code == 200, filled.text
    widget = client.get(f'/api/documents/{ident}/pages/0/content').json()['widgets'][0]
    assert widget['value'] == '05/03/2027'

    cleared = client.post(f'/api/documents/{ident}/operation', json={'action':'clear_fields'})
    assert cleared.status_code == 200, cleared.text
    assert cleared.json()['canUndo'] is True
    widget = client.get(f'/api/documents/{ident}/pages/0/content').json()['widgets'][0]
    assert widget['value'] in (None, '')

    client.post(f'/api/documents/{ident}/operation', json={'action':'undo'})
    widget = client.get(f'/api/documents/{ident}/pages/0/content').json()['widgets'][0]
    assert widget['value'] == '05/03/2027'


def test_clearing_an_empty_form_is_refused_without_touching_history(client):
    document = client.post('/api/documents/create', json={'name':'Date test.pdf'}).json()
    ident = document['id']
    response = client.post(f'/api/documents/{ident}/operation', json={'action':'clear_fields'})
    assert response.status_code == 422
    assert client.get(f'/api/documents/{ident}').json()['canUndo'] is False


# ------------------------------------------------------------- combining files
# The combine window talks to three endpoints, so each is checked here the way
# the interface actually calls it: multipart uploads, with the password list,
# the page selections and the insert position carried as JSON form fields.

def api_labelled(*labels):
    import pymupdf as fitz
    with fitz.open() as doc:
        for label in labels:
            doc.new_page(width=595, height=842).insert_text((72, 120), label, fontsize=26)
        return doc.tobytes()


def upload(name, data):
    return ('files', (name, data, 'application/pdf'))


def api_page_labels(client, ident):
    """The label on each page, read out of the saved file rather than memory."""
    import pymupdf as fitz
    raw = engine.export(ident, 'pdf')[0]
    with fitz.open(stream=raw, filetype='pdf') as doc:
        return [doc[i].get_text().strip() for i in range(len(doc))]


def test_inspecting_describes_files_without_opening_them(client):
    before = client.get('/api/health').json()
    assert before['combine'] is True and before['mergeRanges'] is True

    response = client.post('/api/documents/inspect',
                           files=[upload('A.pdf', api_labelled('A1', 'A2')),
                                  upload('B.pdf', api_labelled('B1'))])
    assert response.status_code == 200, response.text
    report = response.json()['files']
    assert [(item['name'], item['pages'], item['locked'], item['readable']) for item in report] == \
           [('A.pdf', 2, False, True), ('B.pdf', 1, False, True)]
    # Looking at a file must not leave a document behind in the workspace.
    assert not any(doc.name in ('A.pdf', 'B.pdf') for doc in engine.documents.values())


def test_a_locked_file_is_flagged_and_unflagged_by_its_password(client):
    import pymupdf as fitz
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'LOCKED', fontsize=26)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='o', user_pw='pw')
    import json as jsonlib
    report = client.post('/api/documents/inspect', files=[upload('Locked.pdf', locked)],
                         data={'passwords': jsonlib.dumps([''])}).json()['files'][0]
    assert report['locked'] is True and report['pages'] == 1
    report = client.post('/api/documents/inspect', files=[upload('Locked.pdf', locked)],
                         data={'passwords': jsonlib.dumps(['pw'])}).json()['files'][0]
    assert report['locked'] is False


def test_combine_builds_a_new_document_from_several_files(client):
    import json as jsonlib
    response = client.post('/api/documents/combine',
                           files=[upload('A.pdf', api_labelled('A1', 'A2')),
                                  upload('B.pdf', api_labelled('B1'))],
                           data={'name': 'Combined pack.pdf',
                                 'ranges': jsonlib.dumps(['2', '1'])})
    assert response.status_code == 200, response.text
    document = response.json()
    assert document['name'] == 'Combined pack.pdf'
    # Only page 2 of A and page 1 of B, in that order.
    assert api_page_labels(client, document['id']) == ['A2', 'B1']
    assert client.get(f"/api/documents/{document['id']}").json()['pageCount'] == 2


def test_merging_into_a_document_honours_position_and_ranges(client):
    import json as jsonlib
    ident = client.post('/api/documents/create', json={'name': 'Target.pdf'}).json()['id']
    response = client.post(f'/api/documents/{ident}/merge',
                           files=[upload('A.pdf', api_labelled('A1', 'A2'))],
                           data={'ranges': jsonlib.dumps(['2']), 'position': jsonlib.dumps(0)})
    assert response.status_code == 200, response.text
    assert response.json()['pageCount'] == 2
    # Inserted in front of the blank first page, not appended.
    assert api_page_labels(client, ident) == ['A2', '']


def test_a_bad_position_or_page_range_is_refused_clearly(client):
    import json as jsonlib
    ident = client.post('/api/documents/create', json={'name': 'Target.pdf'}).json()['id']
    cases = [
        ({'position': jsonlib.dumps(-2)}, 'Invalid insert position.'),
        ({'position': jsonlib.dumps('first')}, 'Invalid insert position.'),
        ({'position': 'not json'}, 'Invalid insert position.'),
        ({'ranges': jsonlib.dumps(['1-99'])}, 'page 99 does not exist'),
        ({'ranges': 'not json'}, 'Invalid page selection.'),
        ({'ranges': jsonlib.dumps([7])}, 'Invalid page selection.'),
        ({'passwords': jsonlib.dumps('nope')}, 'Invalid password list.'),
    ]
    for payload, expected in cases:
        response = client.post(f'/api/documents/{ident}/merge',
                               files=[upload('A.pdf', api_labelled('A1', 'A2'))], data=payload)
        assert response.status_code == 422, f'{payload} -> {response.status_code}'
        assert expected in response.json()['detail'], f'{payload} -> {response.json()["detail"]}'
    # A refused merge leaves the document exactly as it was.
    assert client.get(f'/api/documents/{ident}').json()['pageCount'] == 1


def test_combining_with_no_files_is_refused(client):
    assert client.post('/api/documents/combine', data={}).status_code == 422
    assert client.post('/api/documents/inspect', data={}).status_code == 422


# ---------------------------------------------------------------- splitting files
# The split window talks to two endpoints: one to describe the parts while the
# settings are typed, one to produce them. Both are checked the way the interface
# calls them, and both are checked to leave the open document alone.

def demo_document(client):
    document = open_demo(client).json()
    return document['id'], document['pageCount']


def test_health_reports_the_split_capabilities(client):
    health = client.get('/api/health').json()
    assert health['split'] is True
    assert health['splitModes'] == ['chunks', 'parts', 'ranges']
    assert health['maxSplitFiles'] == 200


def test_split_plan_describes_the_parts_without_writing_them(client):
    ident, total = demo_document(client)
    response = client.post(f'/api/documents/{ident}/split/plan', json={'mode': 'chunks', 'size': 1})
    assert response.status_code == 200, response.text
    plan = response.json()
    assert plan['fileCount'] == total and plan['pageTotal'] == total
    assert plan['archive'] is True and plan['omitted'] == []
    assert [part['first'] for part in plan['parts']] == list(range(1, total + 1))
    assert [part['pages'] for part in plan['parts']] == [1] * total
    # Planning is a read: the document is untouched and no history step appears.
    after = client.get(f'/api/documents/{ident}').json()
    assert after['pageCount'] == total and after['canUndo'] is False


def test_split_produces_an_archive_and_leaves_the_document_alone(client):
    import io
    import zipfile
    import pymupdf as fitz
    ident, total = demo_document(client)
    response = client.post(f'/api/documents/{ident}/split', json={'mode': 'parts', 'parts': 2})
    assert response.status_code == 200, response.text
    assert response.headers['content-type'] == 'application/zip'
    assert '.zip' in response.headers['content-disposition']
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        entries = archive.namelist()
        assert len(entries) == 2
        counted = 0
        for entry in entries:
            with fitz.open(stream=archive.read(entry), filetype='pdf') as part:
                counted += len(part)
        assert counted == total
    assert client.get(f'/api/documents/{ident}').json()['pageCount'] == total


def test_a_single_part_is_downloaded_as_a_plain_pdf(client):
    ident, _ = demo_document(client)
    response = client.post(f'/api/documents/{ident}/split', json={'mode': 'ranges', 'ranges': '2-3'})
    assert response.status_code == 200, response.text
    assert response.headers['content-type'] == 'application/pdf'
    assert response.content.startswith(b'%PDF')
    assert 'part-001-pages-2-3.pdf' in response.headers['content-disposition']


def test_a_bad_split_setting_is_refused_clearly(client):
    ident, total = demo_document(client)
    cases = [
        ({'mode': 'chunks', 'size': 0}, 'between 1 and'),
        ({'mode': 'parts', 'parts': 999}, 'between 2 and'),
        ({'mode': 'ranges', 'ranges': '1-999'}, 'does not exist'),
        ({'mode': 'ranges', 'ranges': 'nope'}, 'separated by commas'),
        ({'mode': 'sideways'}, 'Choose how to split'),
    ]
    for payload, expected in cases:
        response = client.post(f'/api/documents/{ident}/split/plan', json=payload)
        assert response.status_code == 422, f'{payload} -> {response.status_code}'
        assert expected in response.json()['detail'], f'{payload} -> {response.json()["detail"]}'
        assert client.post(f'/api/documents/{ident}/split', json=payload).status_code == 422
    # A refused split leaves the document exactly as it was.
    assert client.get(f'/api/documents/{ident}').json()['pageCount'] == total


# --------------------------------------------------- documents already open
# The merge window can take a document the workspace is already holding, so the
# two endpoints behind that are checked here: the one that lists them and the
# one that consumes them.

def test_the_open_documents_endpoint_lists_the_workspace(client):
    first = client.post('/api/documents/create', json={'name': 'First.pdf'}).json()
    client.post('/api/documents/upload',
                files={'file': ('Second.pdf', api_labelled('S1', 'S2'), 'application/pdf')})
    report = client.get('/api/documents').json()['documents']
    assert [(d['name'], d['pageCount'], d['readable'], d['canAssemble']) for d in report] == \
           [('First.pdf', 1, True, True), ('Second.pdf', 2, True, True)]
    assert report[0]['id'] == first['id']
    # Listing documents does not disturb the workspace.
    assert client.get(f"/api/documents/{first['id']}").json()['pageCount'] == 1


def test_merge_takes_a_document_that_is_already_open(client):
    import json as jsonlib
    target = client.post('/api/documents/create', json={'name': 'Target.pdf'}).json()['id']
    opened = client.post('/api/documents/upload',
                         files={'file': ('Open.pdf', api_labelled('O1', 'O2'), 'application/pdf')}).json()
    response = client.post(f'/api/documents/{target}/merge',
                           data={'sources': jsonlib.dumps([{'kind': 'document', 'id': opened['id']}])})
    assert response.status_code == 200, response.text
    assert response.json()['pageCount'] == 3
    assert api_page_labels(client, target) == ['', 'O1', 'O2']
    # The source is still open and unchanged: merging copies pages.
    still = [d for d in client.get('/api/documents').json()['documents'] if d['id'] == opened['id']]
    assert still and still[0]['pageCount'] == 2


def test_combine_mixes_an_open_document_with_a_chosen_file(client):
    import json as jsonlib
    opened = client.post('/api/documents/upload',
                         files={'file': ('Open.pdf', api_labelled('O1'), 'application/pdf')}).json()
    response = client.post('/api/documents/combine',
                           files=[upload('Chosen.pdf', api_labelled('C1', 'C2'))],
                           data={'name': 'Mixed.pdf',
                                 'sources': jsonlib.dumps([{'kind': 'file', 'index': 0},
                                                           {'kind': 'document', 'id': opened['id']}]),
                                 'ranges': jsonlib.dumps(['2', '1'])})
    assert response.status_code == 200, response.text
    document = response.json()
    assert document['name'] == 'Mixed.pdf'
    # Page 2 of the upload, then page 1 of the open document, in that order —
    # the order the window listed them, not the order they arrived in.
    assert api_page_labels(client, document['id']) == ['C2', 'O1']


def test_a_bad_source_list_is_refused_clearly(client):
    import json as jsonlib
    ident = client.post('/api/documents/create', json={'name': 'Target.pdf'}).json()['id']
    cases = [
        ('not json', 'Invalid source list.'),
        (jsonlib.dumps({'kind': 'file'}), 'Invalid source list.'),
        (jsonlib.dumps([{'kind': 'nonsense'}]), 'Invalid source list.'),
        (jsonlib.dumps([{'kind': 'file', 'index': 4}]), 'Invalid source list.'),
        (jsonlib.dumps([{'kind': 'document', 'id': ''}]), 'Invalid source list.'),
        (jsonlib.dumps([]), 'Choose one or more files'),
    ]
    for raw, expected in cases:
        response = client.post(f'/api/documents/{ident}/merge', data={'sources': raw})
        assert response.status_code == 422, f'{raw} -> {response.status_code}'
        assert expected in response.json()['detail'], f'{raw} -> {response.json()["detail"]}'
    # A document that is not open is named as such rather than silently skipped.
    response = client.post(f'/api/documents/{ident}/merge',
                           data={'sources': jsonlib.dumps([{'kind': 'document', 'id': 'gone'}])})
    assert response.status_code == 409
    assert response.json()['code'] == 'document_not_found'
    assert client.get(f'/api/documents/{ident}').json()['pageCount'] == 1


def test_the_workspace_limit_is_reported_to_the_interface(client):
    health = client.get('/api/health').json()
    assert health['maxDocuments'] == 6


# ------------------------------------------------------------------ AI reading
# Two paths through the same panel, and the interface has to keep them apart: an
# offline reading that quotes the document, and a model somebody connected. These
# check the endpoints, the refusals, and that the key never comes back.

def test_health_reports_ai_honestly(client):
    health = client.get('/api/health').json()
    assert health['ai'] is True and health['aiOffline'] is True
    # Nothing is sent anywhere by default, which is why this is false rather
    # than absent.
    assert health['aiCloud'] is False and health['aiModel'] == 'optional'


def test_ai_status_starts_offline(client):
    status = client.get('/api/ai/status').json()
    assert status['offline'] is True and status['modes'] == ['offline', 'model']
    assert status['model'] == {'endpoint': '', 'model': '', 'configured': False, 'keySet': False}


def test_connecting_a_model_is_validated_and_the_key_never_comes_back(client):
    for payload, expected in [
        ({'mode': 'nonsense'}, 'Choose whether'),
        ({'mode': 'model', 'endpoint': 'ftp://host/v1', 'model': 'm'}, 'http:// or https://'),
        ({'mode': 'model', 'endpoint': 'https://host/v1', 'model': ''}, 'model name'),
    ]:
        response = client.post('/api/ai/configure', json=payload)
        assert response.status_code == 422, payload
        assert expected in response.json()['detail'], response.json()['detail']

    response = client.post('/api/ai/configure',
                           json={'mode': 'model', 'endpoint': 'https://host/v1',
                                 'model': 'small', 'apiKey': 'sk-do-not-echo'})
    assert response.status_code == 200, response.text
    assert 'sk-do-not-echo' not in response.text
    assert response.json()['model'] == {'endpoint': 'https://host/v1', 'model': 'small',
                                        'configured': True, 'keySet': True}
    # A later save without a key keeps the one already held.
    again = client.post('/api/ai/configure',
                        json={'mode': 'model', 'endpoint': 'https://host/v1', 'model': 'small'}).json()
    assert again['model']['keySet'] is True
    # And disconnecting forgets it.
    off = client.post('/api/ai/configure', json={'mode': 'off'}).json()
    assert off['model']['keySet'] is False and off['model']['configured'] is False


def test_an_offline_summary_quotes_the_document(client):
    document = open_demo(client).json()
    response = client.post(f"/api/documents/{document['id']}/ai/summary",
                           json={'mode': 'offline', 'sentences': 3})
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['mode'] == 'offline' and body['model'] is None
    assert body['selected'] == 3 and body['sentenceCount'] >= 3
    assert body['summary'] and body['keywords']
    # The summary is quoted, not written: every sentence it returns is in the
    # document. Whitespace is collapsed on both sides first, because a
    # sentence that wrapped across two lines is quoted as one line.
    import re as relib
    text = engine.export(document['id'], 'txt')[0].decode('utf-8')
    flat = relib.sub(r'\s+', ' ', text)
    for sentence in body['sentences']:
        assert relib.sub(r'\s+', ' ', sentence).strip() in flat, sentence


def test_an_offline_prompt_becomes_real_form_fields(client):
    document = open_demo(client).json()
    ident = document['id']
    response = client.post(f'/api/documents/{ident}/ai/form',
                           json={'mode': 'offline',
                                 'prompt': 'full name, email, date signed and a checkbox to agree'})
    assert response.status_code == 200, response.text
    fields = response.json()['fields']
    assert [(f['label'], f['kind']) for f in fields] == [
        ('Full name', 'text'), ('Email', 'text'), ('Date signed', 'date'), ('Agree', 'checkbox')]

    # Proposing changes nothing; applying is one undoable step.
    before = client.get(f'/api/documents/{ident}').json()
    assert before['pageCount'] == document['pageCount']
    applied = client.post(f'/api/documents/{ident}/operation',
                          json={'action': 'add_fields', 'fields': fields, 'newPage': True})
    assert applied.status_code == 200, applied.text
    after = applied.json()
    assert after['pageCount'] == before['pageCount'] + 1
    assert after['formCount'] == before['formCount'] + 4
    widgets = client.get(f"/api/documents/{ident}/pages/{after['pageCount'] - 1}/content").json()['widgets']
    assert [w['label'] for w in widgets] == ['Full name', 'Email', 'Date signed', 'Agree']
    assert [w['kind'] for w in widgets] == ['text', 'text', 'date', 'checkbox']
    undone = client.post(f'/api/documents/{ident}/operation', json={'action': 'undo'}).json()
    assert undone['pageCount'] == before['pageCount'] and undone['formCount'] == before['formCount']


def test_a_prompt_naming_nothing_is_refused(client):
    document = open_demo(client).json()
    response = client.post(f"/api/documents/{document['id']}/ai/form",
                           json={'mode': 'offline', 'prompt': 'what do you think?'})
    assert response.status_code == 422
    assert 'full name' in response.json()['detail']
    assert client.post(f"/api/documents/{document['id']}/ai/form",
                       json={'mode': 'offline', 'prompt': 'x' * 3000}).status_code == 422


def test_the_model_is_refused_until_one_is_connected(client):
    document = open_demo(client).json()
    ident = document['id']
    for path, payload in ((f'/api/documents/{ident}/ai/summary', {'mode': 'model'}),
                          (f'/api/documents/{ident}/ai/form', {'mode': 'model', 'prompt': 'a name'})):
        response = client.post(path, json=payload)
        assert response.status_code == 409, response.text
        assert response.json()['code'] == 'ai_not_configured'
    assert client.post(f'/api/documents/{ident}/ai/summary',
                       json={'mode': 'sideways'}).status_code == 422


def test_a_document_that_forbids_copying_cannot_be_read(client):
    import pymupdf as fitz
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'NOT FOR COPYING', fontsize=26)
        restricted = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='user',
                                 permissions=fitz.PDF_PERM_PRINT | fitz.PDF_PERM_MODIFY)
    ident = client.post('/api/documents/upload',
                        files={'file': ('Restricted.pdf', restricted, 'application/pdf')},
                        data={'password': 'user'}).json()['id']
    response = client.post(f'/api/documents/{ident}/ai/summary', json={'mode': 'offline'})
    assert response.status_code == 403
    assert response.json()['code'] == 'permission_denied'


# ------------------------------------------- combining the files Explorer selected

def _three_files(folder):
    """Three one-page PDFs in one folder, as if they had been selected together."""
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for index in range(3):
        path = folder / f'part-{index + 1}.pdf'
        with fitz.open() as doc:
            doc.new_page().insert_text((72, 100), f'Part {index + 1}', fontsize=14)
            path.write_bytes(doc.tobytes())
        paths.append(str(path))
    return paths


def test_combine_paths_builds_one_document_out_of_the_selection(desktop, tmp_path):
    paths = _three_files(tmp_path / 'Invoices')
    result = desktop.post('/api/system/combine-paths', json={'paths': paths})
    assert result.status_code == 200, result.text
    info = result.json()
    assert info['pageCount'] == 3
    # Named after the folder, which is usually what the selection is.
    assert info['name'] == 'Invoices.pdf', info['name']
    # And it is an ordinary working document, not a special case.
    assert info['id'] in {doc['id'] for doc in engine.open_documents()}


def test_combine_paths_has_no_file_count_limit(desktop, tmp_path):
    """Regression: the Explorer entry used to refuse a selection past 20 files.

    The only remaining ceiling is the 500 MB combined size guard, so a
    selection of 25 must be read, ordered and combined like any other.
    """
    folder = tmp_path / 'Many invoices'
    folder.mkdir(parents=True)
    paths = []
    for index in range(25):
        path = folder / f'part-{index + 1:02}.pdf'
        with fitz.open() as doc:
            doc.new_page().insert_text((72, 100), f'Part {index + 1}', fontsize=14)
            path.write_bytes(doc.tobytes())
        paths.append(str(path))
    result = desktop.post('/api/system/combine-paths', json={'paths': paths})
    assert result.status_code == 200, result.text
    info = result.json()
    assert info['pageCount'] == 25, info['pageCount']
    first = str(engine.content(info['id'], 0))
    last = str(engine.content(info['id'], 24))
    assert 'Part 1' in first and 'Part 25' in last


def test_combine_paths_keeps_the_order_they_were_given(desktop, tmp_path):
    paths = _three_files(tmp_path / 'Order')
    info = desktop.post('/api/system/combine-paths', json={'paths': paths}).json()
    text = engine.content(info['id'], 0)[0] if isinstance(engine.content(info['id'], 0), list) \
        else engine.content(info['id'], 0)
    assert 'Part 1' in str(text)


def test_combine_paths_refuses_a_file_that_is_not_a_pdf(desktop, tmp_path):
    paths = _three_files(tmp_path / 'Mixed')
    impostor = tmp_path / 'Mixed' / 'notes.pdf'
    impostor.write_text('not a pdf at all', encoding='utf-8')
    result = desktop.post('/api/system/combine-paths', json={'paths': paths + [str(impostor)]})
    assert result.status_code == 422, result.text
    assert 'not a PDF' in result.json()['detail']


def test_combine_paths_needs_some_files(desktop):
    for payload in ({}, {'paths': []}, {'paths': 'one.pdf'}, {'paths': [1, 2]}):
        result = desktop.post('/api/system/combine-paths', json=payload)
        assert result.status_code == 422, (payload, result.text)
