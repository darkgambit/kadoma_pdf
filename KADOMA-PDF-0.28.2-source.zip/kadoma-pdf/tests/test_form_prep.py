"""Preparing a flat PDF so that anybody can fill it in.

What is checked here is the *file*, not the dialog: the fields have to be real
AcroForm widgets (so a reader that has never heard of KADOMA can type in them),
and a date field has to carry the two JavaScript actions Acrobat writes for its
own date picker. The private KADOMA keys are checked as well, because the
application's own calendar still has to recognise the field.
"""
from __future__ import annotations

import pymupdf as fitz
import pytest

from app import engine, form_prep


def flat_document() -> bytes:
    """A page with the four things the scan looks for."""
    with fitz.open() as doc:
        page = doc.new_page(width=595, height=842)
        page.insert_text((60, 120), 'Name:', fontsize=12)
        page.insert_text((60, 160), 'Date of birth:', fontsize=12)
        page.insert_text((60, 200), 'Signature ______________________', fontsize=12)
        page.draw_rect(fitz.Rect(60, 230, 72, 242), color=(0, 0, 0), width=1)
        page.insert_text((80, 240), 'I agree to the terms', fontsize=12)
        return doc.tobytes()


@pytest.fixture
def prepared():
    """The document with the fields added, as bytes."""
    machine = engine.Engine()
    ident = machine.load(flat_document(), 'application form.pdf')['id']
    with machine.opened(machine.get(ident)) as doc:
        found = form_prep.scan(doc)
    machine.operation(ident, {'action': 'prepare_form', 'fields': found})
    return machine.export(ident, 'pdf')[0], found


def test_the_scan_finds_the_four_places_a_field_goes():
    with fitz.open(stream=flat_document(), filetype='pdf') as doc:
        found = form_prep.scan(doc)
    kinds = {item['label']: item['kind'] for item in found}
    assert kinds.get('Name') == 'text', kinds
    assert kinds.get('Date of birth') == 'date', kinds
    assert kinds.get('Signature') == 'text', kinds
    assert 'Checkbox' in kinds, kinds
    # Every candidate has a rectangle on a page, or it cannot be a field.
    for item in found:
        assert item['page'] == 0
        x0, y0, x1, y1 = item['rect']
        assert x1 > x0 and y1 > y0, item


def test_an_empty_page_offers_nothing():
    with fitz.open() as doc:
        doc.new_page().insert_text((60, 90), 'Nothing to fill in on this page.', fontsize=12)
        assert form_prep.scan(doc) == []


def test_the_fields_are_real_widgets_any_reader_can_use(prepared):
    data, found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        widgets = [widget for page in doc for widget in (page.widgets() or [])]
        names = [widget.field_name for widget in widgets]
        assert len(widgets) == len(found), names
        assert len(set(names)) == len(names), f'two fields share a name: {names}'
        # A real /AcroForm in the catalog is what makes the fields fillable in
        # another program; a drawn rectangle would not be.
        assert 'AcroForm' in (doc.xref_object(doc.pdf_catalog()) or '')
        assert any(widget.field_type_string == 'CheckBox' for widget in widgets), names
        assert any(widget.field_type_string == 'Text' for widget in widgets), names


def test_a_date_field_carries_acrobats_own_date_actions(prepared):
    data, _found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        dates = [widget for page in doc for widget in (page.widgets() or [])
                 if doc.xref_get_key(widget.xref, engine.DATE_KIND_KEY)[1] == 'date']
        assert dates, 'no field was marked as a date'
        widget = dates[0]
        kind, actions = doc.xref_get_key(widget.xref, 'AA')
        assert kind == 'dict', actions
        assert 'AFDate_FormatEx' in actions, actions
        assert 'AFDate_KeystrokeEx' in actions, actions
        # The format written for Acrobat matches the one the application uses,
        # so the two do not disagree about what a date looks like.
        stored = doc.xref_get_key(widget.xref, engine.DATE_FORMAT_KEY)[1]
        assert form_prep.ACROBAT_FORMATS[stored] in actions, (stored, actions)


def test_a_repeated_label_gets_its_own_name():
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((60, 120), 'Name:', fontsize=12)
        page.insert_text((60, 180), 'Name:', fontsize=12)
        found = form_prep.scan(doc)
        data = doc.tobytes()
    assert len(found) == 2, found
    machine = engine.Engine()
    ident = machine.load(data, 'two names.pdf')['id']
    machine.operation(ident, {'action': 'prepare_form', 'fields': found})
    with fitz.open(stream=machine.export(ident, 'pdf')[0], filetype='pdf') as result:
        names = [widget.field_name for page in result for widget in (page.widgets() or [])]
    assert len(names) == 2 and len(set(names)) == 2, names


def test_preparing_a_form_is_one_undo_step(prepared):
    machine = engine.Engine()
    ident = machine.load(flat_document(), 'application form.pdf')['id']
    with machine.opened(machine.get(ident)) as doc:
        found = form_prep.scan(doc)
    before = machine.meta(ident)['formCount']
    after = machine.operation(ident, {'action': 'prepare_form', 'fields': found})
    assert after['formCount'] == before + len(found)
    restored = machine.history(ident, 'undo')
    assert restored['formCount'] == before, 'undo did not take the whole form back off'


# ------------------------------------------- what a reader needs to be able to type
# A widget with a rectangle and a name is enough for Chrome and MuPDF, which is
# why these gaps were invisible here. Acrobat rebuilds a field's appearance from
# the document-wide /DR and cannot do it without those fonts; and a widget that
# does not name its page cannot be placed. Both are asserted on the exported
# file, because that is the file the other application opens.

def test_the_exported_form_carries_the_fonts_a_reader_rebuilds_it_from(prepared):
    data, _found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        kind, value = doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')
        assert kind == 'dict', kind
        assert '/DR' in value, value
        assert '/Font' in value, value
        for name in ('Helv', 'ZaDb'):
            assert f'/{name}' in value, (name, value)
        # The default appearance has to name a font that /DR actually provides.
        assert '/DA' in value and '/Helv' in value.split('/DA', 1)[1][:40], value
        assert '/NeedAppearances false' in value, value


def test_every_widget_names_the_page_it_sits_on(prepared):
    data, found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        assert len(doc) >= 1
        for page in doc:
            for widget in page.widgets() or []:
                kind, value = doc.xref_get_key(widget.xref, 'P')
                assert kind == 'xref', (widget.field_name, kind)
                assert value == f'{page.xref} 0 R', (widget.field_name, value)


def test_the_field_list_names_every_widget_on_every_page(prepared):
    data, _found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        listed = form_prep._existing_field_xrefs(doc)
        on_pages = [widget.xref for page in doc for widget in (page.widgets() or [])]
        assert sorted(listed) == sorted(on_pages), (listed, on_pages)


def test_asking_twice_changes_nothing(prepared):
    data, _found = prepared
    with fitz.open(stream=data, filetype='pdf') as doc:
        before = doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')[1]
        form_prep.ensure_acroform(doc)
        again = doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')[1]
    assert again == before, 'a second pass rewrote the form differently'


def test_a_document_with_no_fields_is_left_alone():
    with fitz.open() as doc:
        doc.new_page().insert_text((60, 100), 'Nothing to fill in here', fontsize=12)
        assert form_prep.ensure_acroform(doc)['widgets'] == 0
        assert doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')[0] == 'null'


def test_an_xfa_form_is_not_rewritten_around():
    # A dynamic XFA document is driven by its own XML. Rewriting the AcroForm
    # beside it would break the file rather than make its fields work.
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((60, 100), 'Name:', fontsize=12)
        widget = fitz.Widget()
        widget.rect, widget.field_name = fitz.Rect(120, 90, 260, 104), 'Name'
        widget.field_type, widget.field_value = fitz.PDF_WIDGET_TYPE_TEXT, ''
        page.add_widget(widget)
        doc.xref_set_key(doc.pdf_catalog(), 'AcroForm',
                         '<</Fields[]/XFA 99 0 R>>')
        result = form_prep.ensure_acroform(doc)
        assert result['resources'] is False and result.get('xfa') is True
        assert '/XFA' in doc.xref_get_key(doc.pdf_catalog(), 'AcroForm')[1]
