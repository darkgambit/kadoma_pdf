"""The icon set, which now comes from one supplied image.

The artwork is a single 1080 px JPEG. Everything the application needs — the
Windows ICO, the macOS ICNS, the in-app mark and the browser tab — is resampled
from it by `scripts/make_icons.py`, so these tests check the sizes that the
packaging actually asks for and the transparency that stops a white square
appearing on a dark taskbar.
"""
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'
STATIC = ROOT / 'app' / 'static'


def test_the_windows_icon_has_every_size_windows_asks_for():
    with Image.open(ASSETS / 'KADOMA.ico') as icon:
        sizes = icon.info.get('sizes', set())
    for wanted in ((16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)):
        assert wanted in sizes, f'the ICO is missing the {wanted[0]} px size'


def test_the_mac_icon_is_a_real_icns_with_png_chunks():
    raw = (ASSETS / 'KADOMA.icns').read_bytes()
    assert raw[:4] == b'icns'
    assert int.from_bytes(raw[4:8], 'big') == len(raw)
    # 128, 256, 512 and 1024 px, as PNG payloads.
    for code in (b'ic07', b'ic08', b'ic09', b'ic10'):
        assert code in raw, f'the ICNS is missing {code!r}'
    with Image.open(ASSETS / 'KADOMA.icns') as icon:
        assert icon.size[0] >= 128


def test_the_master_icon_is_square_and_transparent_at_the_corners():
    with Image.open(ASSETS / 'KADOMA.png') as icon:
        assert icon.size == (1024, 1024)
        assert icon.mode == 'RGBA'
        assert icon.getpixel((2, 2))[3] == 0, 'the rounded corner is not transparent'
        assert icon.getpixel((512, 512))[3] == 255, 'the middle of the icon is transparent'


def test_the_mark_used_in_the_window_is_small_and_transparent():
    with Image.open(STATIC / 'logo.png') as mark:
        assert mark.size == (128, 128)
        assert mark.mode == 'RGBA'
        assert mark.getpixel((1, 1))[3] == 0
