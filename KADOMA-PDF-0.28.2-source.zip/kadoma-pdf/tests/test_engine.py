from io import BytesIO
import zipfile
import pytest
import pymupdf as fitz
from PIL import Image, ImageDraw, ImageFont
from support.demo_document import make_demo
from app.engine import (Engine, MAX_DOCUMENTS, PDFError, cell_value, find_soffice,
                        find_tesseract, safe_name)


@pytest.fixture
def engine():
    return Engine()


@pytest.fixture
def demo(engine):
    # The application ships no sample document, so the tests build the report
    # they work on and open it the way a person would.
    return engine.load(make_demo(), 'Quarterly performance.pdf')


def text_in(engine, ident):
    return engine.export(ident, 'txt')[0].decode('utf-8')


def picture(fill='red'):
    image = Image.new('RGB', (400, 180), fill)
    out = BytesIO()
    image.save(out, 'PNG')
    return out.getvalue()


def test_demo_is_real_pdf_with_tables_images_and_forms(engine, demo):
    assert demo['pageCount'] == 4
    assert demo['wordCount'] > 300
    assert demo['imageCount'] == 1
    assert demo['formCount'] == 3
    assert engine.render(demo['id'], 0, .2).startswith(b'\x89PNG')
    assert engine.search(demo['id'], 'Quarterly')[0]['page'] == 0


def test_create_add_text_unicode_and_undo_redo(engine):
    info = engine.blank()
    ident = info['id']
    info = engine.operation(ident, {'action':'add_text','page':0,'rect':[40,40,300,95], 'text':'Café — local editing', 'size':16})
    assert info['canUndo'] and info['modified']
    assert 'Café' in text_in(engine, ident)
    engine.operation(ident, {'action':'undo'})
    assert 'Café' not in text_in(engine, ident)
    engine.operation(ident, {'action':'redo'})
    assert 'Café' in text_in(engine, ident)


def test_replace_removes_original_text_and_failure_is_atomic(engine, demo):
    ident = demo['id']
    span = next(x for x in engine.content(ident, 0)['spans'] if x['text'] == 'Quarterly')
    engine.operation(ident, {'action':'replace_text','page':0,'rect':span['rect'],'text':'Annual','size':32})
    assert 'Annual' in text_in(engine, ident)
    assert not engine.search(ident, 'Quarterly')
    before = engine.get(ident).data
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'add_text','page':0,'rect':[10,10,13,13],'text':'x'*5000,'size':96})
    assert engine.get(ident).data == before


def test_editable_runs_join_sentences_but_separate_table_cells(engine, demo):
    ident = demo['id']
    content = engine.content(ident, 0)
    assert content['spans'] and content['runs']
    runs = {r['text']: r for r in content['runs']}
    # A whole sentence is one editable unit.
    assert any('A clear view of revenue, expenses' in text for text in runs)
    # Table cells and a right-aligned page label stay independently editable.
    assert 'Department' in runs and 'Revenue' in runs and 'Products' in runs
    assert runs['Department']['rect'][2] < runs['Revenue']['rect'][0]
    # Every span points at the run that contains it, and fonts map to a substitute family.
    for span in content['spans']:
        assert content['runs'][span['run']]['rect'][0] <= span['rect'][0] + .01
        assert span['family'] in ('sans-serif', 'serif', 'monospace')


def test_direct_edit_can_delete_text_and_undo_restores_it(engine, demo):
    ident = demo['id']
    run = next(r for r in engine.content(ident, 1)['runs'] if 'NL-2048-9931' in r['text'])
    engine.operation(ident, {'action': 'replace_text', 'page': 1, 'rect': run['rect'], 'text': '', 'size': run['size']})
    assert not engine.search(ident, 'NL-2048-9931')
    assert 'Account reference' not in text_in(engine, ident)
    assert engine.meta(ident)['canUndo']
    engine.operation(ident, {'action': 'undo'})
    assert engine.search(ident, 'NL-2048-9931')
    # Adding brand-new text still refuses to create an empty box.
    with pytest.raises(PDFError):
        engine.operation(ident, {'action': 'add_text', 'page': 1, 'rect': [40, 40, 300, 80], 'text': '   '})


def test_longer_replacement_grows_into_free_space_and_keeps_font_size(engine, demo):
    ident = demo['id']
    run = next(r for r in engine.content(ident, 0)['runs'] if r['text'] == 'Quarterly')
    assert round(run['size'], 1) == 32.0
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': run['rect'],
                             'text': 'Quarterly performance summary', 'size': 32, 'color': run['color'], 'expand': True})
    with fitz.open(stream=engine.export(ident, 'pdf')[0], filetype='pdf') as doc:
        spans = [s for b in doc[0].get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
        written = next(s for s in spans if 'Quarterly performance summary' in s['text'])
        assert round(written['size'], 1) == 32.0, 'the replacement shrank instead of using free space'
        assert written['bbox'][2] - written['bbox'][0] > (run['rect'][2] - run['rect'][0]) + 100
        assert not any(s['text'].strip() == 'Quarterly' for s in spans)


def test_replacement_never_grows_over_neighbouring_text(engine, demo):
    ident = demo['id']
    run = next(r for r in engine.content(ident, 0)['runs'] if r['text'] == 'Department')
    neighbour = next(r for r in engine.content(ident, 0)['runs'] if r['text'] == 'Revenue')
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': run['rect'],
                             'text': 'Department and reporting group', 'size': run['size'], 'expand': True})
    with fitz.open(stream=engine.export(ident, 'pdf')[0], filetype='pdf') as doc:
        spans = [s for b in doc[0].get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
        written = next(s for s in spans if 'Department and reporting' in s['text'])
        assert written['bbox'][2] <= neighbour['rect'][0] + 1, 'the grown box overlapped the next table cell'
        assert any(s['text'].strip() == 'Revenue' for s in spans), 'the neighbouring cell was destroyed'


def test_replace_text_expansion_can_be_switched_off(engine, demo):
    ident = demo['id']
    run = next(r for r in engine.content(ident, 0)['runs'] if r['text'] == 'Quarterly')
    width = run['rect'][2] - run['rect'][0]
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': run['rect'],
                             'text': 'Quarterly report', 'size': 32, 'expand': False})
    with fitz.open(stream=engine.export(ident, 'pdf')[0], filetype='pdf') as doc:
        spans = [s for b in doc[0].get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
        # With expansion off the box keeps its original width, so the engine has
        # to shrink (and wrap) the text instead of growing into free space.
        shrunk = [s for s in spans if s['size'] < 32 and 128 < s['bbox'][1] < 185]
        joined = ' '.join(s['text'] for s in shrunk)
        assert 'Quarterly' in joined and 'report' in joined, f'wrapped replacement text missing: {joined!r}'
        assert all(s['bbox'][2] - s['bbox'][0] <= width + 2 for s in shrunk), 'a fixed box must not grow'
        assert not any(s['text'].strip() == 'Quarterly' and s['size'] > 31 for s in spans)


def test_rotated_coordinates_and_new_text(engine, demo):
    ident = demo['id']
    engine.operation(ident, {'action':'rotate','pages':[0],'angle':90})
    assert engine.meta(ident)['pages'][0] == {'width':792.0,'height':612.0,'rotation':90}
    engine.operation(ident, {'action':'add_text','page':0,'rect':[100,80,330,125],'text':'Rotated display','size':16})
    match = engine.search(ident, 'Rotated display')[0]
    assert 95 <= match['rect'][0] <= 110
    assert 75 <= match['rect'][1] <= 105
    assert match['rect'][2] < 335


def test_reorder_duplicate_delete_insert_and_keep_last_page(engine, demo):
    ident = demo['id']
    engine.operation(ident, {'action':'reorder','pages':[3,0,1,2]})
    assert engine.search(ident, 'A clear path')[0]['page'] == 0
    engine.operation(ident, {'action':'duplicate','pages':[1]})
    assert engine.meta(ident)['pageCount'] == 5
    assert engine.search(ident, 'Quarterly')[-1]['page'] == 4
    engine.operation(ident, {'action':'delete_pages','pages':[4]})
    engine.operation(ident, {'action':'insert_blank','position':2})
    assert engine.meta(ident)['pageCount'] == 5
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'delete_pages','pages':list(range(5))})
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'reorder','pages':[0,0,1,2,3]})


def test_merge_pdf_and_image_is_atomic(engine, demo):
    ident = demo['id']
    other = engine.blank('Other.pdf')
    other_bytes = engine.export(other['id'], 'pdf')[0]
    engine.merge(ident, [(other_bytes,'Other.pdf'),(picture(),'image.png')])
    assert engine.meta(ident)['pageCount'] == 6
    before = engine.get(ident).data
    with pytest.raises(PDFError):
        engine.merge(ident, [(other_bytes,'Other.pdf'),(b'not a PDF','broken.pdf')])
    assert engine.get(ident).data == before


def test_insert_replace_and_delete_embedded_image(engine):
    ident = engine.blank()['id']
    engine.insert_image(ident, 0, picture('red'), [50,50,300,180])
    info = engine.content(ident, 0)['images'][0]
    original = engine.render(ident, 0, .4)
    engine.insert_image(ident, 0, picture('blue'), None, xref=info['xref'])
    assert engine.render(ident, 0, .4) != original
    current = engine.content(ident, 0)['images'][0]
    engine.operation(ident, {'action':'delete_image','page':0,'xref':current['xref']})
    data = engine.render(ident, 0, .4)
    assert data != original


def test_comments_highlights_and_removal(engine, demo):
    ident = demo['id']
    engine.operation(ident, {'action':'comment','page':0,'x':40,'y':400,'text':'Review this total.'})
    engine.operation(ident, {'action':'highlight','page':0,'rect':[45,580,530,600]})
    annotations = engine.content(ident,0)['annotations']
    assert len(annotations) == 2
    assert any(a['content'] == 'Review this total.' for a in annotations)
    engine.operation(ident, {'action':'delete_annotation','page':0,'xref':annotations[0]['xref']})
    assert len(engine.content(ident,0)['annotations']) == 1


def test_real_redaction_removes_content_metadata_attachments_and_history(engine, demo):
    ident = demo['id']
    secret = 'NL-2048-9931'
    match = engine.search(ident, secret)[0]
    engine.operation(ident, {'action':'comment','page':1,'x':100,'y':300,'text':'A prior comment'})
    assert engine.meta(ident)['canUndo']
    engine.operation(ident, {'action':'redact','page':1,'rect':match['rect']})
    assert not engine.search(ident, secret)
    assert secret not in text_in(engine, ident)
    assert not engine.meta(ident)['canUndo']
    assert not engine.meta(ident)['canRedo']
    with fitz.open(stream=engine.export(ident,'pdf')[0], filetype='pdf') as result:
        assert not result.metadata['title']
        assert secret not in ''.join(p.get_text() for p in result)
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'undo'})


def test_redaction_removes_overlapping_field_value(engine):
    ident = engine.blank()['id']
    engine.operation(ident, {'action':'add_field','page':0,'rect':[50,50,250,90],'type':'text','name':'sensitive'})
    xref = engine.content(ident,0)['widgets'][0]['xref']
    engine.operation(ident, {'action':'fill_forms','values':{str(xref):'SECRET_FIELD_VALUE'}})
    engine.operation(ident, {'action':'redact','page':0,'rect':[45,45,260,100]})
    assert not engine.content(ident,0)['widgets']
    with fitz.open(stream=engine.export(ident,'pdf')[0], filetype='pdf') as doc:
        assert not list(doc[0].widgets() or [])


def test_create_all_form_types_and_fill(engine):
    ident = engine.blank()['id']
    for type_,name,rect in [('text','name',[50,50,250,80]),('checkbox','yes',[50,100,68,118]),('dropdown','status',[50,140,250,170])]:
        engine.operation(ident, {'action':'add_field','page':0,'type':type_,'name':name,'rect':rect,'choices':['Pending','Approved']})
    widgets = engine.content(ident,0)['widgets']
    values = {str(w['xref']):'Alex' if w['name']=='name' else True if w['name']=='yes' else 'Approved' for w in widgets}
    engine.operation(ident, {'action':'fill_forms','values':values})
    results = {w['name']:w['value'] for w in engine.content(ident,0)['widgets']}
    assert results['name'] == 'Alex'
    assert results['status'] == 'Approved'
    assert results['yes'] != 'Off'
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'add_field','page':0,'type':'text','name':'name','rect':[50,200,250,230]})


def test_encryption_owner_permissions_and_preservation(engine, demo):
    data = engine.export(demo['id'],'protected',{'openPassword':'readpass','ownerPassword':'ownerpass','allowCopying':False,'allowEditing':False})[0]
    with pytest.raises(PDFError) as exc:
        engine.load(data,'locked.pdf')
    assert exc.value.code == 'password_required'
    user = engine.load(data,'locked.pdf','readpass')
    assert user['encrypted'] and not user['owner'] and not user['canEdit'] and not user['canCopy']
    with pytest.raises(PDFError):
        engine.operation(user['id'], {'action':'rotate','pages':[0]})
    with pytest.raises(PDFError):
        engine.export(user['id'], 'txt')
    still_encrypted = engine.export(user['id'],'pdf')[0]
    with fitz.open(stream=still_encrypted, filetype='pdf') as doc:
        assert doc.needs_pass
        assert doc.authenticate('readpass')
    owner = engine.load(data,'locked.pdf','ownerpass')
    assert owner['owner'] and owner['canEdit']
    engine.operation(owner['id'], {'action':'rotate','pages':[0]})
    with fitz.open(stream=engine.export(owner['id'],'pdf')[0], filetype='pdf') as doc:
        assert doc.needs_pass
        assert doc.authenticate('readpass')
        assert doc[0].rotation == 90
    with pytest.raises(PDFError):
        engine.export(owner['id'],'protected',{'openPassword':'samepass','ownerPassword':'samepass'})


@pytest.mark.parametrize('format,signature', [('pdf',b'%PDF'),('docx',b'PK'),('xlsx',b'PK'),('pptx',b'PK'),('images',b'PK'),('split',b'PK')])
def test_actual_export_formats(engine, demo, format, signature):
    data,name,mime = engine.export(demo['id'], format, {'pages':[0]})
    assert data.startswith(signature)
    assert len(data) > 1000
    if format == 'images':
        with zipfile.ZipFile(BytesIO(data)) as archive:
            assert len(archive.namelist()) == 1
            assert archive.read(archive.namelist()[0]).startswith(b'\x89PNG')
    if format == 'split':
        with zipfile.ZipFile(BytesIO(data)) as archive:
            with fitz.open(stream=archive.read(archive.namelist()[0]),filetype='pdf') as doc:
                assert len(doc) == 1


def test_excel_tables_numbers_and_formula_sanitization(engine, demo):
    from openpyxl import load_workbook
    data,_,_ = engine.export(demo['id'],'xlsx',{'pages':[0]})
    workbook = load_workbook(BytesIO(data), data_only=False)
    assert workbook['Page 1 Table 1']['B2'].value == 142375
    assert workbook['Page 1 Table 1']['D2'].value == .5
    assert cell_value('=HYPERLINK("malicious")').startswith("'")
    assert cell_value('+cmd').startswith("'")
    assert cell_value('@SUM(A1)').startswith("'")
    assert cell_value('-42.5') == -42.5
    assert cell_value('$1,250') == 1250
    assert cell_value('12,45') == '12,45'
    assert cell_value('1.234,56') == '1.234,56'
    assert cell_value('00123') == '00123'
    assert cell_value('12345678901234567') == '12345678901234567'


def test_word_is_editable_and_powerpoint_is_explicitly_raster(engine, demo):
    from docx import Document
    from pptx import Presentation
    word = Document(BytesIO(engine.export(demo['id'],'docx',{'pages':[0]})[0]))
    assert any('Quarterly' in p.text for p in word.paragraphs)
    assert word.tables
    powerpoint = Presentation(BytesIO(engine.export(demo['id'],'pptx',{'pages':[0,1]})[0]))
    assert len(powerpoint.slides) == 2
    assert all(len(slide.shapes) == 1 for slide in powerpoint.slides)
    assert 'not editable' in powerpoint.slides[0].notes_slide.notes_text_frame.text


def test_local_html_images_and_input_validation(engine):
    data = b'<h1>Local webpage</h1><p>Hello offline world.</p><script>secret_script_should_not_appear</script><img src="https://example.invalid/tracker">'
    ident = engine.load(data,'page.html')['id']
    assert 'Hello offline world' in text_in(engine,ident)
    assert 'secret_script' not in text_in(engine,ident)
    assert engine.load(picture(),'test.jpg')['pageCount'] == 1
    with pytest.raises(PDFError):
        engine.load(b'garbage','bad.pdf')
    with pytest.raises(PDFError):
        engine.load(b'a','unknown.exe')
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'rotate','pages':[-1]})
    assert safe_name('../../private.pdf') == 'private.pdf'
    assert '/' not in safe_name('a\\b.pdf')


@pytest.mark.skipif(not find_soffice(), reason='LibreOffice is an optional external engine')
def test_office_creation_from_word_excel_and_powerpoint(engine):
    from docx import Document
    from openpyxl import Workbook
    from pptx import Presentation
    word = Document(); word.add_heading('Office conversion sample',0); word.add_paragraph('WORD_LOCAL_2026')
    out = BytesIO(); word.save(out)
    ident = engine.load(out.getvalue(),'sample.docx')['id']
    assert 'WORD_LOCAL_2026' in text_in(engine,ident)
    book = Workbook(); book.active.append(['Reference','Amount']); book.active.append(['EXCEL_LOCAL_2026',1200])
    book.active.column_dimensions['A'].width = 30
    out = BytesIO(); book.save(out)
    ident = engine.load(out.getvalue(),'sample.xlsx')['id']
    assert 'EXCEL_LOCAL_2026' in text_in(engine,ident)
    presentation = Presentation(); slide = presentation.slides.add_slide(presentation.slide_layouts[0]); slide.shapes.title.text='POWERPOINT_LOCAL_2026'
    out = BytesIO(); presentation.save(out)
    ident = engine.load(out.getvalue(),'sample.pptx')['id']
    assert 'POWERPOINT_LOCAL_2026' in text_in(engine,ident)


@pytest.mark.skipif(not find_tesseract(), reason='Tesseract is an optional external engine')
def test_ocr_creates_saved_searchable_text(engine):
    im = Image.new('RGB',(1600,650),'white')
    draw = ImageDraw.Draw(im)
    draw.text((90,100),'INVOICE 2038',font=ImageFont.load_default(size=90),fill='black')
    draw.text((90,260),'TOTAL 1234',font=ImageFont.load_default(size=90),fill='black')
    out = BytesIO(); im.save(out,'PNG')
    ident = engine.load(out.getvalue(),'scan.png')['id']
    assert not engine.search(ident,'INVOICE')
    engine.ocr(ident,[0],'eng')
    assert engine.search(ident,'INVOICE')
    with fitz.open(stream=engine.export(ident,'pdf')[0],filetype='pdf') as doc:
        assert 'INVOICE' in doc[0].get_text()


def test_redaction_strips_real_embedded_files_and_metadata(engine):
    with fitz.open() as original:
        page = original.new_page()
        page.insert_text((50,80),'REMOVE_THIS_98765',fontsize=16)
        original.embfile_add('hidden.txt',b'REMOVE_THIS_98765 in a hidden attachment')
        original.set_metadata({'title':'Confidential','subject':'REMOVE_THIS_98765'})
        data = original.tobytes()
    ident = engine.load(data,'sensitive.pdf')['id']
    rect = engine.search(ident,'REMOVE_THIS_98765')[0]['rect']
    engine.operation(ident,{'action':'redact','page':0,'rect':rect})
    with fitz.open(stream=engine.export(ident,'pdf')[0],filetype='pdf') as result:
        assert result.embfile_count() == 0
        assert not result.metadata['title'] and not result.metadata['subject']
        assert 'REMOVE_THIS_98765' not in result[0].get_text()


def test_redaction_removes_actual_underlying_image_pixels(engine):
    ident = engine.blank()['id']
    engine.insert_image(ident,0,picture('red'),[50,50,450,230])
    engine.operation(ident,{'action':'redact','page':0,'rect':[100,80,300,190]})
    with fitz.open(stream=engine.export(ident,'pdf')[0],filetype='pdf') as result:
        images = result[0].get_images()
        assert images
        pixels = Image.open(BytesIO(result.extract_image(images[0][0])['image'])).convert('RGB')
        # A mere black overlay would leave this source pixel red. MuPDF
        # replaces selected raster pixels with white underneath the black fill.
        assert pixels.getpixel((150,90)) == (255,255,255)
        assert pixels.getpixel((10,10)) == (255,0,0)


def test_form_filling_allowed_without_copying_permission(engine):
    with fitz.open() as doc:
        page = doc.new_page()
        widget=fitz.Widget();widget.field_name='allowed_name';widget.field_type=fitz.PDF_WIDGET_TYPE_TEXT
        widget.rect=fitz.Rect(50,50,250,85);widget.field_value=''
        page.add_widget(widget)
        data=doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256,user_pw='reader-pass',owner_pw='owner-pass',
                         permissions=fitz.PDF_PERM_FORM|fitz.PDF_PERM_ACCESSIBILITY)
    info=engine.load(data,'forms.pdf','reader-pass')
    assert not info['canCopy'] and info['canFill']
    content=engine.content(info['id'],0)
    assert not content['spans'] and content['widgets']
    engine.operation(info['id'],{'action':'fill_forms','values':{str(content['widgets'][0]['xref']):'Allowed'}})
    assert engine.content(info['id'],0)['widgets'][0]['value']=='Allowed'


def test_permission_options_reject_truthy_string_values(engine, demo):
    with pytest.raises(PDFError):
        engine.export(demo['id'],'protected',{'openPassword':'reader-pass','ownerPassword':'owner-pass','allowCopying':'false'})


def test_duplicated_form_fields_are_unique_and_independent(engine, demo):
    ident=demo['id']
    engine.operation(ident,{'action':'duplicate','pages':[3]})
    assert engine.meta(ident)['formCount']==6
    original=engine.content(ident,3)['widgets']
    copied=engine.content(ident,4)['widgets']
    assert not set(w['name'] for w in original) & set(w['name'] for w in copied)
    text=next(w for w in copied if w['type']==7)
    engine.operation(ident,{'action':'fill_forms','values':{str(text['xref']):'Independent copy'}})
    assert next(w for w in engine.content(ident,3)['widgets'] if w['type']==7)['value']==''
    assert next(w for w in engine.content(ident,4)['widgets'] if w['type']==7)['value']=='Independent copy'


def test_assembly_permission_separate_from_text_modification(engine):
    with fitz.open() as doc:
        doc.new_page()
        data=doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256,user_pw='reader-pass',owner_pw='owner-pass',
                         permissions=fitz.PDF_PERM_ASSEMBLE|fitz.PDF_PERM_ACCESSIBILITY)
    info=engine.load(data,'assemble-only.pdf','reader-pass')
    assert info['canAssemble'] and not info['canEdit']
    engine.operation(info['id'],{'action':'rotate','pages':[0]})
    with pytest.raises(PDFError):
        engine.operation(info['id'],{'action':'add_text','page':0,'rect':[40,40,200,80],'text':'Not permitted'})


# ------------------------------------------------- date fields and clearing
# A PDF has no date field type, so a date field is a plain text field that
# carries two private keys. These tests exist because that marker is invisible
# to every other PDF application: if it fails to survive a save, the field
# silently turns back into an ordinary text box and the calendar disappears.

def field_xrefs(engine, ident, page=0):
    """Widget xrefs by field name, read fresh.

    Saving renumbers xrefs — a second field moved from 8 to 7 after an
    unrelated edit — so an xref has to be re-read before every use instead of
    being captured once. The interface does the same thing: it re-fetches the
    page after every change and only ever sends the xrefs it was just handed.
    """
    return {w['name']: str(w['xref']) for w in engine.content(ident, page)['widgets']}


def field_values(engine, ident, page=0):
    return {w['name']: w['value'] for w in engine.content(ident, page)['widgets']}

def test_date_field_survives_save_and_reopen(engine):
    ident = engine.blank()['id']
    engine.operation(ident, {'action':'add_field','page':0,'type':'date','name':'signed_on',
                             'rect':[50,50,250,80],'dateFormat':'DD/MM/YYYY'})
    widget = engine.content(ident, 0)['widgets'][0]
    assert widget['kind'] == 'date'
    assert widget['dateFormat'] == 'DD/MM/YYYY'
    # The marker has to survive a full save and reload, not just the open
    # document, or it is lost the moment the file is written.
    again = engine.load(engine.export(ident, 'pdf')[0], 'dated.pdf')
    reloaded = engine.content(again['id'], 0)['widgets'][0]
    assert reloaded['kind'] == 'date'
    assert reloaded['dateFormat'] == 'DD/MM/YYYY'


def test_date_field_refuses_free_text_and_normalises_real_dates(engine):
    ident = engine.blank()['id']
    engine.operation(ident, {'action':'add_field','page':0,'type':'date','name':'due',
                             'rect':[50,50,250,80],'dateFormat':'DD/MM/YYYY'})
    # Free text, and dates that do not exist: the 31st of February and a 32nd
    # day must both be refused rather than quietly rolled over into March.
    for bad in ('not a date', '31/02/2027', '32/01/2027', '00/01/2027', '1/13/2027'):
        with pytest.raises(PDFError) as exc:
            engine.operation(ident, {'action':'fill_forms','values':{field_xrefs(engine, ident)['due']:bad}})
        assert 'date' in str(exc.value), f'{bad!r} was refused for the wrong reason: {exc.value}'
        assert field_values(engine, ident)['due'] in (None, '')
    # An ISO date is accepted in any format and written back in the field's own
    # format, so a value typed elsewhere is never silently rejected.
    engine.operation(ident, {'action':'fill_forms','values':{field_xrefs(engine, ident)['due']:'2027-12-31'}})
    assert field_values(engine, ident)['due'] == '31/12/2027'
    # A short but real date is padded, so what is displayed never depends on
    # how it was typed.
    engine.operation(ident, {'action':'fill_forms','values':{field_xrefs(engine, ident)['due']:'5/3/2027'}})
    assert field_values(engine, ident)['due'] == '05/03/2027'
    # An empty value is how a date field is left blank, and must not be refused.
    engine.operation(ident, {'action':'fill_forms','values':{field_xrefs(engine, ident)['due']:''}})
    assert field_values(engine, ident)['due'] in (None, '')


def test_erasing_a_filled_value_really_removes_it(engine):
    # The same PyMuPDF trap as clearing, reached a different way: somebody fills
    # a field, then deletes what they typed and applies again. An empty string
    # used to be silently ignored, so the field kept showing the old value and
    # the old text stayed inside the file — which matters most for exactly the
    # fields people erase, like a name they decided not to share.
    ident = engine.blank()['id']
    for type_, name in (('text', 'note'), ('date', 'on_date')):
        engine.operation(ident, {'action':'add_field','page':0,'type':type_,'name':name,
                                 'rect':[50,50,250,80],'dateFormat':'DD/MM/YYYY'})
    names = field_xrefs(engine, ident)
    engine.operation(ident, {'action':'fill_forms',
                             'values':{names['note']:'ERASE-ME-11', names['on_date']:'05/03/2027'}})
    values = field_values(engine, ident)
    assert values['note'] == 'ERASE-ME-11' and values['on_date'] == '05/03/2027'

    names = field_xrefs(engine, ident)
    engine.operation(ident, {'action':'fill_forms',
                             'values':{names['note']:'', names['on_date']:''}})
    values = field_values(engine, ident)
    assert values['note'] in (None, ''), f'the text field kept {values["note"]!r}'
    assert values['on_date'] in (None, ''), f'the date field kept {values["on_date"]!r}'
    raw = engine.export(ident, 'pdf')[0]
    assert b'ERASE-ME-11' not in raw, 'the erased value is still inside the saved file'

    engine.operation(ident, {'action':'undo'})
    values = field_values(engine, ident)
    assert values['note'] == 'ERASE-ME-11' and values['on_date'] == '05/03/2027'


def test_the_same_typed_date_means_different_days_in_different_formats(engine):
    # 03/05/2027 is the 3rd of May in one format and the 5th of March in the
    # other. The field's own format decides, which is the whole reason a date
    # field carries one.
    ident = engine.blank()['id']
    for name, label in (('day_first', 'DD/MM/YYYY'), ('month_first', 'MM/DD/YYYY')):
        engine.operation(ident, {'action':'add_field','page':0,'type':'date','name':name,
                                 'rect':[50,50,250,80],'dateFormat':label})
    # 13/05/2027 only exists as a date when the day comes first, and 05/13/2027
    # only when the month does, so the two formats cannot be confused.
    with pytest.raises(PDFError) as exc:
        engine.operation(ident, {'action':'fill_forms',
                                 'values':{field_xrefs(engine, ident)['month_first']:'13/05/2027'}})
    assert 'date' in str(exc.value), f'refused for the wrong reason: {exc.value}'
    engine.operation(ident, {'action':'fill_forms',
                             'values':{field_xrefs(engine, ident)['day_first']:'13/05/2027'}})
    assert field_values(engine, ident)['day_first'] == '13/05/2027'
    with pytest.raises(PDFError) as exc:
        engine.operation(ident, {'action':'fill_forms',
                                 'values':{field_xrefs(engine, ident)['day_first']:'05/13/2027'}})
    assert 'date' in str(exc.value), f'refused for the wrong reason: {exc.value}'
    engine.operation(ident, {'action':'fill_forms',
                             'values':{field_xrefs(engine, ident)['month_first']:'05/13/2027'}})
    assert field_values(engine, ident)['month_first'] == '05/13/2027'


def test_clear_fields_empties_every_field_type_and_is_undoable(engine):
    ident = engine.blank()['id']
    for type_, name, rect in [('text','name',[50,50,250,80]), ('checkbox','agree',[50,100,68,118]),
                              ('dropdown','status',[50,140,250,170]), ('date','signed',[50,190,250,220])]:
        engine.operation(ident, {'action':'add_field','page':0,'type':type_,'name':name,
                                 'rect':rect,'choices':['Pending','Approved'],'dateFormat':'YYYY-MM-DD'})
    widgets = engine.content(ident, 0)['widgets']
    values = {}
    for widget in widgets:
        if widget['type'] == 2:
            values[str(widget['xref'])] = True
        elif widget['type'] in (3, 4):
            values[str(widget['xref'])] = 'Approved'
        elif widget['kind'] == 'date':
            values[str(widget['xref'])] = '2027-05-03'
        else:
            values[str(widget['xref'])] = 'Alex'
    engine.operation(ident, {'action':'fill_forms','values':values})
    filled = {w['name']: w['value'] for w in engine.content(ident, 0)['widgets']}
    assert filled['name'] == 'Alex' and filled['status'] == 'Approved'
    assert filled['agree'] not in (None, '', 'Off') and filled['signed'] == '2027-05-03'

    info = engine.operation(ident, {'action':'clear_fields'})
    assert info['canUndo'] and info['modified']
    cleared = {w['name']: w['value'] for w in engine.content(ident, 0)['widgets']}
    assert cleared['name'] in (None, '') and cleared['signed'] in (None, '')
    assert cleared['agree'] in (None, '', 'Off')
    # A choice field keeps a selected index as well as a value; leaving the
    # index behind re-selects the old option in some readers.
    assert engine.content(ident, 0)['widgets'][2]['value'] in (None, '')
    # The fields themselves, and the page, are untouched.
    assert len(engine.content(ident, 0)['widgets']) == 4
    assert engine.meta(ident)['formCount'] == 4

    engine.operation(ident, {'action':'undo'})
    restored = {w['name']: w['value'] for w in engine.content(ident, 0)['widgets']}
    assert restored['name'] == 'Alex' and restored['signed'] == '2027-05-03'
    assert restored['agree'] not in (None, '', 'Off')
    engine.operation(ident, {'action':'redo'})
    assert engine.content(ident, 0)['widgets'][0]['value'] in (None, '')


def test_clear_fields_refuses_when_nothing_is_filled(engine):
    ident = engine.blank()['id']
    engine.operation(ident, {'action':'add_field','page':0,'type':'text','name':'empty',
                             'rect':[50,50,250,80]})
    before = engine.get(ident).data
    with pytest.raises(PDFError):
        engine.operation(ident, {'action':'clear_fields'})
    # A refusal has to be atomic: same bytes, and no history step consumed.
    assert engine.get(ident).data == before
    assert engine.meta(ident)['revision'] == 1


def test_clear_fields_leaves_read_only_fields_alone(engine):
    # Built directly, because the editor deliberately cannot create a read-only
    # field. A read-only field is somebody else's fixed value; clearing must
    # skip it rather than blank a value the document depends on.
    with fitz.open() as doc:
        page = doc.new_page()
        locked = fitz.Widget()
        locked.rect, locked.field_name, locked.field_label = fitz.Rect(50, 50, 250, 80), 'locked', 'locked'
        locked.field_type, locked.field_flags = fitz.PDF_WIDGET_TYPE_TEXT, fitz.PDF_FIELD_IS_READ_ONLY
        locked.field_value = 'Fixed value'
        page.add_widget(locked)
        editable = fitz.Widget()
        editable.rect, editable.field_name, editable.field_label = fitz.Rect(50, 100, 250, 130), 'open', 'open'
        editable.field_type = fitz.PDF_WIDGET_TYPE_TEXT
        editable.field_value = 'Editable value'
        page.add_widget(editable)
        data = doc.tobytes()
    info = engine.load(data, 'readonly.pdf')
    engine.operation(info['id'], {'action':'clear_fields'})
    values = {w['name']: w['value'] for w in engine.content(info['id'], 0)['widgets']}
    assert values['locked'] == 'Fixed value'
    assert values['open'] in (None, '')


def test_cleared_values_are_really_gone_from_the_saved_file(engine):
    # PyMuPDF ignores `field_value = ''` on a text field, so the value has to be
    # removed from the field dictionary. If that is ever "simplified" back to an
    # empty assignment the value stays in the file and only the appearance is
    # blank, which is exactly the kind of leak this checks for.
    ident = engine.blank()['id']
    engine.operation(ident, {'action':'add_field','page':0,'type':'text','name':'secret',
                             'rect':[50,50,250,80]})
    xref = str(engine.content(ident, 0)['widgets'][0]['xref'])
    engine.operation(ident, {'action':'fill_forms','values':{xref:'DO-NOT-LEAK-42'}})
    engine.operation(ident, {'action':'clear_fields'})
    raw = engine.export(ident, 'pdf')[0]
    assert b'DO-NOT-LEAK-42' not in raw
    with fitz.open(stream=raw, filetype='pdf') as doc:
        assert (list(doc[0].widgets())[0].field_value or '') == ''



# ------------------------------------------------------------- combining files
# Merging and combining share one code path, because they differ only in what
# they copy into: the open document, or a brand-new one. These tests read the
# saved file back page by page, so page order is proven rather than assumed.

def labelled(*labels):
    """A PDF with one labelled page each, so order can be read back exactly."""
    with fitz.open() as doc:
        for label in labels:
            doc.new_page(width=595, height=842).insert_text((72, 120), label, fontsize=26)
        return doc.tobytes()


def page_labels(engine, ident):
    with fitz.open(stream=engine.export(ident, 'pdf')[0], filetype='pdf') as doc:
        return [doc[i].get_text().strip() for i in range(len(doc))]


def test_merging_appends_in_the_order_given(engine):
    ident = engine.blank('Target.pdf')['id']
    engine.merge(ident, [(labelled('A1', 'A2'), 'A.pdf'), (labelled('B1'), 'B.pdf')])
    assert page_labels(engine, ident) == ['', 'A1', 'A2', 'B1']


def test_merging_can_insert_in_front_of_a_chosen_page(engine):
    ident = engine.blank('Target.pdf')['id']
    engine.merge(ident, [(labelled('A1', 'A2'), 'A.pdf')])
    engine.merge(ident, [(labelled('B1'), 'B.pdf')], position=0)
    assert page_labels(engine, ident) == ['B1', '', 'A1', 'A2']
    # A position past the end is clamped rather than refused, because "insert
    # before page 99" of a four-page document plainly means "at the end".
    engine.merge(ident, [(labelled('C1'), 'C.pdf')], position=99)
    assert page_labels(engine, ident) == ['B1', '', 'A1', 'A2', 'C1']


def test_only_some_pages_of_a_source_can_be_taken(engine):
    ident = engine.blank('Target.pdf')['id']
    engine.merge(ident, [(labelled('A1', 'A2', 'A3', 'A4'), 'A.pdf')], ranges=['2-3'])
    assert page_labels(engine, ident) == ['', 'A2', 'A3']
    # The order typed is kept, so a selection can be used to reorder as well.
    engine.merge(ident, [(labelled('B1', 'B2', 'B3'), 'B.pdf')], ranges=['3,1'])
    assert page_labels(engine, ident) == ['', 'A2', 'A3', 'B3', 'B1']


def test_a_page_selection_past_the_end_is_refused_not_shortened(engine):
    ident = engine.blank('Target.pdf')['id']
    before = engine.get(ident).data
    with pytest.raises(PDFError) as caught:
        engine.merge(ident, [(labelled('A1', 'A2'), 'A.pdf')], ranges=['1-9'])
    assert 'page 9 does not exist' in str(caught.value)
    # A refused merge must not have written anything, and must not have left a
    # history step behind for an edit that never happened.
    assert engine.get(ident).data == before
    assert not engine.meta(ident)['canUndo']


def test_combining_builds_a_new_document_and_leaves_the_open_one_alone(engine):
    ident = engine.blank('Open.pdf')['id']
    engine.operation(ident, {'action':'add_text','page':0,'rect':[50,50,300,90],'text':'KEEP ME'})
    before = engine.get(ident).data
    combined = engine.combine([(labelled('A1'), 'A.pdf'), (labelled('B1', 'B2'), 'B.pdf')],
                              name='Report pack.pdf')
    assert combined['name'] == 'Report pack.pdf'
    assert combined['id'] != ident
    assert page_labels(engine, combined['id']) == ['A1', 'B1', 'B2']
    # The document that was open is untouched, which is the whole difference
    # between combining and merging.
    assert engine.get(ident).data == before
    assert engine.get(ident).revision == 1
    assert 'KEEP ME' in text_in(engine, ident)


def test_a_locked_source_needs_its_password_for_both_operations(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'SECRET PAGE', fontsize=26)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='open-sesame')
    ident = engine.blank('Target.pdf')['id']
    for call in (lambda: engine.merge(ident, [(locked, 'Locked.pdf')]),
                 lambda: engine.combine([(locked, 'Locked.pdf')])):
        with pytest.raises(PDFError) as caught:
            call()
        assert caught.value.status == 401 and caught.value.code == 'merge_password_required'
        assert 'needs a password' in str(caught.value)
    # With the password it works, and the page really is the locked one.
    merged = engine.merge(ident, [(locked, 'Locked.pdf')], passwords=['open-sesame'])
    assert merged['pageCount'] == 2
    assert 'SECRET PAGE' in page_labels(engine, ident)[1]


def test_inspecting_reports_page_counts_and_locks_without_storing_anything(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'LOCKED', fontsize=26)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='o', user_pw='pw')
    before = len(engine.documents)
    report = engine.inspect_files([(labelled('A1', 'A2'), 'A.pdf'), (locked, 'Locked.pdf')])
    # Nothing is added to the workspace by looking at a file.
    assert len(engine.documents) == before
    assert [(item['name'], item['pages'], item['locked']) for item in report] == \
           [('A.pdf', 2, False), ('Locked.pdf', 1, True)]
    # The password turns "locked" off, which is what the window keys its
    # Combine button off.
    unlocked = engine.inspect_files([(locked, 'Locked.pdf')], ['pw'])[0]
    assert unlocked['locked'] is False and unlocked['pages'] == 1


def test_an_unreadable_file_is_reported_rather_than_guessed_at(engine):
    report = engine.inspect_files([(b'not a PDF at all', 'junk.pdf')])[0]
    assert report['readable'] is False
    assert report['pages'] == 0
    assert 'junk.pdf' in report['error']
    # And it is refused when it is actually combined, not skipped silently.
    with pytest.raises(PDFError):
        engine.combine([(b'not a PDF at all', 'junk.pdf')])


def test_the_file_and_page_limits_are_enforced(engine):
    ident = engine.blank('Target.pdf')['id']
    with pytest.raises(PDFError):
        engine.merge(ident, [])
    # 500 pages is the working-document ceiling and combining respects it.
    with pytest.raises(PDFError) as caught:
        engine.combine([(labelled(*[f'p{n}' for n in range(501)]), 'Big.pdf')])
    assert 'exceed' in str(caught.value)


def test_merging_is_a_single_undoable_step(engine):
    ident = engine.blank('Target.pdf')['id']
    engine.merge(ident, [(labelled('A1', 'A2'), 'A.pdf'), (labelled('B1'), 'B.pdf')])
    assert engine.meta(ident)['pageCount'] == 4
    engine.operation(ident, {'action':'undo'})
    # All the files go back in one step, not one step per file.
    assert engine.meta(ident)['pageCount'] == 1
    engine.operation(ident, {'action':'redo'})
    assert page_labels(engine, ident) == ['', 'A1', 'A2', 'B1']


def test_merging_keeps_forms_links_and_annotations_from_the_source(engine):
    # insert_pdf has to be told to carry these over; the default drops widgets,
    # which would silently strip a form out of a document somebody combined.
    with fitz.open() as doc:
        page = doc.new_page()
        widget = fitz.Widget()
        widget.rect, widget.field_name, widget.field_label = fitz.Rect(50, 50, 250, 80), 'combined_field', 'combined_field'
        widget.field_type = fitz.PDF_WIDGET_TYPE_TEXT
        widget.field_value = 'Carried over'
        page.add_widget(widget)
        page.add_text_annot((200, 200), 'a note that must survive')
        source = doc.tobytes()
    ident = engine.blank('Target.pdf')['id']
    engine.merge(ident, [(source, 'Form.pdf')])
    merged = engine.meta(ident)
    assert merged['formCount'] == 1
    assert merged['annotationCount'] == 1
    values = {w['name']: w['value'] for w in engine.content(ident, 1)['widgets']}
    assert values['combined_field'] == 'Carried over'


# --------------------------------------------------------------- splitting files
# Splitting is the mirror of combining, so these read every produced part back
# page by page: the names the plan promised are checked against what is actually
# inside the bytes, rather than against what the plan said.

def split_parts(engine, ident, options):
    """(archive name, [(file name, page labels), ...]) from the real output."""
    data, name, mime = engine.split(ident, options)
    if mime == 'application/zip':
        with zipfile.ZipFile(BytesIO(data)) as archive:
            return name, [(entry, read_labels(archive.read(entry))) for entry in archive.namelist()]
    return name, [(name, read_labels(data))]


def read_labels(data):
    with fitz.open(stream=data, filetype='pdf') as doc:
        return [doc[i].get_text().strip() for i in range(len(doc))]


def ten_pages(engine):
    return engine.load(labelled(*[f'P{n}' for n in range(1, 11)]), 'Report.pdf')['id']


def test_splitting_into_equal_blocks_keeps_every_page_once_in_order(engine):
    ident = ten_pages(engine)
    name, parts = split_parts(engine, ident, {'mode': 'chunks', 'size': 3})
    assert name == 'Report-split.zip'
    # Three three-page blocks and a short tail, named so the pages inside are
    # readable from the file name alone.
    assert [entry for entry, _ in parts] == [
        'Report-part-001-pages-1-3.pdf', 'Report-part-002-pages-4-6.pdf',
        'Report-part-003-pages-7-9.pdf', 'Report-part-004-page-10.pdf']
    assert [labels for _, labels in parts] == [
        ['P1', 'P2', 'P3'], ['P4', 'P5', 'P6'], ['P7', 'P8', 'P9'], ['P10']]
    # Every page of the original appears exactly once across the parts.
    flat = [label for _, labels in parts for label in labels]
    assert flat == [f'P{n}' for n in range(1, 11)]


def test_a_block_size_of_one_is_one_file_per_page(engine):
    ident = ten_pages(engine)
    _, parts = split_parts(engine, ident, {'mode': 'chunks', 'size': 1})
    assert len(parts) == 10
    assert all(len(labels) == 1 for _, labels in parts)
    assert [labels[0] for _, labels in parts] == [f'P{n}' for n in range(1, 11)]


def test_splitting_into_a_number_of_files_divides_as_evenly_as_it_can(engine):
    ident = ten_pages(engine)
    _, parts = split_parts(engine, ident, {'mode': 'parts', 'parts': 3})
    # 10 into 3 is 4 + 3 + 3, with the longer part first.
    assert [len(labels) for _, labels in parts] == [4, 3, 3]
    assert [labels for _, labels in parts] == [
        ['P1', 'P2', 'P3', 'P4'], ['P5', 'P6', 'P7'], ['P8', 'P9', 'P10']]
    # A number that divides exactly leaves no ragged tail.
    _, even = split_parts(engine, ident, {'mode': 'parts', 'parts': 5})
    assert [len(labels) for _, labels in even] == [2, 2, 2, 2, 2]


def test_splitting_by_hand_written_ranges_and_reporting_the_gap(engine):
    ident = ten_pages(engine)
    _, parts = split_parts(engine, ident, {'mode': 'ranges', 'ranges': '1-3, 8-10'})
    assert [labels for _, labels in parts] == [['P1', 'P2', 'P3'], ['P8', 'P9', 'P10']]
    plan = engine.split_plan(ident, {'mode': 'ranges', 'ranges': '1-3, 8-10'})
    # Pages 4 to 7 are in no part at all, and the plan says so instead of
    # leaving somebody to discover it after the fact.
    assert plan['omitted'] == [4, 5, 6, 7]
    assert plan['omittedLabel'] == '4\u20137'
    assert plan['pageTotal'] == 6
    # A covering set of ranges reports no gap.
    assert engine.split_plan(ident, {'mode': 'ranges', 'ranges': '1-2, 3-10'})['omitted'] == []


def test_a_single_part_comes_back_as_a_pdf_and_several_as_an_archive(engine):
    ident = ten_pages(engine)
    data, name, mime = engine.split(ident, {'mode': 'ranges', 'ranges': '3-5'})
    assert mime == 'application/pdf' and name == 'Report-part-001-pages-3-5.pdf'
    assert data.startswith(b'%PDF') and read_labels(data) == ['P3', 'P4', 'P5']
    # An archive holding one file would just be a worse PDF, so it is not one.
    _, name, mime = engine.split(ident, {'mode': 'ranges', 'ranges': '3-5, 7'})
    assert mime == 'application/zip' and name == 'Report-split.zip'


def test_the_plan_describes_exactly_what_the_split_writes(engine):
    ident = ten_pages(engine)
    options = {'mode': 'chunks', 'size': 4}
    plan = engine.split_plan(ident, options)
    _, parts = split_parts(engine, ident, options)
    assert [entry for entry, _ in parts] == [part['name'] for part in plan['parts']]
    assert [len(labels) for _, labels in parts] == [part['pages'] for part in plan['parts']]
    assert plan['fileCount'] == 3 and plan['pageCount'] == 10 and plan['archive'] is True
    # Planning writes nothing and changes nothing.
    assert engine.meta(ident)['pageCount'] == 10 and not engine.meta(ident)['canUndo']


def test_splitting_never_changes_the_open_document(engine):
    ident = ten_pages(engine)
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [50, 50, 300, 90], 'text': 'KEEP ME'})
    before, revision = engine.get(ident).data, engine.get(ident).revision
    engine.split(ident, {'mode': 'chunks', 'size': 2})
    assert engine.get(ident).data == before
    assert engine.get(ident).revision == revision
    assert engine.meta(ident)['pageCount'] == 10
    assert 'KEEP ME' in text_in(engine, ident)


def test_impossible_splits_are_refused_with_a_reason(engine):
    ident = ten_pages(engine)
    cases = [
        ({'mode': 'chunks', 'size': 0}, 'between 1 and'),
        ({'mode': 'chunks', 'size': 'lots'}, 'how many pages'),
        ({'mode': 'parts', 'parts': 1}, 'between 2 and'),
        ({'mode': 'parts', 'parts': 11}, 'cannot become 11 files'),
        ({'mode': 'ranges', 'ranges': ''}, 'one file per range'),
        ({'mode': 'ranges', 'ranges': 'three'}, 'separated by commas'),
        ({'mode': 'ranges', 'ranges': '4-2'}, 'smaller page first'),
        ({'mode': 'ranges', 'ranges': '1-99'}, 'page 99 does not exist'),
        ({'mode': 'sideways'}, 'Choose how to split'),
    ]
    for options, expected in cases:
        with pytest.raises(PDFError) as caught:
            engine.split(ident, options)
        assert expected in str(caught.value), f'{options} -> {caught.value}'
    # Nothing was written by any of the refusals.
    assert engine.meta(ident)['pageCount'] == 10 and not engine.meta(ident)['canUndo']


def test_splitting_is_limited_to_a_sane_number_of_files(engine):
    ident = ten_pages(engine)
    # 250 one-page ranges is more parts than anybody wants to download at once.
    with pytest.raises(PDFError) as caught:
        engine.split(ident, {'mode': 'ranges', 'ranges': ','.join(['1'] * 250)})
    assert caught.value.code == 'too_many_files'


def test_splitting_a_protected_document_is_refused_rather_than_stripped(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'SECRET', fontsize=26)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='open-sesame')
    ident = engine.load(locked, 'Locked.pdf', 'open-sesame')['id']
    # The parts could not be re-encrypted without both passwords again, and
    # quietly handing back an unprotected copy would be worse than saying no.
    for call in (lambda: engine.split_plan(ident, {'mode': 'chunks', 'size': 1}),
                 lambda: engine.split(ident, {'mode': 'chunks', 'size': 1})):
        with pytest.raises(PDFError) as caught:
            call()
        assert caught.value.status == 403
        assert 'Unlock an authorized copy first' in str(caught.value)


def test_splitting_needs_the_assembly_permission(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'NO ASSEMBLY', fontsize=26)
        restricted = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='user',
                                 permissions=fitz.PDF_PERM_PRINT | fitz.PDF_PERM_COPY)
    # Opened with the user password, so the owner's restriction stands.
    ident = engine.load(restricted, 'Restricted.pdf', 'user')['id']
    with pytest.raises(PDFError) as caught:
        engine.split_plan(ident, {'mode': 'chunks', 'size': 1})
    assert caught.value.status == 403 and caught.value.code == 'permission_denied'


def test_splitting_carries_forms_links_and_annotations_into_every_part(engine):
    with fitz.open() as doc:
        page = doc.new_page()
        widget = fitz.Widget()
        widget.rect, widget.field_name, widget.field_label = fitz.Rect(50, 50, 250, 80), 'split_field', 'split_field'
        widget.field_type = fitz.PDF_WIDGET_TYPE_TEXT
        widget.field_value = 'Carried over'
        page.add_widget(widget)
        page.add_text_annot((200, 200), 'a note that must survive')
        doc.new_page().insert_text((72, 120), 'SECOND', fontsize=26)
        source = doc.tobytes()
    ident = engine.load(source, 'Form.pdf')['id']
    data, _, mime = engine.split(ident, {'mode': 'chunks', 'size': 1})
    assert mime == 'application/zip'
    with zipfile.ZipFile(BytesIO(data)) as archive:
        first = fitz.open(stream=archive.read('Form-part-001-page-1.pdf'), filetype='pdf')
        with first:
            assert sum(1 for _ in first[0].widgets() or []) == 1
            assert sum(1 for _ in first[0].annots() or []) == 1
            assert next(first[0].widgets()).field_value == 'Carried over'



# --------------------------------------------------- documents kept open
# The workspace holds several documents at once, which is what lets one be
# combined into another without either being read from disk again. These check
# the two engine pieces that makes possible: the list, and the handover.

def test_the_workspace_lists_every_document_it_holds_open(engine):
    engine.load(labelled('A1'), 'A.pdf')
    engine.load(labelled('B1', 'B2'), 'B.pdf')
    report = engine.open_documents()
    assert [(d['name'], d['pageCount'], d['readable'], d['canAssemble']) for d in report] == \
           [('A.pdf', 1, True, True), ('B.pdf', 2, True, True)]
    assert all(d['id'] for d in report)
    # Listing them is a read: nothing is opened, closed or reordered by looking.
    assert len(engine.documents) == 2


def test_an_open_document_can_be_used_as_a_merge_source(engine):
    first = engine.load(labelled('A1', 'A2'), 'A.pdf')['id']
    second = engine.load(labelled('B1'), 'B.pdf')['id']
    data, name, password = engine.source_of(second)
    assert name == 'B.pdf' and password == ''
    engine.merge(first, [(data, name)], [password])
    assert page_labels(engine, first) == ['A1', 'A2', 'B1']
    # The source document is untouched — merging copies pages, it does not move
    # them.
    assert engine.meta(second)['pageCount'] == 1
    assert page_labels(engine, second) == ['B1']


def test_a_protected_document_that_is_open_needs_no_second_password(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'SECRET', fontsize=26)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='open-sesame')
    target = engine.blank('Target.pdf')['id']
    opened = engine.load(locked, 'Locked.pdf', 'open-sesame')['id']
    data, name, password = engine.source_of(opened)
    # The password already used to open it is handed back, which is the whole
    # point: a document that is open is not locked a second time.
    assert password == 'open-sesame'
    engine.merge(target, [(data, name)], [password])
    assert 'SECRET' in page_labels(engine, target)[1]


def test_an_open_document_that_forbids_assembly_says_so(engine):
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'NO ASSEMBLY', fontsize=26)
        restricted = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='user',
                                 permissions=fitz.PDF_PERM_PRINT | fitz.PDF_PERM_COPY)
    engine.load(restricted, 'Restricted.pdf', 'user')
    entry = engine.open_documents()[0]
    # Reported before anybody tries to use it, rather than failing afterwards.
    assert entry['owner'] is False and entry['canAssemble'] is False
    target = engine.blank('Target.pdf')['id']
    data, name, password = engine.source_of(entry['id'])
    with pytest.raises(PDFError) as caught:
        engine.merge(target, [(data, name)], [password])
    assert caught.value.status == 403 and caught.value.code == 'permission_denied'


def test_the_oldest_document_is_dropped_past_the_workspace_limit(engine):
    ids = [engine.load(labelled(f'P{n}'), f'{n}.pdf')['id'] for n in range(MAX_DOCUMENTS + 2)]
    held = [d['id'] for d in engine.open_documents()]
    assert len(held) == MAX_DOCUMENTS
    assert ids[0] not in held and ids[1] not in held
    assert ids[-1] in held
    # The one that was dropped reports as gone rather than half-alive.
    with pytest.raises(PDFError) as caught:
        engine.source_of(ids[0])
    assert caught.value.status == 404


# ---------------------------------------------------------------- scans as pages
# A page that is a picture of text has no text layer, so "click a line and type"
# has nothing to click. The way in is to drag a box over the words: the ink is
# painted over with the colour of the paper around it, and the replacement is
# written as real text on top.

def grey_scan(paper=(0.88, 0.88, 0.86), words='OLD WORDS HERE'):
    """A one-page PDF that looks like a photographed sheet, with no text layer."""
    source = fitz.open()
    page = source.new_page(width=595, height=842)
    page.draw_rect(page.rect, color=None, fill=paper)
    page.insert_text((60, 120), words, fontsize=26, color=(0.1, 0.1, 0.1))
    png = page.get_pixmap(dpi=150).tobytes('png')
    source.close()
    scan = fitz.open()
    sheet = scan.new_page(width=595, height=842)
    sheet.insert_image(fitz.Rect(0, 0, 595, 842), stream=png)
    data = scan.tobytes()
    scan.close()
    return data


def pixel_at(data: bytes, x: float, y: float):
    with fitz.open(stream=data, filetype='pdf') as doc:
        pixmap = doc[0].get_pixmap(dpi=72, clip=fitz.Rect(x - 1, y - 1, x + 1, y + 1),
                                   colorspace=fitz.csRGB)
        red, green, blue = pixmap.samples[:3]
    return red, green, blue


def test_a_page_with_no_text_layer_reports_no_spans_and_one_image(engine):
    info = engine.load(grey_scan(), 'scan.pdf')
    content = engine.content(info['id'], 0)
    assert content['spans'] == []
    assert len(content['images']) == 1


def darkest_in(data: bytes, box):
    """The darkest pixel inside a box, which is where the ink is."""
    with fitz.open(stream=data, filetype='pdf') as doc:
        pixmap = doc[0].get_pixmap(dpi=72, clip=fitz.Rect(*box), colorspace=fitz.csRGB)
    samples = pixmap.samples
    return min(samples[0::pixmap.n])


def test_erasing_part_of_a_scan_covers_the_ink_with_the_paper_colour(engine):
    info = engine.load(grey_scan(), 'scan.pdf')
    ident = info['id']
    box = (58, 96, 300, 124)
    before = engine.export(ident, 'pdf')[0]
    assert darkest_in(before, box) < 120, 'the fixture has no dark ink to cover'

    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': list(box),
                             'text': '', 'size': 26, 'color': '#1a1a1a',
                             'family': 'sans-serif', 'rotation': 0, 'expand': False})
    after = engine.export(ident, 'pdf')[0]
    # No ink left anywhere under the box.
    assert darkest_in(after, box) > 180, darkest_in(after, box)
    # And the patch is the colour of the paper, not white: a bright rectangle in
    # the middle of a grey scan is the thing this is here to prevent.
    patch = pixel_at(after, 70, 100)
    assert all(200 <= channel <= 245 for channel in patch), patch
    assert engine.export(ident, 'txt')[0].decode('utf-8').strip().endswith('--- Page 1 ---')


def test_a_replacement_is_written_as_real_text_on_a_scan(engine):
    info = engine.load(grey_scan(), 'scan.pdf')
    ident = info['id']
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': [58, 96, 300, 124],
                             'text': 'NEW WORDS', 'size': 26, 'color': '#1a1a1a',
                             'family': 'sans-serif', 'rotation': 0, 'expand': True})
    # Selectable, searchable text — not a picture of the new words.
    assert [span['text'] for span in engine.content(ident, 0)['spans']] == ['NEW WORDS']
    assert engine.search(ident, 'NEW WORDS')[0]['page'] == 0
    # The old ink is gone from the part of the box the new words do not cover.
    assert darkest_in(engine.export(ident, 'pdf')[0], (250, 96, 300, 124)) > 180


def test_a_date_can_be_written_onto_a_scan_as_selectable_text(engine):
    info = engine.load(grey_scan(), 'scan.pdf')
    ident = info['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 288, 168, 311],
                             'text': '15/03/2026', 'size': 12, 'color': '#292b3d',
                             'family': 'sans-serif'})
    assert '15/03/2026' in engine.export(ident, 'txt')[0].decode('utf-8')
    content = engine.content(ident, 0)
    assert [span['text'] for span in content['spans']] == ['15/03/2026']


def test_the_scan_background_is_sampled_not_assumed(engine):
    from app.engine import scan_background
    info = engine.load(grey_scan(paper=(0.55, 0.55, 0.52)), 'dark.pdf')
    with fitz.open(stream=engine.export(info['id'], 'pdf')[0], filetype='pdf') as doc:
        colour = scan_background(doc[0], fitz.Rect(58, 96, 300, 124))
    # Mid grey, not white: white would leave a bright hole in a dark scan.
    assert all(0.45 < channel < 0.65 for channel in colour), colour
