"""Printing tests.

Most of this file is about one function, `_dib_bytes`, because that is where
printing actually broke. Everything else on the print path is a thin call into
Windows, but the bytes handed to the driver have two requirements that are
easy to get wrong and neither of them fails loudly in an obvious way:

* rows must be padded to four bytes, or the driver reads past the end of a row
  and faults inside itself (this made A4 unprintable while US Letter worked);
* a 24-bit BI_RGB bitmap is BGR, while PyMuPDF produces RGB (this swapped red
  and blue on paper).

Both are checked here directly, and again end to end where a printer exists.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
import pymupdf as fitz

from app import printing


def test_dib_rows_are_padded_to_a_four_byte_boundary():
    # Three pixels is nine bytes a row, which is not a multiple of four, so
    # every row needs three bytes of padding. The expected bytes are written out
    # by hand rather than recomputed, so this checks the result and not the
    # implementation. Each source pixel ABC arrives as CBA (BGR), then the row
    # is padded with zeroes.
    width, height = 3, 2
    samples = bytes(range(width * height * 3))
    out = printing._dib_bytes(samples, width, height)
    assert out == (b'\x02\x01\x00\x05\x04\x03\x08\x07\x06\x00\x00\x00'
                   b'\x0b\x0a\x09\x0e\x0d\x0c\x11\x10\x0f\x00\x00\x00')
    assert len(out) == 12 * height, 'the rows were not padded to four bytes'


def test_even_a_single_pixel_row_is_padded():
    # One pixel is three bytes, so this is the smallest case that still needs
    # padding — and the one where forgetting it is easiest to miss.
    assert printing._dib_bytes(bytes([255, 0, 0]), 1, 1) == b'\x00\x00\xff\x00'


def test_dib_swaps_red_and_blue_because_a_dib_is_bgr():
    # Four pixels, one row, already a multiple of four bytes, so nothing is
    # padded and the channel order is the only thing changing. A 24-bit BI_RGB
    # DIB stores B, G, R in that order, so pure red has to reach the driver as
    # 00 00 FF and not FF 00 00. Red and blue coming out swapped on paper is
    # exactly what this prevents.
    samples = bytes([255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255])
    assert printing._dib_bytes(samples, 4, 1) == bytes([0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255])


def test_a4_is_not_already_aligned_which_is_why_the_bug_hid():
    # 200 DPI is the print resolution, and these are the widths two paper sizes
    # render to. Letter is already a multiple of four; A4 is not, and A4 is the
    # page size that crashed the driver.
    a4 = round(210 / 25.4 * printing.PRINT_DPI)
    letter = round(8.5 * printing.PRINT_DPI)
    assert (a4 * 3) % 4 != 0, 'this test no longer demonstrates anything'
    assert (letter * 3) % 4 == 0


def test_rendered_pages_have_aligned_rows_for_a4_and_letter():
    # The invariant the driver needs, checked on real rendered pages rather than
    # on a made-up buffer.
    for name, size in (('a4', (595.276, 841.89)), ('letter', (612.0, 792.0))):
        with fitz.open() as doc:
            doc.new_page(width=size[0], height=size[1])
            data = doc.tobytes()
        pages = printing._render_pages(data)
        assert len(pages) == 1
        width, height, dib = pages[0]
        assert len(dib) % height == 0, f'{name}: rows are not a whole number of bytes'
        assert (len(dib) // height) % 4 == 0, f'{name}: {len(dib) // height} bytes a row is not aligned'
        assert len(dib) >= width * height * 3


def test_rendered_pages_keep_every_page_and_their_order():
    with fitz.open() as doc:
        for index in range(3):
            page = doc.new_page(width=300, height=300)
            page.insert_text((40, 60), f'page {index}')
        data = doc.tobytes()
    pages = printing._render_pages(data)
    assert len(pages) == 3
    assert len({(w, h) for w, h, _ in pages}) == 1


def test_print_pdf_refuses_an_empty_document():
    assert printing.print_pdf(b'')['ok'] is False


@pytest.mark.skipif(sys.platform != 'win32', reason='the GDI print path is Windows only')
def test_printers_are_listed_with_their_printable_flag():
    found = printing.printers()
    assert isinstance(found, list)
    for item in found:
        assert set(item) == {'name', 'default', 'printable'}
        assert isinstance(item['name'], str) and item['name']
    # Default first, then printers that can actually print, then the rest. A
    # machine whose default is a file printer would otherwise look broken.
    assert found == sorted(found, key=lambda i: (not i['default'], not i['printable'], i['name'].lower()))


@pytest.mark.skipif(sys.platform != 'win32', reason='the GDI print path is Windows only')
def test_methods_describes_what_this_machine_can_do():
    described = printing.methods()
    for key in ('print', 'printer', 'printers', 'canPrint', 'savesToFile', 'via', 'dpi', 'note'):
        assert key in described, f'methods() is missing {key!r}'
    assert described['via'] == 'gdi'
    assert described['dpi'] == printing.PRINT_DPI


@pytest.mark.skipif(sys.platform != 'win32', reason='the GDI print path is Windows only')
def test_a_file_only_printer_is_recognised_rather_than_attempted():
    # Sending a job to one of these opens a Save dialog in another process and
    # never returns, so the refusal has to happen before the job is started.
    file_printers = [p for p in printing.printers() if not p['printable']]
    for item in file_printers:
        assert printing.saves_to_a_file(item['name']), f'{item["name"]} should be flagged as file-only'
        result = printing.print_pdf(b'%PDF-1.4\n', 'probe', item['name'])
        assert result['ok'] is False
        assert result.get('savesToFile') is True


@pytest.mark.skipif(sys.platform != 'win32', reason='the GDI print path is Windows only')
def test_a_real_print_job_produces_the_document(tmp_path: Path):
    """Print for real, through the spooler, and check what came out.

    The job is redirected to a file by the driver rather than sent to paper, but
    nothing else is stubbed: the same rendering, the same GDI calls, the same
    device context. This is the check that would have caught both of the driver
    bugs above, so it is skipped only when the machine has no file-capable
    printer to redirect into.

    Under pytest this test prints a "Windows fatal exception: code 0x80040155"
    traceback. That is not a failure: it is a first-chance exception the print
    driver raises and handles itself while opening the device context, and
    pytest's fault handler reports it on the way past. The test still passes,
    and running the same job from a plain script is silent.
    """
    candidates = [p['name'] for p in printing.printers() if not p['printable']]
    if not candidates:
        pytest.skip('no file-capable printer is installed to redirect the job into')

    with fitz.open() as doc:
        for index in range(2):
            page = doc.new_page(width=595.276, height=841.89)  # A4, the size that used to crash
            page.insert_text((60, 90), f'Printed page {index + 1}', fontsize=28)
        data = doc.tobytes()

    target = tmp_path / 'printed.pdf'
    result = printing.print_pdf(data, 'KADOMA test', candidates[0], output=str(target))
    assert result['ok'] is True, result.get('error')
    assert result['pages'] == 2
    assert target.exists() and target.stat().st_size > 1000
    with fitz.open(target) as printed:
        assert printed.page_count == 2
        # The capture is a raster, so the ink is counted rather than the text.
        for page in printed:
            pixmap = page.get_pixmap(dpi=40)
            assert pixmap.samples.count(0) + sum(1 for b in pixmap.samples if b < 128) > 200, \
                'the printed page came out blank'


# ------------------------------------------------------------- print preview
# The preview has one job: show the sheet, not the page. These check the two
# things that make it a preview rather than a second page view — the paper's
# proportions, and the margin the printer cannot reach.

def ink_page(width=595.276, height=841.89):
    """A page that is entirely black, so paper and ink can be told apart."""
    with fitz.open() as doc:
        page = doc.new_page(width=width, height=height)
        page.draw_rect(page.rect, color=None, fill=(0, 0, 0))
        return doc.tobytes()


def image_of(png: bytes):
    with fitz.open(stream=png, filetype='png') as doc:
        return doc[0].get_pixmap()


def test_the_preview_is_the_sheet_and_leaves_the_margin_as_paper(monkeypatch):
    sheet = {'available': True, 'printer': 'Fake printer',
             'width': 612.0, 'height': 792.0,
             'printable': {'x': 36.0, 'y': 36.0, 'width': 540.0, 'height': 720.0}}
    monkeypatch.setattr(printing, 'paper', lambda printer=None: sheet)

    pixmap = image_of(printing.preview_png(ink_page(), 0))
    assert pixmap.width / pixmap.height == pytest.approx(612 / 792, rel=0.01), \
        'the preview is not the shape of the paper'
    # A quarter-inch in, at 96 DPI, is still the unprintable edge.
    assert pixmap.pixel(3, 3) == (255, 255, 255), 'the preview drew ink in the printer\'s margin'
    assert pixmap.pixel(pixmap.width // 2, pixmap.height // 2) == (0, 0, 0), \
        'the page itself is missing from the preview'


def test_without_a_printer_the_preview_falls_back_to_the_page(monkeypatch):
    monkeypatch.setattr(printing, 'paper', lambda printer=None: {'available': False, 'printer': None})
    pixmap = image_of(printing.preview_png(ink_page(), 0))
    assert pixmap.width / pixmap.height == pytest.approx(595.276 / 841.89, rel=0.01)
    assert pixmap.pixel(3, 3) == (0, 0, 0), 'the fallback added a margin nobody asked for'


def test_the_preview_refuses_a_page_that_is_not_there():
    with pytest.raises(ValueError):
        printing.preview_png(ink_page(), 3)


def test_the_preview_follows_the_page_it_is_given():
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'FIRST', fontsize=20)
        doc.new_page().insert_text((72, 120), 'SECOND', fontsize=20)
        data = doc.tobytes()
    first = image_of(printing.preview_png(data, 0))
    second = image_of(printing.preview_png(data, 1))
    # Same sheet, different ink: the second page must not be a cached first one.
    assert (first.width, first.height) == (second.width, second.height)
    assert first.samples != second.samples


def test_a_printer_on_an_ordinary_port_can_still_be_a_sink(monkeypatch):
    """OneNote reports `nul:`, which is neither a filename prompt nor paper.

    The first version returned "printable" as soon as any port was found, so a
    printer with an ordinary-looking port was never checked by name at all.
    """
    monkeypatch.setattr(printing, 'printer_details',
                        lambda name: ('nul:', 'Send to Microsoft OneNote 16 Driver'))
    assert printing.saves_to_a_file('OneNote (Desktop)') is True

    monkeypatch.setattr(printing, 'printer_details',
                        lambda name: ('PORTPROMPT:', 'Microsoft Print To PDF'))
    assert printing.saves_to_a_file('Microsoft Print to PDF') is True

    monkeypatch.setattr(printing, 'printer_details',
                        lambda name: ('IP_192.168.1.9', 'HP LaserJet M404'))
    assert printing.saves_to_a_file('HP LaserJet M404') is False


# ------------------------------------------------------- pages, copies, settings
# What the print dialog offers beyond "print it": which sheets, how many times,
# and the driver's own settings. The first two are arithmetic and are checked
# against a real spooled job; the third is checked without opening a dialog.

def test_the_page_list_refuses_what_is_not_a_page():
    assert printing.page_list(None, 3) == [0, 1, 2]
    assert printing.page_list([2, 0], 3) == [2, 0]
    # A duplicate is not an error, it is the same sheet twice in one job.
    assert printing.page_list([1, 1], 3) == [1]
    for bad in ([3], [-1], ['1'], [True], []):
        with pytest.raises(ValueError):
            printing.page_list(bad, 3)


def test_a_chosen_range_and_a_copy_count_reach_the_spooler(tmp_path: Path):
    candidates = [p['name'] for p in printing.printers() if not p['printable']]
    if not candidates:
        pytest.skip('no file-capable printer is installed to redirect the job into')
    with fitz.open() as doc:
        for index in range(4):
            doc.new_page(width=595.276, height=841.89).insert_text(
                (60, 90), f'Sheet {index + 1}', fontsize=28)
        data = doc.tobytes()

    target = tmp_path / 'range.pdf'
    # Pages 1 and 3, twice: four sheets, in that order.
    result = printing.print_pdf(data, 'KADOMA test', candidates[0],
                                output=str(target), pages=[0, 2], copies=2)
    assert result['ok'] is True, result.get('error')
    assert result['pages'] == 4
    with fitz.open(target) as printed:
        assert printed.page_count == 4


def test_a_page_outside_the_document_is_refused_before_anything_is_spooled(tmp_path: Path):
    candidates = [p['name'] for p in printing.printers() if not p['printable']]
    if not candidates:
        pytest.skip('no file-capable printer is installed')
    with fitz.open() as doc:
        doc.new_page()
        data = doc.tobytes()
    target = tmp_path / 'never.pdf'
    result = printing.print_pdf(data, 'KADOMA test', candidates[0],
                                output=str(target), pages=[4])
    assert result['ok'] is False and 'not in this document' in result['error']
    assert not target.exists(), 'a refused job still reached the printer'


@pytest.mark.skipif(sys.platform != 'win32', reason='the DEVMODE round-trip is Windows only')
def test_the_printer_settings_can_be_read_without_a_dialog():
    """The plumbing behind Printer properties…, without a human to click OK."""
    if not printing.default_printer():
        pytest.skip('no printer is installed')
    settings = printing.printer_preferences(prompt=False)
    assert settings['ok'] is True, settings.get('error')
    assert settings['orientation'] in ('portrait', 'landscape')
    assert settings['paper']
    assert printing.preferences_summary(settings['printer'])['paper'] == settings['paper']


def test_collated_and_uncollated_order_the_same_sheets_differently():
    # Two copies of pages 1-3: collated is a set each time, uncollated is a
    # stack of each page. Same number of sheets, different order.
    assert printing.sheet_order([0, 1, 2], 2, collate=True) == [0, 1, 2, 0, 1, 2]
    assert printing.sheet_order([0, 1, 2], 2, collate=False) == [0, 0, 1, 1, 2, 2]
    assert len(printing.sheet_order([0, 1, 2], 3, collate=True)) == 9
    assert len(printing.sheet_order([0, 1, 2], 3, collate=False)) == 9
    # One copy has no order to choose.
    assert printing.sheet_order([0, 2], 1, collate=False) == [0, 2]


def test_an_uncollated_job_still_spools_every_sheet(tmp_path: Path):
    candidates = [p['name'] for p in printing.printers() if not p['printable']]
    if not candidates:
        pytest.skip('no file-capable printer is installed to redirect the job into')
    with fitz.open() as doc:
        for index in range(3):
            doc.new_page(width=595.276, height=841.89).insert_text(
                (60, 90), f'Sheet {index + 1}', fontsize=28)
        data = doc.tobytes()

    target = tmp_path / 'uncollated.pdf'
    result = printing.print_pdf(data, 'KADOMA test', candidates[0], output=str(target),
                                pages=[0, 2], copies=2, collate=False)
    assert result['ok'] is True, result.get('error')
    assert result['pages'] == 4
    assert result['collated'] is False
    with fitz.open(target) as printed:
        assert printed.page_count == 4


# ------------------------------------------------ paper size and orientation
# The list comes from the driver and the choice goes back into its own settings
# block, so the preview's sheet and the job's paper are the same thing. A
# machine with no printer that reports papers skips these rather than pretending.

def _paper_printer():
    for item in printing.printers():
        if item['printable'] and printing.papers(item['name']):
            return item['name']
    return None


def test_the_paper_sizes_are_asked_of_the_driver_not_invented():
    printer = _paper_printer()
    if not printer:
        pytest.skip('no printer here reports its paper sizes')
    sizes = printing.papers(printer)
    assert sizes, 'the driver reported no papers at all'
    assert all(isinstance(item['id'], int) and item['name'] for item in sizes)
    # Every driver in the world has US Letter and A4 among its sizes; a list
    # that contains neither is not a paper list.
    names = {item['name'] for item in sizes}
    assert names & {'A4', 'Letter'}, names


def test_a_chosen_paper_and_orientation_change_the_sheet():
    printer = _paper_printer()
    if not printer:
        pytest.skip('no printer here reports its paper sizes')
    sizes = {item['name']: item['id'] for item in printing.papers(printer)}
    if not {'A4', 'Letter'} & set(sizes):
        pytest.skip('this driver has neither A4 nor Letter')
    first = sizes.get('A4') or sizes.get('Letter')
    second = sizes.get('Letter') or sizes.get('A4')

    portrait = printing.apply_settings(printer, paper=first, orientation='portrait')
    assert portrait['ok'] is True, portrait.get('error')
    assert portrait['orientation'] == 'portrait'
    upright = printing.paper(printer)
    assert upright['available'] is True
    assert upright['height'] > upright['width'], f"portrait came out {upright['width']}x{upright['height']}"

    landscape = printing.apply_settings(printer, paper=first, orientation='landscape')
    assert landscape['ok'] is True, landscape.get('error')
    turned = printing.paper(printer)
    assert turned['width'] > turned['height'], f"landscape came out {turned['width']}x{turned['height']}"
    # The same paper, turned: the long and short sides swap.
    assert abs(turned['width'] - upright['height']) < 2
    assert abs(turned['height'] - upright['width']) < 2

    # Another paper really is another size, and the printable area follows it.
    other = printing.apply_settings(printer, paper=second, orientation='portrait')
    assert other['ok'] is True, other.get('error')
    assert other['paperId'] == second
    assert printing.preferences_summary(printer)['paperId'] == second


def test_impossible_printer_settings_are_refused_with_a_reason():
    printer = _paper_printer() or printing.default_printer()
    if not printer:
        pytest.skip('no printer is installed')
    assert printing.apply_settings(printer, orientation='sideways')['ok'] is False
    assert printing.apply_settings(printer, paper=0)['ok'] is False
    assert printing.apply_settings(printer, paper='A4')['ok'] is False


def test_asking_for_nothing_changes_nothing():
    printer = _paper_printer() or printing.default_printer()
    if not printer:
        pytest.skip('no printer is installed')
    before = printing.preferences_summary(printer)
    result = printing.apply_settings(printer)
    assert result['ok'] is True
    assert printing.preferences_summary(printer) == before


# ------------------------------------------------------------ two-sided print

def test_two_sided_is_only_offered_when_the_driver_reports_it():
    printer = _paper_printer() or printing.default_printer()
    if not printer:
        pytest.skip('no printer is installed')
    modes = printing.duplex_options(printer)
    assert 'simplex' in modes, modes
    assert set(modes) <= {'simplex', 'long', 'short'}, modes
    # A driver that reports nothing must not be offered two-sided printing.
    assert modes == ['simplex'] or len(modes) > 1


def test_a_two_sided_choice_is_written_into_the_settings_block():
    printer = _paper_printer() or printing.default_printer()
    if not printer:
        pytest.skip('no printer is installed')
    supported = 'long' in printing.duplex_options(printer)
    chosen = printing.apply_settings(printer, duplex='long')
    assert chosen['ok'] is True, chosen.get('error')
    if supported:
        assert chosen['duplex'] == 'long'
        assert printing.preferences_summary(printer)['duplex'] == 'long'
    else:
        # A driver that cannot do it is allowed to normalise the request rather
        # than accept a setting it will ignore. What must never happen is the
        # summary claiming two-sided when the driver said simplex.
        assert chosen['duplex'] == 'simplex', chosen
        assert printing.preferences_summary(printer)['duplex'] == 'simplex'
    # And back, so the rest of the run prints one-sided.
    back = printing.apply_settings(printer, duplex='simplex')
    assert back['ok'] is True and back['duplex'] == 'simplex'


def test_an_impossible_side_choice_is_refused():
    printer = _paper_printer() or printing.default_printer()
    if not printer:
        pytest.skip('no printer is installed')
    result = printing.apply_settings(printer, duplex='sideways')
    assert result['ok'] is False and 'two-sided' in result['error']
