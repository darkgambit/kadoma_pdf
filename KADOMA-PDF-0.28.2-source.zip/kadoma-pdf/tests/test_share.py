"""Sharing a finished PDF, and registering as the default PDF handler.

The two risky parts of this feature are pinned down here:

* the share folder is the only place these helpers will act on, so a crafted
  path from the interface cannot make the desktop shell reveal, copy or attach
  an arbitrary file on the machine;
* the .eml really carries the document, byte for byte — a mailto link cannot,
  which is why the attachment route exists at all.
"""
import email
import os
import sys
from pathlib import Path

import pytest

from app import share, shell_integration
from app.errors import PDFError

SAMPLE = b'%PDF-1.7\n1 0 obj\n<< /Type /Catalog >>\nendobj\ntrailer\n%%EOF\n'


def read_eml(raw: bytes) -> email.message.EmailMessage:
    """Parse with the modern policy so headers come back decoded and the
    EmailMessage helpers (iter_attachments) are available."""
    return email.message_from_bytes(raw, policy=email.policy.default)


@pytest.fixture
def prepared():
    return share.prepare(SAMPLE, 'Quarterly performance.pdf')


# -------------------------------------------------------------- share folder

def test_prepare_writes_the_file_and_describes_it(prepared):
    assert prepared['name'] == 'Quarterly performance.pdf'
    assert prepared['size'] == len(SAMPLE)
    target = Path(prepared['path'])
    assert target.is_file()
    assert target.read_bytes() == SAMPLE
    assert target.parent == share.share_dir()


def test_prepare_forces_a_pdf_extension(prepared):
    result = share.prepare(SAMPLE, 'report.docx')
    assert result['name'] == 'report.pdf'


def test_prepare_keeps_the_name_findable_in_a_mail_client():
    """The user has to hunt for this file in another program, so the name must
    stay close to the original while losing anything a file system dislikes."""
    result = share.prepare(SAMPLE, 'Invoice: 2048 / <final>?.pdf')
    assert result['name'].endswith('.pdf')
    assert '/' not in result['name'] and ':' not in result['name']
    assert '<' not in result['name'] and '?' not in result['name']
    assert 'Invoice' in result['name'] and '2048' in result['name']


def test_prepare_falls_back_when_the_name_is_unusable():
    result = share.prepare(SAMPLE, '///')
    assert result['name'] == 'document.pdf'


def test_share_folder_is_stable_between_calls():
    """A random folder would break the flow: the user is sent to another
    program to find the file by hand."""
    assert share.share_dir() == share.share_dir()
    assert Path(prepared_path()).parent == share.share_dir()


def prepared_path():
    return share.prepare(SAMPLE, 'stable.pdf')['path']


# ------------------------------------------------------- untrusted-path guard

def test_inside_share_accepts_only_files_it_created(prepared):
    assert share.inside_share(prepared['path']) is not None


@pytest.mark.parametrize('hostile', [
    r'C:\Windows\System32\drivers\etc\hosts',
    '/etc/passwd',
    r'..\..\Windows\win.ini',
    '',
    'not-a-path',
    None,
])
def test_inside_share_refuses_anything_else(hostile):
    assert share.inside_share(hostile) is None


def test_inside_share_refuses_traversal_out_of_the_share_folder(prepared):
    escape = str(Path(prepared['path']).parent / '..' / 'elsewhere.pdf')
    assert share.inside_share(escape) is None


def test_inside_share_refuses_a_directory():
    assert share.inside_share(str(share.share_dir())) is None


def test_every_action_refuses_a_path_outside_the_share_folder(tmp_path):
    outsider = tmp_path / 'secret.pdf'
    outsider.write_bytes(b'private')
    for action in (share.reveal, share.copy_file, share.mail_draft, share.mail_with_attachment):
        result = action(str(outsider))
        assert result['ok'] is False, action.__name__
        assert 'share folder' in result['error']


# ------------------------------------------------------------- email payload

def test_eml_attaches_the_real_document_byte_for_byte(prepared):
    raw = share.eml_bytes(Path(prepared['path']), to='client@example.com',
                          subject='Your invoice')
    message = read_eml(raw)
    assert str(message['Subject']) == 'Your invoice'
    assert str(message['To']) == 'client@example.com'
    parts = list(message.iter_attachments())
    assert len(parts) == 1
    assert parts[0].get_filename() == 'Quarterly performance.pdf'
    assert parts[0].get_content_type() == 'application/pdf'
    assert parts[0].get_payload(decode=True) == SAMPLE


def test_eml_defaults_are_sensible(prepared):
    message = read_eml(share.eml_bytes(Path(prepared['path'])))
    assert str(message['Subject']) == 'PDF: Quarterly performance.pdf'
    assert message.get_content_type() == 'multipart/mixed'


def test_prepare_hands_the_dialog_the_sentence_to_start_with(prepared):
    # The share dialog shows this text and sends it back, so the sentence the
    # message is built with and the sentence on screen come from one place.
    details = share.prepare(SAMPLE, 'Quarterly performance.pdf')
    assert details['defaultBody'] == 'Please see the attached file'
    assert details['name'].endswith('.pdf')


def test_the_draft_says_please_see_the_attached_file_and_carries_the_pdf(prepared):
    # The body and the attachment are the two things the request asked for, so
    # both are read out of the message rather than trusted from the builder.
    message = read_eml(share.eml_bytes(Path(prepared['path'])))
    assert message.get_body(('plain',)).get_content().strip() == 'Please see the attached file'
    attached = list(message.iter_attachments())
    assert len(attached) == 1, 'the draft does not carry exactly one attachment'
    assert attached[0].get_content_type() == 'application/pdf'
    assert attached[0].get_payload(decode=True) == SAMPLE


def test_the_mailto_route_uses_the_same_body(prepared, monkeypatch):
    opened = {}

    def fake_open(url):
        opened['url'] = url
        return {'ok': True}

    monkeypatch.setattr(share, 'open_url', fake_open)
    monkeypatch.setattr(share, 'copy_file', lambda path: {'ok': True})
    monkeypatch.setattr(share, 'reveal', lambda path: {'ok': True})
    share.mail_draft(prepared['path'])
    assert 'Please%20see%20the%20attached%20file' in opened['url'], opened['url']


def test_eml_survives_a_non_ascii_subject(prepared):
    """Arabic and accented subjects must not be mangled or rejected.

    The raw header is RFC 2047 encoded (that is what every mail client
    expects), so the check is on the decoded value.
    """
    raw = share.eml_bytes(Path(prepared['path']), subject='الفاتورة رقم ٢٠٤٨',
                          to='client@example.com')
    assert b'=?utf-8?' in raw, 'a non-ASCII subject must be RFC 2047 encoded'
    message = read_eml(raw)
    assert 'الفاتورة' in str(message['Subject'])
    assert list(message.iter_attachments())[0].get_payload(decode=True) == SAMPLE


def test_mailto_carries_a_subject_and_body_but_never_an_attachment(prepared):
    url = share.mailto_url('client@example.com', 'Your invoice', 'Hello there')
    assert url.startswith('mailto:client%40example.com?')
    assert 'subject=Your%20invoice' in url
    assert 'body=Hello%20there' in url
    # mailto has no attachment parameter — that is the whole reason the .eml
    # route exists, so this must never quietly change.
    assert 'attach' not in url.lower()


def test_mailto_with_nothing_but_a_recipient_has_no_query():
    assert share.mailto_url('client@example.com') == 'mailto:client%40example.com'


# ------------------------------------------------------------------ reporting

def test_methods_reports_what_this_machine_can_do():
    reported = share.methods()
    assert set(reported) >= {'reveal', 'copyFile', 'mailDraft', 'mailAttachment', 'folder'}
    assert all(isinstance(reported[key], bool)
               for key in ('reveal', 'copyFile', 'mailDraft', 'mailAttachment'))
    assert Path(reported['folder']) == share.share_dir()


# ------------------------------------------------- default-PDF-app registration

def test_command_line_passes_the_opened_file_to_the_app():
    line = shell_integration.command_line()
    assert '%1' in line, line
    assert line.startswith('"'), 'the executable path must be quoted'


def test_icon_is_a_file_or_the_executable_not_a_script_call():
    icon = shell_integration.icon_path()
    assert icon
    assert '%1' not in icon, 'the icon entry must not carry the file argument'


def test_supported_matches_the_platform():
    assert shell_integration.supported() is (sys.platform == 'win32')


def test_extension_and_progid_are_well_formed():
    assert shell_integration.EXTENSION == '.pdf'
    assert shell_integration.PROG_ID.count('.') >= 2, 'ProgIDs are conventionally dotted'


@pytest.mark.skipif(sys.platform != 'win32', reason='Windows registry only')
@pytest.mark.skipif(not os.environ.get('PAPERDESK_TEST_REGISTRY'),
                    reason='writes to HKCU; set PAPERDESK_TEST_REGISTRY=1 to run')
def test_register_and_unregister_round_trip_leaves_no_trace():
    """Opt-in because it touches the real user registry, even though it only
    writes under HKCU and removes everything again."""
    try:
        registered = shell_integration.register()
        assert registered['ok'] is True, registered
        status = shell_integration.status()
        assert status['registered'] is True
        # Read the keys back independently of the code that wrote them.
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            rf'Software\Classes\{shell_integration.PROG_ID}\shell\open\command') as key:
            assert '%1' in winreg.QueryValueEx(key, '')[0]
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            rf'Software\Classes\{shell_integration.EXTENSION}\OpenWithProgids') as key:
            assert winreg.QueryValueEx(key, shell_integration.PROG_ID)[0] == ''
    finally:
        removed = shell_integration.unregister()
    assert removed['ok'] is True, removed
    assert removed['failed'] == [], removed
    assert removed['removed'], 'nothing was reported as removed'
    assert shell_integration.status()['registered'] is False


# ------------------------------------------------------- the compose window route
# The request was specific: the email option has to open a message with the PDF
# already on it and the recipient left for the person to fill in. An `.eml` is
# not that — Outlook shows it as a received message with no address field. These
# check the command that is handed to the mail client, which is what decides
# whether the window really is a draft.

def test_the_outlook_command_attaches_the_file_and_leaves_the_recipient_empty():
    attachment = Path('Share') / 'Report.pdf'
    command = share.outlook_command('OUTLOOK.EXE', attachment, '', '', '')
    assert command[:4] == ['OUTLOOK.EXE', '/c', 'ipm.note', '/m'], command
    assert command[-2:] == ['/a', str(attachment)], command
    address = command[4]
    # An empty address in front of the query: Outlook opens the message with an
    # empty To box and still applies the subject and the body.
    assert address.startswith('?'), address
    assert 'body=Please%20see%20the%20attached%20file' in address, address
    assert 'subject=PDF%3A%20Report.pdf' in address, address


def test_a_typed_recipient_and_message_are_used_as_given():
    command = share.outlook_command('O', Path('a.pdf'), 'client@example.com', 'Your invoice', 'Here it is')
    assert command[4] == 'client@example.com?subject=Your%20invoice&body=Here%20it%20is', command[4]


def test_the_chain_says_which_program_opened_the_message(prepared, monkeypatch):
    monkeypatch.setattr(share, 'compose_with_outlook', lambda *a, **k: {'ok': True, 'how': 'outlook'})
    result = share.mail_with_attachment(prepared['path'])
    assert result['ok'] is True and result['how'] == 'outlook', result
    assert 'Choose the recipient' in result['note'], result['note']


def test_the_recipient_is_never_invented(prepared, monkeypatch):
    seen = {}

    def fake(target, to, subject, body):
        seen.update(to=to, subject=subject, body=body)
        return {'ok': True, 'how': 'outlook'}

    monkeypatch.setattr(share, 'compose_with_outlook', fake)
    share.mail_with_attachment(prepared['path'], '', '', '')
    assert seen['to'] == '', seen


def test_with_no_client_able_to_compose_a_file_is_written_instead(prepared, monkeypatch):
    monkeypatch.setattr(share, 'compose_with_outlook', lambda *a, **k: {'ok': False, 'how': 'outlook'})
    monkeypatch.setattr(share, 'compose_with_thunderbird', lambda *a, **k: {'ok': False, 'how': 'thunderbird'})
    monkeypatch.setattr(share, 'open_url', lambda url: {'ok': True})
    result = share.mail_with_attachment(prepared['path'], '', '', '')
    assert result['ok'] is True and result['how'] == 'eml', result
    assert Path(result['draft']).exists()
    # And it says so plainly rather than pretending a draft was opened.
    assert 'Reply or Forward' in result['note'], result['note']


# ------------------------------------------- the right-click "combine" entry

def test_the_combine_command_takes_every_selected_file():
    line = shell_integration.combine_command()
    assert '--combine' in line, line
    # %* is what turns a multi-selection into one click; with %1 only the first
    # of the selected files would ever be combined.
    assert line.rstrip().endswith('%*'), line
    assert line.startswith('"'), 'the executable path must be quoted'


def test_the_menu_entry_is_under_the_file_type_not_the_app():
    # SystemFileAssociations is what makes the entry appear for a .pdf whether
    # or not KADOMA is the default handler.
    assert shell_integration.COMBINE_KEY.startswith(r'Software\Classes\SystemFileAssociations\.pdf')
    assert shell_integration.COMBINE_KEY.endswith(shell_integration.COMBINE_VERB)
    assert shell_integration.COMBINE_LABEL == 'Combine with KADOMA PDF'


def test_reading_selected_files_accepts_real_pdfs(tmp_path):
    first = tmp_path / 'one.pdf'
    first.write_bytes(SAMPLE)
    second = tmp_path / 'two.pdf'
    second.write_bytes(SAMPLE)
    documents = shell_integration.read_documents([str(first), str(second)])
    assert [name for _data, name in documents] == ['one.pdf', 'two.pdf']
    assert all(data.startswith(b'%PDF-') for data, _name in documents)


def test_a_pdf_extension_is_not_evidence_of_a_pdf(tmp_path):
    liar = tmp_path / 'pretending.pdf'
    liar.write_text('this is a text file with a .pdf name', encoding='utf-8')
    with pytest.raises(PDFError) as error:
        shell_integration.read_documents([str(liar)])
    assert 'not a PDF' in str(error.value)


def test_a_file_that_is_gone_is_reported_not_ignored(tmp_path):
    with pytest.raises(PDFError) as error:
        shell_integration.read_documents([str(tmp_path / 'gone.pdf')])
    assert 'no longer there' in str(error.value)


def test_empty_file_list_is_refused():
    with pytest.raises(PDFError) as error:
        shell_integration.read_documents([])
    assert 'one or more' in str(error.value)
