"""The document tools: watermark, header and footer, numbering, crop, bookmarks,
attachments and compression.

These are tested against a bare document rather than through the interface,
because that is the layer where a mistake writes the wrong thing into somebody's
file. The assertions are about what ends up **in the PDF** — extractable text,
page boxes, the outline tree, embedded file bytes — not about return values.
"""
import io

import pymupdf as fitz
import pytest
from PIL import Image

from support.demo_document import make_demo
from app import document_tools as tools
from app.engine import Engine, PDFError


def typed_document(pages: int = 3) -> fitz.Document:
    """A document with two heading sizes and body text, for the outline test."""
    doc = fitz.open()
    for index in range(pages):
        page = doc.new_page(width=595, height=842)
        page.insert_text((60, 100), f'Chapter {index + 1}', fontsize=26)
        page.insert_text((60, 140), 'A section heading', fontsize=16)
        page.insert_text((60, 170), 'Body text that carries the most characters by far. ' * 3,
                         fontsize=10)
    return doc


def text_of(doc: fitz.Document) -> str:
    return '\n'.join(page.get_text() for page in doc)


def png_bytes(size=(60, 30), colour=(255, 0, 0, 255)) -> bytes:
    image = Image.new('RGBA', size, colour)
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    return buffer.getvalue()


# ------------------------------------------------------------------ watermark

def test_a_text_watermark_lands_on_the_page_as_real_text():
    doc = typed_document(2)
    tools.watermark(doc, {'kind': 'text', 'text': 'CONFIDENTIAL', 'opacity': 0.2})
    for page in doc:
        assert 'CONFIDENTIAL' in page.get_text(), 'the watermark is not in the text layer'
    # It goes on every page when no selection is given.
    assert tools.watermark(doc, {'kind': 'text', 'text': 'X', 'pages': [1]})['pages'] == 1


def test_a_fainter_watermark_really_is_fainter():
    # A blank page, so the only ink on it is the watermark: on a page with body
    # text the darkest pixel is the body text and the measurement means nothing.
    faint, solid = fitz.open(), fitz.open()
    for document in (faint, solid):
        document.new_page(width=595, height=842)
    tools.watermark(faint, {'kind': 'text', 'text': 'MARK', 'opacity': 0.05, 'size': 60})
    tools.watermark(solid, {'kind': 'text', 'text': 'MARK', 'opacity': 1.0, 'size': 60})
    # The darkest pixel the watermark produces, sampled where it is drawn.
    def darkest(document):
        pixmap = document[0].get_pixmap(dpi=72, colorspace=fitz.csRGB)
        return min(pixmap.samples[0::pixmap.n])
    # The watermark colour is #7a7a7a, so at full opacity it can only ever reach
    # 122 — the test is about the gap between the two, not about absolute black.
    assert darkest(solid) < 160
    assert darkest(faint) > darkest(solid) + 60


def test_an_image_watermark_is_placed_and_keeps_its_transparency():
    doc = typed_document(1)
    tools.watermark(doc, {'kind': 'image', 'image': png_bytes(), 'opacity': 0.4, 'scale': 0.5})
    assert len(doc[0].get_images()) == 1


def test_a_watermark_needs_text_and_a_real_place_to_go():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='required'):
        tools.watermark(doc, {'kind': 'text', 'text': '   '})
    with pytest.raises(PDFError, match='where the watermark goes'):
        tools.watermark(doc, {'kind': 'text', 'text': 'X', 'layout': 'sideways'})
    with pytest.raises(PDFError, match='Opacity'):
        tools.watermark(doc, {'kind': 'text', 'text': 'X', 'opacity': 4})


# --------------------------------------------------------- header and footer

def test_tokens_expand_to_the_page_number_and_total():
    doc = typed_document(3)
    tools.header_footer(doc, {'footer_right': 'Page {page} of {pages}', 'name': 'demo.pdf'})
    assert 'Page 1 of 3' in doc[0].get_text()
    assert 'Page 3 of 3' in doc[2].get_text()


def test_the_first_page_can_be_left_alone():
    doc = typed_document(2)
    tools.header_footer(doc, {'footer_center': 'Page {page}', 'skipFirst': True})
    assert 'Page 1' not in doc[0].get_text()
    assert 'Page 2' in doc[1].get_text()


def test_numbering_can_start_anywhere():
    doc = typed_document(2)
    tools.header_footer(doc, {'footer_center': 'Page {page}', 'numberStart': 10})
    assert 'Page 10' in doc[0].get_text()
    assert 'Page 11' in doc[1].get_text()


def test_a_header_goes_above_the_content_and_a_footer_below_it():
    doc = typed_document(1)
    tools.header_footer(doc, {'header_center': 'TOP', 'footer_center': 'BOTTOM'})
    page = doc[0]
    top = page.search_for('TOP')[0]
    bottom = page.search_for('BOTTOM')[0]
    body = page.search_for('Chapter')[0]
    assert top.y1 < body.y0, 'the header is not above the body text'
    assert bottom.y0 > body.y0, 'the footer is not below the body text'


def test_an_unknown_token_is_refused_rather_than_printed():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='not one of'):
        tools.header_footer(doc, {'footer_center': 'Page {pageno}'})


def test_an_empty_header_is_refused():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='Write something'):
        tools.header_footer(doc, {'footer_center': '   '})


# ------------------------------------------------------------------- numbering

def test_bates_numbering_pads_and_offsets():
    doc = typed_document(3)
    tools.numbering(doc, {'mode': 'bates', 'prefix': 'ABC-', 'digits': 6, 'start': 42})
    assert 'ABC-000042' in doc[0].get_text()
    assert 'ABC-000044' in doc[2].get_text()


def test_page_numbering_writes_the_chosen_format():
    doc = typed_document(2)
    tools.numbering(doc, {'mode': 'page', 'format': '{page}/{pages}'})
    assert '1/2' in doc[0].get_text()
    assert '2/2' in doc[1].get_text()


# ------------------------------------------------------------------------ crop

def test_cropping_shrinks_the_page_box_without_losing_content():
    doc = typed_document(1)
    before = doc[0].rect
    tools.crop(doc, {'top': 10, 'bottom': 10, 'left': 10, 'right': 10, 'unit': 'mm'})
    after = doc[0].rect
    # 10 mm is 28.35 pt, and it comes off both sides.
    trim = 2 * 10 * 72 / 25.4
    assert after.width == pytest.approx(before.width - trim, abs=0.5)
    assert after.height == pytest.approx(before.height - trim, abs=0.5)
    assert 'Chapter 1' in doc[0].get_text(), 'cropping deleted content'


def test_cropping_to_nothing_is_refused():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='leave no page'):
        tools.crop(doc, {'left': 400, 'right': 400})


def test_cropping_with_no_margins_says_so():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='at least one margin'):
        tools.crop(doc, {})


# ------------------------------------------------------------------- bookmarks

def test_headings_become_an_outline_with_levels():
    doc = typed_document(2)
    found = tools.bookmarks(doc, {'mode': 'auto'})['bookmarks']
    titles = [entry['title'] for entry in found]
    assert titles[:2] == ['Chapter 1', 'A section heading']
    assert found[0]['level'] == 1 and found[1]['level'] == 2
    assert found[0]['page'] == 1 and found[1]['page'] == 1
    assert doc.get_toc(), 'the outline was not written into the document'


def test_a_watermark_is_not_mistaken_for_a_heading():
    doc = typed_document(3)
    tools.watermark(doc, {'kind': 'text', 'text': 'DRAFT COPY', 'size': 60, 'opacity': 0.2})
    titles = [entry['title'] for entry in tools.bookmarks(doc, {'mode': 'auto'})['bookmarks']]
    assert 'DRAFT COPY' not in titles, 'the watermark became a bookmark'


def test_the_outline_is_always_a_tree_a_reader_will_accept():
    doc = typed_document(1)
    # A first entry at level two would make PyMuPDF refuse the outline.
    tools.bookmarks(doc, {'mode': 'set', 'bookmarks': [
        {'level': 2, 'title': 'Second first', 'page': 1},
        {'level': 3, 'title': 'Deep', 'page': 1},
    ]})
    toc = doc.get_toc(simple=True)
    assert toc[0][0] == 1
    assert toc[1][0] <= 2


def test_clearing_the_outline_removes_it():
    doc = typed_document(2)
    tools.bookmarks(doc, {'mode': 'auto'})
    assert doc.get_toc()
    assert tools.bookmarks(doc, {'mode': 'clear'})['bookmarks'] == []
    assert doc.get_toc() == []


# ---------------------------------------------------------------- attachments

def test_a_file_can_be_attached_read_back_and_removed():
    doc = typed_document(1)
    payload = b'column,value\nrevenue,284750\n'
    tools.attachments(doc, {'mode': 'add', 'name': 'figures.csv', 'data': payload,
                            'description': 'Source figures'})
    listed = tools.attachments(doc, {'mode': 'list'})['attachments']
    assert [entry['name'] for entry in listed] == ['figures.csv']
    assert listed[0]['size'] == len(payload)
    assert tools.attachments(doc, {'mode': 'extract', 'name': 'figures.csv'})['data'] == payload
    tools.attachments(doc, {'mode': 'delete', 'name': 'figures.csv'})
    assert tools.attachments(doc, {'mode': 'list'})['attachments'] == []


def test_the_same_attachment_cannot_be_added_twice():
    doc = typed_document(1)
    tools.attachments(doc, {'mode': 'add', 'name': 'a.txt', 'data': b'one'})
    with pytest.raises(PDFError, match='already attached'):
        tools.attachments(doc, {'mode': 'add', 'name': 'a.txt', 'data': b'two'})


# ------------------------------------------------------------------ compression

def test_compression_keeps_the_document_and_never_grows_it():
    doc = typed_document(2)
    # A photograph-like image, which is what compression is for.
    image = Image.effect_noise((1200, 900), 60).convert('RGB')
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    doc[0].insert_image(fitz.Rect(40, 200, 555, 600), stream=buffer.getvalue())
    data, before = tools.compress(doc, {'quality': 60, 'dpi': 96})
    assert len(data) <= before, 'compression made the file bigger'
    with fitz.open(stream=data, filetype='pdf') as squeezed:
        assert len(squeezed) == 2
        assert 'Chapter 1' in squeezed[0].get_text(), 'compression lost the text'


# ------------------------------------------------------------- engine plumbing

def test_the_engine_dispatches_the_tools_and_undoes_them():
    engine = Engine()
    ident = engine.load(make_demo(), 'Quarterly performance.pdf')['id']
    result = engine.operation(ident, {'action': 'watermark', 'kind': 'text',
                                      'text': 'UNDO ME', 'pages': [0]})
    assert result['pageCount'] == 4
    # A watermark is rotated, and the plain-text export orders rotated text its
    # own way — so the honest test is whether it can be found, which is what a
    # person searching for it would do.
    assert engine.search(ident, 'UNDO ME'), 'the watermark is not searchable text'
    engine.operation(ident, {'action': 'undo'})
    assert not engine.search(ident, 'UNDO ME'), 'undo left the watermark behind'


def test_listing_bookmarks_does_not_count_as_an_edit():
    engine = Engine()
    ident = engine.load(make_demo(), 'Quarterly performance.pdf')['id']
    before = engine.meta(ident)['revision']
    engine.operation(ident, {'action': 'bookmarks', 'mode': 'list'})
    assert engine.meta(ident)['revision'] == before
    assert engine.meta(ident)['modified'] is False


def test_an_attachment_comes_back_out_through_the_engine_as_base64():
    import base64
    engine = Engine()
    ident = engine.load(make_demo(), 'Quarterly performance.pdf')['id']
    engine.operation(ident, {'action': 'attachments', 'mode': 'add',
                             'name': 'note.txt', 'data': base64.b64encode(b'hello').decode()})
    # The engine takes base64 from JSON and returns it the same way.
    found = engine.operation(ident, {'action': 'attachments', 'mode': 'extract',
                                     'name': 'note.txt'})
    assert base64.b64decode(found['result']['data']) == b'hello'


# --------------------------------------------------------------------- stamps

def test_a_stamp_is_real_text_in_the_place_it_was_asked_for():
    doc = typed_document(2)
    tools.stamp(doc, {'page': 1, 'label': 'Confidential', 'x': 100, 'y': 200, 'size': 20})
    assert 'Confidential' in doc[1].get_text(), 'the stamp is not selectable text'
    assert 'Confidential' not in doc[0].get_text(), 'the stamp landed on the wrong page'
    # It is drawn where it was clicked, not in a corner.
    hits = doc[1].search_for('Confidential')
    assert hits and 90 < hits[0].x0 < 130, f'the stamp is at {hits[0] if hits else None}'


def test_a_stamp_with_a_date_carries_the_date_as_text():
    doc = typed_document(1)
    tools.stamp(doc, {'page': 0, 'label': 'Approved', 'date': '2026-10-24'})
    assert '2026-10-24' in doc[0].get_text()


def test_an_unknown_stamp_is_refused_rather_than_invented():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='standard stamp'):
        tools.stamp(doc, {'label': 'Excellent'})


def test_a_custom_stamp_needs_its_text():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='required'):
        tools.stamp(doc, {'label': 'Custom', 'text': '  '})
    tools.stamp(doc, {'label': 'Custom', 'text': 'RECEIVED 24 OCT'})
    assert 'RECEIVED 24 OCT' in doc[0].get_text()


def test_a_stamp_near_the_edge_is_pulled_back_onto_the_page():
    doc = typed_document(1)
    tools.stamp(doc, {'page': 0, 'label': 'For Public Release', 'x': 560, 'y': 830})
    hits = doc[0].search_for('For Public Release')
    assert hits, 'the stamp is off the page'
    assert hits[0].x1 <= doc[0].rect.x1 and hits[0].y1 <= doc[0].rect.y1


# ---------------------------------------------------------------------- links

def test_a_web_link_can_be_added_listed_and_removed():
    doc = typed_document(1)
    assert tools.links(doc, {'page': 0})['links'] == []
    result = tools.links(doc, {'page': 0, 'mode': 'add', 'kind': 'uri',
                               'url': 'https://example.org', 'rect': [60, 100, 200, 120]})
    assert len(result['links']) == 1
    assert result['links'][0]['label'] == 'https://example.org'
    assert result['links'][0]['kind'] == 'web'
    tools.links(doc, {'page': 0, 'mode': 'remove', 'index': 0})
    assert doc[0].get_links() == [], 'the link was not removed'


def test_a_page_link_points_at_the_page_that_was_chosen():
    doc = typed_document(3)
    tools.links(doc, {'page': 0, 'mode': 'add', 'kind': 'goto', 'target': 3,
                      'rect': [60, 100, 200, 120]})
    found = tools.links(doc, {'page': 0})['links']
    assert found[0]['kind'] == 'page'
    assert found[0]['label'] == 'Page 3'
    assert doc[0].get_links()[0]['page'] == 2


def test_a_link_address_must_be_an_address():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='must start with'):
        tools.links(doc, {'page': 0, 'mode': 'add', 'kind': 'uri',
                          'url': 'example.org', 'rect': [60, 100, 200, 120]})


def test_a_link_needs_a_box_big_enough_to_click():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='Drag a box'):
        tools.links(doc, {'page': 0, 'mode': 'add', 'kind': 'uri',
                          'url': 'https://example.org', 'rect': [60, 100, 61, 101]})


def test_removing_a_link_that_is_no_longer_there_says_so():
    doc = typed_document(1)
    with pytest.raises(PDFError, match='no longer on this page'):
        tools.links(doc, {'page': 0, 'mode': 'remove', 'index': 3})


# --------------------------------------------------------------------- resize

def test_resizing_changes_the_paper_and_scales_the_drawing_with_it():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((60, 100), 'Top left corner', fontsize=14)
    before = page.search_for('Top left corner')[0]
    tools.resize(doc, {'size': 'A5', 'scale': True})
    reopened = fitz.open(stream=doc.tobytes(), filetype='pdf')
    box = reopened[0].rect
    assert round(box.width) == 420 and round(box.height) == 595, f'the page is {box}'
    after = reopened[0].search_for('Top left corner')[0]
    # A5 from A4 is 0.705 on both axes, anchored at the top-left corner.
    assert after.x0 == pytest.approx(before.x0 * 0.705, abs=1.0)
    assert after.y0 == pytest.approx(before.y0 * 0.705, abs=1.0)


def test_resizing_without_scaling_leaves_the_content_where_it_was():
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((60, 100), 'Unmoved text', fontsize=14)
    before = page.search_for('Unmoved text')[0]
    tools.resize(doc, {'size': 'Letter', 'scale': False})
    reopened = fitz.open(stream=doc.tobytes(), filetype='pdf')
    assert round(reopened[0].rect.width) == 612
    after = reopened[0].search_for('Unmoved text')[0]
    assert after.x0 == pytest.approx(before.x0, abs=0.5)
    assert after.y0 == pytest.approx(before.y0, abs=0.5)


def test_resizing_carries_forms_links_and_highlights_into_the_new_box():
    # Everything that floats above the page is stored in its own coordinate
    # space; scaling only the content stream would leave a signature field
    # pointing at blank paper.
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((60, 100), 'Sign here', fontsize=14)
    page.add_underline_annot(page.search_for('Sign here')[0])
    page.insert_link({'kind': fitz.LINK_URI, 'from': fitz.Rect(60, 200, 300, 220),
                      'uri': 'https://example.org'})
    widget = fitz.Widget()
    widget.field_type = fitz.PDF_WIDGET_TYPE_TEXT
    widget.field_name = 'signature'
    widget.rect = fitz.Rect(60, 400, 300, 430)
    page.add_widget(widget)
    # Every tool runs on a document reopened from the bytes it was saved to, so
    # the test does the same. The page is held in a variable on purpose: an
    # annotation whose page has been garbage collected crashes the process when
    # its rectangle is read.
    doc = fitz.open(stream=doc.tobytes(), filetype='pdf')
    reopened_page = doc[0]
    before_annot = fitz.Rect(list(reopened_page.annots() or [])[0].rect)

    tools.resize(doc, {'size': 'A5', 'scale': True})
    reopened = fitz.open(stream=doc.tobytes(), filetype='pdf')
    fresh = reopened[0]

    found = list(fresh.annots() or [])
    assert len(found) == 1, 'the annotation was lost'
    assert found[0].rect.x0 == pytest.approx(before_annot.x0 * 0.705, abs=1.5)
    assert found[0].rect.y0 == pytest.approx(before_annot.y0 * 0.705, abs=1.5)

    links = fresh.get_links()
    assert len(links) == 1, 'the link was lost'
    assert links[0]['from'].x1 == pytest.approx(300 * 0.705, abs=1.5)

    fields = list(fresh.widgets() or [])
    assert len(fields) == 1, 'the form field was lost'
    assert fields[0].rect.x0 == pytest.approx(60 * 0.705, abs=1.5)
    assert fields[0].rect.y0 == pytest.approx(400 * 0.705, abs=1.5)


def test_resizing_only_the_pages_that_were_chosen():
    doc = typed_document(3)
    tools.resize(doc, {'size': 'A5', 'pages': [1]})
    assert round(doc[0].rect.width) == 595
    assert round(doc[1].rect.width) == 420


def test_a_custom_page_size_is_measured_in_the_unit_that_was_chosen():
    doc = typed_document(1)
    tools.resize(doc, {'size': 'Custom', 'width': 100, 'height': 150, 'unit': 'mm', 'scale': False})
    assert doc[0].rect.width == pytest.approx(283.46, abs=0.5)
    with pytest.raises(PDFError, match='Choose points'):
        tools.resize(doc, {'size': 'A4', 'unit': 'furlongs'})


# -------------------------------------------------------------------- compare

def test_comparing_a_document_with_itself_finds_no_differences():
    left = typed_document(2)
    right = fitz.open(stream=left.tobytes(), filetype='pdf')
    report = tools.compare(left, right)
    assert report['identical'] is True
    assert report['differing'] == 0
    assert report['total'] == 2


def test_a_changed_page_names_the_words_that_changed():
    left = typed_document(2)
    right = fitz.open(stream=left.tobytes(), filetype='pdf')
    right[1].insert_text((60, 320), 'An added sentence.', fontsize=11)
    report = tools.compare(left, right)
    assert report['differing'] == 1
    page = report['pages'][1]
    assert page['status'] == 'changed'
    assert 'sentence.' in page['added'], page['added']
    assert page['removedCount'] == 0
    assert report['pages'][0]['status'] == 'same'


def test_a_page_that_only_exists_on_one_side_is_reported_as_such():
    left = typed_document(2)
    right = typed_document(1)
    report = tools.compare(left, right)
    assert report['total'] == 2
    assert report['pages'][1]['status'] == 'removed'
    assert report['leftPages'] == 2 and report['rightPages'] == 1
    assert tools.compare(right, left)['pages'][1]['status'] == 'added'


def test_the_engine_compares_two_open_documents_without_editing_either():
    engine = Engine()
    left = engine.load(make_demo(), 'Quarterly performance.pdf')['id']
    right = engine.load(engine.documents[left].data, 'copy.pdf')['id']
    before = engine.meta(left)['revision']
    report = engine.compare_documents(left, right)
    assert report['identical'] is True
    assert engine.meta(left)['revision'] == before
    with pytest.raises(PDFError, match='Choose a document'):
        engine.compare_documents(left, '')


def test_a_watermark_is_not_a_heading_even_on_a_single_page():
    # Repetition across pages is the usual signal for furniture, and a one-page
    # document has no repetition to measure — the rotated direction is what
    # saves it there.
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_text((60, 100), 'Chapter 1', fontsize=26)
    page.insert_text((60, 140), 'Body text that carries the most characters. ' * 4, fontsize=10)
    tools.watermark(doc, {'kind': 'text', 'text': 'DRAFT COPY', 'size': 60, 'opacity': 0.2})
    titles = [entry['title'] for entry in tools.bookmarks(doc, {'mode': 'auto'})['bookmarks']]
    assert titles == ['Chapter 1'], f'the outline is {titles!r}'
