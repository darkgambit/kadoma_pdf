"""The window that has to come to the front, and the one that takes it back.

The Win32 calls themselves are exercised against a real WebView2 window by
`scripts/check_window_front.py`. These tests pin the *decision* — when the
application should give up the topmost style and when it should take it back —
without needing a desktop session, by substituting a fake window manager.
"""
from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

from app import window_front
from app.server import app as server_app, engine, yield_front

FAKE_HWND = 0x1234
OTHER_HWND = 0x9999


class FakeFront:
    """A window manager with a scripted foreground and a recorded style."""

    def __init__(self, foreground=FAKE_HWND, hwnd=FAKE_HWND, available=True):
        self.foreground = foreground
        self.hwnd = hwnd
        self.available = available
        self.styles: list[bool] = []
        self.topmost = True

    def apply(self, hwnd, flag):
        self.styles.append(flag)
        self.topmost = flag
        return True


@pytest.fixture
def fake(monkeypatch):
    """Run the guard on Windows semantics with a fake window manager."""
    front = FakeFront()
    monkeypatch.setattr(window_front, 'IS_WINDOWS', True)
    monkeypatch.setattr(window_front, 'set_topmost', front.apply)
    monkeypatch.setattr(window_front, 'foreground_window', lambda: front.foreground)
    monkeypatch.setattr(window_front.FrontGuard, 'resolve',
                        lambda self: front.hwnd if front.available else None)
    return front


@pytest.fixture
def desktop():
    """A desktop-shell client. The loopback guard reads the peer address."""
    engine.documents.clear()
    server_app.state.token = None
    server_app.state.desktop = True
    server_app.state.pending_open = []
    server_app.state.release_front = None
    with TestClient(server_app, raise_server_exceptions=True,
                    client=('127.0.0.1', 50000)) as client:
        yield client
    server_app.state.release_front = None
    server_app.state.token = None
    server_app.state.desktop = False
    server_app.state.pending_open = []
    engine.documents.clear()


def test_non_windows_is_a_no_op(monkeypatch):
    monkeypatch.setattr(window_front, 'IS_WINDOWS', False)
    assert window_front.set_topmost(FAKE_HWND, False) is False
    assert window_front.is_topmost(FAKE_HWND) is False
    assert window_front.app_windows() == []
    assert window_front.foreground_window() is None
    guard = window_front.FrontGuard()
    assert guard.release() is False
    assert guard.start() is False


def test_release_drops_the_style_immediately(fake):
    guard = window_front.FrontGuard(interval=0.01, no_show_timeout=60)
    assert guard.release() is True
    assert fake.styles == [False]
    assert guard.released is True
    guard.stop()


def test_an_external_window_in_front_keeps_the_style_off(fake):
    guard = window_front.FrontGuard(interval=0.01, no_show_timeout=0.2)
    guard.start()
    guard.release()
    fake.foreground = OTHER_HWND
    time.sleep(0.25)
    # The no-show timeout has elapsed, but a real external window was seen, so
    # the application must NOT jump back in front of the compose window.
    assert guard.released is True
    assert fake.topmost is False
    guard.stop()


def test_coming_back_to_kadoma_restores_the_style(fake):
    guard = window_front.FrontGuard(interval=0.01, no_show_timeout=60)
    guard.start()
    guard.release()
    fake.foreground = OTHER_HWND
    time.sleep(0.05)
    fake.foreground = FAKE_HWND
    deadline = time.monotonic() + 2
    while guard.released and time.monotonic() < deadline:
        time.sleep(0.01)
    assert guard.released is False
    assert fake.styles[-1] is True
    guard.stop()


def test_a_hand_off_that_never_shows_a_window_does_not_demote_forever(fake):
    guard = window_front.FrontGuard(interval=0.01, no_show_timeout=0.05)
    guard.start()
    guard.release()
    deadline = time.monotonic() + 2
    while guard.released and time.monotonic() < deadline:
        time.sleep(0.01)
    assert guard.released is False
    assert fake.styles == [False, True]
    guard.stop()


def test_a_release_asked_before_the_window_exists_is_applied_later(fake):
    fake.available = False
    guard = window_front.FrontGuard(interval=0.01, no_show_timeout=60)
    guard.start()
    assert guard.release() is False  # no handle yet, but the request is kept
    fake.available = True
    fake.foreground = OTHER_HWND
    deadline = time.monotonic() + 2
    while not fake.styles and time.monotonic() < deadline:
        time.sleep(0.01)
    assert fake.styles[0] is False
    guard.stop()


# ------------------------------------------------------- the routes that yield

def test_yield_front_is_best_effort(desktop):
    """No callback, a broken callback — neither may stop the real action."""
    assert yield_front() is False

    def broken():
        raise RuntimeError('no window')

    server_app.state.release_front = broken
    assert yield_front() is False
    calls = []
    server_app.state.release_front = lambda: calls.append('released') or True
    assert yield_front() is True
    assert calls == ['released']


@pytest.mark.parametrize('path,payload', [
    ('/api/share/reveal', {'path': 'missing.pdf'}),
    ('/api/system/print/preferences', {}),
    ('/api/system/default-app', {'action': 'settings'}),
])
def test_external_window_routes_step_aside_first(desktop, path, payload, monkeypatch):
    calls = []
    server_app.state.release_front = lambda: calls.append(path)
    # These routes reach outside the process; only the fact that they yield is
    # under test, so the external call itself is replaced with a quiet answer.
    monkeypatch.setattr('app.share.reveal', lambda _p: {'ok': True})
    monkeypatch.setattr('app.printing.printer_preferences', lambda _p: {'ok': True})
    monkeypatch.setattr('app.shell_integration.open_settings', lambda: {'ok': True})
    desktop.post(path, json=payload)
    assert calls == [path], path


def test_email_route_steps_aside_before_composing(desktop, monkeypatch):
    calls = []
    server_app.state.release_front = lambda: calls.append('email')
    monkeypatch.setattr('app.share.mail_with_attachment',
                        lambda *a, **k: {'ok': True, 'how': 'outlook'})
    response = desktop.post('/api/share/email', json={'path': 'x.pdf', 'attach': True})
    assert response.status_code == 200, response.text
    assert calls == ['email']


def test_an_overlong_email_is_refused_without_opening_any_window(desktop, monkeypatch):
    calls = []
    server_app.state.release_front = lambda: calls.append('email')
    response = desktop.post('/api/share/email', json={'path': 'x.pdf', 'body': 'x' * 4001})
    assert response.status_code == 422
    assert calls == []


def test_clipboard_and_prepare_do_not_touch_the_window(desktop, monkeypatch):
    """Neither opens a window, so neither should demote the application."""
    calls = []
    server_app.state.release_front = lambda: calls.append('released')
    monkeypatch.setattr('app.share.copy_file', lambda _p: {'ok': True})
    assert desktop.post('/api/share/clipboard', json={'path': 'x.pdf'}).status_code == 200
    assert calls == []
