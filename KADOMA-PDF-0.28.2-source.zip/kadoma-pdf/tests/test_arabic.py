"""Right-to-left (Arabic) support.

These tests pin down the four things that actually break Arabic in a PDF
editor, each of which was established by measurement rather than assumption:

* detection, so Latin text is never routed down the RTL path;
* reading shaped text back as the letters the user typed;
* finding Arabic words, which is impossible against the raw stored text;
* choosing a font that round-trips, not merely one that looks right.
"""
from io import BytesIO

import pymupdf as fitz
import pytest

from app import rtl
from app.engine import Engine, PDFError, capabilities

ARABIC = 'مرحبا بالعالم'
INVOICE = 'الفاتورة رقم ٢٠٤٨'


@pytest.fixture
def engine():
    return Engine()


@pytest.fixture
def blank(engine):
    return engine.blank()


def text_in(engine, ident):
    return engine.export(ident, 'txt')[0].decode('utf-8')


# ------------------------------------------------------------------ detection

def test_rtl_detection_covers_the_scripts_that_matter():
    assert rtl.is_rtl(ARABIC)
    assert rtl.is_rtl('שלום')            # Hebrew
    assert rtl.is_rtl('سلام')            # Persian/Arabic
    assert rtl.is_rtl('٢٠٤٨')            # Arabic-Indic digits are Arabic block
    assert not rtl.is_rtl('Quarterly performance report')
    assert not rtl.is_rtl('')
    assert not rtl.is_rtl(None)


def test_rtl_ratio_distinguishes_mixed_text_from_latin():
    assert rtl.rtl_ratio(ARABIC) == 1.0
    assert rtl.rtl_ratio('Total 284') == 0.0
    # One Arabic word in an otherwise Latin label lands strictly between the
    # two extremes, and a longer Latin label pushes the ratio further down.
    assert 0 < rtl.rtl_ratio('Invoice الفاتورة') < 1.0
    assert rtl.rtl_ratio('Quarterly performance report الفاتورة') < 0.3


# ------------------------------------------------------- presentation forms

def test_logical_converts_shaped_forms_back_to_typed_letters():
    # The lam-alef ligature is what shaping produces for "لا".
    shaped = '\ufefb'  # ARABIC LIGATURE LAM WITH ALEF ISOLATED FORM
    assert rtl.logical(shaped) == '\u0644\u0627'
    # Measured: this is the exact byte sequence MuPDF stores for "بمحمد".
    # It is not guessable — the medial meem and final dal variants in
    # particular are easy to get wrong — so the expectation is pinned to a
    # real read-back rather than composed by hand.
    assert rtl.logical('\ufe91\ufee4\ufea4\ufee4\ufeaa') == '\u0628\u0645\u062d\u0645\u062f'


def test_logical_leaves_unrelated_text_untouched():
    """NFKC must not be applied blanket: it would rewrite text we did not shape."""
    assert rtl.logical('Quarterly') == 'Quarterly'
    # The "fi" ligature is not an Arabic presentation form and must survive.
    assert rtl.logical('of\ufb01ce') == 'of\ufb01ce'
    assert rtl.logical('') == ''
    assert rtl.logical(None) is None


def test_search_key_folds_digits_spaces_and_case():
    assert rtl.search_key('٢٠٤٨') == '2048'      # Arabic-Indic
    assert rtl.search_key('۲۰۴۸') == '2048'      # Extended/Persian
    assert rtl.search_key('a\u00a0b') == 'a b'   # no-break space
    assert rtl.search_key('Quarterly') == 'quarterly'


# --------------------------------------------------------------- font choice

def test_a_font_is_chosen_and_its_quality_is_declared():
    chosen = rtl.choose_font()
    assert chosen['path'], 'no Arabic-capable font found on this machine'
    assert chosen['quality'] in ('exact', 'approximate')
    assert chosen['correct'] > 0


def test_choose_font_prefers_a_faithful_round_trip():
    """A font that renders but reads back corrupted is worse than none.

    Measured here rather than assumed: whatever this machine offers, the chosen
    font must be at least as faithful as every other candidate, and an exact
    font must win outright when one exists.
    """
    chosen = rtl.choose_font(force=True)
    scored = [(p, rtl._measure(p)) for p in rtl.font_candidates()]
    usable = [(p, c, w) for p, (c, w) in scored if c]
    assert usable, 'no usable font to compare against'
    best_wrong = min(w for _p, _c, w in usable)
    assert chosen['wrong'] == best_wrong
    if any(w == 0 for _p, _c, w in usable):
        assert chosen['exact'], 'an exact font exists but was not chosen'


def test_the_bundled_font_ships_and_covers_arabic():
    """The fallback has to be present in the build, or a machine with no
    Arabic system font would simply refuse to add RTL text."""
    assert rtl.BUNDLED_FONT.is_file(), f'missing bundled font: {rtl.BUNDLED_FONT}'
    font = fitz.Font(fontfile=str(rtl.BUNDLED_FONT))
    for char in 'مرحبا بالعالم الفاتورة':
        assert font.has_glyph(ord(char)), f'bundled font lacks {char!r}'


# ------------------------------------------------------------ engine: writing

def test_capabilities_declare_rtl_support():
    caps = capabilities()
    assert caps['rtlText'] is True
    assert caps['rtlQuality'] in ('exact', 'approximate')
    assert isinstance(caps['rtlBundledFont'], bool)


def test_added_arabic_reads_back_as_the_letters_typed(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 18})
    stored = text_in(engine, ident)
    # Every word must be present in logical form, not as presentation forms.
    for word in ARABIC.split():
        assert word in stored, f'{word!r} missing from {stored!r}'
    assert not any(0xFB50 <= ord(c) <= 0xFEFF for c in stored), 'shaped forms leaked out'


def test_content_marks_arabic_runs_as_rtl_and_latin_as_not(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 18})
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 600, 460, 640], 'text': 'Latin line', 'size': 18})
    spans = engine.content(ident, 0)['spans']
    arabic = [s for s in spans if rtl.is_rtl(s['text'])]
    latin = [s for s in spans if 'Latin' in s['text']]
    assert arabic and arabic[0]['rtl'] is True
    assert latin and latin[0]['rtl'] is False


def test_arabic_survives_a_full_round_trip_through_the_document(engine, blank):
    """Write it, read it, write it again. Corruption shows up on the second pass."""
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': INVOICE, 'size': 18})
    first = text_in(engine, ident)
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 600, 460, 640], 'text': 'second', 'size': 18})
    second = text_in(engine, ident)
    assert 'الفاتورة' in first and 'الفاتورة' in second
    assert 'رقم' in first and 'رقم' in second


def test_rtl_text_grows_into_free_space_on_the_left(engine):
    """Arabic reads right-to-left, so a longer replacement must expand leftwards.

    Growing to the right instead would push the text over whatever sits to its
    right — usually the page margin.
    """
    ident = engine.blank()['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [400, 700, 500, 730], 'text': 'مرحبا', 'size': 18})
    span = next(s for s in engine.content(ident, 0)['spans'] if rtl.is_rtl(s['text']))
    before = fitz.Rect(span['rect'])
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': span['rect'],
                             'text': 'مرحبا بالعالم الجميل', 'size': 18})
    after = fitz.Rect(next(s for s in engine.content(ident, 0)['spans']
                           if rtl.is_rtl(s['text']))['rect'])
    assert after.width > before.width, 'text did not grow'
    assert after.x0 < before.x0, 'RTL text grew to the right instead of the left'
    assert after.x1 <= before.x1 + 1, 'the right edge moved right, over the margin'


# ------------------------------------------------------------ engine: finding

def test_arabic_is_searchable_even_though_it_is_stored_shaped(engine, blank):
    """The raw stored text contains presentation forms, so a naive search for
    the typed word returns nothing. This is the regression that guards it."""
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': INVOICE, 'size': 18})
    assert engine.search(ident, 'الفاتورة'), 'single Arabic word not found'
    assert engine.search(ident, 'رقم'), 'second Arabic word not found'
    assert engine.search(ident, INVOICE), 'full Arabic phrase not found'


def test_arabic_search_finds_nothing_in_a_document_that_lacks_it(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 18})
    assert engine.search(ident, 'ليس هنا') == []


def test_search_results_are_not_duplicated(engine, blank):
    """The Arabic path can report the same hit twice: once from the ordinary
    search and once from the word-window fallback."""
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': INVOICE, 'size': 18})
    hits = engine.search(ident, 'الفاتورة')
    keys = {(h['page'], round(h['rect'][0], 1), round(h['rect'][1], 1)) for h in hits}
    assert len(keys) == len(hits), f'duplicate hits: {hits}'


# ------------------------------------------------------------ engine: replacing

def test_replacing_arabic_keeps_it_readable(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': INVOICE, 'size': 18})
    span = next(s for s in engine.content(ident, 0)['spans'] if rtl.is_rtl(s['text']))
    engine.operation(ident, {'action': 'replace_text', 'page': 0, 'rect': span['rect'],
                             'text': 'الفاتورة رقم ٩٩٩٩', 'size': 18})
    stored = text_in(engine, ident)
    # The digits are compared through search_key rather than literally: the font
    # is free to substitute the Extended Arabic-Indic variant (U+06F9) for the
    # Arabic-Indic one that was typed, and that is not a defect. This is the
    # same folding the search path relies on.
    folded = rtl.search_key(stored)
    assert '9999' in folded, stored
    assert '2048' not in folded, stored
    assert 'الفاتورة' in stored
    assert engine.search(ident, 'الفاتورة'), 'replaced Arabic is no longer searchable'
    assert engine.search(ident, '٩٩٩٩'), 'the new digits are not searchable in any variant'


def test_arabic_edit_is_undoable_like_any_other(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 18})
    engine.operation(ident, {'action': 'undo'})
    assert 'مرحبا' not in text_in(engine, ident)
    engine.operation(ident, {'action': 'redo'})
    assert 'مرحبا' in text_in(engine, ident)


# --------------------------------------------------------- honest failure mode

def test_rtl_text_fails_loudly_when_no_font_can_be_found(engine, blank, monkeypatch):
    """Better an explicit error than silently writing reversed, disconnected
    letters that look like corruption the user cannot undo."""
    monkeypatch.setattr(rtl, 'font_candidates', lambda: [])
    monkeypatch.setattr(rtl, '_FONT_CACHE', {})
    ident = blank['id']
    with pytest.raises(PDFError) as caught:
        engine.operation(ident, {'action': 'add_text', 'page': 0,
                                 'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 18})
    assert caught.value.code == 'rtl_font_missing'


def test_latin_text_still_works_when_no_arabic_font_exists(engine, blank, monkeypatch):
    """The missing font must not disable the whole editor."""
    monkeypatch.setattr(rtl, 'font_candidates', lambda: [])
    monkeypatch.setattr(rtl, '_FONT_CACHE', {})
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': 'Still fine', 'size': 18})
    assert 'Still fine' in text_in(engine, ident)


def test_arabic_render_produces_a_real_page(engine, blank):
    ident = blank['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0,
                             'rect': [60, 700, 460, 740], 'text': ARABIC, 'size': 24})
    png = engine.render(ident, 0, 1.0)
    assert png.startswith(b'\x89PNG')
    assert len(png) > 1000
