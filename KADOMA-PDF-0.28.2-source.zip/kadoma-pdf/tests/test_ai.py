"""The offline reading, and the optional model connection.

The offline half is ordinary text analysis and is tested as such: what it picks,
what it refuses, and that it quotes the document rather than inventing anything.
The model half is tested against a stub endpoint on loopback, so the request
shape, the auth header, the reply parsing and every failure mode are exercised
without a provider, a key or a network.
"""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from app import ai


# ------------------------------------------------------------------ sentences

def test_sentences_survive_decimals_and_abbreviations():
    text = ("Churn held at 2.1 percent. Mr. Smith noted the target, e.g. in the north. "
            "See p. 12 for detail.")
    assert ai.sentences(text) == [
        'Churn held at 2.1 percent.',
        'Mr. Smith noted the target, e.g. in the north.',
        'See p. 12 for detail.',
    ]


def test_a_closing_quote_stays_with_the_sentence_it_closes():
    assert ai.sentences('He said "hello." Then he left.') == ['He said "hello."', 'Then he left.']


def test_a_wrapped_line_is_not_a_new_sentence():
    text = ("Revenue increased while costs stayed below plan. We enter\n"
            "the next quarter with a healthy margin.")
    assert ai.sentences(text) == [
        'Revenue increased while costs stayed below plan.',
        'We enter the next quarter with a healthy margin.',
    ]


def test_a_designed_document_is_broken_at_the_lines_that_start_something():
    # A report extracts as a run of headings with almost no full stops. The lines
    # that start with a capital are new items; the one that carries on in lower
    # case is part of the heading above it.
    text = ("N NORTHLINE FINANCIAL REPORT\nQ3 2026 / JULY - SEPTEMBER\n"
            "Quarterly\nperformance report\nPrepared by Finance Operations")
    parts = ai.sentences(text)
    assert 'N NORTHLINE FINANCIAL REPORT' in parts
    assert 'Q3 2026 / JULY - SEPTEMBER' in parts
    # The lower-case line carries on the heading above it rather than starting a
    # new one, which is how a wrapped line is told from a new item.
    assert 'Quarterly performance report' in parts


def test_sentences_handles_other_scripts():
    assert ai.sentences('مرحبا بالعالم. هذه فقرة ثانية.') == ['مرحبا بالعالم.', 'هذه فقرة ثانية.']
    assert ai.sentences('第一句。第二句。') == ['第一句。', '第二句。']


# ------------------------------------------------------------------ summarise

PROSE = (
    'Quarterly performance review. Revenue grew by 12 percent this quarter, driven mainly by the '
    'new subscription tier. Expenses rose more slowly than revenue, so the operating margin '
    'improved from 18 percent to 21 percent. Churn remained flat at 2.1 percent. The company '
    'expects revenue of 4.5 million next quarter.'
)


def test_the_summary_quotes_the_document_and_nothing_else():
    result = ai.summarize(PROSE, 3)
    assert result['selected'] == 3
    assert result['sentenceCount'] == 5
    # Every sentence returned is one of the document's own, unchanged.
    for sentence in result['sentences']:
        assert sentence in PROSE
    assert '2.1' not in result['summary'] or '2.1 percent' in result['summary']


def test_the_summary_keeps_document_order():
    result = ai.summarize(PROSE, 4)
    positions = [PROSE.index(sentence) for sentence in result['sentences']]
    assert positions == sorted(positions)


def test_the_summary_ignores_running_headers_and_short_fragments():
    text = ('NORTHLINE / INTERNAL WORKING DOCUMENT 01\n'
            'A strong third quarter, led by growth in our product teams.\n'
            'NORTHLINE / INTERNAL WORKING DOCUMENT 02\n'
            'Revenue by department\n'
            'Margin improved while costs stayed below plan.\n')
    result = ai.summarize(text, 2)
    joined = ' '.join(result['sentences'])
    assert 'INTERNAL WORKING DOCUMENT' not in joined
    assert 'Revenue by department' not in joined


def test_keywords_ignore_stop_words_and_numbers():
    words = ai.keywords('The revenue was 12 and the revenue grew while the revenue held. ' * 2)
    assert 'revenue' in words
    assert 'the' not in words and '12' not in words


def test_summarising_a_document_with_no_text_says_so():
    with pytest.raises(ai.AIError) as caught:
        ai.summarize('   \n\n  ')
    assert caught.value.code == 'no_text'
    assert 'OCR' in caught.value.message


# ------------------------------------------------------------- prompt to form

def test_a_plain_sentence_becomes_the_fields_it_names():
    fields = ai.parse_form_prompt('Add a full name, email, phone number and date signed')
    assert [(f['label'], f['kind']) for f in fields] == [
        ('Full name', 'text'), ('Email', 'text'), ('Phone', 'text'), ('Date signed', 'date')]


def test_the_order_is_the_order_they_were_asked_for():
    fields = ai.parse_form_prompt('I need the company, then a signature, and last an email')
    assert [f['label'] for f in fields] == ['Company', 'Signature', 'Email']


def test_a_type_word_in_front_of_a_phrase_is_that_phrase_s_type():
    fields = ai.parse_form_prompt('a checkbox to agree to the terms')
    assert [(f['label'], f['kind']) for f in fields] == [('Agree', 'checkbox')]


def test_a_bare_checkbox_beside_another_field_is_a_field_of_its_own():
    fields = ai.parse_form_prompt('add a checkbox and a signature')
    assert [(f['label'], f['kind']) for f in fields] == [('Checkbox', 'checkbox'), ('Signature', 'text')]


def test_a_longer_phrase_is_not_also_its_own_shorter_field():
    fields = ai.parse_form_prompt('the date of birth and the address line 1')
    assert [f['label'] for f in fields] == ['Date of birth', 'Address line 1']


def test_quoted_names_are_taken_as_written():
    fields = ai.parse_form_prompt('Create a form with "Project code", "Reviewer" and "Approved"')
    assert [(f['label'], f['kind']) for f in fields] == [
        ('Project code', 'text'), ('Reviewer', 'text'), ('Approved', 'checkbox')]


def test_options_attach_to_the_field_they_belong_to():
    fields = ai.parse_form_prompt('a dropdown for department with options Sales, Support, Finance')
    assert len(fields) == 1
    assert fields[0]['label'] == 'Department' and fields[0]['kind'] == 'dropdown'
    assert fields[0]['choices'] == ['Sales', 'Support', 'Finance']


def test_options_with_no_field_become_a_field_of_their_own():
    fields = ai.parse_form_prompt('choose from Yes, No')
    assert len(fields) == 1 and fields[0]['kind'] == 'dropdown'
    assert fields[0]['choices'] == ['Yes', 'No']


def test_field_names_are_safe_and_unique_ready():
    fields = ai.parse_form_prompt('full name, date signed')
    assert [f['name'] for f in fields] == ['full_name', 'date_signed']
    assert ai.field_name('2026 Total') == 'field_2026_total'


def test_a_prompt_naming_nothing_is_refused_with_an_example():
    for prompt in ('what do you think?', ''):
        with pytest.raises(ai.AIError) as caught:
            ai.parse_form_prompt(prompt)
        assert 'full name' in caught.value.message


def test_a_dropdown_with_no_options_is_not_a_dropdown():
    assert ai.field_spec('Department', 'dropdown', [])['kind'] == 'text'


# -------------------------------------------------------------------- layout

def test_fields_are_laid_out_in_two_columns_and_a_wide_one_takes_the_row():
    fields = [{'wide': False}] * 2 + [{'wide': True}] + [{'wide': False}] * 2
    rects = ai.layout_fields(fields)
    assert rects[0][0] == 56 and rects[1][0] > rects[0][0]      # side by side
    assert rects[0][1] == rects[1][1]                            # same row
    assert rects[2][0] == 56 and rects[2][2] > rects[0][2]       # wide, full width
    assert rects[3][1] > rects[2][1]                             # a new row after it
    assert rects[3][0] == rects[4][0] - 253.5 or rects[4][0] > rects[3][0]


def test_more_fields_than_fit_are_refused_rather_than_run_off_the_page():
    with pytest.raises(ai.AIError) as caught:
        ai.layout_fields([{'wide': False}] * 60)
    assert 'fit on one page' in caught.value.message
    # And nothing is placed past the bottom margin when they do fit.
    for rect in ai.layout_fields([{'wide': False}] * 10):
        assert rect[3] <= 842 - 72 + 0.01


# -------------------------------------------------------------- model address

def test_the_chat_url_is_built_from_a_base_or_a_full_address():
    assert ai.chat_url('https://api.openai.com/v1') == 'https://api.openai.com/v1/chat/completions'
    assert ai.chat_url('http://localhost:11434/v1/') == 'http://localhost:11434/v1/chat/completions'
    assert ai.chat_url('https://x/y/chat/completions') == 'https://x/y/chat/completions'


def test_a_model_address_that_is_not_http_is_refused():
    for bad in ('ftp://host/v1', 'file:///etc/passwd', 'nonsense', ''):
        with pytest.raises(ai.AIError):
            ai.chat_url(bad)


# ------------------------------------------------------------------- the model

class StubModel(BaseHTTPRequestHandler):
    reply = 'a summary'
    status = 200
    seen: list = []

    def do_POST(self):                                             # noqa: N802
        length = int(self.headers.get('content-length', 0))
        StubModel.seen.append({
            'path': self.path,
            'auth': self.headers.get('authorization'),
            'body': json.loads(self.rfile.read(length) or b'{}'),
        })
        if StubModel.status != 200:
            payload = json.dumps({'error': {'message': 'no such model'}}).encode()
        else:
            payload = json.dumps({'choices': [{'message': {'content': StubModel.reply}}]}).encode()
        self.send_response(StubModel.status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *args):                                  # noqa: D102
        pass


@pytest.fixture
def model_server():
    server = HTTPServer(('127.0.0.1', 0), StubModel)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    StubModel.seen = []
    StubModel.reply, StubModel.status = 'a summary', 200
    yield f'http://127.0.0.1:{server.server_port}/v1'
    server.shutdown()


def test_a_summary_request_carries_the_model_the_key_and_the_text(model_server):
    config = ai.ModelConfig(endpoint=model_server, model='test-model', api_key='sk-secret')
    assert ai.model_summary(config, 'Revenue rose this quarter.', 3) == 'a summary'
    call = StubModel.seen[-1]
    assert call['path'].endswith('/v1/chat/completions')
    assert call['auth'] == 'Bearer sk-secret'
    assert call['body']['model'] == 'test-model'
    assert call['body']['stream'] is False
    assert 'Revenue rose this quarter.' in call['body']['messages'][1]['content']
    assert 'same language' in call['body']['messages'][0]['content']


def test_a_long_document_is_clipped_before_it_is_sent(model_server):
    config = ai.ModelConfig(endpoint=model_server, model='m', api_key='k')
    ai.model_summary(config, 'word ' * 40000, 3)
    sent = StubModel.seen[-1]['body']['messages'][1]['content']
    assert len(sent) <= ai.MAX_MODEL_CHARS + 200
    assert sent.endswith('\u2026')


def test_a_refusal_from_the_model_is_reported_with_its_reason(model_server):
    StubModel.status = 404
    config = ai.ModelConfig(endpoint=model_server, model='m', api_key='k')
    with pytest.raises(ai.AIError) as caught:
        ai.model_summary(config, 'text', 3)
    assert caught.value.status == 502
    assert 'HTTP 404' in caught.value.message and 'no such model' in caught.value.message


def test_an_unreachable_model_is_reported_as_such():
    config = ai.ModelConfig(endpoint='http://127.0.0.1:9/v1', model='m', api_key='k')
    with pytest.raises(ai.AIError) as caught:
        ai.model_summary(config, 'text', 3)
    assert caught.value.code == 'ai_unreachable'


def test_an_unconfigured_model_is_refused_before_any_request():
    with pytest.raises(ai.AIError) as caught:
        ai.model_summary(ai.ModelConfig(), 'text', 3)
    assert caught.value.code == 'ai_not_configured'


def test_a_reply_that_is_not_what_was_asked_for_is_refused(model_server):
    config = ai.ModelConfig(endpoint=model_server, model='m', api_key='k')
    StubModel.reply = 'I think you should add a name field.'
    with pytest.raises(ai.AIError) as caught:
        ai.model_fields(config, 'a name field')
    assert caught.value.code == 'ai_bad_response'
    # A fenced code block around valid JSON is accepted, because that is what
    # most models actually send.
    StubModel.reply = '```json\n{"fields":[{"label":"Name","type":"text"}]}\n```'
    assert ai.model_fields(config, 'a name field')[0]['label'] == 'Name'


def test_the_model_cannot_smuggle_in_a_field_this_application_cannot_build():
    fields = ai.clean_model_fields({'fields': [
        {'label': 'Name', 'type': 'text'},
        {'label': 'Signed', 'type': 'date'},
        {'label': 'Odd', 'type': 'nonsense'},
        {'label': 'Pick', 'type': 'dropdown', 'choices': ['A', 'B']},
        {'label': 'Empty dropdown', 'type': 'dropdown'},
        {'label': '', 'type': 'text'},
        'not an object',
    ]})
    assert [(f['label'], f['kind']) for f in fields] == [
        ('Name', 'text'), ('Signed', 'date'), ('Odd', 'text'),
        ('Pick', 'dropdown'), ('Empty dropdown', 'text')]


def test_a_model_reply_with_no_usable_fields_is_refused():
    with pytest.raises(ai.AIError):
        ai.clean_model_fields({'fields': [{'label': ''}]})
    with pytest.raises(ai.AIError):
        ai.clean_model_fields({'nothing': 'here'})
