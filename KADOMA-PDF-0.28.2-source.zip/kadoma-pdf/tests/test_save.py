"""Saving: the only path in this application that writes over a user's file.

The rules being tested are the ones that make an overwrite safe rather than the
ones that make it work: a file that changed since it was read is never replaced,
a protected original is never turned into an unprotected one, and a failed write
never leaves a half-written PDF where a good one used to be.
"""
import os
import stat
import sys

import pymupdf as fitz
import pytest
from fastapi.testclient import TestClient

from support.demo_document import make_demo
from app.engine import Engine, PDFError, same_file
from app.server import app, engine as shared_engine


def source_pdf(path, text='ORIGINAL PAGE'):
    """A one-page PDF on disk, so there is something real to save over."""
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), text, fontsize=22)
        path.write_bytes(doc.tobytes(deflate=True))
    return path


def page_text(path):
    with fitz.open(path) as doc:
        return '\n'.join(page.get_text() for page in doc)


@pytest.fixture
def engine():
    return Engine()


@pytest.fixture
def opened(engine, tmp_path):
    """(engine, info, path) for a document opened from a real file."""
    path = source_pdf(tmp_path / 'Report.pdf')
    return engine, engine.load(path.read_bytes(), path.name, path=path), path


# ------------------------------------------------------------------- the engine

def test_save_writes_over_the_file_and_reports_it_saved(opened):
    engine, info, path = opened
    ident = info['id']
    assert info['path'] == str(path) and info['canSave'] is True
    assert info['savedRevision'] is None and info['dirty'] is False

    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'SAVED EDIT', 'size': 18})
    assert engine.meta(ident)['dirty'] is True

    result = engine.save(ident)
    assert result['saved'] is True and result['path'] == str(path)
    assert 'SAVED EDIT' in page_text(path)
    after = result['document']
    assert after['savedRevision'] == after['revision'] and after['dirty'] is False


def test_save_without_a_file_asks_where_instead_of_guessing(engine):
    ident = engine.blank('Untitled.pdf')['id']
    assert engine.meta(ident)['canSave'] is False
    with pytest.raises(PDFError) as caught:
        engine.save(ident)
    assert caught.value.status == 409 and caught.value.code == 'no_save_path'


def test_save_as_moves_the_document_and_leaves_the_original_alone(engine, tmp_path):
    original = source_pdf(tmp_path / 'Original.pdf')
    ident = engine.load(original.read_bytes(), original.name, path=original)['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'COPY ONLY', 'size': 18})
    copy = tmp_path / 'Copy.pdf'
    result = engine.save(ident, str(copy))

    assert result['name'] == 'Copy.pdf'
    assert 'COPY ONLY' in page_text(copy)
    assert 'COPY ONLY' not in page_text(original), 'Save as changed the file it was copied from'
    assert result['document']['path'] == str(copy)

    # The document follows the copy: a later Save goes there, not back to the
    # file it was opened from.
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 380, 400, 420],
                             'text': 'SECOND EDIT', 'size': 18})
    engine.save(ident)
    assert 'SECOND EDIT' in page_text(copy)
    assert 'SECOND EDIT' not in page_text(original)


def test_save_refuses_a_file_that_changed_on_disk_since_it_was_opened(engine, tmp_path):
    path = source_pdf(tmp_path / 'Shared.pdf')
    ident = engine.load(path.read_bytes(), path.name, path=path)['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'MY EDIT', 'size': 18})
    # Somebody else writes the file — a sync client, another editor, a script.
    source_pdf(path, 'SOMEBODY ELSE')
    with pytest.raises(PDFError) as caught:
        engine.save(ident)
    assert caught.value.status == 409 and caught.value.code == 'file_changed'
    assert 'SOMEBODY ELSE' in page_text(path), 'the other program\'s work was overwritten'

    # Save as is still offered, and writes somewhere else.
    elsewhere = tmp_path / 'Mine.pdf'
    engine.save(ident, str(elsewhere))
    assert 'MY EDIT' in page_text(elsewhere)


def test_saving_a_protected_file_keeps_its_encryption(engine, tmp_path):
    """Measured rather than assumed: writing the document back keeps the
    original encryption, both passwords and the permissions. An overwrite can
    therefore never quietly turn a protected file into an unprotected one.
    """
    with fitz.open() as doc:
        doc.new_page().insert_text((72, 120), 'PROTECTED', fontsize=20)
        locked = doc.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256,
                             owner_pw='owner-pass', user_pw='open-pass',
                             permissions=fitz.PDF_PERM_PRINT | fitz.PDF_PERM_MODIFY)
    path = tmp_path / 'Locked.pdf'
    path.write_bytes(locked)
    ident = engine.load(locked, path.name, 'open-pass', path=path)['id']
    assert engine.meta(ident)['canSave'] is True

    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'EDITED INSIDE', 'size': 16})
    engine.save(ident)

    with fitz.open(path) as saved:
        assert bool(saved.needs_pass), 'the saved file lost its password'
        assert saved.authenticate('open-pass')
        assert saved.permissions & fitz.PDF_PERM_PRINT
        assert not saved.permissions & fitz.PDF_PERM_COPY
        assert 'EDITED INSIDE' in saved[0].get_text()
    with fitz.open(path) as saved:
        assert saved.authenticate('owner-pass') == 4, 'the owner password changed'


def test_save_refuses_a_destination_it_cannot_use(engine, tmp_path):
    path = source_pdf(tmp_path / 'Doc.pdf')
    ident = engine.load(path.read_bytes(), path.name, path=path)['id']

    with pytest.raises(PDFError) as caught:
        engine.save(ident, str(tmp_path / 'notes.txt'))
    assert caught.value.status == 422 and caught.value.code == 'invalid_path'

    with pytest.raises(PDFError) as caught:
        engine.save(ident, 'relative/Report.pdf')
    assert caught.value.code == 'invalid_path'

    with pytest.raises(PDFError) as caught:
        engine.save(ident, str(tmp_path / 'missing folder' / 'Report.pdf'))
    assert caught.value.status == 404 and caught.value.code == 'folder_missing'


def test_save_adds_the_pdf_suffix_when_no_suffix_was_given(engine, tmp_path):
    path = source_pdf(tmp_path / 'Doc.pdf')
    ident = engine.load(path.read_bytes(), path.name, path=path)['id']
    result = engine.save(ident, str(tmp_path / 'Named later'))
    assert result['path'].endswith('Named later.pdf')
    assert (tmp_path / 'Named later.pdf').is_file()


def test_save_leaves_no_temporary_file_and_no_half_written_pdf(engine, tmp_path):
    path = source_pdf(tmp_path / 'Clean.pdf')
    ident = engine.load(path.read_bytes(), path.name, path=path)['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'TIDY', 'size': 18})
    engine.save(ident)
    left = sorted(item.name for item in tmp_path.iterdir())
    assert left == ['Clean.pdf'], f'unexpected files left behind: {left}'
    with fitz.open(path) as doc:
        assert len(doc) == 1, 'the saved file is not a readable single-page PDF'


@pytest.mark.skipif(sys.platform != 'win32', reason='the read-only attribute is a Windows behaviour')
def test_save_reports_a_read_only_file_instead_of_failing_silently(engine, tmp_path):
    path = source_pdf(tmp_path / 'Read only.pdf')
    ident = engine.load(path.read_bytes(), path.name, path=path)['id']
    engine.operation(ident, {'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                             'text': 'BLOCKED', 'size': 18})
    os.chmod(path, stat.S_IREAD)
    try:
        with pytest.raises(PDFError) as caught:
            engine.save(ident)
        assert caught.value.code == 'save_failed'
        assert 'BLOCKED' not in page_text(path)
    finally:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)


def test_a_converted_source_never_keeps_a_path_to_write_back_to(engine, tmp_path):
    """A .txt opened here becomes a PDF in memory; saving over the .txt would
    replace the person's text file with a PDF."""
    text = tmp_path / 'notes.txt'
    text.write_text('A line of text that becomes a page.\n', encoding='utf-8')
    info = engine.load(text.read_bytes(), text.name, path=text)
    assert info['path'] is None and info['canSave'] is False
    assert info['name'].endswith('.pdf')


def test_same_file_sees_through_case_and_relative_spelling(tmp_path):
    path = source_pdf(tmp_path / 'Case.pdf')
    assert same_file(path, tmp_path / 'Case.pdf')
    assert not same_file(path, tmp_path / 'other.pdf')


# ------------------------------------------------------------------------ the API

@pytest.fixture
def preview():
    shared_engine.documents.clear()
    app.state.token = None
    app.state.desktop = False
    with TestClient(app, raise_server_exceptions=True) as client:
        yield client
    app.state.desktop = False
    shared_engine.documents.clear()


@pytest.fixture
def desktop():
    """The desktop shell, which is the only place a save can write anything."""
    shared_engine.documents.clear()
    app.state.token = None
    app.state.desktop = True
    app.state.pending_open = []
    with TestClient(app, raise_server_exceptions=True, client=('127.0.0.1', 50000)) as client:
        yield client
    app.state.token = None
    app.state.desktop = False
    app.state.pending_open = []
    shared_engine.documents.clear()


def upload_demo(client):
    """Open the fixture report — the application ships no sample document."""
    response = client.post('/api/documents/upload',
                           files={'file': ('Quarterly performance.pdf', make_demo(), 'application/pdf')})
    assert response.status_code == 200, response.text
    return response.json()
def test_saving_is_refused_in_the_browser_preview(preview):
    document = upload_demo(preview)
    for path in (f"/api/documents/{document['id']}/save",
                 f"/api/documents/{document['id']}/save-as"):
        response = preview.post(path, json={'path': '/tmp/anything.pdf'})
        assert response.status_code == 403
        assert response.json()['code'] == 'desktop_only'


def test_open_by_path_remembers_the_file_so_save_can_write_to_it(desktop, tmp_path):
    path = source_pdf(tmp_path / 'Opened.pdf')
    document = desktop.post('/api/documents/open-path', json={'path': str(path)}).json()
    assert document['path'] == str(path) and document['canSave'] is True

    desktop.post(f"/api/documents/{document['id']}/operation",
                 json={'action': 'add_text', 'page': 0, 'rect': [60, 300, 400, 340],
                       'text': 'FROM THE API', 'size': 18})
    saved = desktop.post(f"/api/documents/{document['id']}/save")
    assert saved.status_code == 200
    body = saved.json()
    assert body['saved'] is True and body['document']['dirty'] is False
    assert 'FROM THE API' in page_text(path)


def test_save_as_needs_a_path_and_then_keeps_it(desktop, tmp_path):
    document = upload_demo(desktop)
    ident = document['id']
    assert desktop.post(f'/api/documents/{ident}/save-as', json={}).status_code == 422

    target = tmp_path / 'Chosen.pdf'
    result = desktop.post(f'/api/documents/{ident}/save-as', json={'path': str(target)})
    assert result.status_code == 200
    assert result.json()['document']['path'] == str(target)
    assert target.is_file() and page_text(target).strip()


# ------------------------------------------------------------- the desktop shell
# The native dialogs themselves need a human, but the contract between the shell
# and the interface does not: the bridge must answer with a path, a cancellation
# or a reason, and the filters it hands pywebview must be ones pywebview accepts.

class FakeWindow:
    def __init__(self, result):
        self.result, self.calls = result, []

    def create_file_dialog(self, *args, **kwargs):
        self.calls.append(kwargs)
        return self.result


def test_the_bridge_answers_with_a_path_a_cancellation_or_a_reason():
    from desktop import DesktopBridge
    from webview.util import parse_file_type

    bridge = DesktopBridge()
    bridge._window = FakeWindow((r'C:/Users/someone/Saved.pdf',))
    assert bridge.choose_save_path('Suggested.pdf') == {'path': r'C:/Users/someone/Saved.pdf'}
    for kind in bridge._window.calls[0]['file_types']:
        parse_file_type(kind)  # raises if the filter is malformed

    bridge._window = FakeWindow(None)
    assert bridge.choose_save_path('Suggested.pdf') == {'cancelled': True}

    bridge._window = FakeWindow((r'C:/Users/someone/Opened.pdf',))
    assert bridge.choose_open_path() == {'path': r'C:/Users/someone/Opened.pdf'}
    for kind in bridge._window.calls[0]['file_types']:
        parse_file_type(kind)

    bridge._window = FakeWindow(())
    assert bridge.choose_open_path() == {'cancelled': True}

    class Broken:
        def create_file_dialog(self, *args, **kwargs):
            raise RuntimeError('no dialog on this platform')

    bridge._window = Broken()
    # A platform that cannot show a dialog is reported as such, so the interface
    # can fall back to its own file picker instead of appearing dead.
    assert 'error' in bridge.choose_save_path('Suggested.pdf')
