"""Build the report the tests and the audit work on.

This used to live in the application as a sample document that opened on
start. It is a test fixture now: the application ships with no document, so
the same bytes are built here for the checks that need something to edit.
"""
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.utils import ImageReader
from PIL import Image, ImageDraw

NAVY = HexColor('#242538')
PURPLE = HexColor('#7162da')
GRAY = HexColor('#707180')
PALE = HexColor('#f2f0fc')
LINE = HexColor('#e4e4ec')


def sample_chart() -> bytes:
    im = Image.new('RGB', (1000, 390), '#f8f8fc')
    d = ImageDraw.Draw(im)
    for y in (65, 125, 185, 245, 305):
        d.line((50, y, 950, y), fill='#e7e7ee', width=2)
    for i, h in enumerate((150, 195, 225, 205, 260, 285)):
        x = 90 + i * 145
        d.rounded_rectangle((x, 335 - h, x + 82, 335), 10, fill='#a89ee9' if i < 5 else '#7162da')
    out = BytesIO()
    im.save(out, 'PNG')
    return out.getvalue()


def make_demo() -> bytes:
    out = BytesIO()
    c = canvas.Canvas(out, pagesize=(612, 792))
    c.setTitle('Quarterly performance report — Q3 2026')
    c.setAuthor('Northline / KADOMA sample')
    c.setSubject('A sample document for testing offline PDF tools')

    def header(page, category='FINANCIAL REPORT'):
        c.setFillColor(PURPLE)
        c.roundRect(48, 724, 23, 23, 5, fill=1, stroke=0)
        c.setFillColor(white)
        c.setFont('Helvetica-Bold', 13)
        c.drawString(54, 730, 'N')
        c.setFillColor(NAVY)
        c.setFont('Helvetica-Bold', 11)
        c.drawString(81, 732, 'NORTHLINE')
        c.setFillColor(GRAY)
        c.setFont('Helvetica', 8)
        c.drawRightString(564, 732, category)
        c.setStrokeColor(LINE)
        c.line(48, 708, 564, 708)
        c.line(48, 50, 564, 50)
        c.setFillColor(GRAY)
        c.setFont('Helvetica', 8)
        c.drawString(48, 33, 'NORTHLINE  /  INTERNAL WORKING DOCUMENT')
        c.drawRightString(564, 33, f'{page:02}')

    def lines(text_lines, x, y, size=10.5, leading=17, color=GRAY):
        c.setFillColor(color)
        c.setFont('Helvetica', size)
        for line in text_lines:
            c.drawString(x, y, line)
            y -= leading
        return y

    def table(x, y, widths, headers, rows, row_h=30):
        width = sum(widths)
        c.setFillColor(PALE)
        c.rect(x, y - row_h, width, row_h, fill=1, stroke=0)
        c.setStrokeColor(LINE)
        c.setLineWidth(.65)
        for i in range(len(rows) + 2):
            yy = y - i * row_h
            c.line(x, yy, x + width, yy)
        xx = x
        for w in [0] + widths:
            xx += w
            c.line(xx, y, xx, y - row_h * (len(rows) + 1))
        for r, values in enumerate([headers] + rows):
            c.setFillColor(NAVY)
            c.setFont('Helvetica-Bold' if r == 0 or r == len(rows) else 'Helvetica', 9)
            xx = x
            for i, value in enumerate(values):
                c.drawString(xx + 12, y - r * row_h - 19, str(value))
                xx += widths[i]

    header(1)
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(48, 676, 'Q3 2026  /  JULY - SEPTEMBER')
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 32)
    c.drawString(48, 633, 'Quarterly')
    c.drawString(48, 595, 'performance report')
    lines(['A clear view of revenue, expenses, and the quarter ahead.'], 49, 568, 10.5)
    cards = [('Total revenue', '$284,750', '+12.4% vs. Q2'),
             ('Operating expenses', '$176,320', '-3.2% vs. Q2'),
             ('Net profit', '$108,430', '+$24,600 this quarter')]
    for i, (label, value, delta) in enumerate(cards):
        x = 48 + i * 177
        c.setFillColor(PALE if i == 0 else HexColor('#f6f6f9'))
        c.roundRect(x, 455, 162, 83, 7, fill=1, stroke=0)
        c.setFillColor(GRAY)
        c.setFont('Helvetica', 8.5)
        c.drawString(x + 14, 519, label)
        c.setFillColor(NAVY)
        c.setFont('Helvetica-Bold', 21)
        c.drawString(x + 14, 488, value)
        c.setFillColor(PURPLE if i != 1 else HexColor('#348875'))
        c.setFont('Helvetica', 8)
        c.drawString(x + 14, 471, delta)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(48, 419, 'Quarter at a glance')
    lines(['A strong third quarter, led by growth in our product and services teams.',
           'Revenue increased while operating costs remained below plan. We enter',
           'the next quarter with a healthy margin and a focused investment strategy.'], 48, 396)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(48, 315, 'Revenue by department')
    table(48, 295, [220, 110, 95, 91], ['Department', 'Revenue', 'Change', 'Share'], [
        ['Products', '$142,375', '+18.2%', '50%'],
        ['Services', '$85,425', '+9.6%', '30%'],
        ['Consulting', '$42,712', '+5.1%', '15%'],
        ['Licensing', '$14,238', '+2.4%', '5%'],
        ['Total', '$284,750', '+12.4%', '100%'],
    ], row_h=29)
    lines(['Prepared by Finance Operations  |  Reviewed on 6 October 2026'], 48, 87, 8.5)
    c.showPage()

    header(2, 'FINANCIAL POSITION')
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(48, 676, '02  /  BALANCE SUMMARY')
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 29)
    c.drawString(48, 630, 'Built on solid ground.')
    lines(['A practical snapshot of cash, commitments, and outstanding balances.'], 48, 600)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(48, 542, 'Cash & receivables')
    table(48, 519, [296, 220], ['Account', 'Balance'], [
        ['Operating cash', '$186,400'],
        ['Accounts receivable', '$64,820'],
        ['Reserve fund', '$40,000'],
        ['Total liquid assets', '$291,220'],
    ], row_h=34)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(48, 308, 'Internal account details')
    lines(['Account reference: NL-2048-9931',
           'Finance contact: finance@example.invalid',
           'Review owner: Maya Thompson'], 48, 282, color=NAVY)
    c.setFillColor(PALE)
    c.roundRect(48, 123, 516, 78, 7, fill=1, stroke=0)
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(63, 180, 'TRY THE REDACTION TOOL')
    lines(['The account reference above is fictional. Select it with the Redact tool',
           'to permanently remove its content from your exported sample PDF.'], 63, 160, 9)
    c.showPage()

    header(3, 'OPERATIONS REVIEW')
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(48, 676, '03  /  MOMENTUM')
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 29)
    c.drawString(48, 630, 'Progress, month by month.')
    lines(['A steady performance trend with room to grow in the next quarter.'], 48, 600)
    c.drawImage(ImageReader(BytesIO(sample_chart())), 48, 332, width=516, height=201, mask='auto')
    c.setFillColor(GRAY)
    c.setFont('Helvetica', 9)
    for i, month in enumerate(['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']):
        c.drawString(92 + i * 75, 315, month)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 14)
    c.drawString(48, 270, 'Next-quarter priorities')
    lines(['01   Improve invoice turnaround and collections.',
           '02   Expand services capacity while protecting margin.',
           '03   Keep discretionary spending aligned with the plan.',
           '04   Complete the year-end reporting checklist.'], 48, 243, 10.5, 24, NAVY)
    lines(['The chart is a real embedded image. Use Select to replace it,',
           'or add your own image from the editing toolbar.'], 48, 108, 9)
    c.showPage()

    header(4, 'APPROVAL & SIGN-OFF')
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(48, 676, '04  /  READY FOR REVIEW')
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 29)
    c.drawString(48, 630, 'A clear path to approval.')
    lines(['Complete these real PDF form fields, then add a visual signature.'], 48, 599)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(48, 550, 'Reviewer name')
    c.acroForm.textfield(name='reviewer_name', tooltip='Reviewer name',
                        x=48, y=509, width=330, height=28, borderWidth=1,
                        borderColor=LINE, fillColor=white, textColor=NAVY,
                        fontSize=11, forceBorder=True)
    c.drawString(48, 479, 'Approval status')
    c.acroForm.choice(name='approval_status', tooltip='Approval status',
                      x=48, y=438, width=250, height=28,
                      options=['Pending review', 'Approved', 'Needs changes'], value='Pending review',
                      borderColor=LINE, fillColor=white, textColor=NAVY,
                      borderWidth=1, fontSize=11, forceBorder=True)
    c.acroForm.checkbox(name='review_confirmed', tooltip='I have reviewed this report',
                        x=48, y=386, size=16, borderWidth=1, borderColor=LINE,
                        fillColor=white, textColor=PURPLE, buttonStyle='check', forceBorder=True)
    lines(['I have reviewed the figures and supporting information.'], 75, 391, 10, color=NAVY)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(48, 337, 'Signature')
    c.setStrokeColor(LINE)
    c.roundRect(48, 224, 330, 94, 5, fill=0, stroke=1)
    lines(['Add a typed or drawn visual signature here.'], 61, 239, 9)
    c.setFillColor(PALE)
    c.roundRect(48, 108, 516, 76, 7, fill=1, stroke=0)
    c.setFillColor(PURPLE)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(63, 161, 'LOCAL BY DESIGN')
    lines(['This sample uses visual signatures, not certificate-based digital signing.',
           'Signature requests and online tracking are not part of the offline build.'], 63, 141, 9)
    c.showPage()
    c.save()
    return out.getvalue()
