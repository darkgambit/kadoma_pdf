"""Build native artifacts on Windows or macOS. Never pretends to cross-compile."""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import __version__

EXCLUDED = {'.git', '.venv', 'venv', 'node_modules', 'build', 'dist', 'release',
            '__pycache__', '.pytest_cache', '.cache', 'qa', '.arena'}


def source_archive(destination: Path):
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob('*')):
            relative = path.relative_to(ROOT)
            if path.is_file() and not any(part in EXCLUDED for part in relative.parts) and path.suffix not in ('.pyc', '.log'):
                archive.write(path, 'kadoma-pdf/' + str(relative).replace(os.sep, '/'))


def metadata_text(distribution) -> str:
    """Serialise distribution metadata without the email generator.

    Some packages ship a long description containing a '-----' underline, which
    the email folder rejects as an embedded header — `str(metadata)` then raises
    HeaderParseError and the whole build dies. altgraph (a PyInstaller
    dependency) is one of them. Reading the installed METADATA file is simpler
    and lossless, so use that first.
    """
    for file in distribution.files or []:
        path = Path(file)
        if path.name == 'METADATA' and path.parent.name.endswith('.dist-info'):
            source = Path(distribution.locate_file(file))
            if source.is_file():
                return source.read_text(encoding='utf-8', errors='replace')
    return '\n'.join(f'{key}: {value}' for key, value in (distribution.metadata.items() or []))


def collect_licenses():
    """Include installed distribution metadata and any bundled license texts."""
    output = ROOT / 'assets' / 'third_party_licenses'
    output.mkdir(exist_ok=True)
    manifest = []
    # The build virtualenv contains only required packages; enumerate them all
    # so platform-specific Python/.NET/WebKit dependencies are not missed.
    # Anything the spec excludes is skipped here too: shipping the licence of a
    # package that is not in the build makes the notices describe something that
    # is not there. This list must stay in step with UNUSED_PACKAGES in
    # kadoma.spec.
    skipped = {'pip', 'setuptools', 'wheel', 'pytest', 'pluggy', 'iniconfig', 'httpx',
               'playwright', 'pyee', 'greenlet',
               'numpy', 'scipy', 'pandas', 'matplotlib', 'schedula', 'tqdm', 'regex'}
    for distribution in importlib.metadata.distributions():
        name = distribution.metadata.get('Name', 'unknown')
        if name.lower() in skipped:
            continue
        try:
            directory = output / name
            directory.mkdir(exist_ok=True)
            copied = []
            for file in distribution.files or []:
                if any(keyword in Path(file).name.lower() for keyword in ('license', 'copying', 'notice')):
                    source = Path(distribution.locate_file(file))
                    if source.is_file() and source.stat().st_size < 2 * 1024 * 1024:
                        filename = str(file).replace('/', '__').replace('\\', '__')
                        shutil.copyfile(source, directory / filename)
                        copied.append(filename)
            (directory / 'METADATA.txt').write_text(metadata_text(distribution), encoding='utf-8')
            manifest.append({'name': name, 'version': distribution.version, 'licenseFiles': copied})
        except Exception as exc:
            # One unusual package must never stop a native build.
            print(f'  licence collection skipped {name}: {type(exc).__name__}', flush=True)
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')


def run(*command, **kwargs):
    print('+', ' '.join(str(x) for x in command), flush=True)
    subprocess.run([str(x) for x in command], cwd=ROOT, check=True, **kwargs)


def find_iscc():
    candidates = [shutil.which('ISCC'),
                  r'C:\Program Files (x86)\Inno Setup 6\ISCC.exe',
                  r'C:\Program Files\Inno Setup 6\ISCC.exe']
    return next((x for x in candidates if x and Path(x).is_file()), None)


def smoke_test(executable: Path, label: str) -> dict:
    """Run the packaged engine self-test inside the built artifact.

    The build is windowed (console=False), so it has no usable stdout. The result
    is read back from the JSON report the executable writes instead of trusting an
    exit code alone.
    """
    report = ROOT / 'build' / f'self-test-{label}.json'
    report.parent.mkdir(parents=True, exist_ok=True)
    if report.exists():
        report.unlink()
    try:
        run(executable, '--self-test', '--self-test-output', report, timeout=150)
    except subprocess.TimeoutExpired as exc:
        raise SystemExit(f'The {label} build hung in its packaged self-test and was stopped.') from exc
    except subprocess.CalledProcessError as exc:
        detail = ''
        if report.is_file():
            try:
                detail = (json.loads(report.read_text(encoding='utf-8')).get('error') or '')
            except ValueError:
                detail = ''
        raise SystemExit(f'The {label} build failed its packaged self-test '
                         f'(exit code {exc.returncode}){": " + detail if detail else "."}') from exc
    if not report.is_file():
        raise SystemExit(f'The {label} build wrote no self-test report: the packaged engine did not start.')
    data = json.loads(report.read_text(encoding='utf-8'))
    checks = data.get('checks') or []
    if len(checks) < 10 or not data.get('frozen'):
        raise SystemExit(f'The {label} build reported {len(checks)} checks and frozen={data.get("frozen")}.')
    print(f'  {label}: {len(checks)} packaged-engine checks passed in the frozen executable', flush=True)
    return data


def build_macos_artifact(mode: str, release: Path, arch: str) -> list[Path]:
    bundle = ROOT / 'dist' / 'KADOMA.app'
    # PyInstaller uses ad-hoc code signing. This is NOT Apple Developer ID
    # signing or notarization and is deliberately not advertised as such.
    stage = ROOT / 'build' / 'dmg-stage'
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    shutil.copytree(bundle, stage / bundle.name, symlinks=True)
    (stage / 'Applications').symlink_to('/Applications', target_is_directory=True)
    shutil.copyfile(ROOT / 'assets' / 'INSTALL_NOTES.txt', stage / 'Read before installing.txt')
    suffix = '-standalone' if mode == 'onefile' else ''
    dmg = release / f'KADOMA-PDF-{__version__}-macOS-{arch}{suffix}.dmg'
    run('hdiutil', 'create', '-volname', 'KADOMA PDF', '-srcfolder', stage,
        '-ov', '-format', 'UDZO', dmg)
    return [dmg]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--installer', action='store_true', help='Require a Windows Inno Setup installer in addition to the portable ZIP.')
    parser.add_argument('--mode', choices=('folder', 'onefile', 'both', 'source'), default='folder',
                        help='folder = portable folder plus ZIP (default); onefile = one stand-alone executable; '
                             'both = build each; source = refresh only the source ZIP and checksums.')
    args = parser.parse_args()
    if sys.platform not in ('win32', 'darwin'):
        raise SystemExit('Native builds require Windows or macOS. This script will not label Linux binaries as .exe or .app files.')
    arch = platform.machine().lower()
    if sys.platform == 'win32' and arch not in ('amd64', 'x86_64'):
        raise SystemExit('The Windows build currently targets x64 Python. Install 64-bit Python first.')
    if sys.platform == 'darwin' and arch not in ('arm64', 'x86_64'):
        raise SystemExit('Use native arm64 or x86_64 Python on macOS.')
    release = ROOT / 'release'
    release.mkdir(exist_ok=True)
    collect_licenses()
    # 'source' skips PyInstaller entirely: documentation-only changes should not
    # cost a full binary rebuild (and would change the EXE hash for no reason).
    modes = () if args.mode == 'source' else (('folder', 'onefile') if args.mode == 'both' else (args.mode,))
    artifacts: list[Path] = []
    smoke: dict[str, dict] = {}
    for mode in modes:
        os.environ['KADOMA_BUILD_MODE'] = mode
        print(f'\n=== Building the {mode} target ===', flush=True)
        run(sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean', 'kadoma.spec')
        if sys.platform == 'win32':
            if mode == 'folder':
                smoke[mode] = smoke_test(ROOT / 'dist' / 'KADOMA' / 'KADOMA.exe', mode)
                zip_name = release / f'KADOMA-PDF-{__version__}-Windows-x64-portable'
                shutil.make_archive(str(zip_name), 'zip', root_dir=ROOT / 'dist', base_dir='KADOMA')
                # Not with_suffix(): the version contains dots, so that would
                # replace '.0-Windows-x64-portable' and produce KADOMA-PDF-0.2.zip.
                artifacts.append(zip_name.parent / (zip_name.name + '.zip'))
            else:
                standalone = ROOT / 'dist' / 'KADOMA.exe'
                smoke[mode] = smoke_test(standalone, mode)
                target = release / f'KADOMA-PDF-{__version__}-Windows-x64-standalone.exe'
                shutil.copyfile(standalone, target)
                artifacts.append(target)
        else:
            smoke[mode] = smoke_test(ROOT / 'dist' / 'KADOMA.app' / 'Contents' / 'MacOS' / 'KADOMA', mode)
            artifacts.extend(build_macos_artifact(mode, release, arch))
    if sys.platform == 'win32' and 'folder' in modes:
        compiler = find_iscc()
        if compiler:
            run(compiler, f'/DAppVersion={__version__}', f'/O{release}', ROOT / 'scripts' / 'windows.iss')
            artifacts.extend(release.glob('*Setup.exe'))
        elif args.installer:
            raise SystemExit('Portable build succeeded, but Setup.exe needs Inno Setup 6. Install it and rerun scripts/build.py --installer.')
        else:
            print('Inno Setup not found: the portable ZIP and stand-alone EXE are ready; no installer was generated.')
    source = release / f'KADOMA-PDF-{__version__}-source.zip'
    source_archive(source)
    artifacts.append(source)
    # Merge into any existing manifest instead of replacing it. Rebuilding only
    # one target must not erase the recorded hashes of the artifacts it did not
    # touch, or the manifest silently stops describing the release folder.
    sums_path = release / 'SHA256SUMS.txt'
    recorded: dict[str, str] = {}
    if sums_path.exists():
        for line in sums_path.read_text(encoding='utf-8').splitlines():
            digest, _, name = line.partition('  ')
            if digest and name:
                recorded[name] = digest
    for file in artifacts:
        recorded[file.name] = hashlib.sha256(file.read_bytes()).hexdigest()
    # Written with an explicit LF rather than the platform default: `write_text`
    # would otherwise emit CRLF on Windows, and `sha256sum -c` on Linux or macOS
    # then fails on every line with a name ending in a carriage return. The
    # project's own verify_sums.py strips the line so it never noticed.
    sums_path.write_text(''.join(f'{recorded[name]}  {name}\n'
                                 for name in sorted(recorded, key=str.lower)),
                         encoding='utf-8', newline='\n')
    info_path = release / 'BUILD_INFO.json'
    previous: dict = {}
    if info_path.exists():
        try:
            previous = json.loads(info_path.read_text(encoding='utf-8'))
        except (ValueError, OSError):
            previous = {}
    # A 'source'-only run must not rewrite the record of how the binaries were
    # produced, nor drop them from the artifact list, so carry those forward.
    build_modes = list(modes) if modes else (previous.get('buildModes') or ['source'])
    self_tests = dict(previous.get('packagedEngineSelfTest') or {})
    self_tests.update({mode: len(data.get('checks') or []) for mode, data in smoke.items()})
    present = sorted((p.name for p in release.iterdir()
                      if p.is_file() and p.name not in ('BUILD_INFO.json', 'SHA256SUMS.txt')),
                     key=str.lower)
    info_path.write_text(json.dumps({
        'appVersion': __version__, 'operatingSystem': platform.platform(),
        'architecture': arch, 'python': sys.version,
        'buildModes': build_modes,
        'artifacts': present,
        'packagedEngineSelfTest': self_tests,
        'distributionSigning': 'Not configured. macOS uses ad-hoc signing only.',
        'tests': 'Packaged engine smoke test passed inside each built artifact; interactive OS QA is still required.'
    }, indent=2), encoding='utf-8')
    print('\nNative build complete:', release, flush=True)
    for file in sorted(artifacts):
        print(f'  {file.stat().st_size:>12,} bytes  {file.name}', flush=True)


if __name__ == '__main__':
    main()
