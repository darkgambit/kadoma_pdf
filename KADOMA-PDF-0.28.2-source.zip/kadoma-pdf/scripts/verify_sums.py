"""Re-compute SHA-256 for every file listed in a SHA256SUMS.txt and compare.

    python scripts/verify_sums.py release/SHA256SUMS.txt
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path


def main() -> int:
    manifest = Path(sys.argv[1] if len(sys.argv) > 1 else 'release/SHA256SUMS.txt')
    if not manifest.is_file():
        print(f'Not found: {manifest}')
        return 1
    bad = 0
    for line in manifest.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line:
            continue
        expected, name = line.split('  ', 1)
        target = manifest.parent / name
        if not target.is_file():
            print(f'MISSING   {name}')
            bad += 1
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        ok = actual == expected
        print(f'{"MATCH   " if ok else "MISMATCH"}  {name}  ({target.stat().st_size:,} bytes)')
        bad += 0 if ok else 1
    print(f'\n{bad} problem(s).')
    return 1 if bad else 0


if __name__ == '__main__':
    raise SystemExit(main())
