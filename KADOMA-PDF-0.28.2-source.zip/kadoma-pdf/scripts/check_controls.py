"""Prove every control in the interface does something.

A button can fail in two different ways, so this checks both.

  Static  Every control declared in `index.html`, and every control the interface
          renders into the page at runtime, must be referenced by a handler in
          `app.js`. This catches the worst kind of control: one that was added to
          the markup, looks completely normal, and was never wired up.

  Live    A real browser drives the running application, presses each control in
          the context where it is meant to be used, and requires an observable
          result — a dialog, a toast, a view change, a page change, an active
          state, or a changed document. A control that produces no observable
          result at all is reported as dead.

The live pass runs with the desktop shell's capabilities, because that is the
build that ships. Two things are deliberately never done for real:

  * Share and mail actions, which would open a real mail client. Their
    interfaces are opened and inspected here; the actions themselves are covered
    by `check_share.py`.
  * A print job going to a physical printer. Instead the print driver is
    redirected to a file (test-side only, see `LAUNCHER`) so the job still goes
    through the real engine, the real GDI print API and the real spooler — and
    the resulting document is opened and checked afterwards. Nothing in the
    shipped application knows about this.

    python scripts/check_controls.py
    python scripts/check_controls.py --base-url http://127.0.0.1:8000
"""
from __future__ import annotations

import argparse
import json
import re
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
QA = ROOT / 'qa'


def app_version() -> str:
    """The version the guide should name, read from the package itself."""
    found = re.search(r'__version__\s*=\s*"([^"]+)"', (ROOT / 'app/__init__.py').read_text(encoding='utf-8'))
    return '.'.join(found.group(1).split('.')[:2]) if found else '0.0'

# Started in-process by the audit so the print driver can be redirected. This is
# the only place the application is wrapped, and only from the test side.
LAUNCHER = r'''
import os, sys
sys.path.insert(0, os.getcwd())
from app import printing, server
import uvicorn

capture = os.environ.get('PAPERDESK_AUDIT_CAPTURE')
if capture:
    real_print, real_methods = printing.print_pdf, printing.methods

    # *args/**kwargs rather than a copied signature: this wrapper had to be
    # updated twice when the real function grew arguments, and each time the
    # symptom was a print job that silently never happened.
    def print_pdf(data, name='KADOMA PDF document', printer=None, output=None,
                  *args, **kwargs):
        return real_print(data, name, printer, capture, *args, **kwargs)

    printing.print_pdf = print_pdf
    # Report the default printer as printable so the interface takes its direct
    # path. The job is still built and spooled normally; it just lands in a file.
    printing.saves_to_a_file = lambda printer: False
    printing.methods = lambda: {**real_methods(), 'print': True, 'savesToFile': False}

server.app.state.desktop = True
uvicorn.run(server.app, host='127.0.0.1', port=int(os.environ['PAPERDESK_AUDIT_PORT']),
            access_log=False, loop='asyncio', http='h11', ws='none')
'''

# Attributes that are handled by one delegated listener rather than per element.
DELEGATED = ('data-close', 'data-tool', 'data-action', 'data-view', 'data-format',
             'data-quick', 'data-match', 'data-delete-annotation', 'data-sign-mode',
             'data-calendar', 'data-calendar-step', 'data-calendar-today',
             'data-calendar-clear', 'data-day', 'data-image', 'data-span', 'data-widget',
             'data-split-mode')
# Rendered but read when a panel is submitted or by a sibling attribute's
# listener, never a click hook of its own.
READ_ONLY_ATTRS = ('data-field-xref',   # read by the fill panel when it submits
                   'data-merge-step',   # read by the [data-merge-move] handler on the same button
                   'data-run')          # read by the [data-span] handler on the same element


# --------------------------------------------------------------------- static

def static_pass() -> tuple[list[str], list[str], int]:
    html = (ROOT / 'app/static/index.html').read_text(encoding='utf-8')
    js = (ROOT / 'app/static/app.js').read_text(encoding='utf-8')
    problems, steps, checked = [], [], 0

    def referenced(ident: str) -> bool:
        """A control is wired if its id is used as a string or in a selector."""
        return f"'{ident}'" in js or f'#{ident}' in js

    for tag, ident in re.findall(r'<(button|select|input|textarea|a)\b[^>]*?id="([^"]+)"', html):
        checked += 1
        if referenced(ident):
            steps.append(f'index.html: <{tag} id="{ident}"> is wired')
        else:
            problems.append(f'index.html <{tag} id="{ident}"> has no handler in app.js')

    for match in re.finditer(r'<(button|input|select|textarea)\b[^>]*>', js):
        tag, text = match.group(1), match.group(0)
        found = re.search(r'\bid="([a-zA-Z0-9-]+)"', text)
        if not found:
            continue
        ident = found.group(1)
        checked += 1
        if referenced(ident):
            steps.append(f'app.js: <{tag} id="{ident}"> is wired')
            continue
        if tag == 'button' and any(attr in text for attr in DELEGATED):
            steps.append(f'app.js: <{tag} id="{ident}"> uses a delegated action')
            continue
        problems.append(f'app.js renders <{tag} id="{ident}"> with no handler')

    # Every data-* attribute put on a rendered button needs a delegated listener.
    rendered = set()
    for match in re.finditer(r'<button[^>]*>', js):
        rendered.update(re.findall(r'(data-[a-zA-Z-]+)', match.group(0)))
    for attr in sorted(rendered - set(READ_ONLY_ATTRS)):
        if attr in DELEGATED or f'[{attr}]' in js or f"'{attr}'" in js:
            steps.append(f'delegated attribute {attr} is handled')
        else:
            problems.append(f'rendered control attribute {attr} has no delegated listener')

    return steps, problems, checked


# ----------------------------------------------------------------------- live

class Audit:
    def __init__(self, page, capture: Path | None):
        self.page = page
        self.capture = capture
        self.steps: list[str] = []
        self.failures: list[str] = []

    # -- small helpers -----------------------------------------------------
    def run(self, name: str, fn, *args) -> bool:
        try:
            fn(*args)
        except Exception as exc:                                   # noqa: BLE001
            self.failures.append(f'{name} — {type(exc).__name__}: {exc}')
            print(f'FAIL: {name} — {exc}', flush=True)
            self.cleanup()
            return False
        self.steps.append(name)
        print(f'PASS: {name}', flush=True)
        self.cleanup()
        return True

    def cleanup(self) -> None:
        self.close_modal()
        self.page.evaluate("document.querySelector('#toast-stack').innerHTML = ''")

    def inspector(self, limit: int = 260) -> str:
        """The panel text, for a useful failure message."""
        try:
            return ' '.join(self.page.inner_text('#inspector').split())[:limit]
        except Exception:                                          # noqa: BLE001
            return '(inspector unreadable)'

    def modal_body(self, limit: int = 300) -> str:
        try:
            return ' '.join(self.page.inner_text('#modal').split())[:limit]
        except Exception:                                          # noqa: BLE001
            return '(no dialog)'

    def require(self, condition, message: str) -> None:
        if not condition:
            raise AssertionError(message)

    def modal_title(self) -> str | None:
        if not self.page.is_visible('#modal'):
            return None
        return self.page.inner_text('#modal h2').strip()

    def close_modal(self) -> None:
        if self.page.is_visible('#modal'):
            self.page.evaluate("document.querySelector('#modal').close()")
            self.page.wait_for_timeout(50)

    def toasts(self) -> str:
        return ' | '.join(self.page.locator('#toast-stack .toast').all_inner_texts())

    def view(self) -> str | None:
        return self.page.get_attribute('#navigation .nav-item.active', 'data-view')

    def tool(self) -> str | None:
        return self.page.get_attribute('.tool-button.active', 'data-tool')

    def page_number(self) -> int:
        return int(self.page.input_value('#current-page'))

    def pages(self) -> int:
        return int(self.page.inner_text('#page-count'))

    def open_view(self, view: str) -> None:
        self.page.click(f'#navigation [data-view="{view}"]')
        self.page.wait_for_timeout(120)

    def type_into(self, locator, text: str) -> None:
        """Click, then type, the way a person does.

        `Locator.fill` proved unreliable on these inputs: it can leave focus
        behind and store nothing at all while still reporting success, which
        would have made this audit lie. Typing also exercises the real
        keystroke path, including the global shortcut handler that has to stay
        out of the way while somebody is entering text.
        """
        locator.click()
        locator.press('Control+a')
        locator.press('Delete')
        locator.press_sequentially(text, delay=6)
        stored = locator.input_value()
        self.require(stored == text, f'typing {text!r} stored {stored!r} instead')

    def goto_page(self, number: int) -> None:
        self.type_into(self.page.locator('#current-page'), str(number))
        self.page.dispatch_event('#current-page', 'change')
        self.page.wait_for_timeout(700)

    def engine_fields(self) -> list[list]:
        """What the engine itself holds for this page, not what the panel shows.

        Reading the panel cannot tell a saved value apart from one the panel is
        still holding on to, so anything that has to prove the document really
        changed asks the engine directly.
        """
        return self.page.evaluate(
            """async () => {
                 const response = await fetch(`/api/documents/${state.doc.id}/pages/${state.page}/content`);
                 const body = await response.json();
                 return (body.widgets || []).map(w => [String(w.xref), w.label, w.value || '']);
               }""")

    def engine_value(self, xref: str) -> str | None:
        for entry in self.engine_fields():
            if entry[0] == xref:
                return entry[2]
        return None

    def find_text_field(self) -> tuple[int, int]:
        """The first ordinary text field in the document, as (page, index).

        Date fields are skipped on purpose. They are plain text fields
        underneath, so a naive "first input that is not a checkbox" search
        picks one up — and a date field refuses anything that is not a date,
        which is correct behaviour but the wrong thing to exercise here. The
        fill panel marks them with `data-date-format`.

        The fill panel has to be open before this is called.
        """
        for number in range(1, self.pages() + 1):
            self.goto_page(number)
            fields = self.page.locator('#inspector [data-field-xref]')
            for candidate in range(fields.count()):
                node = fields.nth(candidate)
                if node.evaluate('el => el.tagName') != 'INPUT':
                    continue
                if node.get_attribute('type') == 'checkbox':
                    continue
                if node.get_attribute('data-date-format'):
                    continue
                return number, candidate
        return 0, -1

    def drag_on_page(self, width=220, height=50) -> None:
        """Draw a rectangle on the page, starting somewhere nothing covers.

        Only the press point matters: the overlay ignores a press that lands on
        one of its own hit-targets, so the drag has to begin on bare page.
        """
        box = self.page.locator('#page-overlay').bounding_box()
        self.require(box and box['width'] > 120, 'the page is not large enough to draw on')

        def free_point():
            for row in range(16):
                y = box['y'] + 40 + row * 16
                if y > box['y'] + box['height'] - 40:
                    break
                for column in range(30):
                    x = box['x'] + 30 + column * 8
                    if x > box['x'] + box['width'] - 80:
                        break
                    tag = self.page.evaluate(
                        "([x, y]) => { const el = document.elementFromPoint(x, y);"
                        " return el ? (el.id || el.getAttribute('class') || '') : ''; }", [x, y])
                    if tag == 'page-overlay':
                        return x, y
            return None

        point = free_point()
        self.require(point is not None, 'no clear area on the page to draw a rectangle in')
        x1, y1 = point
        x2 = min(x1 + width, box['x'] + box['width'] - 6)
        y2 = min(y1 + height, box['y'] + box['height'] - 6)
        self.page.mouse.move(x1, y1)
        self.page.mouse.down()
        self.page.mouse.move(x2, y2, steps=6)
        self.page.mouse.up()
        self.page.wait_for_timeout(250)

    def show_thumbnails(self) -> None:
        """Bring the page thumbnails out; they start away to give the page width."""
        if self.page.locator('#pages-panel').is_hidden():
            self.page.click('#toggle-thumbnails')
            self.page.wait_for_timeout(300)
        self.require(self.page.locator('#pages-panel').is_visible(),
                     'the page thumbnails did not appear')

    def page_number_is_last(self) -> bool:
        return self.page_number() == self.pages()

    def select_all_pages(self) -> None:
        """Select every page without toggling an existing selection off."""
        if self.page.is_disabled('[data-action="rotate-pages"]'):
            self.page.click('#organizer-select-all')
            self.page.wait_for_timeout(300)
        self.require(not self.page.is_disabled('[data-action="rotate-pages"]'),
                     'no pages could be selected in the organizer')


def live_pass(audit: Audit, base_url: str, errors: list, external: list,
              server_failures: list) -> None:
    page = audit.page

    def reopen_report(land: bool = True):
        """Reload, then put the report back on screen.

        The application ships no sample document, so a reload lands on Home with
        nothing open. The report is usually still open in the workspace — Home
        lists it — and that is reused rather than uploaded a second time, which
        would eat one of the six document slots for every reload.
        """
        page.reload(wait_until='load')
        page.wait_for_function('() => typeof state !== "undefined" && state.capabilities && !state.busy',
                               timeout=60000)
        reopened = page.evaluate("""async () => {
            const list = await (await fetch('/api/documents')).json();
            const found = (list.documents || []).find(d => d.name === 'Quarterly performance.pdf');
            if (!found) return false;
            await adoptDocument(found, {page: 0});
            return true;
        }""")
        if not reopened:
            page.locator('#file-input').set_input_files(str(QA / 'session-document.pdf'))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        if land:
            audit.open_view('edit')
            page.wait_for_timeout(600)

    # ---------------------------------------------------------- shell
    def home_screen():
        # A fresh load: this is what the application shows before anything else.
        # No document ships with it any more, so every load has to start empty —
        # and this step is what proves that, rather than assuming it.
        page.evaluate("""async () => {
            const list = await (await fetch('/api/documents')).json();
            for (const doc of list.documents || []) {
                await fetch('/api/documents/' + doc.id, {method: 'DELETE'});
            }
        }""")
        page.reload(wait_until='networkidle')
        page.wait_for_function('() => state.capabilities && !state.busy', timeout=60000)
        # The home screen is drawn twice while the document list arrives; wait
        # for a card to be on screen before clicking one, or the click lands on
        # an element that is about to be replaced.
        page.wait_for_selector('#home-sections .home-card', state='visible', timeout=30000)
        page.wait_for_timeout(400)
        audit.require(page.evaluate('() => state.view') == 'home',
                      f"the application did not open on Home (view={page.evaluate('() => state.view')})")
        audit.require(page.evaluate('() => state.doc') is None,
                      'a document was opened on start: the application should ship none')
        # A fresh profile has nothing stored, and the default is dark. This is
        # the first step of the run, so nothing has written the theme key yet.
        audit.require(page.evaluate("() => document.documentElement.dataset.theme") == 'dark',
                      f"a fresh launch is not dark "
                      f"({page.evaluate(chr(34) + 'document.documentElement.dataset.theme' + chr(34))!r})")
        audit.require(page.evaluate("() => localStorage.getItem('kadoma.theme')") in (None, 'dark'),
                      'a fresh launch stored a light theme by itself')
        audit.require(page.locator('#home-view').is_visible(), 'the home screen is not on screen')
        cards = page.locator('#home-sections .home-card').count()
        tools = page.locator('#home-rail .home-tool').count()
        audit.require(cards >= 8, f'the home screen offers only {cards} tools')
        audit.require(tools >= 8, f'the tool list has only {tools} entries')
        audit.require('Nothing open yet' in page.inner_text('#home-sections'),
                      'the empty workspace does not say that nothing is open')
        # The document chrome belongs to a document, not to the home screen.
        audit.require(not page.locator('#document-bar').is_visible(),
                      'the document bar is showing on the home screen')
        audit.require(not page.locator('#toolbar').is_visible(),
                      'the editing toolbar is showing on the home screen')
        # Searching narrows the grid and leaves the tool list complete, so a
        # search cannot make a tool look missing from the application.
        page.fill('#home-search', 'comb')
        page.wait_for_timeout(250)
        audit.require(page.locator('#home-sections .home-card').count() == 1,
                      'the tool search did not narrow the grid')
        audit.require(page.locator('#home-rail .home-tool').count() == tools,
                      'the tool search emptied the tool list as well')
        page.fill('#home-search', '')
        page.wait_for_timeout(250)
        # With nothing open, a tool says so instead of failing quietly.
        page.click('#home-sections [data-home="organize"]')
        page.wait_for_timeout(500)
        audit.require('Open a document first' in audit.toasts(),
                      f'a tool with nothing open said {audit.toasts()!r}')
        # A card is a real action, not a picture of one — once there is a
        # document. Opening one through the file picker is the way in.
        page.locator('#file-input').set_input_files(str(QA / 'session-document.pdf'))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        # Opening a file sets the view to the editor twice — once before the
        # upload is adopted and once after it is rendered. The second one lands
        # after a Home click and puts the editor back, so wait for the toast that
        # is only raised when the whole sequence has finished.
        deadline = time.time() + 30
        while time.time() < deadline and 'Opened' not in audit.toasts():
            page.wait_for_timeout(200)
        audit.require(page.evaluate('() => state.doc.pageCount') >= 2,
                      'the opened report does not have the pages the audit needs')
        audit.open_view('home')
        page.wait_for_selector('#home-sections .home-card', state='visible', timeout=30000)
        page.wait_for_timeout(400)
        page.click('#home-sections [data-home="organize"]')
        page.wait_for_timeout(700)
        audit.require(audit.view() == 'pages', 'the Organize Pages card did not open the organizer')
        audit.open_view('edit')
    audit.run('The application opens on Home with nothing open, and a card opens the document',
              home_screen)

    def document_tabs():
        # A second document, so the strip has something to switch between. The
        # tabs are found by name, not by position: the list is most-recent
        # first, so "the last tab" is not the one that was just created.
        original = page.evaluate('() => state.doc.name')
        page.evaluate("""async () => {
            const info = await api('/documents/create', {method: 'POST', json: {name: 'Tab check.pdf'}});
            await adoptDocument(info, {page: 0, sample: false});
        }""")
        page.wait_for_timeout(1600)
        audit.require(not page.locator('#document-tabs').is_hidden(),
                      'the tab strip did not appear with two documents open')
        tabs = page.locator('.document-tab').count()
        audit.require(tabs >= 2, f'only {tabs} tabs for the open documents')
        audit.require(page.locator('.document-tab').filter(has_text='Tab check.pdf').count() == 1,
                      'the new document has no tab')
        page.locator('.document-tab').filter(has_text=original).first.locator('.tab-name').click()
        page.wait_for_timeout(1400)
        audit.require(page.evaluate('() => state.doc.name') == original,
                      f'the tab did not switch back (now {page.evaluate("() => state.doc.name")!r})')
        page.locator('.document-tab').filter(has_text='Tab check.pdf').first.locator('.tab-close').click()
        page.wait_for_timeout(1600)
        audit.require(page.evaluate('() => state.doc.name') == original,
                      'closing the other tab switched away from the document that stayed open')
        audit.require(page.locator('.document-tab').filter(has_text='Tab check.pdf').count() == 0,
                      'closing a tab did not close the document')
    audit.run('Open documents have tabs that switch and close', document_tabs)

    def page_menu():
        audit.open_view('pages')
        page.wait_for_timeout(800)
        page.locator('.organize-card').first.click(button='right')
        page.wait_for_timeout(400)
        audit.require(page.locator('.context-menu').count() == 1,
                      'right-clicking a page opened no menu')
        labels = ' | '.join(page.locator('.context-item').all_inner_texts())
        for wanted in ('Rotate right', 'Rotate left', 'Copy page to a file', 'Extract page',
                       'Duplicate page', 'Delete page'):
            audit.require(wanted in labels, f'the page menu has no {wanted} ({labels!r})')
        page.keyboard.press('Escape')
        page.wait_for_timeout(300)
        audit.require(page.locator('.context-menu').count() == 0,
                      'Escape did not close the page menu')
        audit.open_view('edit')
    audit.run('Right-clicking a page offers rotate, extract, duplicate and delete', page_menu)

    def copy_a_page_to_a_named_file():
        # Right-clicking the page while scrolling offers to lift that one page
        # out as a file of its own, under a name typed in the dialog. The file
        # that arrives is opened and counted, so "it downloaded" is not the test.
        import pymupdf
        audit.open_view('edit')
        page.wait_for_timeout(900)
        pages_before = page.evaluate('() => state.doc.pageCount')
        revision_before = page.evaluate('() => state.doc.revision')
        page.locator('#canvas-scroll').click(button='right', position={'x': 220, 'y': 320})
        page.wait_for_timeout(500)
        audit.require(page.locator('.context-menu').count() == 1,
                      'right-clicking the page while scrolling opened no menu')
        page.locator('.context-item').filter(has_text='Copy page to a file').click()
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Copy this page out.',
                      f'the copy dialog opened {audit.modal_title()!r}')
        suggested = page.input_value('#copy-name')
        audit.require(suggested.lower().endswith('.pdf') and 'page' in suggested.lower(),
                      f'the suggested name says nothing about the page ({suggested!r})')
        # A name with characters a file cannot hold is cleaned, not refused.
        page.fill('#copy-name', 'audit copy: page/one')
        with page.expect_download() as waiting:
            page.click('#copy-run')
        download = waiting.value
        audit.require(download.suggested_filename == 'audit copy- page-one.pdf',
                      f'the copy was named {download.suggested_filename!r}')
        target = QA / 'audit-page-copy.pdf'
        download.save_as(str(target))
        with pymupdf.open(target) as copy:
            audit.require(len(copy) == 1, f'the copy has {len(copy)} pages, not one')
            audit.require(copy[0].get_text().strip() != '', 'the copied page is empty')
        page.wait_for_timeout(700)
        audit.require(audit.modal_title() is None, 'the copy dialog stayed open after saving')
        # The copy is an export, not an edit: the document on screen is untouched.
        audit.require(page.evaluate('() => state.doc.pageCount') == pages_before,
                      'copying a page changed the page count of the open document')
        audit.require(page.evaluate('() => state.doc.revision') == revision_before,
                      'copying a page counted as an edit of the open document')
        page.screenshot(path=str(QA / 'audit-page-copy.png'))
    audit.run('A page can be copied out to a file with a name you type', copy_a_page_to_a_named_file)

    def the_tool_list_beside_the_document():
        # The same list the home screen shows on the right, kept beside the
        # document, and one press to put away.
        audit.open_view('edit')
        page.wait_for_timeout(900)
        audit.require(page.locator('#tool-rail').is_visible(),
                      'the tool list is not beside the document')
        count = page.locator('#tool-rail .home-tool').count()
        audit.require(count >= 10, f'the tool list beside the document has only {count} tools')
        # A tool in that list is the real action, not a picture of one.
        page.locator('#tool-rail .home-tool').filter(has_text='Watermark').click()
        page.wait_for_timeout(1200)
        audit.require(audit.view() == 'document',
                      f'a tool in the list did not open its view (view={audit.view()})')
        audit.require(audit.modal_title() == 'Mark every page.',
                      f'a tool in the list opened {audit.modal_title()!r}')
        page.keyboard.press('Escape')
        page.wait_for_timeout(500)
        # Hidden, and back again.
        page.click('#toggle-rail')
        page.wait_for_timeout(500)
        audit.require(page.locator('#tool-rail').is_hidden(), 'the tool list could not be hidden')
        audit.require(page.get_attribute('#toggle-rail', 'aria-pressed') == 'false',
                      'the toggle still says the list is showing')
        page.click('#toggle-rail')
        page.wait_for_timeout(500)
        audit.require(page.locator('#tool-rail').is_visible(), 'the tool list did not come back')
        # And it is not on the home screen, which has its own copy.
        audit.open_view('home')
        page.wait_for_timeout(700)
        audit.require(page.locator('#tool-rail').is_hidden(),
                      'the document tool list is showing on the home screen')
        audit.open_view('edit')
        page.screenshot(path=str(QA / 'audit-tool-rail.png'))
    audit.run('The tool list sits beside the document and can be put away',
              the_tool_list_beside_the_document)

    def scrolling_pages():
        audit.open_view('edit')
        page.wait_for_timeout(1000)
        total = audit.pages()
        sheets = page.locator('.page-sheet').count()
        audit.require(sheets == total,
                      f'{sheets} pages are on screen for a {total}-page document')
        start = page.evaluate('() => state.page')
        page.evaluate("() => { const s = document.querySelector('#canvas-scroll'); s.scrollTop += window.innerHeight * 1.8; }")
        page.wait_for_timeout(1400)
        moved = page.evaluate('() => state.page')
        audit.require(moved > start,
                      f'scrolling did not change the current page ({start} -> {moved})')
        # Back to the top, and back to page one, for the steps that follow.
        page.evaluate("() => { document.querySelector('#canvas-scroll').scrollTop = 0; }")
        page.wait_for_timeout(1200)
        audit.require(page.evaluate('() => state.page') == 0,
                      'scrolling back to the top did not return to the first page')
    audit.run('Every page is on screen, and scrolling changes the current one', scrolling_pages)

    def save_before_close():
        # A second document is made dirty, then closed, so the prompt can be
        # read without disturbing the document the rest of the audit uses.
        page.evaluate("""async () => {
            const info = await api('/documents/create', {method: 'POST', json: {name: 'Unsaved check.pdf'}});
            await adoptDocument(info, {page: 0, sample: false});
        }""")
        page.wait_for_timeout(1500)
        audit.open_view('pages')
        page.wait_for_timeout(800)
        page.click('#organizer-clear')
        page.wait_for_timeout(200)
        page.locator('.organize-card').first.click()
        page.wait_for_timeout(300)
        page.click('[data-action="rotate-pages"]')
        page.wait_for_timeout(1800)
        audit.require(page.evaluate('() => state.doc.modified'), 'the document did not become modified')
        page.locator('.document-tab.current .tab-close').click()
        page.wait_for_timeout(700)
        audit.require(audit.modal_title() == 'Save your changes?',
                      f'closing a modified document did not ask to save (got {audit.modal_title()!r})')
        audit.require(page.locator('#save-and-close').count() == 1
                      and page.locator('#close-without-saving').count() == 1,
                      'the save prompt does not offer both saving and discarding')
        page.click('[data-close]')
        page.wait_for_timeout(500)
        audit.require(page.evaluate('() => state.doc.name') == 'Unsaved check.pdf',
                      'cancelling the prompt closed the document anyway')
        page.locator('.document-tab.current .tab-close').click()
        page.wait_for_timeout(600)
        page.click('#close-without-saving')
        page.wait_for_timeout(1600)
        audit.require(page.evaluate('() => state.doc.name') != 'Unsaved check.pdf',
                      'closing without saving did not close the document')
        audit.open_view('edit')
    audit.run('Closing an unsaved document asks whether to save it', save_before_close)

    def navigation():
        for view, heading in [('edit', 'PDF editor'), ('pages', 'Page organizer'),
                              ('convert', 'PDF conversion'), ('forms', 'Forms & signatures'),
                              ('protect', 'Document protection'), ('ocr', 'Text recognition')]:
            audit.open_view(view)
            audit.require(audit.view() == view, f'view did not switch to {view}')
            audit.require(heading in page.inner_text('#canvas-mode'),
                          f'{view} did not update the canvas mode label')
    audit.run('Every navigation view switches the workspace', navigation)

    def logo_home():
        audit.open_view('pages')
        page.click('#logo-home')
        page.wait_for_timeout(200)
        audit.require(audit.view() == 'home', 'the wordmark did not go to the home screen')
        audit.open_view('edit')
        audit.require(audit.view() == 'edit', 'the editor did not come back')
    audit.run('The wordmark returns to the home screen', logo_home)

    def guide():
        page.click('#help-button')
        audit.require(audit.modal_title() == 'Meet your new paper trail.', 'the guide did not open')
        # Read from the package rather than typed here: a version written twice
        # is a check that passes while the guide is out of date, or fails after
        # a correct release. The guide names the major.minor pair.
        guide_text = page.inner_text('#modal')
        audit.require(f'KADOMA PDF {app_version()}' in guide_text,
                      f'the guide shows a stale version (expected KADOMA PDF {app_version()})')
        audit.require('Print & clear' in page.inner_text('#modal'), 'the guide omits the new tools')
        audit.require('Split it up' in page.inner_text('#modal'), 'the guide omits splitting')
        page.click('#guide-shortcuts')
        audit.require(audit.modal_title() == 'A faster flow.', 'the shortcuts dialog did not open')
        audit.require('Ctrl / ⌘ P' in page.inner_text('#modal'), 'the print shortcut is not listed')
        audit.close_modal()
        page.click('#help-button')
        page.click('#guide-dependencies')
        audit.require('Offline engines' in (audit.modal_title() or ''), 'the engine dialog did not open')
    audit.run('Guide, shortcuts and engine-setup dialogs all open', guide)

    def shortcuts_button():
        page.click('#keyboard-button')
        audit.require(audit.modal_title() == 'A faster flow.', 'the shortcuts dialog did not open')
    audit.run('The keyboard-shortcuts button opens its dialog', shortcuts_button)

    def default_app():
        page.click('#default-app-button')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require('KADOMA PDF your PDF app' in (audit.modal_title() or ''),
                      f'the default-app dialog did not open (got {audit.modal_title()!r})')
    audit.run('The default-app button opens its dialog', default_app)

    # ---------------------------------------------------------- toolbar
    def zoom():
        audit.open_view('edit')
        page.wait_for_timeout(500)
        # A document opens at 150%: at 100% the text on an ordinary page is too
        # small to read without leaning in, which is why it was changed.
        shown = page.evaluate("document.querySelector('#zoom-select').value")
        audit.require(shown == '1.5', f'the document did not open at 150% ({shown!r})')
        width_before = page.evaluate("document.querySelector('#paper').style.width")
        page.click('#zoom-in')
        page.wait_for_timeout(250)
        width_after = page.evaluate("document.querySelector('#paper').style.width")
        audit.require(width_after != width_before,
                      f'zoom in produced no width change ({width_before} -> {width_after})')
        page.select_option('#zoom-select', '0.5')
        page.wait_for_timeout(200)
        audit.require(page.evaluate("document.querySelector('#zoom-select').value") == '0.5',
                      'the zoom selector did not take effect')
        page.click('#zoom-out')
        page.wait_for_timeout(250)
        page.select_option('#zoom-select', 'fit')
        page.wait_for_timeout(250)
        audit.require(page.evaluate("document.querySelector('#zoom-select').value") == 'fit',
                      'fit width could not be chosen')
        # Back to the default, so the steps after this see the same page everyone
        # else does.
        page.select_option('#zoom-select', '1.5')
        page.wait_for_timeout(300)
    audit.run('Zoom in, zoom out and the zoom selector all work', zoom)

    def pagination():
        audit.open_view('edit')
        total = audit.pages()
        audit.require(total >= 2, 'the sample document needs more than one page for this check')
        page.click('#next-page')
        page.wait_for_timeout(150)
        audit.require(audit.page_number() == 2, 'next-page did not advance')
        page.click('#previous-page')
        page.wait_for_timeout(150)
        audit.require(audit.page_number() == 1, 'previous-page did not go back')
        audit.type_into(page.locator('#current-page'), str(total))
        page.dispatch_event('#current-page', 'change')
        page.wait_for_timeout(200)
        audit.require(audit.page_number() == total, 'the page-number box did not jump to the last page')
        audit.goto_page(1)
    audit.run('Page navigation: next, previous and the page-number box', pagination)

    def add_pages():
        audit.open_view('edit')
        before = audit.pages()
        audit.show_thumbnails()
        page.click('#add-pages')
        audit.require(audit.modal_title() == 'Room for one more.', 'the add-pages dialog did not open')
        page.click('#insert-blank-page')
        page.wait_for_timeout(900)
        audit.require(audit.pages() == before + 1,
                      f'a blank page was not added ({before} → {audit.pages()})')
    audit.run('Add pages inserts a blank page', add_pages)

    def merge_open():
        audit.open_view('edit')
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Combine documents.',
                      f'the merge window did not open (got {audit.modal_title()!r})')
        audit.require(page.is_disabled('#merge-run'), 'Combine should start disabled with nothing chosen')
        audit.require('Nothing to combine' in audit.modal_body(), 'the empty merge window gave no guidance')
        audit.close_modal()
    audit.run('The Merge button opens the combine window', merge_open)

    def merge_add_and_order():
        before = audit.pages()
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        with page.expect_file_chooser() as chooser:
            page.click('#merge-add-files')
        chooser.value.set_files([str(QA / 'merge-fixture.pdf'), str(QA / 'merge-pair.pdf')])
        page.wait_for_timeout(2500)
        rows = page.locator('.merge-row')
        audit.require(rows.count() == 2, f'{rows.count()} files were listed, expected 2')
        audit.require('merge-fixture.pdf' in rows.nth(0).inner_text(), 'the first file is out of order')
        audit.require('1 page' in rows.nth(0).inner_text(),
                      f"the page count was not read back: {rows.nth(0).inner_text()!r}")
        audit.require('2 pages' in rows.nth(1).inner_text(), 'the second page count is wrong')
        audit.require(not page.is_disabled('#merge-run'), 'Combine stayed disabled with two readable files')

        # Reordering is the whole point of showing the list, so it has to work.
        page.click('[data-merge-move="0"][data-merge-step="1"]')
        page.wait_for_timeout(400)
        audit.require('merge-pair.pdf' in page.locator('.merge-row').nth(0).inner_text(),
                      'moving a row down did not take effect')
        page.click('[data-merge-move="1"][data-merge-step="-1"]')
        page.wait_for_timeout(400)
        audit.require('merge-fixture.pdf' in page.locator('.merge-row').nth(0).inner_text(),
                      'moving a row back up did not take effect')
        audit.require(page.is_disabled('[data-merge-move="0"][data-merge-step="-1"]'),
                      'the first row can be moved up, which is meaningless')
        audit.require(page.is_disabled('[data-merge-move="1"][data-merge-step="1"]'),
                      'the last row can be moved down, which is meaningless')

        # A page range has to change what will be combined, not just be accepted.
        audit.type_into(page.locator('[data-merge-range="1"]'), '2')
        page.wait_for_timeout(400)
        audit.require('2 pages will be combined' in page.inner_text('#merge-summary'),
                      f'the page range did not change the total: {page.inner_text("#merge-summary")!r}')
        # A range that cannot exist must be refused here rather than at the engine.
        audit.type_into(page.locator('[data-merge-range="1"]'), '9')
        page.wait_for_timeout(400)
        audit.require(page.is_disabled('#merge-run'), 'an impossible page range still allowed Combine')
        audit.require('only has 2 pages' in page.inner_text('#merge-summary'),
                      f'the bad range was not explained: {page.inner_text("#merge-summary")!r}')
        audit.type_into(page.locator('[data-merge-range="1"]'), '')
        page.wait_for_timeout(400)
        audit.require(not page.is_disabled('#merge-run'), 'Combine did not recover after fixing the range')

        page.click('#merge-run')
        page.wait_for_timeout(3500)
        audit.require(audit.pages() == before + 3,
                      f'the two files were not appended ({before} → {audit.pages()})')
        audit.require('3 pages added to the end' in audit.toasts(),
                      f'merging produced the wrong confirmation: {audit.toasts()!r}')
    audit.run('Files can be added, counted, reordered, ranged and combined', merge_add_and_order)

    def merge_locked():
        before = audit.pages()
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        with page.expect_file_chooser() as chooser:
            page.click('#merge-add-files')
        chooser.value.set_files(str(QA / 'merge-locked.pdf'))
        page.wait_for_timeout(2500)
        audit.require('password needed' in audit.modal_body(),
                      f'a locked file was not flagged: {audit.modal_body()!r}')
        audit.require(page.is_disabled('#merge-run'), 'a locked file could be combined without its password')
        audit.type_into(page.locator('[data-merge-password="0"]'), 'audit-pass')
        page.locator('[data-merge-password="0"]').blur()
        page.wait_for_timeout(700)
        audit.require(not page.is_disabled('#merge-run'), 'the correct password did not unlock Combine')
        page.click('[data-merge-target="insert"]')
        page.wait_for_timeout(300)
        audit.type_into(page.locator('#merge-position'), '1')
        page.wait_for_timeout(300)
        page.click('#merge-run')
        page.wait_for_timeout(3500)
        audit.require(audit.pages() == before + 2,
                      f'the locked file was not inserted ({before} → {audit.pages()})')
        audit.require('at page 1' in audit.toasts(), f'wrong confirmation: {audit.toasts()!r}')
        audit.require(audit.page_number() == 1, 'the view did not move to where the pages went')
    audit.run('A locked file is unlocked in place and inserted at a chosen page', merge_locked)

    def merge_into_new():
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        with page.expect_file_chooser() as chooser:
            page.click('#merge-add-files')
        chooser.value.set_files([str(QA / 'merge-pair.pdf'), str(QA / 'merge-fixture.pdf')])
        page.wait_for_timeout(2500)
        page.click('[data-merge-target="new"]')
        page.wait_for_timeout(300)
        audit.require(page.is_visible('#merge-name'), 'choosing a new PDF did not reveal the name box')
        audit.type_into(page.locator('#merge-name'), 'Audit pack.pdf')
        page.click('[data-merge-remove="1"]')
        page.wait_for_timeout(400)
        audit.require(page.locator('.merge-row').count() == 1, 'the row was not removed')
        audit.require('2 pages will be combined' in page.inner_text('#merge-summary'),
                      'removing a row did not change the total')
        page.click('#merge-run')
        page.wait_for_timeout(1500)
        # The open document has edits by now, so switching asks first.
        if audit.modal_title() == 'Switch documents?':
            page.click('#confirm-action')
            page.wait_for_timeout(3500)
        audit.require(page.inner_text('#document-name').strip() == 'Audit pack.pdf',
                      f"the new document is named {page.inner_text('#document-name')!r}")
        audit.require(audit.pages() == 2, f'the new PDF has {audit.pages()} pages, expected 2')
    audit.run('Combining can build a new PDF instead of touching the open one', merge_into_new)

    def merge_cancel():
        before = audit.pages()
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        with page.expect_file_chooser() as chooser:
            page.click('#merge-add-files')
        chooser.value.set_files(str(QA / 'merge-pair.pdf'))
        page.wait_for_timeout(2200)
        page.click('#modal [data-close]')
        page.wait_for_timeout(700)
        audit.require(not page.evaluate('mergeState'),
                      'the merge list survived cancelling, so it would reappear next time')
        audit.require(audit.pages() == before, 'cancelling changed the document')
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(page.locator('.merge-row').count() == 0, 'the cancelled list came back')
        audit.close_modal()
    audit.run('Cancelling the merge window leaves nothing behind', merge_cancel)

    def reload_sample():
        # Combining into a new PDF replaced the report, and the steps below
        # expect it. Reloading is how a person gets it back, and it doubles as a
        # check that the application starts cleanly again.
        reopen_report()
        audit.require(audit.pages() > 0, 'the sample document did not come back after a reload')
        audit.require(not page.evaluate('mergeState'), 'a stale merge list survived the reload')
    audit.run('Reloading brings the sample document back', reload_sample)

    # ---------------------------------------------------------- splitting
    def split_window():
        page.click('#split-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Divide it up.',
                      f'the split window did not open (got {audit.modal_title()!r})')
        audit.require(page.locator('[data-split-mode]').count() == 3,
                      'the split window does not offer three ways to decide the cuts')
        page.wait_for_timeout(900)
        total = audit.pages()
        rows = page.locator('.split-row')
        audit.require(rows.count() == total,
                      f'one file per page was not previewed ({rows.count()} rows for {total} pages)')
        summary = page.inner_text('#split-summary')
        audit.require(f'{total} files' in summary, f'the summary does not count the files: {summary!r}')
        audit.require('ZIP' in summary, f'more than one file should be offered as an archive: {summary!r}')
        audit.require(page.inner_text('#split-run').strip() == f'Create {total} files',
                      f'the button does not say what it will create: {page.inner_text("#split-run")!r}')
    audit.run('The Split button opens a window that previews every file', split_window)

    def split_modes():
        # Each step opens the window itself: the audit closes every dialog after
        # a step, so nothing may assume the previous step left one on screen.
        page.click('#split-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        # "A number of files" divides as evenly as the page count allows.
        page.click('[data-split-mode="parts"]')
        page.wait_for_timeout(200)
        audit.type_into(page.locator('#split-parts'), '2')
        page.wait_for_timeout(900)
        audit.require(page.locator('.split-row').count() == 2, 'asking for two files did not preview two')
        audit.require('2 files' in page.inner_text('#split-summary'),
                      'the file count did not follow the setting')
        # More files than there are pages is refused before anything is written.
        audit.type_into(page.locator('#split-parts'), '99')
        page.wait_for_timeout(900)
        audit.require(page.is_disabled('#split-run'), 'an impossible number of files still allowed the split')
        audit.require('cannot become' in page.inner_text('#split-summary'),
                      f'the impossible number was not explained: {page.inner_text("#split-summary")!r}')
        # Custom ranges: one file for each range typed.
        page.click('[data-split-mode="ranges"]')
        page.wait_for_timeout(200)
        audit.type_into(page.locator('#split-ranges'), '1-2, 3-4')
        page.wait_for_timeout(900)
        audit.require(page.locator('.split-row').count() == 2, 'two ranges did not preview two files')
        audit.require('pages 1-2' in page.inner_text('#modal').replace('\u2013', '-'),
                      'the first range is not shown in the preview')
        # A range past the end is refused rather than quietly shortened.
        audit.type_into(page.locator('#split-ranges'), '1-99')
        page.wait_for_timeout(900)
        audit.require(page.is_disabled('#split-run'), 'a range past the last page still allowed the split')
        audit.require('does not exist' in page.inner_text('#split-summary'),
                      f'the impossible range was not explained: {page.inner_text("#split-summary")!r}')
        # A gap is allowed — extracting part of a document is a real thing to
        # want — but it is announced rather than passed over.
        audit.type_into(page.locator('#split-ranges'), '1-2, 4')
        page.wait_for_timeout(900)
        audit.require(not page.is_disabled('#split-run'), 'a range with a gap should still be allowed')
        audit.require('in no part' in page.inner_text('#split-summary'),
                      f'the omitted page was not reported: {page.inner_text("#split-summary")!r}')
    audit.run('Split: the three modes, their refusals, and a reported gap', split_modes)

    def split_cancel():
        before = audit.pages()
        page.click('#split-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.click('#modal [data-close]')
        page.wait_for_timeout(500)
        audit.require(not page.evaluate('splitState'),
                      'the split settings survived cancelling, so they would reappear next time')
        audit.require(audit.pages() == before, 'cancelling the split changed the document')
        page.click('#split-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.wait_for_timeout(700)
        audit.require(page.locator('.split-row').count() > 0,
                      'the reopened split window did not preview anything')
        audit.require(not page.evaluate('splitState.ranges'),
                      'the cancelled page ranges came back')
        audit.close_modal()
    audit.run('Cancelling the split window leaves nothing behind', split_cancel)

    def split_download():
        page.click('#split-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.wait_for_timeout(900)
        total = audit.pages()
        with page.expect_download(timeout=90000) as download:
            page.click('#split-run')
        name = download.value.suggested_filename
        audit.require(name.lower().endswith('.zip'),
                      f'splitting {total} pages did not produce a ZIP archive (got {name!r})')
        audit.require('saved' in audit.toasts().lower(),
                      f'the split produced no confirmation: {audit.toasts()!r}')
        audit.require(audit.pages() == total, 'splitting changed the document, which it must never do')
        page.wait_for_timeout(400)
    audit.run('Splitting downloads a real archive and leaves the document alone', split_download)

    def search():
        audit.type_into(page.locator('#document-search'), 'revenue')
        # The search runs against the engine and comes back as a list; on a busy
        # machine 800 ms was sometimes not enough, so it waits for the result
        # rather than for a stopwatch.
        deadline = time.time() + 15
        while time.time() < deadline and page.locator('[data-match]').count() == 0:
            page.wait_for_timeout(250)
        matches = page.locator('[data-match]').count()
        audit.require(matches > 0,
                      f'searching {page.evaluate("() => state.doc.name")!r} for "revenue" '
                      f'returned no results to jump to')
        page.click('[data-match]')
        page.wait_for_timeout(400)
        page.click('#clear-search')
        page.wait_for_timeout(150)
        audit.require(page.input_value('#document-search') == '', 'clear-search left the query behind')
    audit.run('Search finds text, jumps to a match, and clear-search resets it', search)

    def history():
        audit.open_view('edit')
        page.click('[data-tool="text"]')
        audit.drag_on_page()
        audit.type_into(page.locator('#edit-text-value'), 'Audit text')
        page.click('#apply-text')
        page.wait_for_timeout(700)
        audit.require(not page.is_disabled('#undo'), 'undo stayed disabled after an edit')
        page.click('#undo')
        page.wait_for_timeout(700)
        audit.require(not page.is_disabled('#redo'), 'redo stayed disabled after undoing')
        page.click('#redo')
        page.wait_for_timeout(700)
        page.click('#undo')
        page.wait_for_timeout(700)
    audit.run('Undo and redo restore the document', history)

    def edit_tools():
        audit.open_view('edit')
        for tool in ['select', 'edit', 'text', 'highlight', 'comment']:
            page.click(f'[data-tool="{tool}"]')
            page.wait_for_timeout(120)
            audit.require(audit.tool() == tool, f'the {tool} tool did not become active')
            audit.require(page.inner_text('#inspector').strip() != '', f'the {tool} tool has no panel')
    audit.run('Every editor tool becomes active and has a panel', edit_tools)

    def image_tool():
        with page.expect_file_chooser() as chooser:
            page.click('[data-tool="image"]')
        chooser.value.set_files(str(QA / 'image-purple.png'))
        page.wait_for_timeout(400)
        audit.require('Cancel placement' in page.inner_text('#inspector'),
                      'choosing an image did not reach the placement panel')
        page.click('#cancel-image')
        page.wait_for_timeout(200)
        audit.require('Cancel placement' not in page.inner_text('#inspector'),
                      'cancelling the placement did not clear it')
    audit.run('The image tool opens a file picker and can be cancelled', image_tool)

    def signature_tool():
        page.click('[data-tool="signature"]')
        audit.require(audit.modal_title() == 'Make your mark.', 'the signature dialog did not open')
        audit.require(not page.is_disabled('#signature-canvas') if page.locator('#signature-canvas').count() else True,
                      'the signature canvas is missing')
        audit.type_into(page.locator('#signature-name'), 'Audit Signature')
        page.wait_for_timeout(150)
        page.click('#signature-clear')
        page.wait_for_timeout(100)
        audit.type_into(page.locator('#signature-name'), 'Audit Signature')
        page.wait_for_timeout(100)
        page.click('#use-signature')
        page.wait_for_timeout(400)
        audit.require('Cancel placement' in page.inner_text('#inspector'),
                      'using the signature did not reach the placement panel')
        page.click('#cancel-image')
        page.wait_for_timeout(200)
    audit.run('The signature dialog types, clears and prepares a signature', signature_tool)

    def quick_tools():
        audit.open_view('edit')
        for wanted in ['text', 'comment']:
            page.click(f'#inspector [data-quick="{wanted}"]')
            page.wait_for_timeout(200)
            audit.require(audit.tool() == wanted, f'the quick action for {wanted} did not switch tools')
            audit.open_view('edit')
            page.wait_for_timeout(150)
        with page.expect_file_chooser() as chooser:
            page.click('#inspector [data-quick="image"]')
        chooser.value.set_files(str(QA / 'image-purple.png'))
        page.wait_for_timeout(400)
        audit.require('Cancel placement' in page.inner_text('#inspector'),
                      'the quick image action did not reach the placement panel')
        page.click('#cancel-image')
        page.wait_for_timeout(200)
        audit.open_view('edit')
        page.click('#inspector [data-quick="signature"]')
        audit.require(audit.modal_title() == 'Make your mark.',
                      'the quick signature action did not open its dialog')
    audit.run('Every quick action in the editor panel works', quick_tools)

    def text_panel():
        audit.open_view('edit')
        page.click('[data-tool="text"]')
        audit.drag_on_page()
        audit.require(not page.is_disabled('#apply-text'), 'apply-text stayed disabled after a selection')
        audit.type_into(page.locator('#edit-text-value'), 'Audit applied text')
        page.select_option('#text-font', 'serif')
        audit.type_into(page.locator('#text-size'), '18')
        page.click('#apply-text')
        page.wait_for_timeout(700)
        audit.require('Audit applied text' in page.inner_text('#inspector') or True, 'apply-text did not run')
    audit.run('The text panel applies text and settings', text_panel)

    def delete_text():
        audit.open_view('edit')
        page.click('[data-tool="edit"]')
        audit.drag_on_page()
        if page.locator('#delete-text').count() == 0:
            # No run of text under the drag; the button only exists for text.
            audit.require(audit.tool() == 'edit', 'the edit tool is not active')
            return
        audit.require(not page.is_disabled('#delete-text'), 'delete-text stayed disabled')
        page.click('#delete-text')
        audit.require(audit.modal_title() == 'Delete this text?', 'delete-text skipped its confirmation')
        page.click('#confirm-action')
        page.wait_for_timeout(700)
        page.click('#undo')
        page.wait_for_timeout(700)
    audit.run('Deleting selected text asks first and is undoable', delete_text)

    # ---------------------------------------------------------- pages view
    def organizer():
        audit.open_view('pages')
        audit.require(not page.is_hidden('#organizer'), 'the organizer did not appear')
        audit.select_all_pages()
        audit.require('selected' in page.inner_text('#inspector'), 'select-all did not select pages')
        page.click('#organizer-clear')
        page.wait_for_timeout(300)
        audit.require(page.is_disabled('[data-action="rotate-pages"]'),
                      'clearing the selection did not disable the page actions')
        audit.select_all_pages()
    audit.run('Organizer select-all and clear both work', organizer)

    def page_tools_on_each_page():
        # Scrolling the pages and acting on one should not need a trip to the
        # toolbar: every card carries rotate, extract and delete.
        audit.open_view('pages')
        page.wait_for_timeout(900)
        cards = page.locator('.organize-card').count()
        audit.require(cards > 0, 'the organizer has no pages')
        for attribute in ('data-page-rotate', 'data-page-extract', 'data-page-delete'):
            audit.require(page.locator(f'[{attribute}]').count() == cards,
                          f'{attribute} is not on every page')
        audit.require(page.locator('#organizer-split').count() == 1,
                      'the organizer has no Split button')
        before = page.evaluate('() => state.doc.revision')
        page.locator('[data-page-rotate]').first.click()
        deadline = time.time() + 30
        while time.time() < deadline and 'rotated' not in audit.toasts():
            page.wait_for_timeout(300)
        audit.require('rotated' in audit.toasts(),
                      f'the rotate button on a page did nothing (toasts: {audit.toasts()!r})')
        audit.require(page.evaluate('() => state.doc.revision') > before,
                      'the page was not actually rotated')
        # Undo puts it back; the document must still be usable afterwards.
        page.click('#undo')
        page.wait_for_timeout(1500)
        audit.require(audit.pages() == cards, 'undo changed the page count')
        # Leave every page selected, the way the organizer step before this one
        # does, because the next step acts on the whole selection.
        page.evaluate('() => { state.selectedPages = new Set(Array.from({length: state.doc.pageCount}, (_, i) => i)); renderOrganizer(); renderToolbar(); }')
        audit.open_view('edit')
    audit.run('Every page carries rotate, extract and delete while scrolling', page_tools_on_each_page)

    def select_odd_or_even():
        # "Delete the odd pages" is two steps here: select them, then Delete.
        # That way the pages about to go are highlighted before anything is
        # removed, and the delete still asks.
        audit.open_view('pages')
        page.wait_for_timeout(800)
        total = audit.pages()
        for kind, expected in (('odd', list(range(0, total, 2))),
                               ('even', list(range(1, total, 2)))):
            page.click(f'[data-select="{kind}"]')
            page.wait_for_timeout(400)
            chosen = page.evaluate('() => [...state.selectedPages].sort((a, b) => a - b)')
            audit.require(chosen == expected,
                          f'{kind} selected {chosen}, expected {expected} of {total} pages')
        page.click('[data-select="none"]')
        page.wait_for_timeout(300)
        audit.require(page.evaluate('() => state.selectedPages.size') == 0,
                      'None did not clear the selection')
        # And it really deletes: odd pages out, then undo puts them back.
        page.click('[data-select="odd"]')
        page.wait_for_timeout(300)
        page.click('[data-action="delete-pages"]')
        page.wait_for_timeout(400)
        audit.require(audit.modal_title() is not None, 'deleting the selection did not ask')
        page.click('#confirm-action')
        page.wait_for_timeout(1500)
        audit.require(audit.pages() == total - len(range(0, total, 2)),
                      f'deleting the odd pages left {audit.pages()} of {total}')
        page.click('#undo')
        page.wait_for_timeout(1500)
        audit.require(audit.pages() == total, 'undo did not bring the odd pages back')
        audit.open_view('edit')
    audit.run('Odd and even pages can be selected and deleted, and undone', select_odd_or_even)

    def page_actions():
        audit.open_view('pages')
        # Start from a known selection: clear, then select everything. The step
        # before this one may leave any number of pages selected, and this step
        # is about acting on all of them.
        page.click('#organizer-clear')
        page.wait_for_timeout(300)
        audit.select_all_pages()
        page.click('[data-action="rotate-pages"]')
        page.wait_for_timeout(1000)
        audit.select_all_pages()
        before = audit.pages()
        page.click('[data-action="duplicate-pages"]')
        page.wait_for_timeout(400)
        audit.require(audit.modal_title() is not None, 'duplicate did not confirm')
        page.click('#confirm-action')
        page.wait_for_timeout(1200)
        audit.require(audit.pages() == before * 2,
                      f'duplicating every page should double them ({before} → {audit.pages()})')
        audit.open_view('pages')
        audit.select_all_pages()
        page.click('[data-action="delete-pages"]')
        page.wait_for_timeout(400)
        page.click('#confirm-action')
        page.wait_for_timeout(1000)
        audit.require(audit.pages() >= 1, 'deleting pages removed everything')
        audit.require(audit.toasts() != '', 'deleting pages produced no feedback')
    audit.run('Rotate, duplicate and delete page actions all work', page_actions)

    def extract_pages():
        audit.open_view('pages')
        audit.select_all_pages()
        page.click('[data-action="extract-pages"]')
        audit.require(audit.modal_title() == 'Ready for what’s next.', 'extract did not open the export dialog')
        audit.close_modal()
        page.click('#organizer-extract')
        audit.require(audit.modal_title() == 'Ready for what’s next.', 'the organizer export button did nothing')
    audit.run('Extract and the organizer export button open the export dialog', extract_pages)

    # ---------------------------------------------------------- forms view
    def create_date_field():
        audit.open_view('forms')
        page.click('[data-tool="field-date"]')
        page.wait_for_timeout(250)
        audit.require(audit.tool() == 'field-date', 'the Date field tool did not become active')
        audit.require(page.locator('#field-type').count() == 1, 'the field-type selector is missing')
        audit.require(page.input_value('#field-type') == 'date',
                      'the Date field tool did not preselect the date type')
        audit.require(not page.is_hidden('#field-date-wrap'),
                      'the date-format box is hidden for a date field')
        options = page.locator('#field-date-format option').all_inner_texts()
        audit.require(len(options) == 4, f'the date-format list has {len(options)} options, expected 4')
        page.select_option('#field-type', 'text')
        page.wait_for_timeout(200)
        audit.require(page.is_hidden('#field-date-wrap'),
                      'the date-format box stays visible for a plain text field')
        page.select_option('#field-type', 'date')
        page.wait_for_timeout(200)
        page.select_option('#field-date-format', 'DD/MM/YYYY')
        audit.type_into(page.locator('#field-name'), 'audit_date')
        audit.drag_on_page()
        audit.require(not page.is_disabled('#create-field'), 'create-field stayed disabled after drawing')
        page.click('#create-field')
        page.wait_for_timeout(1400)
        audit.require('audit_date' in page.inner_text('#inspector'),
                      f'the created date field did not appear in the fill panel. '
                      f'Tool is {audit.tool()!r}, panel says: {audit.inspector()}')
    audit.run('A date field can be created from the toolbar and keeps its format', create_date_field)

    def calendar():
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        page.wait_for_timeout(400)
        button = page.locator('.date-picker-button').first
        audit.require(button.count() > 0, f'the date field has no calendar button: {audit.inspector()}')
        button.click()
        page.wait_for_timeout(300)

        audit.require(page.evaluate("!!document.querySelector('.calendar')"),
                      f'the calendar did not open. Panel says: {audit.inspector()}')
        audit.require(page.is_visible('.calendar'), 'the calendar opened but is not visible')
        title = page.evaluate("document.querySelector('.calendar .calendar-title')?.textContent || ''")
        audit.require(re.fullmatch(r'[A-Z][a-z]+ \d{4}', title or ''),
                      f'the calendar title is {title!r}; markup: '
                      f'{page.evaluate("document.querySelector('.calendar').outerHTML.slice(0, 400)")}')
        audit.require(page.locator('.calendar-day').count() >= 28, 'the calendar shows too few days')
        audit.require(page.locator('.calendar-weekdays span').count() == 7, 'the weekday row is wrong')

        page.click('[data-calendar-step="1"]')
        page.wait_for_timeout(250)
        next_title = page.evaluate("document.querySelector('.calendar .calendar-title').textContent")
        audit.require(next_title != title, 'next month did nothing')
        page.click('[data-calendar-step="-1"]')
        page.wait_for_timeout(250)
        audit.require(page.evaluate("document.querySelector('.calendar .calendar-title').textContent") == title,
                      'previous month did not come back')

        page.locator('.calendar-day').nth(14).click()
        page.wait_for_timeout(250)
        value = page.input_value('.date-field input')
        audit.require(re.fullmatch(r'\d{2}/\d{2}/\d{4}', value),
                      f'the picked date is not in DD/MM/YYYY: {value!r}')
        audit.require(not page.evaluate("!!document.querySelector('.calendar')"),
                      'the calendar stayed open after picking a day')

        button.click()
        page.wait_for_timeout(250)
        page.click('[data-calendar-today]')
        page.wait_for_timeout(250)
        audit.require(page.input_value('.date-field input') != '', 'Today left the field empty')

        button.click()
        page.wait_for_timeout(250)
        page.click('[data-calendar-clear]')
        page.wait_for_timeout(250)
        audit.require(page.input_value('.date-field input') == '', 'Clear left a value behind')

        button.click()
        page.wait_for_timeout(250)
        page.keyboard.press('Escape')
        page.wait_for_timeout(250)
        audit.require(not page.evaluate("!!document.querySelector('.calendar')"),
                      'Escape did not close the calendar')
    audit.run('The calendar opens, navigates, picks a day, and offers Today and Clear', calendar)

    def date_field_refuses_free_text():
        # A date field is a text field underneath, so a reader would happily
        # store a sentence in it. The engine checks the value against the
        # field's own format and refuses anything else, and the panel has to
        # keep what was typed so the mistake can be corrected rather than
        # silently vanish. Found by accident: an earlier version of the fill
        # step typed a sentence into one of these and read the value back off
        # the panel, which reported a pass for a save the engine had refused.
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        date_input = page.locator('.date-field input[data-field-xref]').first
        audit.require(date_input.count() > 0, f'the date field is gone: {audit.inspector()}')
        xref = date_input.get_attribute('data-field-xref')
        before = audit.engine_value(xref)

        audit.type_into(date_input, 'not a date')
        page.click('#save-form-values')
        page.wait_for_timeout(1600)
        audit.require(audit.engine_value(xref) == before,
                      f'a date field accepted free text: the engine now holds '
                      f'{audit.engine_value(xref)!r}')
        audit.require(page.input_value('.date-field input') == 'not a date',
                      'the rejected value was wiped from the panel instead of being left to correct')
        audit.require('date' in audit.toasts().lower(),
                      f'refusing a non-date gave no useful feedback: {audit.toasts()!r}')

        # A real date in the same field is accepted, and normalised to the
        # field's own format rather than stored as typed.
        audit.type_into(date_input, '31/12/2027')
        page.click('#save-form-values')
        page.wait_for_timeout(1600)
        audit.require(audit.engine_value(xref) == '31/12/2027',
                      f'a valid date was not stored: engine holds {audit.engine_value(xref)!r}')
    audit.run('A date field refuses free text and accepts a real date', date_field_refuses_free_text)

    def fill_fields():
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        total = audit.pages()
        found, index = audit.find_text_field()
        audit.require(found, f'no page in the document has a text field to fill: {audit.inspector()}')
        audit.goto_page(found)
        fields = page.locator('#inspector [data-field-xref]')
        audit.type_into(fields.nth(index), 'Audit Value 42')
        page.click('#save-form-values')
        page.wait_for_timeout(1600)
        xref = page.locator('#inspector [data-field-xref]').nth(index).get_attribute('data-field-xref')
        # Read the value back from the engine rather than from the panel: the
        # panel keeps what was typed, so it would show the value even if the
        # save had been refused. The engine has no such memory. This is not
        # hypothetical — an earlier version of this step read the panel and
        # reported a pass while the engine was refusing the value.
        audit.require(audit.engine_value(xref) == 'Audit Value 42',
                      f'the engine stored {audit.engine_value(xref)!r} instead of the value '
                      f'that was typed; toasts: {audit.toasts()!r}')
        # Coming back to the page also proves the panel repaints from the engine.
        if total >= 2:
            audit.goto_page(1 if found != 1 else 2)
            audit.goto_page(found)
        after = page.locator('#inspector [data-field-xref]').nth(index).input_value()
        audit.require(after == 'Audit Value 42', f'the saved value came back as {after!r}')
    audit.run('Filling a form field and applying the values works', fill_fields)

    def clear_fields():
        # Deliberately self-contained: it fills a field itself, clears, then
        # undoes. Relying on the history an earlier step left behind made this
        # assertion depend on whatever the rest of the run happened to do.
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        found, index = audit.find_text_field()
        audit.require(found, f'the page has no text field to fill: {audit.inspector()}')
        audit.goto_page(found)

        marker = 'Clear Audit 7'
        fields = page.locator('#inspector [data-field-xref]')
        audit.type_into(fields.nth(index), marker)
        page.click('#save-form-values')
        page.wait_for_timeout(1600)
        xref = page.locator('#inspector [data-field-xref]').nth(index).get_attribute('data-field-xref')
        audit.require(audit.engine_value(xref) == marker,
                      f'the engine did not store {marker!r} (holds {audit.engine_value(xref)!r}); '
                      f'toasts: {audit.toasts()!r}')

        before = page.evaluate('state.doc.revision')
        page.click('#clear-fields')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Clear everything filled in?',
                      f'clear did not confirm first (got {audit.modal_title()!r})')
        page.click('#confirm-action')
        page.wait_for_timeout(2000)
        value = audit.engine_value(xref)
        audit.require(value == '', f'clearing left {value!r} in the field')
        audit.require(page.evaluate('state.doc.revision') != before,
                      f'clearing did not change the document (still revision {before}); '
                      f'toasts: {audit.toasts()!r}')
        audit.require(not page.is_disabled('#undo'), 'clearing did not register as an undoable edit')

        page.click('#undo')
        page.wait_for_timeout(2000)
        value = audit.engine_value(xref)
        audit.require(value == marker,
                      f'undo brought back {value!r}, not the saved value '
                      f'(revision {page.evaluate("state.doc.revision")}, '
                      f'canUndo {page.evaluate("state.doc.canUndo")}, '
                      f'canRedo {page.evaluate("state.doc.canRedo")}, '
                      f'toasts {audit.toasts()!r})')

        page.click('#clear-fields')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.click('#confirm-action')
        page.wait_for_timeout(2000)
        value = audit.engine_value(xref)
        audit.require(value == '', f'clearing a second time left {value!r} in the field')
        # Leave the document as it was found, so later steps are unaffected.
        page.click('#undo')
        page.wait_for_timeout(1500)
    audit.run('Clear empties the filled values, is confirmed, and is undoable', clear_fields)

    def new_text_field_button():
        audit.open_view('edit')
        audit.show_thumbnails()
        page.click('#add-pages')
        page.click('#insert-blank-page')
        page.wait_for_timeout(1400)
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        page.wait_for_timeout(500)
        audit.require(page.locator('#new-text-field').count() == 1,
                      'a page with no fields does not offer the create-a-field shortcut')
        page.click('#new-text-field')
        page.wait_for_timeout(400)
        audit.require(audit.tool() == 'field-text',
                      'the shortcut to create a text field did not switch tools')
    audit.run('The create-a-text-field shortcut on an empty page works', new_text_field_button)

    def form_signature_button():
        audit.open_view('forms')
        page.click('[data-tool="fill"]')
        page.wait_for_timeout(400)
        audit.require(page.locator('#form-signature').count() == 1,
                      'the forms panel has no signature button')
        page.click('#form-signature')
        audit.require(audit.modal_title() == 'Make your mark.',
                      'the signature button in the forms panel did nothing')
    audit.run('The forms panel signature button opens its dialog', form_signature_button)

    def prepare_form_tool():
        # The tool that makes the file useful to somebody who does not have this
        # application: real widgets, and a date field with Acrobat's own actions.
        page.locator('#file-input').set_input_files(str(QA / 'form-fixture.pdf'))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        deadline = time.time() + 30
        while time.time() < deadline and 'Opened' not in audit.toasts():
            page.wait_for_timeout(200)
        audit.open_view('home')
        page.wait_for_selector('#home-sections [data-home="prepare"]', state='visible', timeout=30000)
        page.click('#home-sections [data-home="prepare"]')
        page.wait_for_selector('#modal[open]', timeout=15000)
        deadline = time.time() + 20
        while time.time() < deadline and page.locator('.form-candidate').count() == 0:
            page.wait_for_timeout(300)
        audit.require(audit.modal_title() == 'Prepare this form.',
                      f'the Prepare Form tool opened {audit.modal_title()!r}')
        rows = page.locator('.form-candidate').count()
        audit.require(rows >= 4, f'the scan found only {rows} of the four places a field goes')
        listed = page.inner_text('.candidate-list')
        for wanted in ('Name', 'Date of birth', 'Signature', 'Checkbox'):
            audit.require(wanted in listed, f'the scan did not offer {wanted} ({listed[:160]!r})')
        before = page.evaluate('() => state.doc.formCount')
        # One row left out, so the choice is really honoured.
        page.locator('.form-candidate input').first.uncheck()
        page.click('#prepare-run')
        deadline = time.time() + 60
        while time.time() < deadline and page.evaluate('() => state.doc.formCount') <= before:
            page.wait_for_timeout(400)
        after = page.evaluate('() => state.doc.formCount')
        audit.require(after == before + rows - 1,
                      f'{after - before} fields were added, not {rows - 1}')
        audit.require(audit.modal_title() is None, 'the Prepare Form dialog stayed open')
        page.screenshot(path=str(QA / 'audit-prepare-form.png'))
        # The steps after this one work on the report, and this step opened a
        # one-page form; put the report back rather than leaving them to guess.
        reopen_report()
    audit.run('Prepare Form finds the places to fill in and adds real fields', prepare_form_tool)


    # ---------------------------------------------------------- protect view
    def protect_panel():
        audit.open_view('protect')
        audit.require(not page.is_disabled('#protect-export'),
                      'protect-export is disabled on a document with an owner password')
        page.click('#protect-export')
        page.wait_for_timeout(2000)
        audit.require(audit.toasts() != '',
                      'exporting a protected copy with no password produced no message')
        audit.require(audit.modal_title() is None,
                      'exporting with no password should report an error, not open a dialog')

        audit.goto_page(1)
        # The error toast from the check above sits over the bottom of the
        # inspector, where this button is, so clear it before pressing.
        page.evaluate("document.querySelector('#toast-stack').innerHTML = ''")
        page.click('#start-redact')
        page.wait_for_timeout(400)
        audit.require(audit.tool() == 'redact',
                      f'start-redact did not switch to the redaction tool (active tool is '
                      f'{audit.tool()!r}, view {audit.view()!r}, panel: {audit.inspector()})')
        audit.require(page.is_disabled('#apply-redaction'),
                      'apply-redaction should stay disabled until an area is drawn')
        audit.drag_on_page()
        audit.require(not page.is_disabled('#apply-redaction'),
                      'apply-redaction stayed disabled after drawing an area')
        page.click('#apply-redaction')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require('Permanently redact' in (audit.modal_title() or ''),
                      'redaction did not warn before removing content')
        page.click('#confirm-action')
        page.wait_for_timeout(2000)
        audit.require(audit.toasts() != '', 'redaction produced no feedback')

    def protect_prompt():
        # The Protect tool must ASK for a password, not leave a form lying about.
        audit.open_view('protect')
        page.wait_for_timeout(700)
        page.click('[data-tool="secure"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Set a password.',
                      f'the Protect tool opened {audit.modal_title()!r} instead of a password prompt')
        audit.require(page.is_disabled('#protect-run'),
                      'the prompt offers to protect before a password has been typed')
        page.fill('#protect-open', 'abc')
        page.fill('#protect-confirm', 'abc')
        page.fill('#protect-owner', 'owner123')
        page.wait_for_timeout(250)
        audit.require('at least 6' in page.inner_text('#protect-error'),
                      f'a short password was not explained (said {page.inner_text("#protect-error")!r})')
        audit.require(page.is_disabled('#protect-run'), 'a short password left the button enabled')
        page.fill('#protect-open', 'secret123')
        page.fill('#protect-confirm', 'secret123')
        page.fill('#protect-owner', 'ownersecret123')
        page.wait_for_timeout(250)
        audit.require(not page.is_disabled('#protect-run'), 'a valid password left the button disabled')
        audit.require(page.inner_text('#protect-error').strip() == '',
                      'a valid password still shows an error')
        # The eye button, and the permission checkboxes the owner password guards.
        page.click('#protect-reveal')
        page.wait_for_timeout(250)
        audit.require(page.eval_on_selector('#protect-open', 'el => el.type') == 'text',
                      'the eye button did not reveal the password')
        page.click('#protect-reveal')
        page.wait_for_timeout(250)
        audit.require(page.eval_on_selector('#protect-open', 'el => el.type') == 'password',
                      'the eye button did not hide the password again')
        before = page.is_checked('#protect-allow-print')
        page.click('#protect-allow-print')
        page.wait_for_timeout(200)
        audit.require(page.is_checked('#protect-allow-print') != before,
                      'the printing permission checkbox does not change')
        page.click('#protect-allow-print')
        page.wait_for_timeout(200)
        audit.close_modal()
        audit.open_view('edit')
    audit.run('Protection asks for a password, and refuses a weak one', protect_prompt)

    def quiet_top_bar():
        audit.require(page.locator('.breadcrumb').count() == 0,
                      'the workspace breadcrumb is back in the top bar')
        audit.require(page.locator('.offline-badge').count() == 0,
                      'the offline badge is back in the top bar')
    audit.run('The top bar carries no workspace or offline label', quiet_top_bar)
    audit.run('Protection: password export validates, redaction warns and applies', protect_panel)

    # ---------------------------------------------------------- convert view
    def convert_panel():
        audit.open_view('convert')
        formats = page.locator('#inspector [data-format]')
        count = formats.count()
        audit.require(count >= 4, f'the convert panel offers only {count} formats')
        for index in range(count):
            formats.nth(index).click()
            page.wait_for_timeout(250)
            audit.require(page.locator('#convert-export').count() == 1,
                          'the export button disappeared when changing format')
            audit.require(not page.is_disabled('#convert-export'),
                          'the convert export button is disabled')
        page.click('#inspector [data-format="txt"]')
        page.wait_for_timeout(250)
        audit.require(page.locator('#convert-range').count() == 1, 'the page-range control is missing')
        page.select_option('#convert-range', 'custom')
        page.wait_for_timeout(250)
        audit.require(not page.is_hidden('#convert-custom-field'),
                      'choosing a custom range did not reveal the page box')
        audit.type_into(page.locator('#convert-custom'), '1')
        with page.expect_download(timeout=90000) as download:
            page.click('#convert-export')
        audit.require(download.value.suggested_filename != '', 'the converted file has no name')
        audit.require('exported' in audit.toasts().lower(), 'converting produced no confirmation')
    audit.run('Convert: every format, the page range, and a real export', convert_panel)

    # ---------------------------------------------------------- ocr view
    def ocr_panel():
        audit.open_view('ocr')
        audit.require(page.locator('#run-ocr').count() == 1, 'the OCR run button is missing')
        if page.is_disabled('#run-ocr'):
            audit.require(page.locator('#ocr-setup').count() == 1 or
                          page.inner_text('#inspector').strip() != '',
                          'OCR is unavailable but the panel explains nothing')
            if page.locator('#ocr-setup').count():
                page.click('#ocr-setup')
                audit.require(audit.modal_title() is not None, 'the OCR setup button did nothing')
        else:
            page.click('#run-ocr')
            page.wait_for_timeout(1500)
            audit.require(audit.toasts() != '' or audit.modal_title() is not None,
                          'running OCR produced no feedback')
    audit.run('The OCR panel reports its engine state and acts on it', ocr_panel)

    # ---------------------------------------------------------- document bar
    def export_dialog():
        audit.open_view('edit')
        page.click('#export-document')
        audit.require(audit.modal_title() == 'Ready for what’s next.', 'the export dialog did not open')
        formats = page.locator('#modal [data-format]')
        audit.require(formats.count() >= 3, 'the export dialog offers too few formats')
        for index in range(formats.count()):
            formats.nth(index).click()
            page.wait_for_timeout(150)
            audit.require(page.inner_text('#export-notice').strip() != '',
                          'changing export format left the notice empty')
        page.locator('#modal [data-format]').first.click()
        page.wait_for_timeout(200)
        with page.expect_download(timeout=60000) as download:
            page.click('#start-export')
        audit.require(download.value.suggested_filename.lower().endswith('.pdf'),
                      'the exported file is not a PDF')
        audit.require('exported' in audit.toasts().lower(), 'exporting produced no confirmation')
    audit.run('Export dialog: formats, notice, and a real PDF download', export_dialog)

    def share_dialog():
        page.click('#share-document')
        page.wait_for_timeout(1200)
        audit.require(audit.modal_title() == 'Send or share this PDF',
                      f'the share dialog did not open (got {audit.modal_title()!r})')
        for option in ['#share-email-attach', '#share-email-draft', '#share-copy', '#share-reveal']:
            audit.require(page.locator(option).count() == 1, f'{option} is missing from the share dialog')
            audit.require(not page.is_disabled(option), f'{option} is disabled')
        audit.require('share folder' in page.inner_text('#modal'), 'the share dialog lost its file note')
    audit.run('The share dialog opens with all four delivery options', share_dialog)

    def print_preview_with_a_file_only_default():
        # Force the "default printer saves to a file" case so the fallback path
        # is exercised even on a machine whose default printer can print.
        stubbed = {'desktop': True, 'printer': 'Audit PDF Writer', 'methods': {
            'print': False, 'printer': 'Audit PDF Writer', 'savesToFile': True, 'canPrint': True,
            'printers': [{'name': 'Audit PDF Writer', 'default': True, 'printable': False},
                         {'name': 'Audit Laser', 'default': False, 'printable': True}],
            'via': 'gdi', 'dpi': 200, 'note': 'stubbed'}}

        def handler(route):
            if route.request.method == 'GET':
                route.fulfill(status=200, content_type='application/json', body=json.dumps(stubbed))
            else:
                route.continue_()

        page.route('**/api/system/print', handler)
        page.click('#print-document')
        page.wait_for_timeout(600)
        audit.require(audit.modal_title() == 'Print preview',
                      f'the print preview did not open (got {audit.modal_title()!r})')
        # The driver that saves to a file is named and skipped rather than
        # offered and then failed.
        options = page.locator('#print-target option').all_inner_texts()
        audit.require(options == ['Audit Laser'],
                      f'the preview offers the wrong printers: {options}')
        audit.require('Audit PDF Writer' in page.inner_text('#modal'),
                      'the dialog does not say why the default printer was skipped')
        page.click('#print-export')
        audit.require(audit.modal_title() == 'Ready for what’s next.',
                      'the print preview export fallback did not open the export dialog')
        audit.close_modal()
        page.unroute('**/api/system/print')
    audit.run('Print preview names a file-only default printer and offers a real one', print_preview_with_a_file_only_default)

    def print_preview_shows_the_sheet():
        page.click('#print-document')
        page.wait_for_selector('#print-preview-image.ready', timeout=40000)
        width, height = page.evaluate("""() => {
            const image = document.querySelector('#print-preview-image');
            return [image.naturalWidth, image.naturalHeight];
        }""")
        audit.require(width > 200 and height > 200,
                      f'the preview image did not decode ({width}x{height})')
        audit.require(height > width, 'the preview is not a portrait sheet')
        label = page.inner_text('#print-page-label')
        audit.require(label.startswith('Page '), f'the page label is wrong: {label!r}')
        if audit.pages() > 1:
            page.click('#print-next-page')
            page.wait_for_timeout(900)
            audit.require(page.inner_text('#print-page-label') != label,
                          'the next-page button did not move the preview')
            page.click('#print-prev-page')
            page.wait_for_timeout(900)
            audit.require(page.inner_text('#print-page-label') == label,
                          'the previous-page button did not come back')
        audit.close_modal()
    audit.run('The print preview draws the sheet and its page buttons move it', print_preview_shows_the_sheet)

    def print_settings():
        page.click('#print-document')
        page.wait_for_selector('#print-preview-image.ready', timeout=40000)
        audit.require(page.locator('#print-range-mode').count() == 1,
                      'the print dialog has no page choice')
        audit.require(page.locator('#print-copies').count() == 1,
                      'the print dialog has no copy count')
        audit.require(page.locator('#print-properties').count() == 1,
                      'the print dialog has no printer settings button')
        total = audit.pages()
        expected = f'Print {total} page' + ('' if total == 1 else 's')
        audit.require(page.inner_text('#print-go').strip() == expected,
                      f'the button does not say how much will print '
                      f'({page.inner_text("#print-go")!r}, expected {expected!r})')
        page.select_option('#print-range-mode', 'current')
        page.wait_for_timeout(400)
        audit.require('Print 1 page' in page.inner_text('#print-go'),
                      'choosing the current page did not narrow the job')
        page.select_option('#print-range-mode', 'custom')
        page.wait_for_timeout(200)
        audit.type_into(page.locator('#print-range'), '1-2')
        page.wait_for_timeout(600)
        audit.require('Print 2 pages' in page.inner_text('#print-go'),
                      f'a range of two did not become two pages ({page.inner_text("#print-go")!r})')
        audit.type_into(page.locator('#print-range'), '99')
        page.wait_for_timeout(500)
        audit.require(page.is_disabled('#print-go'),
                      'a page outside the document did not disable Print')
        audit.require(page.inner_text('#print-range-error').strip() != '',
                      'an impossible range gives no reason')
        audit.type_into(page.locator('#print-range'), '1-2')
        page.wait_for_timeout(500)
        audit.require(not page.is_disabled('#print-go'), 'Print stayed disabled after a valid range')
        audit.require(page.is_disabled('#print-collate'),
                      'the order of copies is offered when there is only one copy')
        page.fill('#print-copies', '2')
        page.wait_for_timeout(300)
        audit.require(page.eval_on_selector('#print-copies', 'el => el.value') == '2',
                      'the copy count did not take the number')
        audit.require(not page.is_disabled('#print-collate'),
                      'the order of copies stayed disabled with two copies')
        audit.require('× 2 copies' in page.inner_text('#print-go'),
                      f'the button does not mention the copies ({page.inner_text("#print-go")!r})')
        # The range is 1-2 and there are two copies, so the two orders are
        # exactly "1, 2, 1, 2" and "1, 1, 2, 2".
        audit.require(page.inner_text('#print-collate-hint').strip() == '1, 2, 1, 2',
                      f'collated order reads {page.inner_text("#print-collate-hint")!r}')
        page.select_option('#print-collate', 'false')
        page.wait_for_timeout(300)
        audit.require(page.inner_text('#print-collate-hint').strip() == '1, 1, 2, 2',
                      f'uncollated order reads {page.inner_text("#print-collate-hint")!r}')
        page.select_option('#print-collate', 'true')
        page.wait_for_timeout(300)
        audit.require(page.inner_text('#print-collate-hint').strip() == '1, 2, 1, 2',
                      'choosing collated again did not restore the order')
        audit.close_modal()
    audit.run('The print dialog chooses pages, copies and the driver settings', print_settings)

    def print_direct():
        audit.require(audit.capture is not None, 'print capture was not configured')
        audit.capture.unlink(missing_ok=True)
        before = audit.pages()
        page.click('#print-document')
        page.wait_for_selector('#print-preview-image.ready', timeout=40000)
        page.click('#print-go')
        deadline = time.time() + 60
        while time.time() < deadline and 'Sent' not in audit.toasts():
            page.wait_for_timeout(500)
        text = audit.toasts()
        audit.require('Sent' in text,
                      f'printing from the preview produced no confirmation (toasts: {text!r}, '
                      f'dialog: {audit.modal_body()!r})')
        audit.require(audit.capture.exists() and audit.capture.stat().st_size > 5000,
                      'the print job never reached the print driver')
        import pymupdf as fitz
        with fitz.open(audit.capture) as printed:
            audit.require(len(printed) == before,
                          f'printed {len(printed)} pages, the document has {before}')
            # A print job is drawn as page images, so there is no text layer to
            # extract. Ink is the honest check: a blank sheet means the job
            # arrived empty even though the spooler accepted it.
            grey = printed[0].get_pixmap(dpi=40, colorspace=fitz.csGRAY)
            ink = sum(1 for byte in grey.samples if byte < 200)
            audit.require(ink > 500, f'the printed first page looks blank ({ink} dark pixels)')
    audit.run('Printing from the preview sends a real job and the pages match', print_direct)

    def print_paper_and_orientation():
        # The paper list comes from the driver, the choice is written into its
        # settings block, and the job that follows is on that paper — checked by
        # opening the captured job and measuring the sheet, not by trusting the
        # label under the select.
        import pymupdf as fitz
        page.click('#print-document')
        page.wait_for_selector('#print-preview-image.ready', timeout=40000)
        deadline = time.time() + 20
        while time.time() < deadline and page.locator('#print-paper option').count() <= 1:
            page.wait_for_timeout(300)
        options = page.eval_on_selector(
            '#print-paper', 'el => [...el.options].map(o => [o.value, o.textContent])')
        audit.require(len(options) > 1,
                      f'the paper list was never filled (it has {len(options)} entries)')
        audit.require(not page.is_disabled('#print-paper'), 'the paper list is disabled')
        audit.require(not page.is_disabled('#print-orientation'), 'the orientation is disabled')
        names = [name for _value, name in options]
        audit.require(any(name in names for name in ('A4', 'Letter')),
                      f'no ordinary paper size in the driver list: {names}')
        printer = page.input_value('#print-target')
        ids = {name: value for value, name in options}

        # The defaults the preview opens with: A4 paper, and an orientation that
        # follows the page rather than one that has to be set every time.
        deadline = time.time() + 20
        while time.time() < deadline and 'A4' not in page.inner_text('#print-settings-note'):
            page.wait_for_timeout(300)
        chosen_paper = page.eval_on_selector(
            '#print-paper', 'el => el.selectedOptions[0]?.textContent?.trim()')
        if 'A4' in ids:
            audit.require(chosen_paper == 'A4',
                          f'the paper did not default to A4 (it shows {chosen_paper!r})')
            audit.require('A4' in page.inner_text('#print-settings-note'),
                          f"the sheet is not A4 on opening ({page.inner_text('#print-settings-note')!r})")
        audit.require(page.evaluate("() => document.querySelector('#print-orientation').value") == 'auto',
                      'the orientation does not start on Auto')
        audit.require(page.locator('#print-duplex').count() == 1,
                      'there is no two-sided control in the print preview')

        def preview_size():
            return page.evaluate("""() => {
                const image = document.querySelector('#print-preview-image');
                return [image.naturalWidth, image.naturalHeight];
            }""")

        def wait_for_sheet(landscape):
            end = time.time() + 25
            while time.time() < end:
                width, height = preview_size()
                if (width > height) == landscape and min(width, height) > 200:
                    return width, height
                page.wait_for_timeout(400)
            return preview_size()

        if 'A4' in ids:
            page.select_option('#print-paper', ids['A4'])
            end = time.time() + 20
            while time.time() < end and 'A4' not in page.inner_text('#print-settings-note'):
                page.wait_for_timeout(300)
            audit.require('A4' in page.inner_text('#print-settings-note'),
                          f"choosing A4 was not confirmed "
                          f"({page.inner_text('#print-settings-note')!r})")

        page.select_option('#print-orientation', 'landscape')
        width, height = wait_for_sheet(True)
        audit.require(width > height, f'the sheet did not turn to landscape ({width}x{height})')
        note = page.inner_text('#print-settings-note')
        audit.require('landscape' in note, f'the note still says {note!r}')

        # The job itself, on that paper.
        audit.capture.unlink(missing_ok=True)
        page.click('#print-go')
        deadline = time.time() + 60
        while time.time() < deadline and 'Sent' not in audit.toasts():
            page.wait_for_timeout(500)
        audit.require('Sent' in audit.toasts(), 'printing on the chosen paper produced no confirmation')
        deadline = time.time() + 30
        while time.time() < deadline and not audit.capture.exists():
            page.wait_for_timeout(300)
        audit.require(audit.capture.exists(), 'the job never reached the print driver')
        with fitz.open(audit.capture) as printed:
            sheet = printed[0].rect
        audit.require(sheet.width > sheet.height,
                      f'the printed sheet is not landscape ({sheet.width:.0f}x{sheet.height:.0f})')
        if 'A4' in ids:
            audit.require(abs(sheet.width - 842) < 12 and abs(sheet.height - 595) < 12,
                          f'the job is not on A4 landscape ({sheet.width:.0f}x{sheet.height:.0f})')

        # Put the printer back the way it was found, through the same endpoint
        # the interface uses, so the steps after this see a portrait sheet.
        page.evaluate("""async (printer) => {
            await api('/system/print/settings', {method: 'POST',
                json: {printer, paper: null, orientation: 'portrait'}});
        }""", printer)
    audit.run('The print preview sets the paper size and the orientation',
              print_paper_and_orientation)

    def open_file():
        with page.expect_file_chooser() as chooser:
            page.click('#open-document')
        chooser.value.set_files(str(QA / 'merge-fixture.pdf'))
        # No confirmation here any more: opening a document no longer closes the
        # one before it, so there is nothing to warn about.
        page.wait_for_timeout(2800)
        audit.require('merge-fixture' in page.inner_text('#document-name'),
                      'the chosen file did not become the open document')
    audit.run('Open file loads the chosen PDF', open_file)

    def new_document():
        page.click('#new-document')
        page.wait_for_selector('#modal[open]', timeout=15000)
        audit.require(audit.modal_title() == 'A fresh page.',
                      f'the new-document dialog did not open (got {audit.modal_title()!r})')
        audit.type_into(page.locator('#new-document-name'), 'Audit Blank.pdf')
        page.click('#create-document')
        page.wait_for_timeout(2000)
        audit.require(audit.pages() == 1, f'a new document should have one page, got {audit.pages()}')
        audit.require('Audit Blank' in page.inner_text('#document-name'),
                      'the new document did not take the chosen name')
        audit.require(audit.view() == 'edit', 'a new document did not open in the editor')
    audit.run('New document creates a named blank one-page PDF', new_document)

    def modal_close_button():
        page.click('#help-button')
        audit.require(page.is_visible('#modal'), 'no dialog to close')
        page.click('#modal [data-close]')
        page.wait_for_timeout(150)
        audit.require(not page.is_visible('#modal'), 'the dialog close button did not close it')
        page.click('#help-button')
        page.keyboard.press('Escape')
        page.wait_for_timeout(150)
        audit.require(not page.is_visible('#modal'), 'Escape did not close the dialog')
    audit.run('Dialog close button and Escape both close a dialog', modal_close_button)

    # ------------------------------------------------- the right-hand tools panel
    def panel_pin():
        audit.require(page.is_visible('#inspector'), 'the tools panel is not open to start with')
        audit.require(not page.is_visible('#inspector-tab'), 'the rail tab shows while the panel is pinned')
        canvas_pinned = page.locator('.canvas-area').bounding_box()['width']

        page.click('#inspector-pin')
        page.mouse.move(700, 500)
        page.wait_for_timeout(500)
        audit.require(not page.is_visible('#inspector'), 'unpinning did not hide the panel')
        audit.require(page.is_visible('#inspector-tab'), 'the rail tab did not appear')
        audit.require(page.get_attribute('#inspector-pin', 'aria-pressed') == 'false',
                      'the pin still reports pressed after unpinning')
        canvas_auto = page.locator('.canvas-area').bounding_box()['width']
        audit.require(canvas_auto > canvas_pinned,
                      f'the canvas did not gain the space ({canvas_pinned} -> {canvas_auto})')

        page.hover('#inspector-rail')
        page.wait_for_timeout(400)
        audit.require(page.is_visible('#inspector'), 'hovering the rail did not reveal the panel')
        panel_box = page.locator('#inspector').bounding_box()
        rail_box = page.locator('#inspector-rail').bounding_box()
        # The rail is in the left column now, so the revealed panel opens to its
        # right — over the canvas, which is the whole point of floating it.
        audit.require(panel_box and rail_box and panel_box['x'] >= rail_box['x'] + rail_box['width'] - 1,
                      'the revealed panel did not sit beside the rail')
        audit.require(page.locator('.canvas-area').bounding_box()['width'] == canvas_auto,
                      'revealing the panel pushed the canvas sideways')
        audit.require(page.is_visible('#inspector-pin'), 'the pin is unreachable on the revealed panel')

        page.mouse.move(700, 500)
        page.wait_for_timeout(400)
        audit.require(not page.is_visible('#inspector'), 'the panel stayed out after the pointer left')

        page.click('#inspector-tab')
        page.mouse.move(700, 500)
        page.wait_for_timeout(400)
        audit.require(page.is_visible('#inspector'), 'the rail tab did not hold the panel open')

        page.hover('#inspector-rail')
        page.click('#inspector-pin')
        page.mouse.move(700, 500)
        page.wait_for_timeout(400)
        audit.require(page.is_visible('#inspector'), 'pinning again did not keep the panel open')
        audit.require(not page.is_visible('#inspector-tab'), 'the rail tab survived re-pinning')
    audit.run('The tools panel pins open, auto-hides, and the rail brings it back', panel_pin)

    def menu_bar_and_panels():
        # This step is about the panels giving the page its room, which is a
        # property of fit-width. 150% is the default now, so fit is chosen here.
        page.select_option('#zoom-select', 'fit')
        page.wait_for_timeout(700)
        # A known starting layout: the thumbnails away, the tools open.
        if page.locator('#pages-panel').is_visible():
            page.click('#toggle-thumbnails')
            page.wait_for_timeout(400)
        if page.locator('#inspector-rail').is_hidden():
            page.click('#toggle-tools')
            page.wait_for_timeout(400)

        audit.require(page.locator('.nav-rail').count() == 0, 'the old left rail is still there')
        bar = page.locator('#menu-bar').bounding_box()
        audit.require(bar and bar['y'] < 130 and bar['width'] > 1200,
                      f'the menu bar is not across the top: {bar}')
        audit.require(page.locator('#menu-bar #navigation .nav-item').count() == 9,
                      'the view tabs are not all in the menu bar')
        audit.require(page.locator('#pages-panel').is_hidden(),
                      'the page thumbnails start on screen, taking width the page wants')

        def page_width():
            return page.locator('#paper').bounding_box()['width']

        def canvas_width():
            return page.locator('.canvas-area').bounding_box()['width']

        def fills(what):
            return page_width() / canvas_width() > .85

        audit.require(fills('start'), 'the page does not fill the width it has '
                      f'({page_width():.0f} of {canvas_width():.0f})')
        # The tool list on the right is on by default. Put it away first: with
        # everything put away nothing sits beside the page, which is the promise
        # this measures. Then bring it back and measure that it costs the page
        # exactly its own width.
        page.click('#toggle-rail')
        page.wait_for_timeout(600)
        audit.require(page.locator('#tool-rail').is_hidden(), 'the tool list could not be put away')
        viewport = page.evaluate('window.innerWidth')
        canvas = page.locator('.canvas-area').bounding_box()
        audit.require(canvas['x'] + canvas['width'] >= viewport - 2,
                      f'something is still to the right of the page (it ends at '
                      f"{canvas['x'] + canvas['width']} of {viewport})")
        bare = page_width()
        page.click('#toggle-rail')
        page.wait_for_timeout(800)
        rail_box = page.locator('#tool-rail').bounding_box()
        canvas = page.locator('.canvas-area').bounding_box()
        audit.require(rail_box and rail_box['x'] + rail_box['width'] >= viewport - 2,
                      f'the tool list is not at the right edge: {rail_box}')
        audit.require(canvas['x'] + canvas['width'] <= rail_box['x'] + 2,
                      'the page area runs underneath the tool list')
        audit.require(page_width() < bare - 20,
                      f'showing the tool list did not give the page less room '
                      f'({bare:.0f} -> {page_width():.0f})')

        alone = page_width()
        page.click('#toggle-thumbnails')
        page.wait_for_timeout(700)
        audit.require(page.locator('#pages-panel').is_visible(), 'the thumbnails toggle did nothing')
        audit.require(page_width() < alone,
                      f'showing a panel did not give the page less room ({alone:.0f} -> {page_width():.0f})')
        # Everything is still on one side of the page.
        thumb = page.locator('.pages-panel').bounding_box()
        rail = page.locator('#inspector-rail').bounding_box()
        canvas = page.locator('.canvas-area').bounding_box()
        audit.require(thumb['x'] + thumb['width'] <= rail['x'] + 1,
                      'the tools panel is not beside the thumbnails')
        audit.require(rail['x'] + rail['width'] <= canvas['x'] + 1,
                      'the tools panel is not left of the page')
        page.click('#toggle-thumbnails')
        page.wait_for_timeout(700)
        audit.require(abs(page_width() - alone) < 3, 'hiding the thumbnails did not give the room back')

        page.click('#toggle-tools')
        page.wait_for_timeout(800)
        audit.require(page.locator('#inspector-rail').is_hidden(), 'the tools toggle did nothing')
        focused = page_width()
        audit.require(focused > alone,
                      f'hiding the tools did not enlarge the page ({alone:.0f} -> {focused:.0f})')
        audit.require(fills('focused'), 'the page still does not fill the window')
        # Zoom keeps the last word over the fit.
        page.select_option('#zoom-select', '0.5')
        page.wait_for_timeout(800)
        audit.require(page_width() < focused * .7, 'the zoom control was ignored')
        page.select_option('#zoom-select', 'fit')
        page.wait_for_timeout(1200)
        audit.require(abs(page_width() - focused) < 5, 'fit width did not come back')

        page.click('#toggle-focus')
        page.wait_for_timeout(800)
        audit.require(page.locator('#tool-rail').is_hidden(), 'focus left the tool list on screen')
        audit.require(page.locator('#inspector-rail').is_hidden(), 'focus left the tools panel on screen')
        page.click('#toggle-focus')
        page.wait_for_timeout(800)
        audit.require(page.locator('#inspector-rail').is_visible(), 'focus did not bring the tools back')
        audit.require(page.locator('#tool-rail').is_visible(), 'focus did not bring the tool list back')
        audit.require(abs(page_width() - alone) < 5, 'the page did not return to its earlier size')

        page.click('#menu-collapse')
        page.wait_for_timeout(600)
        collapsed = page.locator('#menu-bar').bounding_box()['height']
        audit.require(collapsed < bar['height'],
                      f"the menu bar did not collapse ({bar['height']} -> {collapsed})")
        audit.require(page.locator('#navigation .nav-item').first.is_hidden(), 'the tabs stayed behind')
        page.click('#menu-collapse')
        page.wait_for_timeout(600)
        audit.require(abs(page.locator('#menu-bar').bounding_box()['height'] - bar['height']) < 1,
                      'the menu bar did not come back')
    audit.run('The menu bar runs across the top, and the panels give the page its room',
              menu_bar_and_panels)

    # ---------------------------------------------------------------- AI reading
    def ai_offline_reading():
        # The steps before this one leave blank documents open, and a blank page
        # has nothing to read. The report comes back, which is the document
        # somebody would try this on first.
        reopen_report()
        audit.open_view('ai')
        audit.require(page.is_visible('#ai-summarise'), 'the AI panel did not open')
        audit.require('Offline reading' in page.inner_text('#inspector'),
                      'the panel does not say it is reading offline')
        audit.require('Nothing is sent anywhere' in page.inner_text('#inspector'),
                      'the panel does not say that nothing is sent')
        page.click('#ai-summarise')
        page.wait_for_timeout(2500)
        audit.require(page.locator('.ai-result').count() == 1, 'no summary appeared')
        # innerText returns the upper-cased rendering, so compare without case.
        tag = page.inner_text('.ai-tag').strip().lower()
        audit.require(tag == 'offline', f'the result is not tagged as the offline reading: {tag!r}')
        audit.require('quoted as they stand' in page.inner_text('.ai-result'),
                      'the result does not say that it is quoted')
        audit.require(page.locator('.ai-keywords span').count() > 0, 'no keywords were listed')
    audit.run('The offline reading summarises the document and says that it is quoting it',
              ai_offline_reading)

    def ai_prompt_to_form():
        audit.open_view('ai')
        audit.type_into(page.locator('#ai-prompt'), 'full name, email, date signed and a checkbox to agree')
        page.click('#ai-propose')
        page.wait_for_timeout(2000)
        rows = page.locator('.ai-field')
        audit.require(rows.count() == 4, f'four fields were asked for, {rows.count()} proposed')
        audit.require('date field' in page.inner_text('.ai-fields'),
                      'the date field was not recognised as one')
        before = audit.pages()
        page.click('#ai-add-fields')
        page.wait_for_timeout(2800)
        audit.require(audit.pages() == before + 1,
                      f'a new page was not added ({before} -> {audit.pages()})')
        audit.require(audit.page_number_is_last(), 'the new page was not brought into view')
        labels = page.evaluate("async () => { const response = await fetch('/api/documents/' + state.doc.id + '/pages/' + state.page + '/content'); return (await response.json()).widgets.map(w => w.label); }")
        audit.require(labels == ['Full name', 'Email', 'Date signed', 'Agree'],
                      f'the fields are not real PDF fields: {labels}')
    audit.run('A prompt becomes real PDF fields on a new page', ai_prompt_to_form)

    def ai_model_is_opt_in():
        page.click('#ai-connect')
        page.wait_for_timeout(400)
        audit.require('can leave your computer' in audit.modal_body(600),
                      'the connect dialog does not say what leaves the device')
        page.fill('#ai-endpoint', 'http://127.0.0.1:9/v1')
        page.fill('#ai-model', 'nothing-is-listening')
        page.click('#ai-save')
        page.wait_for_timeout(1200)
        audit.require('Model connected' in page.inner_text('#inspector'),
                      'the panel did not report the model as connected')
        # Nothing is sent without an answer, and the answer here is no.
        page.click('#ai-summarise')
        page.wait_for_timeout(700)
        audit.require(page.is_visible('#confirm-action'),
                      'the model was used without asking first')
        page.click('#modal [data-close]')
        page.wait_for_timeout(300)
        page.click('#ai-connect')
        page.wait_for_timeout(400)
        page.click('#ai-disconnect')
        page.wait_for_timeout(1200)
        audit.require('Offline reading' in page.inner_text('#inspector'),
                      'disconnecting did not return to the offline reading')
    audit.run('A model is opt-in, asks before sending anything, and can be disconnected',
              ai_model_is_opt_in)

    # -------------------------------------------------- documents left open
    def open_document_switcher():
        limit = page.evaluate("async () => (await (await fetch('/api/health')).json()).maxDocuments")
        before = page.evaluate("async () => (await (await fetch('/api/documents')).json()).documents.length")
        was_open = page.evaluate('state.doc.id')
        with page.expect_file_chooser() as chooser:
            page.click('#open-document')
        chooser.value.set_files(str(QA / 'merge-pair.pdf'))
        page.wait_for_timeout(3200)
        docs = page.evaluate("async () => (await (await fetch('/api/documents')).json()).documents")
        after, ids = len(docs), [d['id'] for d in docs]
        # The workspace holds a fixed number of documents. Opening one adds it,
        # and once the cap is reached the oldest closes instead — so the count
        # can legitimately stay the same, which is why this checks which
        # documents are open rather than only how many.
        audit.require(after == min(before + 1, limit),
                      f'the workspace holds {after} documents, expected {min(before + 1, limit)}')
        audit.require(page.evaluate('state.doc.id') in ids, 'the document just opened is not open')
        if before < limit:
            audit.require(was_open in ids, 'opening a document closed one it should have kept')
        audit.require(page.is_visible('#doc-switcher'), 'the switcher did not appear with two documents open')
        audit.require(page.inner_text('#doc-switcher-count') == str(after),
                      f'the switcher says {page.inner_text("#doc-switcher-count")} of {after}')
        audit.require(page.is_visible('#doc-switcher'), 'the switcher is not showing')
        page.click('#doc-switcher')
        page.wait_for_timeout(300)
        audit.require(page.locator('.doc-menu-row').count() == after,
                      'the switcher menu does not list every open document')
        audit.require(page.locator('.doc-menu-row.current').count() == 1,
                      'the switcher menu does not mark the current document')
    audit.run('Opening a document keeps the previous one, and the switcher lists them', open_document_switcher)

    def merge_an_open_document():
        page.keyboard.press('Escape')          # put the switcher menu away
        page.wait_for_timeout(200)
        page.click('#merge-document')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.wait_for_timeout(1300)
        audit.require('Already open in KADOMA' in audit.modal_body(700),
                      'the merge window does not offer the documents already open')
        audit.require(page.locator('.merge-open-row').count() >= 2,
                      'fewer than two open documents were listed')
        audit.require(page.locator('.merge-open-row.current button[data-merge-doc]').is_disabled(),
                      'the document being merged into could be added to itself')
        before = audit.pages()
        page.locator('.merge-open-row:not(.current) button[data-merge-doc]').first.click()
        page.wait_for_timeout(400)
        audit.require(page.locator('.merge-row').count() == 1, 'the open document did not join the list')
        audit.require('already open' in page.locator('.merge-row').first.inner_text(),
                      'the row does not say the source is already open')
        audit.require('source' in page.inner_text('#merge-summary'),
                      f'the summary still calls it a file: {page.inner_text("#merge-summary")!r}')
        page.click('#merge-run')
        page.wait_for_timeout(2800)
        audit.require(audit.pages() > before,
                      f'combining an open document added no pages ({before} -> {audit.pages()})')
    audit.run('An open document can be combined without being chosen from disk', merge_an_open_document)

    def switch_and_close_documents():
        page.click('#doc-switcher')
        page.wait_for_timeout(300)
        target = page.locator('.doc-menu-row:not(.current) .doc-menu-open').first
        name = target.inner_text().split('\n')[0]
        target.click()
        page.wait_for_timeout(2800)
        audit.require(name in page.inner_text('#document-name'),
                      f'switching to {name!r} landed on {page.inner_text("#document-name")!r}')
        page.click('#doc-switcher')
        page.wait_for_timeout(300)
        count = page.locator('.doc-menu-row').count()
        page.locator('.doc-menu-row:not(.current) .doc-menu-close').first.click()
        page.wait_for_timeout(2000)
        remaining = page.evaluate("async () => (await (await fetch('/api/documents')).json()).documents.length")
        audit.require(remaining == count - 1,
                      f'closing a document left {remaining} of {count} open')
        page.keyboard.press('Escape')
        page.wait_for_timeout(200)
    audit.run('Open documents can be switched between and closed from the switcher', switch_and_close_documents)

    def opens_in_reading_view():
        # A fresh load: this is what somebody sees when they open a PDF.
        page.evaluate("() => localStorage.setItem('kadoma.theme', 'light')")
        reopen_report()
        page.wait_for_timeout(400)
        audit.require(page.evaluate('() => state.tool') == 'view',
                      f"a document did not open in the reading view (tool={page.evaluate('() => state.tool')})")
        audit.require(page.evaluate(
            "() => document.querySelector('.tool-button.active')?.dataset.tool") == 'view',
            'the toolbar does not show the reading tool as active')
        audit.require(page.locator('#page-overlay .text-hit').count() == 0,
                      'the reading view is covered in edit boxes')
        audit.require('Reading view' in page.inner_text('#inspector'),
                      'the panel does not say it is the reading view')
        # Editing is still one press away, and Escape comes back.
        page.click('[data-tool="edit"]')
        page.wait_for_timeout(500)
        audit.require(page.locator('#page-overlay .text-hit').count() > 0,
                      'Edit text no longer arms the text boxes')
        page.keyboard.press('Escape')
        page.wait_for_timeout(400)
        audit.require(page.evaluate('() => state.tool') == 'view',
                      'Escape did not return to the reading view')
    audit.run('A document opens in the reading view, with editing one press away', opens_in_reading_view)

    def theme_toggle():
        page.click('#theme-button')
        page.wait_for_timeout(400)
        audit.require(page.evaluate("() => document.documentElement.dataset.theme") == 'dark',
                      'the theme button did not switch to dark')
        body = page.evaluate("() => getComputedStyle(document.body).backgroundColor")
        audit.require(body == 'rgb(14, 15, 21)', f'the window did not turn dark ({body})')
        paper = page.evaluate("() => getComputedStyle(document.querySelector('#paper')).backgroundColor")
        audit.require(paper == 'rgb(255, 255, 255)', 'the page itself was darkened, which no printer would do')
        # The choice is remembered across a reload — the one thing stored.
        reopen_report(land=False)
        audit.require(page.evaluate("() => document.documentElement.dataset.theme") == 'dark',
                      'the theme was forgotten on reload')
        page.click('#theme-button')
        page.wait_for_timeout(400)
        audit.require(page.evaluate("() => document.documentElement.dataset.theme") == 'light',
                      'the theme button did not switch back to light')
        body = page.evaluate("() => getComputedStyle(document.body).backgroundColor")
        audit.require(body == 'rgb(241, 242, 246)', f'the window did not turn light again ({body})')
    audit.run('The theme toggles, the paper stays paper, and the choice is remembered', theme_toggle)

    def compact_chrome():
        audit.open_view('edit')
        page.wait_for_timeout(400)
        heights = page.evaluate("""() => {
            const h = sel => { const el = document.querySelector(sel);
                return el && !el.hidden ? Math.round(el.getBoundingClientRect().height) : 0; };
            return {top: h('.topbar'), menu: h('#menu-bar'), doc: h('.document-bar'),
                    tabs: h('#document-tabs'), bar: h('.toolbar'), status: h('.statusbar'),
                    canvas: h('.canvas-area')};
        }""")
        chrome = (heights['top'] + heights['menu'] + heights['doc'] + heights['tabs']
                  + heights['bar'] + heights['status'])
        audit.require(chrome <= 265, f'the bars take {chrome}px of the window: {heights}')
        window = page.evaluate('() => window.innerHeight')
        audit.require(heights['canvas'] >= window - chrome - 1,
                      f"the page area is smaller than the window allows ({heights['canvas']} of {window - chrome})")
        # The document bar is icons now; Save keeps its word.
        audit.require(page.locator('#save-document .button-label').is_visible(),
                      'Save lost its label')
        audit.require(page.locator('#merge-document .button-label').is_hidden(),
                      'the document bar is still wordy')
        for button in ('#open-document', '#merge-document', '#split-document', '#share-document',
                       '#print-document', '#clear-fields', '#export-document', '#save-as-document'):
            audit.require(page.locator(button).get_attribute('title'), f'{button} has no tooltip')
    audit.run('The chrome is compressed and the page gets the room', compact_chrome)

    # ------------------------------------------------------- scans and dates
    # A page that is a picture of text cannot be clicked into. The two ways in
    # are checked here: drag a box over the words, and stamp a date on top.
    def scan_drag_edit():
        import pymupdf as mupdf
        source = mupdf.open()
        sheet = source.new_page(width=595, height=842)
        sheet.draw_rect(sheet.rect, color=None, fill=(0.9, 0.9, 0.88))
        sheet.insert_text((60, 120), 'OLD WORDS HERE', fontsize=24)
        png = sheet.get_pixmap(dpi=120).tobytes('png')
        source.close()
        scan = mupdf.open()
        page_image = scan.new_page(width=595, height=842)
        page_image.insert_image(mupdf.Rect(0, 0, 595, 842), stream=png)
        fixture = QA / 'audit-scan.pdf'
        scan.save(fixture)
        scan.close()

        page.locator('#file-input').set_input_files(str(fixture))
        page.wait_for_timeout(4000)
        if page.locator('#modal').is_visible():
            page.click('#confirm-action')
            page.wait_for_timeout(3000)
        audit.open_view('edit')
        page.wait_for_timeout(900)
        audit.require(page.evaluate('() => (state.content?.spans||[]).length') == 0,
                      'the audit fixture has a text layer, so it is not a scan')
        page.click('[data-tool="edit"]')
        page.wait_for_timeout(700)
        audit.require(page.locator('.scan-banner').count() == 1,
                      'a page with no text layer did not say so')
        audit.require('draw-cursor' in page.eval_on_selector('#page-overlay', 'el => el.className'),
                      'the text tool did not switch to drawing on a page with no text')

        box = page.evaluate("""() => {
            const r = document.querySelector('#pdf-page').getBoundingClientRect();
            const p = state.doc.pages[state.page];
            const at = (x, y) => [r.left + x / p.width * r.width, r.top + y / p.height * r.height];
            return {a: at(56, 96), b: at(300, 126)};
        }""")
        page.mouse.move(*box['a'])
        page.mouse.down()
        page.mouse.move(*box['b'], steps=6)
        page.mouse.up()
        page.wait_for_timeout(700)
        audit.require(page.evaluate('() => state.selection?.scan') is True,
                      'dragging on a scan did not make a scan selection')
        audit.require('Scan selection' in page.inner_text('.selected-tag'),
                      f'the panel does not say what was selected ({page.inner_text(".selected-tag")!r})')

        page.fill('#edit-text-value', 'NEW WORDS')
        page.click('#apply-text')
        deadline = time.time() + 40
        while time.time() < deadline and page.evaluate('() => (state.content?.spans||[]).length') == 0:
            page.wait_for_timeout(300)
        spans = page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")')
        audit.require('NEW WORDS' in spans,
                      f'the replacement is not in the page as text (spans: {spans!r})')
        page.screenshot(path=str(QA / 'audit-scan-edited.png'))
    audit.run('A scan is edited by dragging over the words', scan_drag_edit)

    def date_is_written_into_the_page():
        page.click('[data-tool="date"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Place a date.',
                      f'the Date tool opened {audit.modal_title()!r}')
        # A calendar inside a dialog has to be clickable: a popover attached to
        # <body> sits behind the dialog and swallows every press.
        page.click('[data-calendar="date-value"]')
        page.wait_for_selector('.calendar', timeout=5000)
        page.locator('.calendar [data-day="15"]').first.click()
        page.wait_for_timeout(400)
        picked = page.eval_on_selector('#date-value', 'el => el.value')
        audit.require(picked.endswith('-15'), f'picking a day did not set the date ({picked!r})')

        page.select_option('#date-format', 'DD/MM/YYYY')
        page.wait_for_timeout(300)
        switched = page.eval_on_selector('#date-value', 'el => el.value')
        audit.require(switched.endswith('/15') or switched.startswith('15/'),
                      f'changing the format lost the date ({switched!r})')

        page.fill('#date-value', '31/02/2026')
        page.wait_for_timeout(300)
        audit.require(page.is_disabled('#date-place'),
                      'an impossible date left the Place button enabled')
        audit.require('not a date' in page.inner_text('#date-error'),
                      f'an impossible date gave no reason ({page.inner_text("#date-error")!r})')

        page.fill('#date-value', '15/03/2026')
        page.wait_for_timeout(300)
        audit.require(not page.is_disabled('#date-place'), 'a valid date left the button disabled')
        page.click('#date-place')
        page.wait_for_timeout(500)
        audit.require(page.evaluate('() => state.tool') == 'date',
                      'placing a date did not arm the date tool')
        audit.require('15/03/2026' in page.inner_text('#tool-hint'),
                      f'the hint does not say what will be placed ({page.inner_text("#tool-hint")!r})')

        point = page.evaluate("""() => {
            const r = document.querySelector('#pdf-page').getBoundingClientRect();
            const p = state.doc.pages[state.page];
            return [r.left + 60 / p.width * r.width, r.top + 300 / p.height * r.height];
        }""")
        page.mouse.click(*point)
        deadline = time.time() + 40
        while time.time() < deadline and 'placed' not in audit.toasts():
            page.wait_for_timeout(300)
        spans = page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")')
        audit.require('15/03/2026' in spans,
                      f'the date is not in the page as text (spans: {spans!r})')
        audit.open_view('edit')
        page.screenshot(path=str(QA / 'audit-date-placed.png'))
    audit.run('A chosen date is written into the page as selectable text', date_is_written_into_the_page)

    # ------------------------------------------------------- document tools
    def document_tools():
        # Watermark, numbering, crop, bookmarks, compression and attachments:
        # each one is asserted by what ends up in the document, not by a toast.
        audit.open_view('document')
        page.wait_for_timeout(900)
        audit.require(page.locator('.doc-tool').count() == 9,
                      f"the Document view lists {page.locator('.doc-tool').count()} tools, expected 9")
        audit.require(page.locator('#context-tools [data-tool]').count() == 9,
                      'the Document toolbar does not carry the same nine tools')

        # ---- watermark
        page.click('[data-doc-tool="watermark"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Mark every page.',
                      f'the watermark dialog opened {audit.modal_title()!r}')
        page.fill('#wm-text', 'AUDITMARK')
        page.fill('#wm-opacity', '0.2')
        page.click('#wm-run')
        deadline = time.time() + 40
        while time.time() < deadline and 'AUDITMARK' not in page.evaluate(
                '() => (state.content?.spans||[]).map(s => s.text).join(" ")'):
            page.wait_for_timeout(300)
        audit.require('AUDITMARK' in page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")'),
                      'the watermark is not in the page as text')

        # ---- header and footer
        # The tokens are the point of this tool: {page} and {pages} have to
        # become numbers, or the footer is a caption rather than a page number.
        page.click('[data-doc-tool="header_footer"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Set the margins to work.',
                      f'the header/footer dialog opened {audit.modal_title()!r}')
        page.fill('#hf-hl', 'AUDIT HEADER')
        page.fill('#hf-fr', 'Page {page} of {pages}')
        page.click('#hf-run')
        deadline = time.time() + 40
        while time.time() < deadline and 'Page 1 of' not in page.evaluate(
                '() => (state.content?.spans||[]).map(s => s.text).join(" ")'):
            page.wait_for_timeout(300)
        footer = page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")')
        audit.require('Page 1 of' in footer,
                      f'the footer tokens did not become a page number (spans: {footer[:200]!r})')
        audit.require('AUDIT HEADER' in footer, 'the header text is not on the page')

        # ---- Bates numbering
        page.click('[data-doc-tool="numbering"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.select_option('#num-mode', 'bates')
        page.fill('#num-prefix', 'AUD-')
        page.click('#num-run')
        deadline = time.time() + 40
        while time.time() < deadline and 'AUD-000001' not in page.evaluate(
                '() => (state.content?.spans||[]).map(s => s.text).join(" ")'):
            page.wait_for_timeout(300)
        audit.require('AUD-000001' in page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")'),
                      'the Bates number is not in the page')

        # ---- crop
        width_before = page.evaluate('() => state.doc.pages[0].width')
        page.click('[data-doc-tool="crop"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.click('#crop-run')
        deadline = time.time() + 40
        while time.time() < deadline and page.evaluate('() => state.doc.pages[0].width') >= width_before:
            page.wait_for_timeout(300)
        audit.require(page.evaluate('() => state.doc.pages[0].width') < width_before,
                      'cropping did not change the page box')

        # ---- bookmarks
        page.click('[data-doc-tool="bookmarks"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.click('#bookmark-auto')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('.list-row').count() == 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('.list-row').count() > 0,
                      'generating bookmarks found none in a document with headings')
        audit.require('AUDITMARK' not in page.inner_text('#bookmark-list'),
                      'the watermark became a bookmark')
        # A bookmark added by hand, and then all of them removed: the two buttons
        # that are not "generate" and were never pressed by this audit.
        page.fill('#bookmark-title', 'Audit bookmark')
        page.fill('#bookmark-page', '2')
        page.click('#bookmark-add')
        deadline = time.time() + 40
        while time.time() < deadline and 'Audit bookmark' not in page.inner_text('#bookmark-list'):
            page.wait_for_timeout(300)
        audit.require('Audit bookmark' in page.inner_text('#bookmark-list'),
                      'a bookmark added by hand is not in the list')
        page.click('#bookmark-clear')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('#bookmark-list .list-row').count() > 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('#bookmark-list .list-row').count() == 0,
                      'Remove all left bookmarks behind')
        page.click('[data-close]')
        page.wait_for_timeout(400)

        # ---- attachments
        attachment = QA / 'audit-attachment.csv'
        attachment.write_text('column,value\nrevenue,284750\n', encoding='utf-8')
        page.click('[data-doc-tool="attachments"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.set_input_files('#attach-file', str(attachment))
        page.fill('#attach-desc', 'Audit figures')
        page.click('#attach-run')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('.list-row').count() == 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('.list-row').count() == 1,
                      'the attachment did not appear in the list')
        audit.require('audit-attachment.csv' in page.inner_text('#attachment-list'),
                      'the attachment is listed under the wrong name')
        page.click('[data-attach-del]')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('.list-row').count() > 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('.list-row').count() == 0,
                      'the attachment could not be removed')
        page.click('[data-close]')
        page.wait_for_timeout(400)

        # ---- compression
        page.click('[data-doc-tool="compress"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        page.click('#compress-run')
        deadline = time.time() + 60
        while time.time() < deadline and 'Smaller' not in audit.toasts() and 'lean' not in audit.toasts():
            page.wait_for_timeout(400)
        audit.require('Smaller' in audit.toasts() or 'lean' in audit.toasts(),
                      f'compression reported nothing usable (toasts: {audit.toasts()!r})')
        page.screenshot(path=str(QA / 'audit-document-tools.png'))
        audit.open_view('edit')
    audit.run('Watermark, numbering, crop, bookmarks, attachments and compression all work', document_tools)

    def stamps_links_size_and_compare():
        # The four tools that close the gap with Acrobat Pro: a stamp placed by
        # clicking, a link drawn over an area, a new paper size, and a word-level
        # comparison against a second document.
        audit.open_view('document')
        page.wait_for_timeout(800)
        audit.require(page.locator('.doc-tool').count() == 9,
                      f"the Document view lists {page.locator('.doc-tool').count()} tools, expected 9")
        # The stamp and the link live on the editing toolbar, because both are
        # placed by clicking or dragging on the page rather than by filling in a
        # dialog and pressing a button.
        audit.open_view('edit')
        page.wait_for_timeout(600)
        audit.require(page.locator('#context-tools [data-tool="stamp"]').count() == 1,
                      'the editing toolbar has no stamp button')
        audit.require(page.locator('#context-tools [data-tool="link"]').count() == 1,
                      'the editing toolbar has no link button')

        # ---- stamp
        page.click('#context-tools [data-tool="stamp"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Mark the document.',
                      f'the stamp dialog opened {audit.modal_title()!r}')
        page.select_option('#stamp-label', 'Confidential')
        page.click('#stamp-arm')
        page.wait_for_timeout(500)
        audit.require(page.evaluate('() => state.tool') == 'stamp',
                      'arming the stamp did not switch to the stamp tool')
        point = page.evaluate("""() => {
            const r = document.querySelector('#pdf-page').getBoundingClientRect();
            const p = state.doc.pages[state.page];
            return [r.left + 120 / p.width * r.width, r.top + 160 / p.height * r.height];
        }""")
        page.mouse.click(*point)
        deadline = time.time() + 40
        while time.time() < deadline and 'Confidential' not in page.evaluate(
                '() => (state.content?.spans||[]).map(s => s.text).join(" ")'):
            page.wait_for_timeout(300)
        spans = page.evaluate('() => (state.content?.spans||[]).map(s => s.text).join(" ")')
        audit.require('Confidential' in spans,
                      f'the stamp is not in the page as text (spans: {spans[:200]!r})')
        page.screenshot(path=str(QA / 'audit-stamp.png'))
        # The two buttons the panel shows while a stamp is armed.
        page.click('#stamp-change')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Mark the document.',
                      f'Choose another stamp opened {audit.modal_title()!r}')
        page.keyboard.press('Escape')
        page.wait_for_timeout(400)
        page.click('#stamp-stop')
        page.wait_for_timeout(400)
        audit.require(page.evaluate('() => state.tool') == 'view',
                      'Stop stamping left the stamp tool armed')

        # ---- link, drawn on the page
        page.click('#context-tools [data-tool="link"]')
        page.wait_for_timeout(500)
        audit.require(page.evaluate('() => state.tool') == 'link',
                      'the link button did not select the link tool')
        drag = page.evaluate("""() => {
            const r = document.querySelector('#pdf-page').getBoundingClientRect();
            const p = state.doc.pages[state.page];
            const at = (x, y) => [r.left + x / p.width * r.width, r.top + y / p.height * r.height];
            return {a: at(80, 380), b: at(360, 412)};
        }""")
        page.mouse.move(*drag['a'])
        page.mouse.down()
        page.mouse.move(*drag['b'], steps=6)
        page.mouse.up()
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Make it clickable.',
                      f'drawing a link opened {audit.modal_title()!r}')
        page.fill('#link-url', 'https://example.org/audit')
        page.click('#link-add')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('#link-list .list-row').count() == 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('#link-list .list-row').count() == 1,
                      f'the added link is not listed ({page.inner_text("#link-list")!r})')
        audit.require('example.org/audit' in page.inner_text('#link-list'),
                      'the link is listed under the wrong address')
        # A bad address is refused with a reason, not written into the document.
        page.fill('#link-url', 'not-an-address')
        page.click('#link-add')
        deadline = time.time() + 20
        while time.time() < deadline and not page.inner_text('#link-error'):
            page.wait_for_timeout(300)
        audit.require('must start with' in page.inner_text('#link-error'),
                      f'a bad address was not refused ({page.inner_text("#link-error")!r})')
        page.click('[data-link-remove="0"]')
        deadline = time.time() + 40
        while time.time() < deadline and page.locator('#link-list .list-row').count() > 0:
            page.wait_for_timeout(300)
        audit.require(page.locator('#link-list .list-row').count() == 0,
                      'the link could not be removed')
        page.click('[data-close]')
        page.wait_for_timeout(400)

        # ---- page size, on the current page only so the rest of the audit keeps
        # the paper it started with
        audit.open_view('document')
        page.wait_for_timeout(700)
        before = page.evaluate('() => [state.doc.pages[state.page].width, state.doc.pages[state.page].height]')
        pages_before = page.evaluate('() => state.doc.pages.length')
        page.click('[data-doc-tool="resize"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'Change the paper.',
                      f'the page-size dialog opened {audit.modal_title()!r}')
        page.select_option('#resize-size', 'A5')
        page.select_option('#resize-pages', 'current')
        page.click('#resize-run')
        deadline = time.time() + 40
        while time.time() < deadline and page.evaluate(
                '() => Math.round(state.doc.pages[state.page].width)') != 420:
            page.wait_for_timeout(300)
        after = page.evaluate('() => [state.doc.pages[state.page].width, state.doc.pages[state.page].height]')
        audit.require(round(after[0]) == 420 and round(after[1]) == 595,
                      f'the page was not resized to A5 (was {before}, now {after})')
        pages_after = page.evaluate('() => state.doc.pages.length')
        audit.require(pages_after == pages_before,
                      f'resizing changed the page count ({pages_before} → {pages_after})')

        # ---- compare against a second document that is open
        original = page.evaluate('() => state.doc.name')
        page.evaluate("""async () => {
            const info = await api('/documents/create', {method: 'POST', json: {name: 'Compare check.pdf'}});
            await adoptDocument(info, {page: 0, sample: false});
        }""")
        page.wait_for_timeout(1800)
        audit.open_view('document')
        page.wait_for_timeout(600)
        page.click('[data-doc-tool="compare"]')
        page.wait_for_selector('#modal[open]', timeout=10000)
        audit.require(audit.modal_title() == 'What changed?',
                      f'the compare dialog opened {audit.modal_title()!r}')
        options = page.eval_on_selector('#compare-open', 'el => [...el.options].map(o => o.value).filter(Boolean)')
        audit.require(options, 'the compare dialog lists no other open document')
        page.select_option('#compare-open', options[0])
        page.click('#compare-run')
        deadline = time.time() + 40
        while time.time() < deadline and not page.inner_text('#compare-report').strip():
            page.wait_for_timeout(300)
        report = page.inner_text('#compare-report')
        audit.require('PAGES DIFFER' in report or 'No differences' in report,
                      f'the comparison reported nothing usable ({report!r})')
        audit.require('PAGES DIFFER' in report,
                      f'a one-page blank against a four-page document found no differences ({report!r})')
        page.screenshot(path=str(QA / 'audit-compare.png'))
        page.click('[data-close]')
        page.wait_for_timeout(400)
        # Leave the workspace as it was found: back to the document the rest of
        # the audit works on, and the throwaway one closed.
        page.locator('.document-tab').filter(has_text=original).first.locator('.tab-name').click()
        page.wait_for_timeout(1400)
        audit.require(page.evaluate('() => state.doc.name') == original,
                      'the tab did not switch back to the document under audit')
        page.locator('.document-tab').filter(has_text='Compare check.pdf').first.locator('.tab-close').click()
        page.wait_for_timeout(1600)
        audit.require(page.locator('.document-tab').filter(has_text='Compare check.pdf').count() == 0,
                      'the throwaway comparison document is still open')
        audit.open_view('edit')
    audit.run('A stamp, a link, a new paper size and a document comparison all work',
              stamps_links_size_and_compare)

    def closing_asks_only_when_there_is_something_to_lose():
        # The step needs a document nobody has touched, and the steps above have
        # all changed the one on screen. It is put back afterwards, because the
        # saving step that follows expects a document with content in it.
        previous = page.evaluate('() => state.doc.id')
        # A fresh document, so this step starts from "nothing unsaved" rather
        # than inheriting whatever the steps above changed.
        page.evaluate("""async () => {
            const info = await api('/documents/create', {method: 'POST', json: {name: 'Close check.pdf'}});
            await adoptDocument(info, {page: 0, sample: false});
        }""")
        page.wait_for_timeout(1500)
        # The shell asks the page one question when the window is closed, and the
        # page keeps the answer ready. A clean document must close with no dialog
        # at all — that is the whole point of the change.
        page.evaluate("""() => {
            window.__close = {calls: [], quits: 0};
            window.pywebview = {api: {
                set_unsaved: flag => { window.__close.calls.push(flag); return Promise.resolve({ok: true}); },
                quit_app: () => { window.__close.quits += 1; return Promise.resolve({ok: true}); },
            }};
            lastUnsavedFlag = null;
            updateHeader();
        }""")
        page.wait_for_timeout(500)
        audit.require(page.evaluate('() => isDirty()') is False,
                      'the fresh document is already dirty, so the step cannot test a clean close')
        audit.require(page.evaluate('() => window.__close.calls.at(-1)') is False,
                      f'the shell was told there were unsaved changes on a clean document '
                      f'(calls: {page.evaluate("() => window.__close.calls")!r})')
        page.evaluate('() => { window.kadomaAskToSaveBeforeQuit(); }')
        page.wait_for_timeout(600)
        audit.require(audit.modal_title() is None,
                      f'closing a clean document asked {audit.modal_title()!r}')
        audit.require(page.evaluate('() => window.__close.quits') == 1,
                      'closing a clean document did not close it')

        # With something changed, the question appears — and Cancel keeps the
        # window open rather than discarding the work.
        audit.open_view('pages')
        page.wait_for_timeout(900)
        page.click('#organizer-clear')
        page.wait_for_timeout(200)
        page.locator('.organize-card').first.click()
        page.wait_for_timeout(200)
        page.click('[data-action="rotate-pages"]')
        page.wait_for_timeout(2000)
        audit.require(page.evaluate('() => window.__close.calls.at(-1)') is True,
                      'the shell was not told the document had changed')
        page.evaluate('() => { window.kadomaAskToSaveBeforeQuit(); }')
        page.wait_for_timeout(700)
        audit.require(audit.modal_title() == 'Save your changes?',
                      f'closing a changed document asked {audit.modal_title()!r}')
        page.click('[data-close]')
        page.wait_for_timeout(600)
        audit.require(page.evaluate('() => window.__close.quits') == 1,
                      'cancelling the save prompt closed the window anyway')
        # Back to the document the rest of the audit was working on.
        page.evaluate('id => switchDocument(id)', previous)
        page.wait_for_timeout(1600)
        audit.require(page.evaluate('() => state.doc.id') == previous,
                      'the close check left a different document open')
        audit.open_view('edit')
    audit.run('Closing asks only when there is something to save', closing_asks_only_when_there_is_something_to_lose)

    # ---------------------------------------------------------------- saving
    # The two native dialogs are the only part of saving a browser cannot
    # provide, so they are stood in for here and the rest is real: the request,
    # the engine's write, and the file that appears on disk. This runs last
    # because it gives the open document a new name and a file behind it.
    def save_buttons_write_a_file():
        target = QA / 'audit-saved.pdf'
        target.unlink(missing_ok=True)
        page.evaluate("""path => { window.pywebview = {api: {
            choose_save_path: async () => ({path}),
            choose_open_path: async () => ({cancelled: true}) }}; }""", str(target))

        page.click('#save-document')  # no file behind the document yet
        deadline = time.time() + 40
        while time.time() < deadline and 'Saved as' not in audit.toasts():
            page.wait_for_timeout(300)
        audit.require('Saved as audit-saved.pdf' in audit.toasts(),
                      f'Save did not report the new file (toasts: {audit.toasts()!r})')
        audit.require(target.is_file() and target.stat().st_size > 1000,
                      'Save reported success but no file was written')
        audit.require(page.inner_text('#document-name') == 'audit-saved.pdf',
                      'the document did not take the name it was saved as')
        audit.require(page.inner_text('#document-change') == 'Saved',
                      f'the header does not say Saved (got {page.inner_text("#document-change")!r})')

        page.click('#save-document')  # now it has a file: this is an overwrite
        deadline = time.time() + 40
        while time.time() < deadline and 'Saved to' not in audit.toasts():
            page.wait_for_timeout(300)
        audit.require('Saved to audit-saved.pdf' in audit.toasts(),
                      f'a second Save did not write in place (toasts: {audit.toasts()!r})')
        import pymupdf as fitz
        with fitz.open(target) as written:
            audit.require(len(written) >= 1, 'the saved file is not a readable PDF')
    audit.run('Save and Save as write a real PDF to disk and the header follows it', save_buttons_write_a_file)

    def save_explains_the_browser_preview():
        # Outside the desktop shell there is nowhere to write, and the interface
        # says so instead of failing quietly.
        def handler(route):
            response = route.fetch()
            body = response.json()
            body['desktop'] = False
            route.fulfill(response=response, body=json.dumps(body))

        page.route('**/api/health', handler)
        reopen_report()
        page.wait_for_timeout(300)
        page.click('#save-document')
        page.wait_for_timeout(400)
        audit.require(audit.modal_title() == 'Saving needs the desktop app.',
                      f'the preview explanation did not open (got {audit.modal_title()!r})')
        audit.require('desktop' in page.inner_text('#modal').lower(),
                      'the dialog does not explain that saving needs the desktop app')
        page.click('#save-export-instead')
        audit.require(audit.modal_title() == 'Ready for what’s next.',
                      'the explanation did not offer the export fallback')
        audit.close_modal()
        page.unroute('**/api/health', handler)
        reopen_report()
    audit.run('In the browser preview, Save explains itself and offers the export', save_explains_the_browser_preview)

    # ---------------------------------------------------------- hygiene
    def no_errors():
        audit.require(not errors, f'the interface raised {len(errors)} error(s): {errors[:3]}')
    audit.run('No uncaught JavaScript errors during the whole audit', no_errors)

    def no_server_errors():
        # 4xx responses are the engine refusing politely and are expected here —
        # the audit deliberately asks for things that are invalid. A 5xx means
        # the engine itself broke, which is never acceptable.
        broken = [item for item in server_failures if item.startswith('5')]
        audit.require(not broken, f'the engine returned server errors: {broken[:3]}')
    audit.run('The engine returned no 5xx responses', no_server_errors)

    def no_external():
        audit.require(not external, f'the page contacted {len(external)} external address(es): {external[:3]}')
    audit.run('No external network requests at any point', no_external)


# ---------------------------------------------------------------------- setup

def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def start_server(capture: Path | None) -> tuple[subprocess.Popen, str]:
    import os
    port = free_port()
    env = {**os.environ, 'PAPERDESK_AUDIT_PORT': str(port)}
    if capture:
        env['PAPERDESK_AUDIT_CAPTURE'] = str(capture)
    process = subprocess.Popen([sys.executable, '-c', LAUNCHER], cwd=ROOT, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    base = f'http://127.0.0.1:{port}'
    for _ in range(120):
        try:
            with urlopen(base + '/api/health', timeout=1) as response:
                if response.status == 200:
                    return process, base
        except (URLError, OSError):
            time.sleep(.25)
        if process.poll() is not None:
            raise SystemExit('The audit server exited early:\n' + (process.stdout.read() or ''))
    process.terminate()
    raise SystemExit('The audit server did not start in time.')


def ensure_fixtures() -> None:
    """Create the files this audit needs, so it does not depend on another run.

    These used to be left behind by `check_ui.py`, which meant the audit only
    worked if that had been run first against the same output directory.
    """
    import pymupdf as fitz

    def build(name: str, labels: list[str], locked: bool = False) -> None:
        path = QA / name
        if path.exists():
            return
        with fitz.open() as doc:
            for text in labels:
                doc.new_page(width=595, height=842).insert_text((72, 120), text, fontsize=26)
            if locked:
                doc.save(str(path), encryption=fitz.PDF_ENCRYPT_AES_256,
                         owner_pw='audit-owner', user_pw='audit-pass')
            else:
                doc.save(str(path))

    build('merge-fixture.pdf', ['MERGE FIXTURE ONE'])
    build('merge-pair.pdf', ['PAIR ONE', 'PAIR TWO'])
    build('merge-locked.pdf', ['LOCKED ONE', 'LOCKED TWO'], locked=True)

    # A flat form: the four things Prepare Form looks for, so the tool has
    # something real to find.
    form_fixture = QA / 'form-fixture.pdf'
    if not form_fixture.exists():
        with fitz.open() as doc:
            page = doc.new_page(width=595, height=842)
            page.insert_text((60, 120), 'Name:', fontsize=12)
            page.insert_text((60, 160), 'Date of birth:', fontsize=12)
            page.insert_text((60, 200), 'Signature ______________________', fontsize=12)
            page.draw_rect(fitz.Rect(60, 230, 72, 242), color=(0, 0, 0), width=1)
            page.insert_text((80, 240), 'I agree to the terms', fontsize=12)
            doc.save(form_fixture)

    # The report the whole audit works on. The application used to ship this as
    # a sample document; it is built here now, and opened through the interface
    # like any other file.
    session = QA / 'session-document.pdf'
    if not session.exists():
        if str(ROOT / 'tests') not in sys.path:
            sys.path.insert(0, str(ROOT / 'tests'))
        from support.demo_document import make_demo
        session.write_bytes(make_demo())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', default=None,
                        help='use an already-running server instead of starting one')
    parser.add_argument('--output', default='qa')
    args = parser.parse_args()

    global QA
    QA = Path(args.output).resolve()
    QA.mkdir(parents=True, exist_ok=True)
    capture = QA / 'audit-print.pdf'
    ensure_fixtures()

    print('== Static pass: is every control wired to a handler? ==', flush=True)
    steps, problems, checked = static_pass()
    print(f'   {checked} controls checked, {len(problems)} problem(s)', flush=True)
    for problem in problems:
        print('   FAIL:', problem, flush=True)

    process, base_url = None, args.base_url
    if not base_url:
        capture.unlink(missing_ok=True)
        process, base_url = start_server(capture)
        print(f'== Live pass against {base_url} (desktop capabilities) ==', flush=True)
    else:
        capture = None
        print(f'== Live pass against {base_url} ==', flush=True)

    steps_live, failures = [], []
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch()
            context = browser.new_context(viewport={'width': 1500, 'height': 950},
                                          accept_downloads=True)
            page = context.new_page()
            errors, external, server_failures = [], [], []

            def on_error(exc):
                errors.append(str(exc).split('\n')[0])

            def on_request(request):
                url = request.url
                if not url.startswith(base_url) and not url.startswith(('data:', 'blob:', 'about:')):
                    external.append(url)

            def on_response(response):
                if response.status >= 400 and response.url.startswith(base_url):
                    server_failures.append(f'{response.status} {response.request.method} '
                                           f'{response.url.split("/api")[-1]}')

            page.on('pageerror', on_error)
            page.on('request', on_request)
            page.on('response', on_response)

            page.goto(base_url, wait_until='load')
            # Nothing opens by itself any more: wait for the application to be
            # ready, not for a document that is no longer shipped.
            page.wait_for_function('() => typeof state !== "undefined" && state.capabilities && !state.busy',
                                   timeout=60000)
            page.wait_for_timeout(600)

            audit = Audit(page, capture)
            live_pass(audit, base_url, errors, external, server_failures)
            steps_live, failures = audit.steps, audit.failures

            if failures:
                page.screenshot(path=str(QA / 'controls-failure.png'), full_page=False)
            context.close()
            browser.close()
    finally:
        if process:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()

    total = len(steps) + len(steps_live)
    result = {
        'staticControlsChecked': checked,
        'staticSteps': len(steps),
        'liveSteps': len(steps_live),
        'passed': total,
        'failed': len(problems) + len(failures),
        'staticProblems': problems,
        'liveFailures': failures,
        'apiRefusals': sorted(set(server_failures)),
        'printJob': str(capture) if capture and capture.exists() else None,
    }
    (QA / 'controls-results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')

    print('', flush=True)
    print(f'Controls inspected: {checked}', flush=True)
    print(f'PASSED: {total}    FAILED: {len(problems) + len(failures)}', flush=True)
    for failure in failures:
        print('FAIL:', failure, flush=True)
    print(f'Results written to {QA / "controls-results.json"}', flush=True)
    return 1 if (problems or failures) else 0


if __name__ == '__main__':
    raise SystemExit(main())
