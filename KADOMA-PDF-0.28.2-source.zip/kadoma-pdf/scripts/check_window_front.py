"""Prove the topmost hand-off against a real WebView2 window.

Unit tests cover *when* the application should step aside. This covers *whether
it actually can*: that `SetWindowPos`, called from a background thread, really
changes `WS_EX_TOPMOST` on the same kind of window the desktop shell creates,
and that a window belonging to another process can then come in front of it.

A second process opens a small modal window twice — once while KADOMA is still
topmost, once after the release — and the Z-order of the two windows is read
back. That is the user's complaint reproduced and then fixed, without opening a
real mail client or printer driver dialog.

    python scripts/check_window_front.py

The native windows are opened briefly and closed again. Nothing is written to
any document. The result is written to qa/window-front-results.json.
"""
from __future__ import annotations

import ctypes
import json
import subprocess
import sys
import threading
import time
import traceback
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import window_front  # noqa: E402

QA = ROOT / 'qa'
EXTERNAL_TITLE = 'KADOMA external probe'
CHILD = ("import ctypes; "
         "ctypes.windll.user32.MessageBoxW(None, 'External window probe', "
         f"'{EXTERNAL_TITLE}', 0x10040)")
_WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


def visible_windows() -> list[tuple[int, str]]:
    """Visible titled top-level windows, in Z-order, front first.

    EnumWindows walks the system's window list from the top of the Z-order down,
    which is exactly the ordering a person sees on screen.
    """
    user32 = ctypes.windll.user32
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    found: list[tuple[int, str]] = []

    def collect(hwnd, _lparam):
        if user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buffer, length + 1)
                found.append((hwnd, buffer.value))
        return True

    user32.EnumWindows(_WNDENUMPROC(collect), 0)
    return found


def rank(hwnd: int) -> int:
    """Where a window sits in the Z-order; smaller is nearer the front."""
    for index, (candidate, _title) in enumerate(visible_windows()):
        if candidate == hwnd:
            return index
    return 10 ** 6


def spawn_external(timeout: float = 10.0):
    """Open a window in another process, mimicking a compose/driver dialog."""
    process = subprocess.Popen([sys.executable, '-c', CHILD])
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for hwnd, title in visible_windows():
            if title == EXTERNAL_TITLE:
                time.sleep(0.2)  # let the window manager finish ordering it
                return process, hwnd
        time.sleep(0.1)
    process.terminate()
    return process, None


def dismiss(process):
    try:
        process.terminate()
        process.wait(timeout=5)
    except Exception:  # noqa: BLE001
        try:
            process.kill()
        except Exception:  # noqa: BLE001
            pass


def probe() -> dict:
    import webview

    steps: list[str] = []
    problems: list[str] = []
    state: dict = {}

    def check(name, condition):
        (steps if condition else problems).append(name)

    window = webview.create_window('KADOMA PDF', html='<h1>Front check</h1>',
                                   width=520, height=320, on_top=True)

    def run():
        guard = None
        real_foreground = window_front.foreground_window
        try:
            # The form (and its HWND) only exists after WebView2 has shown it.
            deadline = time.monotonic() + 15
            hwnd = None
            while time.monotonic() < deadline:
                titled = [h for h, title in window_front.app_windows()
                          if 'kadoma' in title.lower()]
                if titled:
                    hwnd = titled[0]
                    break
                time.sleep(0.1)
            check('a titled window for this process was found', hwnd is not None)
            if hwnd is None:
                return
            state['hwnd'] = hwnd
            state['windows'] = [title for _h, title in window_front.app_windows()]
            check('the window starts topmost', window_front.is_topmost(hwnd))

            # Reproduce the complaint: while topmost, an external window that
            # explicitly asks for the foreground is still stacked behind us.
            before, other = spawn_external()
            try:
                check('an external window opened in another process', other is not None)
                state['zOrderBefore'] = {'kadoma': rank(hwnd), 'external': rank(other)}
                check('with the topmost style, KADOMA covers the external window',
                      other is not None and rank(hwnd) < rank(other))
            finally:
                dismiss(before)

            # The release normally arrives on the server thread, not the UI one.
            guard = window_front.FrontGuard(interval=0.05, no_show_timeout=60)
            guard.start()
            window_front.foreground_window = lambda: other or 0xDEADBEEF
            guard.release()
            check('release() clears WS_EX_TOPMOST from another thread',
                  not window_front.is_topmost(hwnd))

            after, second = spawn_external()
            try:
                check('the external window opened again after the release', second is not None)
                state['zOrderAfter'] = {'kadoma': rank(hwnd), 'external': rank(second)}
                check('after the release, the external window is in front of KADOMA',
                      second is not None and rank(second) < rank(hwnd))
                check('the style stays off while an external window is in front',
                      not window_front.is_topmost(hwnd))
            finally:
                dismiss(after)

            # ...and must restore once KADOMA is the active window again.
            window_front.foreground_window = lambda: hwnd
            until = time.monotonic() + 3
            while guard.released and time.monotonic() < until:
                time.sleep(0.02)
            check('coming back restores WS_EX_TOPMOST', window_front.is_topmost(hwnd))
            check('the guard is no longer released', not guard.released)
        except Exception:  # noqa: BLE001 - a broken probe must still close the window
            problems.append(traceback.format_exc(limit=3))
        finally:
            window_front.foreground_window = real_foreground
            if guard:
                guard.stop()
            threading.Timer(0.2, lambda: window.destroy()).start()

    window.events.loaded += lambda: threading.Thread(target=run, daemon=True).start()
    webview.start(gui='edgechromium' if sys.platform == 'win32' else None, debug=False)
    return {
        'supported': window_front.IS_WINDOWS,
        'steps': steps,
        'problems': problems,
        'hwnd': state.get('hwnd'),
        'windows': state.get('windows', []),
        'zOrderBefore': state.get('zOrderBefore'),
        'zOrderAfter': state.get('zOrderAfter'),
        'passed': len(steps),
        'failed': len(problems),
    }


def main() -> int:
    QA.mkdir(parents=True, exist_ok=True)
    if not window_front.IS_WINDOWS:
        result = {'supported': False, 'steps': [], 'problems': [], 'passed': 0, 'failed': 0,
                  'note': 'Windows-only check; skipped on this platform.'}
    else:
        try:
            result = probe()
        except Exception as exc:  # noqa: BLE001
            result = {'supported': True, 'steps': [], 'problems': [f'{type(exc).__name__}: {exc}'],
                      'passed': 0, 'failed': 1}
    (QA / 'window-front-results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    for step in result['steps']:
        print('PASS:', step, flush=True)
    for problem in result['problems']:
        print('FAIL:', problem, flush=True)
    print(f"\n{result['passed']} checks passed, {result['failed']} failed.", flush=True)
    print(f"Results written to {QA / 'window-front-results.json'}", flush=True)
    return 1 if result['failed'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
