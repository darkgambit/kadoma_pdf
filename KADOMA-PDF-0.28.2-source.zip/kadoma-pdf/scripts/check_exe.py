"""Launch a built KADOMA executable and verify that it actually runs.

Starts the executable the way a user would, waits for its authenticated loopback
service to answer, fetches the interface it serves, and reports the native window
title. This does not replace hands-on GUI QA, but it does prove that a packaged
build boots, serves its own UI, applies its token gate, and opens a window on
this machine.

    python scripts/check_exe.py release/KADOMA-0.5.0-Windows-x64-standalone.exe
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

LISTEN = re.compile(r'^\s*TCP\s+(?:127\.0\.0\.1|\[::1\]):(\d+)\s+\S+\s+LISTENING\s+(\d+)\s*$')

# The title the desktop shell gives its window. It is fixed — it does not change
# with the open document — which is what makes it usable as evidence here. It is
# read out of the shell's own source rather than copied, so the two cannot drift
# apart and leave this check quietly looking for the wrong thing.
FALLBACK_WINDOW_TITLE = 'KADOMA PDF'
# The source tree this check is run from, so the interface the executable serves
# can be compared with the interface that was built into it.
SOURCE = Path(__file__).resolve().parents[1]


def app_window_title() -> str:
    try:
        source = (Path(__file__).resolve().parents[1] / 'desktop.py').read_text(encoding='utf-8')
    except OSError:
        return FALLBACK_WINDOW_TITLE
    match = re.search(r"create_window\(\s*'([^']+)'", source)
    return match.group(1) if match else FALLBACK_WINDOW_TITLE


APP_WINDOW_TITLE = app_window_title()


def loopback_listeners() -> dict[int, int]:
    """{port: owning pid} for every loopback listener, via netstat.

    Ownership matters because a PyInstaller one-file build runs the application in
    a child process: the parent bootloader owns the extracted files, not the port.
    """
    try:
        output = subprocess.run(['netstat', '-ano'], capture_output=True, text=True, timeout=30).stdout
    except Exception:
        return {}
    listeners = {}
    for line in output.splitlines():
        match = LISTEN.match(line)
        if match:
            listeners[int(match.group(1))] = int(match.group(2))
    return listeners


def visible_windows() -> list[tuple[int, str]]:
    """[(pid, title)] for every visible top-level window with a real title.

    Enumerated through user32 directly rather than parsing `tasklist`, which
    reports the literal string 'N/A' when it cannot read a window title. That
    placeholder must never be mistaken for evidence of a window.
    """
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return []
    user32 = ctypes.windll.user32
    found: list[tuple[int, str]] = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def callback(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        title = buffer.value.strip()
        if not title or title.upper() in ('N/A', 'DEFAULT IME WINDOW'):
            return True
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        found.append((int(pid.value), title))
        return True

    try:
        user32.EnumWindows(WNDENUMPROC(callback), 0)
    except Exception:
        return found
    return found


def task_rows() -> list[tuple[int, str]]:
    """[(pid, image name)] for every running process, via tasklist."""
    try:
        output = subprocess.run(['tasklist', '/FO', 'CSV', '/NH'],
                                capture_output=True, text=True, timeout=30).stdout
    except Exception:
        return []
    rows = []
    for line in output.splitlines():
        parts = [part.strip().strip('"') for part in line.split(',')]
        if len(parts) < 2:
            continue
        try:
            rows.append((int(parts[1]), parts[0]))
        except ValueError:
            continue
    return rows


def kadoma_processes() -> list[tuple[int, str]]:
    """[(pid, image name)] for every running copy of the application.

    The image name is matched by *prefix*, not equality. `tasklist` truncates it
    to 25 characters, so the one-file build reports itself as
    `KADOMA-0.5.0-Windows-x` — filtering on the literal `KADOMA.exe` finds
    nothing and reports a clean machine while a copy is still running. That exact
    mistake is what made the handoff check look like a broken build.
    """
    return [(pid, name) for pid, name in task_rows() if name.lower().startswith('kadoma')]


def terminate_tree(pid: int) -> None:
    """Kill a process *and everything it spawned*.

    A one-file PyInstaller build is a bootloader that extracts itself and runs the
    real application as a **child** process. Terminating the handle Popen gave us
    kills only the bootloader, so the application — plus the WebView2 processes it
    started — survive as orphans. An orphan still holds the single-instance mutex,
    so the next run of any check hands its file to a window nobody is looking at,
    exits 0, and never opens a service. The symptom is indistinguishable from a
    build that cannot start, which is why this has to be handled here.
    """
    if sys.platform == 'win32':
        subprocess.run(['taskkill', '/T', '/F', '/PID', str(pid)],
                       capture_output=True, text=True, timeout=30)
        return
    import os
    import signal
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        pass


def stop_process(process, timeout: float = 20.0) -> None:
    """Terminate a launched copy completely, then confirm it is gone."""
    if process is None:
        return
    terminate_tree(process.pid)
    try:
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        process.kill()
    # The child is not the process we hold a handle for, so wait for the machine
    # to actually be quiet rather than trusting the parent's exit.
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and kadoma_processes():
        time.sleep(.5)


def window_title(pid: int) -> str:
    """Title of the application's own window, or '' when there is none.

    Two passes, and the second one has to be strict. A window owned by the
    application's process is conclusive. Failing that, the WebView2 window can
    belong to a helper process, so the fallback looks for the title the shell
    actually sets — `KADOMA — Offline PDF Studio`, which is fixed and never
    changes with the open document.

    An earlier version of this matched any window whose title merely contained
    "kadoma". That reported a File Explorer window open on a folder named
    `kadoma` as proof that the application had opened a window, which is
    exactly the kind of false pass this script exists to prevent.
    """
    windows = visible_windows()
    for owner, title in windows:
        if owner == pid:
            return title
    for _owner, title in windows:
        lowered = title.lower()
        if lowered == APP_WINDOW_TITLE.lower() or APP_WINDOW_TITLE.lower() in lowered:
            return title
    return ''


def fetch(url: str) -> tuple[int, bytes]:
    """Return (status, body) even for error responses."""
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as error:
        return error.code, error.read()
    except Exception:
        return 0, b''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('executable')
    parser.add_argument('--timeout', type=float, default=90.0)
    parser.add_argument('--json-out', default=None)
    args = parser.parse_args()
    executable = Path(args.executable).resolve()
    if not executable.is_file():
        raise SystemExit(f'Not found: {executable}')
    print(f'Launching {executable.name} ({executable.stat().st_size:,} bytes)', flush=True)

    # A copy left running by an earlier check holds the single-instance mutex. The
    # launch below would then hand off to it and exit 0 without ever serving, which
    # reads as "the application exited immediately". Say what is actually wrong.
    leftover = kadoma_processes()
    if leftover:
        raise SystemExit('A KADOMA instance is already running (pid '
                         + ', '.join(str(pid) for pid, _ in leftover)
                         + '). Close it, or run "python scripts/check_open_with.py --cleanup", '
                           'then try again — a second copy cannot start a service.')

    checks, warnings, health, title = [], [], {}, ''
    started = time.monotonic()
    # Snapshot before launch. A one-file build extracts itself and re-executes the
    # real application as a *child* process, so the port's owning PID is not the
    # PID we launch. What matters is that a loopback listener appears that no
    # other process owned a moment ago: the shell binds 127.0.0.1 only, by design.
    before = set(loopback_listeners())
    process = subprocess.Popen([str(executable)], cwd=str(executable.parent))
    try:
        ports, owner, deadline = [], None, time.monotonic() + args.timeout
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise SystemExit(f'The application exited immediately (code {process.returncode}).')
            current = loopback_listeners()
            fresh = {port: pid for port, pid in current.items() if port not in before}
            if fresh:
                ports, owner = sorted(fresh), next(iter(fresh.values()))
                break
            time.sleep(.5)
        if not ports:
            raise SystemExit('The application never opened its loopback service.')
        checks.append(f'loopback service listening on 127.0.0.1 port(s) {ports} (pid {owner})')

        status, body = 0, b''
        for port in ports:
            status, body = fetch(f'http://127.0.0.1:{port}/api/health')
            if status in (200, 401):
                break
        if status not in (200, 401):
            raise SystemExit('The service is listening but /api/health did not answer.')
        health = json.loads(body.decode('utf-8'))
        if status == 401:
            # The desktop shell sets a random request token, so an unauthenticated
            # probe is expected to be refused. That refusal is the security gate working.
            checks.append(f'API token gate active (HTTP {status}, code {health.get("code")!r})')
        else:
            checks.append(f'health answered: version {health.get("version")}, offline={health.get("offline")}')

        interface_status, interface_body = 0, b''
        for port in ports:
            interface_status, interface_body = fetch(f'http://127.0.0.1:{port}/')
            if interface_status == 200:
                break
        if interface_status != 200 or b'KADOMA' not in interface_body:
            raise SystemExit('The packaged interface was not served from the executable.')
        checks.append(f'interface served from the bundle ({len(interface_body):,} bytes of HTML)')

        # The HTML answering is not the same as the interface working: a bundle
        # that lost app.js, the stylesheet or a font still returns 200 on `/`,
        # and the window then opens on an unstyled page with no behaviour. Every
        # asset the served HTML names is therefore fetched from the running
        # executable and compared, byte for byte, with the source tree.
        assets = sorted(set(re.findall(r'(?:href|src)="(/static/[^"?#]+)"',
                                       interface_body.decode('utf-8', 'replace'))))
        # The stylesheet names the fonts it needs, and those are not in the HTML.
        for asset in list(assets):
            if not asset.endswith('.css'):
                continue
            local_css = SOURCE / 'app' / asset.lstrip('/')
            if not local_css.is_file():
                continue
            for reference in re.findall(r'url\(([^)]+)\)', local_css.read_text(encoding='utf-8', errors='replace')):
                reference = reference.strip('\'" ')
                if not reference or reference.startswith(('data:', 'http:', 'https:')):
                    continue
                resolved = (Path(asset).parent / reference).as_posix()
                assets.append('/' + resolved.lstrip('/'))
        assets = sorted(set(assets))
        missing, different = [], []
        for asset in assets:
            asset_status, asset_body = 0, b''
            for port in ports:
                asset_status, asset_body = fetch(f'http://127.0.0.1:{port}{asset}')
                if asset_status == 200:
                    break
            if asset_status != 200 or not asset_body:
                missing.append(f'{asset} (HTTP {asset_status})')
                continue
            local = SOURCE / 'app' / asset.lstrip('/')
            if local.is_file() and local.read_bytes() != asset_body:
                different.append(asset)
        if missing:
            raise SystemExit('The packaged interface is missing assets it names: '
                             + ', '.join(missing))
        if different:
            raise SystemExit('The packaged interface serves different bytes than the source for: '
                             + ', '.join(different))
        if not assets:
            raise SystemExit('The packaged interface names no static assets at all.')
        checks.append(f'{len(assets)} interface assets served from the bundle, byte-identical '
                      f'to the source')

        for _ in range(60):
            # The window belongs to the real application process, which is the
            # owner of the freshly opened port (the child of the bootloader).
            title = window_title(owner)
            if title:
                break
            time.sleep(.5)
        if title:
            checks.append(f'native window created: {title!r}')
        else:
            warnings.append('No window title was reported. The service and UI work, but this '
                            'session may have no interactive desktop for the WebView2 window.')

        # The right-click entry is written by the app itself at startup, so this
        # is the only place it can be seen pointing at the *shipped* binary
        # rather than at the source tree. Reading the key is not a side effect;
        # the write already happened when the window opened.
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r'Software\Classes\SystemFileAssociations\.pdf\shell'
                                r'\KADOMACombine\command') as handle:
                command = winreg.QueryValueEx(handle, None)[0]
            if executable.name in command and '--combine' in command:
                checks.append(f'Explorer menu entry registered: {command[:60]}…')
            else:
                warnings.append(f'The Explorer menu entry does not point at this build: {command}')
        except OSError:
            warnings.append('The Explorer menu entry was not found in HKCU after launch.')
    finally:
        stop_process(process)

    elapsed = round(time.monotonic() - started, 1)
    for name in checks:
        print('PASS:', name, flush=True)
    for name in warnings:
        print('WARN:', name, flush=True)
    result = {'executable': str(executable), 'checks': checks, 'warnings': warnings,
              # The token gate refuses an unauthenticated probe, so the version is
              # only readable when the gate let the request through. Saying which
              # of the two happened is more useful than a bare null.
              'version': health.get('version') or (
                  'not readable without the request token (the gate refused the probe)'
                  if health.get('code') == 'unauthorized' else None),
              'portOwnerPid': owner, 'seconds': elapsed}
    if args.json_out:
        Path(args.json_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json_out).write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'\n{len(checks)} checks passed in {elapsed}s, {len(warnings)} warnings.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
