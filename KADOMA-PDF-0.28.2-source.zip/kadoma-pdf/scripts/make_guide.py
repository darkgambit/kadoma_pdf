"""Generate the included getting-started PDF from local source assets."""
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.utils import ImageReader

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
DOCS.mkdir(exist_ok=True)
TARGET = DOCS / 'KADOMA-PDF-Getting-Started.pdf'
PURPLE=colors.HexColor('#7162da')
INK=colors.HexColor('#28283d')
MUTED=colors.HexColor('#797387')
PALE=colors.HexColor('#f1eefb')
LINE=colors.HexColor('#e5e0ed')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='PDTitle',fontName='Helvetica-Bold',fontSize=32,leading=37,textColor=INK,spaceAfter=12))
styles.add(ParagraphStyle(name='PDHeading',fontName='Helvetica-Bold',fontSize=22,leading=28,textColor=INK,spaceAfter=12))
# keepWithNext so a step's heading never sits alone at the foot of a page with
# its paragraph overleaf, which is what happened to "15 / Export a copy".
styles.add(ParagraphStyle(name='PDSection',fontName='Helvetica-Bold',fontSize=12,leading=16,textColor=INK,spaceBefore=15,spaceAfter=7,keepWithNext=1))
styles.add(ParagraphStyle(name='PDBody',fontName='Helvetica',fontSize=10,leading=15,textColor=MUTED,spaceAfter=9))
styles.add(ParagraphStyle(name='PDSmall',fontName='Helvetica',fontSize=8.5,leading=12.5,textColor=MUTED,spaceAfter=6))
styles.add(ParagraphStyle(name='PDLabel',fontName='Helvetica-Bold',fontSize=8,leading=11,textColor=PURPLE,spaceAfter=13))
styles.add(ParagraphStyle(name='PDCode',fontName='Courier',fontSize=8,leading=12,textColor=INK,spaceAfter=7))


def p(text,style='PDBody'):
    return Paragraph(text,styles[style])


def card(title,text,background=PALE):
    t=Table([[p(title,'PDSection')],[p(text,'PDSmall')]],colWidths=[499])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),background),('BOX',(0,0),(-1,-1),.5,LINE),
                          ('LEFTPADDING',(0,0),(-1,-1),15),('RIGHTPADDING',(0,0),(-1,-1),15),
                          ('TOPPADDING',(0,0),(-1,0),0),('BOTTOMPADDING',(0,-1),(-1,-1),11)]))
    return t


def two_column(rows,widths=(132,367)):
    data=[[p(a,'PDSmall'),p(b,'PDSmall')] for a,b in rows]
    t=Table(data,colWidths=list(widths),hAlign='LEFT')
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.5,LINE),
                          ('LEFTPADDING',(0,0),(-1,-1),10),('RIGHTPADDING',(0,0),(-1,-1),10),
                          ('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),8),
                          ('BACKGROUND',(0,0),(0,-1),colors.HexColor('#faf8fd'))]))
    return t


def footer(canvas,doc):
    canvas.saveState()
    canvas.setFillColor(PURPLE)
    canvas.drawImage(str(ROOT/'assets'/'KADOMA-print.png'),48,795,width=21,height=21,mask='auto')
    canvas.setFillColor(INK);canvas.setFont('Helvetica-Bold',12);canvas.drawString(77,801,'KADOMA PDF')
    canvas.setFillColor(MUTED);canvas.setFont('Helvetica',8);canvas.drawRightString(547,803,'KADOMA PDF / GETTING STARTED')
    canvas.setStrokeColor(LINE);canvas.line(48,783,547,783);canvas.line(48,43,547,43)
    canvas.setFont('Helvetica',7);canvas.drawString(48,28,'Version 0.28.2  |  Source + native build kit  |  6 November 2026')
    canvas.drawRightString(547,28,f'{doc.page:02}')
    canvas.restoreState()


story=[]
story += [p('YOUR NEW PDF WORKSPACE','PDLabel'),p('Your PDFs.<br/>Your workspace.','PDTitle'),
          p('KADOMA PDF is an offline-first PDF editor built around the everyday work of editing, organizing, reviewing, and exporting documents.')]
story += [card('What is included in this delivery?',
               'A working application source tree, live development preview, test suite, and separate Windows / Mac build recipes. <b>A Windows x64 build was produced and launch-verified on this machine:</b> a one-file <b>KADOMA.exe</b> that runs with no companion folder, and a portable ZIP. <b>No Windows installer and no macOS APP/DMG were built here.</b> Mac builds and all native release QA must run on the appropriate operating systems.'),Spacer(1,18)]
story += [card('New in version 0.28.2',
               '<b>External windows come to the front.</b> KADOMA still opens maximised and on top, but the moment you ask for a mail compose window, printer preferences, a file in Explorer or Windows Settings, it steps out of the way so that window is visible and usable. The on-top behaviour returns when you come back to KADOMA.'),
          Spacer(1,12)]
story += [card('New in version 0.28.1',
               '<b>Unlimited combine.</b> The right-click <b>Combine with KADOMA PDF</b> entry and the in-app merge window no longer cap the number of files. The only limit is the 500 MB combined size guard — select as many PDFs as you need.'),
          Spacer(1,12)]
story += [card('New in version 0.28',
               '<b>Dark by default.</b> The interface opens dark and the page stays white, because it is paper. The moon/sun button switches, and a choice made there is remembered.<br/>'
               '<b>Combine from Explorer.</b> Select any number of PDFs in File Explorer, right-click and choose <b>Combine with KADOMA PDF</b>: they are joined in the order you selected them and open as one document named after their folder. Nothing to configure — the menu entry is added for your user the first time the application runs.'),
          Spacer(1,12)]
story += [card('New in version 0.27',
               '<b>Fields that work in other PDF applications.</b> Every field the application creates now carries the document-wide font resources and the page link a strict reader needs. Chrome, Edge, Preview and Acrobat can all type in them; the check fills a prepared form in Chrome, with KADOMA closed.<br/>'
               '<b>The window opens filling the screen, and stays in front.</b><br/>'
               '<b>Email opens a real draft.</b> The first share option asks your mail program to compose a new message with the PDF already attached and the recipient box left empty, so you choose who gets it.'),
          Spacer(1,12)]
story += [card('New in version 0.26',
               '<b>Prepare Form.</b> A new tool that finds the places a form belongs — runs of underscores, drawn boxes, and labels ending in a colon — and adds the ones you keep as real PDF fields. Date fields carry the format Acrobat uses, so Acrobat offers its own date picker, and any reader can fill the result in.<br/>'
               '<b>500 MB documents.</b> Uploads, working documents and exports.<br/>'
               '<b>No sample document.</b> The application starts with nothing open.<br/>'
               '<b>Print:</b> orientation follows the page, paper starts at A4 and the content is scaled to fit, and two-sided printing is offered when the printer reports it.<br/>'
               '<b>Email:</b> the message can be edited, and starts as <i>Please see the attached file</i>.'),
          Spacer(1,12)]
story += [card('New in version 0.25',
               '<b>Paper and orientation in the print preview.</b> The list of paper sizes is read from the printer driver itself, so a printer that has never heard of A3 is not offered it. Choosing a paper or turning the sheet redraws the preview at once, and the job that follows is printed on it — the preview and the paper are the same setting, not two. Duplex, quality and trays stay in <b>Printer properties</b>, where the driver can describe its own options.<br/>'
               '<b>Documents open at 150%.</b> At 100% an ordinary page was too small to read comfortably. The zoom control still overrides it at any time.<br/>'
               '<b>Email drafts say what they need to.</b> The first share option now builds a message with the PDF already attached and the body <i>Please see the attached file</i>.'),
          Spacer(1,12)]
story += [card('New in version 0.24',
               '<b>Every tool, beside the document.</b> The list of tools that the home screen keeps on the right now sits on the right of the document as well, so a tool is one press away while you are reading. It is put away, and brought back, with <b>All tools</b> in the menu bar; hiding it gives the width straight back to the page.<br/>'
               '<b>One page, out as a file.</b> Right-clicking the page while scrolling now offers <b>Copy page to a file</b>: name the copy in the dialog and it is written as a one-page PDF under that name. Characters a file name cannot hold are cleaned rather than refused, and the document on screen is never changed.'),
          Spacer(1,12)]
story += [card('New in version 0.23',
               '<b>Four more of Acrobat\u2019s tools, written from scratch.</b> <b>Stamps</b> \u2014 Approved, Draft, Confidential and four more, or your own words \u2014 placed where you click, with an optional date. <b>Links</b>: drag a box, then point it at a web address or another page. <b>Page size</b>: A3 to Tabloid or a custom size, with the content, form fields and comments scaled to fit. <b>Compare</b>: two versions, page by page and word by word.<br/>'
               '<b>Everything is still local.</b> Nothing in this release sends a byte anywhere, and the comparison runs in the same offline engine as the rest.'),
          Spacer(1,12)]
story += [card('New in version 0.22',
               '<b>A Document view with seven more tools.</b> <b>Watermark</b> (text or image, faded, rotated, tiled), <b>Header &amp; footer</b> with tokens for the page, date and file name, <b>Page numbers</b> and <b>Bates numbering</b>, <b>Crop</b>, <b>Bookmarks</b> — including an outline generated from the document&rsquo;s own headings — <b>Attachments</b> carried inside the PDF, and <b>Reduce size</b>.<br/>'
               '<b>Written, not drawn.</b> Headers, footers and numbers go into the page as real text, so they can be selected and searched. A watermark is drawn over the content, faint enough to read through.')]
story += [card('New in version 0.21',
               '<b>Closing is quiet unless there is something to save.</b> The window used to ask “close this window?” every time — even for a document nobody had touched, which turned quitting into a two-click ritual. It now closes at once, and asks only when there is work that is not in a file yet: <b>Save and close</b>, <b>Close without saving</b>, or <b>Cancel</b> to stay.')]
story += [card('New in version 0.20',
               '<b>A scanned page can be edited.</b> A page that is a picture of text has nothing to click, so the text tool draws instead: <b>drag a box over the words</b> and type the replacement. The old ink is painted over with the colour sampled from the paper around it — not white, which would leave a bright rectangle on a grey scan — and the new text is written as real, selectable text. Leave the box empty to erase an area.<br/>'
               '<b>Or make the page searchable.</b> <b>Make it editable</b> still runs local OCR on that page, after which every line is clickable like any other text. If nothing is recognised, it says so instead of pretending.<br/>'
               '<b>The Date tool.</b> Pick a date from a calendar — or type it — choose a format, size and colour, then click on the page. The date is written in as selectable text, and it works on a scan, where there is nothing to edit.')]
story += [card('New in version 0.19',
               '<b>The window says what it is and nothing more.</b> The title bar reads <b>KADOMA PDF</b>; the “Offline PDF Studio” subtitle is gone, and so is it from the top of this guide.')]
story += [card('New in version 0.18',
               '<b>Protection asks for a password.</b> The Protect tool opens a prompt: the opening password typed twice, an owner password, a reveal button, and a message that names the actual problem — too short, not the same, the same as the owner password — with the button disabled until it is usable.<br/>'
               '<b>Scans become editable.</b> A page that is a picture of text now says so on the page itself, and <b>Make it editable</b> recognises it with local OCR and hands the text tool straight back — one press, then click any line.<br/>'
               '<b>A quieter top bar.</b> The “Workspace” breadcrumb and the “Offline workspace” badge are gone; the status bar still says everything on your device, and it says it better.')]
story += [card('New in version 0.17',
               '<b>One tab per open document.</b> The tabs appear when you have more than one document open; a dot means unsaved changes, and the × asks whether to save before it closes.<br/>'
               '<b>The whole document scrolls.</b> Every page is in one column now, and the page in the middle of the window is the one you are working on — the tools panel and the page number follow it. Pages are fetched as they come into view, so a long document opens quickly.<br/>'
               '<b>Right-click a page</b> for rotate left or right, extract, duplicate and delete — in the editor, in Pages, or on a thumbnail.<br/>'
               '<b>500 MB documents</b>, and the zoom opens at 150%.<br/>'
               '<b>Scans say so.</b> A page with no text layer explains that there is nothing to click and offers <b>Make this page searchable</b>, which runs OCR on that page.<br/>'
               '<b>Combining shows the result</b>, scrolled to the pages that were added, and <b>printing</b> says how many sheets are going and gives up waiting after three minutes rather than leaving an overlay that never clears.')]
story += [card('New in version 0.16',
               '<b>Odd and even pages, in one press.</b> The Pages view has a <b>Select</b> group: <b>Odd</b> picks pages 1, 3, 5…, <b>Even</b> picks 2, 4, 6…, with <b>All</b> and <b>None</b> beside them. Choose one, see the pages highlight, then press <b>Delete</b> — the same confirmation and the same undo as deleting any other selection.<br/>'
               '<b>Selection first, deletion second.</b> Nothing is removed by a single stray press: the pages about to go are on screen before they go, which is the only way to be sure that “the odd pages” means what you think it does.')]
story += [card('New in version 0.15',
               '<b>Copies, collated or not.</b> Printing more than one copy now asks how the sheets should come out. <b>Collated</b> is a complete set per copy — 1, 2, 3 then 1, 2, 3. <b>Uncollated</b> is a stack of each page — 1, 1, 2, 2, 3, 3 — which is what you want when the copies are going to be separated page by page.<br/>'
               '<b>Written out, not described.</b> The dialog shows the actual order with the real page numbers before anything is sent, and the button says what will happen: <b>Print 4 pages × 2 copies</b>. With one copy the choice is disabled, because it makes no difference.')]
story += [card('New in version 0.14',
               '<b>Page tools on every page.</b> The Pages view is a scrolling list of every page, and each one carries <b>rotate</b>, <b>extract</b> and <b>delete</b> on the page itself — no selecting a page in one place and pressing a button in another. <b>Split</b> sits beside <b>Add pages</b>, and the Home screen has a <b>Page tools</b> group for all four.<br/>'
               '<b>A print dialog that asks the questions.</b> <b>Pages</b> (all, the current page, or a range like <b>1-3, 5</b>), <b>Copies</b>, and <b>Printer properties…</b>, which opens the printer driver&rsquo;s own settings for paper, orientation and quality. The preview follows the range, the arrows step through the pages you chose, and the button says exactly how many sheets will come out.<br/>'
               '<b>Refused rather than guessed.</b> A range that runs past the last page disables Print and says why, instead of printing something else.')]
story += [card('New in version 0.13',
               '<b>It is called KADOMA PDF, and it has its own mark.</b> The name is on the window, the executable, the installer, the registry entry, the share folder and every export, and the supplied artwork is the only icon source — one image resampled to every size the application needs.<br/>'
               '<b>A home screen, the way a PDF application should open.</b> A <b>Search tools</b> field, a <b>Create &amp; Edit</b> grid, a <b>Forms &amp; Signatures</b> grid, and the same tools listed down the right. Every card runs the real action: Create PDF, Combine Files, Organize Pages, Edit PDF, Export PDF, Scan &amp; OCR, Fill &amp; Sign, Sign and Protect. The documents already open are listed under <b>Recent</b>.<br/>'
               '<b>And the document still opens for reading</b> once you are in it: no text boxes, no edit cursor, Edit text one press away.')]
story += [card('New in version 0.12',
               '<b>It opens for reading, not for editing.</b> A document now arrives in a <b>reading view</b>: the page is shown as it is, with no text boxes, no cursor and nothing waiting to be clicked. <b>Edit text</b> is one press away in the toolbar, and a double-click on any line still starts an edit straight away; <b>Esc</b> goes back to reading.<br/>'
               '<b>Dark and light.</b> The button at the top right of the window switches the interface between light and dark, and remembers which one you chose. The <b>page stays white</b> in both: it is paper, and it should look on screen the way it will look on the printer.<br/>'
               '<b>A thinner frame around the page.</b> The bars above the page are shorter and the buttons in the document bar are icons with their names on hover, so the page is about seventy pixels taller and half a screen wider than before.')]
story += [card('New in version 0.11',
               '<b>Print preview, and a printer to choose.</b> The <b>Print</b> button and Ctrl / Command P open a preview instead of firing a job at whatever printer happens to be default. The preview is the <b>sheet</b>, not the page: its paper size and its margins come from the chosen printer, and the page is drawn inside them at the scale the printer is given. Choosing another printer redraws it, because another printer may load another paper size.<br/>'
               '<b>A driver that saves to a file is named, not offered.</b> &ldquo;Microsoft Print to PDF&rdquo;, XPS, OneNote and fax drivers would each open a Save dialog owned by another process and wait, so the preview says which one it skipped and why.<br/>'
               '<b>Page by page.</b> The arrows under the preview step through the document, and <b>Export instead</b> is one press away when the paper is not what you wanted.')]
story += [card('New in version 0.10',
               '<b>Save, and Save as.</b> <b>Save</b> writes the document over the file you opened, in one press or with Ctrl / Command S. <b>Save as</b> asks where the copy should go, and the document follows it, so later saves keep writing there. The header says <b>Saved</b> or <b>Unsaved changes</b> for the document on screen.<br/>'
               '<b>It refuses rather than guesses.</b> If the file changed on disk since you opened it &mdash; a sync client, another editor &mdash; Save stops and says so instead of replacing somebody else\'s work. Save as is still offered.<br/>'
               '<b>A failed write cannot spoil a good file.</b> The PDF is written beside the destination and moved into place in one step, so a half-written file never lands on top of a working one. A password-protected file keeps its encryption, both passwords and its permissions when it is saved over.<br/>'
               '<b>Nothing is written until you say so.</b> Opening, editing and closing still touch no file: only Save, Save as and export write anything.')]
story += [card('New in version 0.9',
               '<b>A menu across the top.</b> The view tabs and the panel switches moved into a bar across the top of the window, and the bar folds to a thin strip with one press. The page now begins at the left edge of the window: nothing sits beside it that you did not ask for.<br/>'
               '<b>Two panels, both yours to switch.</b> <b>Pages</b> shows the thumbnail column, <b>Tools</b> shows the settings panel, and <b>Focus</b> puts both away. The thumbnail column starts away, because the Pages view already shows every page when you want to look at them.<br/>'
               '<b>The page as large as the window allows.</b> Fit width now genuinely fits &mdash; it used to stop at 125%, which left a quarter of an ordinary window empty. The page is rendered at the size it is shown, so it stays sharp when it is large, and the zoom control still overrides the fit at any time, from 50% to 300%.')]
story += [card('New in version 0.8',
               '<b>Every tool on one side.</b> The view switcher, the page thumbnails and the tools panel now share the left column, with the page filling everything to their right. Nothing sits on the far side of the page any more.<br/>'
               '<b>Merge what is already open, first.</b> The Merge window lists the documents already open in KADOMA above the file picker, with an <b>Add all</b> button when there is more than one. Two open documents combine in one press, in either direction.<br/>'
               '<b>An AI reading, offline by default.</b> A new <b>Read</b> view summarises the document by quoting the sentences that best represent it, and turns ordinary words into real PDF form fields. Neither is a language model and the app says so on every result. A model of your own can be connected, and is then the only thing that ever leaves this computer — only the extracted text, only after you agree, and the key is never written to disk.')]
story += [card('New in version 0.7',
               '<b>Several documents at once.</b> Opening a document no longer closes the one before it. The workspace keeps the last six open, and the button beside the document name lists them with their page count, size and whether they have been edited &mdash; switch between them, or close one. The current document asks before closing if it has unexported edits.<br/>'
               '<b>Merge what is already open.</b> The <b>Merge</b> window lists the documents already open in KADOMA, so one can be combined into another without being found on disk and uploaded again. An open protected document is not unlocked twice, because the password already used to open it is reused. Open documents and files from disk can be mixed in any order.<br/>'
               '<b>A panel you can put away.</b> The tools panel on the right has a pin. Pinned &mdash; the default &mdash; it stays open. Unpinned it auto-hides to a narrow rail and comes back when you hover it or press its tab, floating over the page so the document you are reading never shifts sideways.')]
story += [card('New in version 0.6',
               '<b>A split window.</b> Press <b>Split</b> to break one PDF into several files, in whichever of three ways suits the job: <b>equal blocks</b> of pages (10 pages each, for example), a <b>chosen number of files</b> divided as evenly as the page count allows, or <b>your own page ranges</b> (1-3, 4-6, 7-10), one file per range.<br/>'
               '<b>You see every file before it exists.</b> The window lists the files it is about to create, with the page span of each one in its name. The list, the file count and the button label all come from the engine, so the preview and the result cannot disagree.<br/>'
               '<b>Refusals instead of surprises.</b> A range that runs past the last page, a request for more files than there are pages, or a block size of zero is refused with the reason, before anything is written. A range that leaves pages out is allowed &mdash; extracting part of a document is a real thing to want &mdash; but the window says which pages are in no part. Splitting only ever reads: your open document is not touched, and no undo step appears.')]
story += [card('New in version 0.5',
               '<b>A merge window.</b> Press <b>Merge</b> and add PDFs, images or Office files. The window lists each one with its real page count, and you can reorder the list, remove a file you picked by mistake, or take only some pages of a source (2-3, 7) instead of all of it. A password-protected file is unlocked in the window rather than refused.<br/>'
               '<b>Three destinations.</b> Add the result to the end of the document you have open, insert it in front of any page of it, or build a brand-new PDF that leaves the open document untouched. Dropping several files onto the window opens the same list.<br/>'
               '<b>Nothing is guessed.</b> The button says how many pages the result will have, and that count follows the page ranges as you type them. A range that runs past the end of a file is refused rather than quietly shortened, and the whole combine is one undoable step that leaves your document exactly as it was if any file fails. Limits: no file count cap, 500&nbsp;MB combined, 500 pages.')]
story += [card('New in version 0.4',
               '<b>Date fields with a calendar.</b> A fourth field type beside Text, Checkbox and Dropdown. Choose the format once, then pick a day from a calendar instead of typing one. A date that does not exist in that format is refused rather than rolled over.<br/>'
               '<b>Print, straight to a printer.</b> Every page is rendered at print quality and sent to your printer directly &mdash; no other PDF program involved, and the app&rsquo;s own buttons can never appear on paper. Ctrl / Command P does the same thing.<br/>'
               '<b>Clear a filled-in form.</b> One button empties every filled text, date, checkbox and dropdown value, leaves the fields and the page alone, and can be undone.')]
story += [card('New in version 0.3',
               '<b>Arabic and right-to-left text.</b> Arabic, Hebrew, Persian and Urdu are shaped, joined and laid out right-to-left, read back as the letters you typed, and searchable; the in-place editor switches direction for them.<br/>'
               '<b>Send and share.</b> Write a copy to a share folder, then build an email <b>with the file attached</b>, open a plain mail draft, copy the file itself, or show it in its folder. KADOMA never sends anything.<br/>'
               '<b>Be your default PDF app.</b> Register KADOMA as a PDF handler for your user account, then confirm it in Windows Settings. Double-clicked PDFs open in the window you already have.')]
shot=ROOT/'qa'/'workspace.png'
if shot.exists():
    image=Image(str(shot),width=499,height=346.5)
    story += [image,Spacer(1,8),p('The real editor interface, shown with the locally generated sample report.','PDSmall')]
story += [p('Hosted preview vs. offline desktop','PDSection'),p('The hosted preview sends uploaded files to its workspace. Use only sample or non-sensitive documents there. Run the desktop build on your own computer for local processing.','PDSmall')]

story += [p('A simple, practical flow.','PDHeading'),p('Start with the sample PDF, or open your own file in a local desktop installation.')]
steps=[
 ('01 / Open or create','Open a PDF, an image, local HTML/text, or an Office document. Office imports need LibreOffice. Use the plus button for a new blank PDF.'),
 ('02 / Keep several documents open','Opening a document does not close the one before it. The workspace holds the last six, and the button beside the document name lists them with their page count and whether they have been edited. Switch between them there, or close one &mdash; the document on screen asks first if it has unsaved changes. Documents are written to disk only when you save or export, so anything unsaved is gone when you close it or quit.'),
 ('03 / The menu, the panels, and the page','The tabs for Edit, Pages, Convert, Forms, Protect, OCR and Read are in a bar across the top, along with three switches: <b>Pages</b> for the thumbnail column, <b>Tools</b> for the settings panel, and <b>Focus</b> to put both away and give the page the whole window. The chevron on the left folds the bar itself away. A document opens in the <b>reading view</b>: nothing is armed until you choose a tool. The moon button at the top right switches the whole interface between light and dark, and the page stays white in both. The page is fitted to the width it has, so it grows as panels go; the zoom control still has the last word, from 50% to 300%, with Fit width and Fit page. The tools panel also has a pin of its own: unpinned it collapses to a narrow rail and comes back when you hover it or press its tab.'),
 ('04 / Edit text right on the page','Click a line of text and an editable box opens over it, matching its size, colour, and rotation. Type directly over the words, then press Enter to apply or Esc to cancel; clicking away also applies, and clearing the box deletes that line. Double-click any text to start an edit. Longer text grows into free space and keeps its font size. The side panel offers the same edit with exact size, colour, and family controls. Add new text by drawing an area. Image and Sign ask you to choose or create an image, then draw its placement area.'),
 ('05 / Put pages in order','Use Pages to select, rotate, duplicate, extract, or remove pages. Drag thumbnails to reorder. Cloned form fields get independent, unique names.'),
 ('06 / Combine several files','Press <b>Merge</b>. The documents already open in KADOMA are listed first, with an <b>Add</b> button each and <b>Add all</b> when there is more than one &mdash; so a document in the app is combined without being found on disk again. PDFs, images and Office files can be added below, or dropped onto the window. The list shows each file&rsquo;s real page count. Reorder it, remove a file, or restrict a source to some pages (<b>2-3, 7</b>). A protected file asks for its password here. Then choose where the pages go: <b>the end</b> of the open document, <b>inside it</b> in front of any page, or a <b>new PDF</b> that leaves the open document untouched. The button tells you how many pages the result will have.'),
 ('07 / Split one PDF into several','Press <b>Split</b> to break the open document into several files. Choose how the cuts are decided: <b>equal blocks</b> of pages, a <b>number of files</b>, or <b>your own page ranges</b>. The window lists every file it is about to create, with the pages of each one in its name, and the button says how many files you will get. A single part comes back as a plain PDF; several arrive as one ZIP archive. Your open document is never changed by a split.'),
 ('08 / Read it for you','Open <b>Read</b> for two tools that run entirely on this computer. <b>Summarise</b> quotes the sentences that best represent the document, chosen by word frequency, and lists its key terms; it does not paraphrase and cannot answer questions, and it says so. <b>Build a form from a prompt</b>: type &ldquo;full name, email, date signed, and a checkbox to agree&rdquo; and real PDF fields are laid out on a new page in one undoable step. A model of your own can be connected if you want one &mdash; that is the only part of KADOMA that can leave your computer, only the extracted text is sent, only after you agree, and the key is never written to disk.'),
 ('09 / Fill and review','Create text, date, checkbox, and dropdown fields, or fill existing supported fields. A date field opens a calendar to pick a day from, and refuses anything that is not a real date in its own format. <b>Clear</b> empties every filled value at once &mdash; the fields and the page stay put, and it can be undone. Add highlights and comments; these annotations are stored inside the exported PDF.'),
 ('10 / Protect the right way','Use separate opening and owner passwords for an AES-256 protected copy. Use Redact to remove underlying content. Redaction clears undo history and strips attachments and metadata.'),
 ('11 / Send it on','Press <b>Share</b> to write a copy into a temporary share folder. From there you can build an email <b>with the file attached</b> (a real message handed to your mail program), open a plain mail draft with the file on your clipboard, copy the file itself to paste into any chat or mail client, or show it in its folder to drag somewhere. KADOMA never sends anything and stores no mail password. A "mailto" link cannot carry an attachment, which is why the first option builds a real message instead. Desktop app only.'),
 ('12 / Print it','Press <b>Print</b> (or Ctrl / Command P) to open the <b>print preview</b>. The sheet on the left is the paper the chosen printer will use, with the margins it cannot reach; the arrows under it step through the pages, and the list on the right chooses the printer. <b>Print</b> sends every page at print quality. Because only the document&rsquo;s pages are drawn, the interface itself can never reach paper. A driver that saves to a file &mdash; &ldquo;Print to PDF&rdquo;, XPS, OneNote, fax &mdash; is named and skipped rather than started, because it would wait on a Save dialog you cannot see. Desktop app only.'),
 ('13 / Make it your PDF app','Press the default-app button in the toolbar and register KADOMA. Windows then opens its Settings page so you can confirm it. Windows deliberately does not let any application claim a file type silently, so that confirmation is yours to make. After that, double-clicking a PDF opens it in the running window rather than starting a second copy.'),
 ('14 / Save your work','<b>Save</b> writes over the file you opened; <b>Save as</b> puts the copy where you choose and the document follows it. A document opened from the file picker, created blank, or converted from Word has no file behind it yet, so its first Save asks where to put the copy. If the file changed on disk since you opened it, Save refuses and tells you.'),
 ('15 / Export a copy','Export PDF, Word, Excel, PowerPoint page-image slides, image ZIPs, plain text, or separate-page PDF ZIPs. Export always writes a new file and leaves your document where it is. Reopen and check converted or redacted output before sharing.')]
for title,text in steps:
    story += [p(title,'PDSection'),p(text)]
share_shot=ROOT/'qa'/'share-panel.png'
if share_shot.exists():
    story += [Spacer(1,10),Image(str(share_shot),width=430,height=round(430*675/1080)),Spacer(1,6),
              p('The share panel. Every option is real: nothing is sent by KADOMA, and the panel says so plainly.','PDSmall')]
story += [Spacer(1,8),card('Keyboard shortcuts','Ctrl / Command O opens a file; <b>S saves over the file you opened; Shift S saves a copy somewhere else</b>; <b>P opens the print preview, where the printer is chosen</b>; F searches; Z undoes; Shift Z redoes. Double-click text to edit it in place; Enter applies and Esc cancels an in-place edit; Shift + Enter adds a line inside the box. V selects, E edits, T adds text, H highlights, C comments, R redacts. Page Up/Down navigates.')]
story += [PageBreak()]

story += [p('Build for your computers.','PDHeading'),p('Windows and macOS need separate binaries. One Windows EXE cannot run natively on a Mac. Apple Silicon and Intel are separate Mac targets.')]
story += [two_column([
 ('<b>Windows x64</b>','<b>Already built:</b> KADOMA-0.5.0-Windows-x64-standalone.exe, one file you can copy anywhere, plus a portable ZIP. An optional Setup.exe needs Inno Setup 6. <b>If you want KADOMA as your default PDF app, use the portable ZIP</b>: it hands a double-clicked PDF to the running window in about 2.6 seconds, where the one-file build takes about 32 seconds because it unpacks itself first.'),
 ('<b>Apple Silicon</b>','Expected: <b>KADOMA-0.5.0-macOS-arm64.dmg</b>, containing a native APP bundle. Build on an M-series Mac or the supplied arm64 job.'),
 ('<b>Intel Mac</b>','Expected: <b>KADOMA-0.5.0-macOS-x86_64.dmg</b>, containing an Intel APP bundle. Build on Intel or the supplied Intel job.')]),
          p('Option A / Run the included native workflow','PDSection'),
          p('Put the source folder contents in a repository, preserving the hidden .github folder. Open its Actions area, select <b>Desktop installers</b>, and run it manually. Download artifacts from all three successful jobs. This workflow has not been run in your account.'),
          p('Option B / Build on your own machines','PDSection'),
          p('<b>Windows:</b> install 64-bit Python (3.12 recommended), then run <b>build-windows.cmd</b>. That produces both the one-file EXE and the portable ZIP. Run <b>python scripts/build.py --mode onefile</b> for just the single file, or <b>--mode both</b> for everything plus SHA256SUMS.txt. Add Inno Setup 6 for a Setup.exe.'),
          p('<b>Mac:</b> use native Python 3.11-3.13 and run <b>bash build-macos.command</b>. Repeat on the other architecture if you need both. The build scripts produce an APP/DMG and include a packaged-engine smoke test.'),
          card('Signing and installation are separate release steps.','Windows builds are not Authenticode-signed. Mac builds use ad-hoc signing, not Apple Developer ID signing or notarization. SmartScreen or Gatekeeper may block downloads. Review source and build locally for trusted testing; proper signed distribution requires certificates and native release QA.'),
          p('Run source before building','PDSection'),
          p('Create a virtual environment, install requirements-desktop.txt, then run desktop.py. Detailed Windows and Mac commands are in README.md. Windows also needs Microsoft Edge WebView2; macOS uses its built-in WKWebView.','PDSmall')]
story += [PageBreak()]

story += [p('Useful tools. Honest limits.','PDHeading'),p('This first version is not an Acrobat-equivalent product. The scope is intentionally local and practical.')]
story += [two_column([
 ('<b>Text editing</b>','Direct in-place editing: click a line and type over it. Longer text grows into free space and keeps its size; substitute font families are chosen from the original font. Editing is one visual line at a time, with no font-identical document-wide reflow or arbitrary vector-object editing.'),
 ('<b>Arabic / RTL</b>','Arabic, Hebrew, Persian and Urdu shape, join and lay out right-to-left correctly, read back as the letters you typed, and are searchable. Two honest limits: Arabic-Indic digits may return in the equivalent Persian variant (they look the same and search folds them, but extracted text is not byte-identical), and the bundled fallback font is approximate. Font quality decides how faithfully Arabic reads back, so KADOMA <b>measures the fonts on your machine</b> and reports whether it found an exact or only an approximate one. Mixed Arabic/Latin lines are not separately verified.'),
 ('<b>Sharing</b>','KADOMA prepares the file and hands it to your own mail program; it never sends anything and stores no mail credentials. A "mailto" link cannot carry an attachment, so the attach option builds a real message instead, and the draft option says plainly that it copies the file to your clipboard. Sharing and default-app registration are desktop-only.'),
 ('<b>Word / Excel</b>','Best-effort text, table and image extraction. Word layout and reading order may differ. Excel detects table geometry, not accounting truth: check columns, percentages and totals.'),
 ('<b>PowerPoint</b>','Each page becomes a slide image. Its text and graphics are not individually editable slide objects.'),
 ('<b>Forms / signatures</b>','Text fields, checkboxes and dropdowns are real PDF fields. Typed/drawn signatures are images, not certificate signing or identity verification.'),
 ('<b>OCR</b>','Local Tesseract makes saved searchable raster PDF pages at 200 DPI, up to 20 pages per run. Selected-page forms/annotations are flattened. Recognition and localized white-background scan edits must be checked.'),
 ('<b>Privacy / security</b>','Local desktop processing; in-memory working documents and bounded undo. Uploads/converters may use temporary files. Redaction does not alter the original file or past backups. Password permission flags depend on reader enforcement.'),
 ('<b>Not included</b>','Cloud sync, live multi-user review, remote signature requests/status, AI summaries or Q&amp;A, certificate validation, and production signing/notarization.')]),
          p('Optional local engines','PDSection'),
          p('<b>LibreOffice:</b> Word/Excel/PowerPoint to PDF. Install the usual desktop version; KADOMA detects standard Windows/Mac locations. It is an external application, not an OS-level sandbox.'),
          p('<b>Tesseract:</b> OCR plus language packs. English: eng; Arabic: ara; both: eng+ara. On a Mac with Homebrew: <font name="Courier">brew install tesseract tesseract-lang</font>. On Windows, install a trusted build or set PAPERDESK_TESSERACT. Restart KADOMA after installation.'),
          p('<b>WebView2:</b> required Windows browser runtime, not bundled. The offline app uses it only for its local interface.','PDSmall')]

story += [p('Tested here. Release there.','PDHeading'),p('The development environment was Windows 11 x64 with Python 3.13.14. Native Windows and Mac installation tests cannot be inferred from these results.')]
story += [two_column([
 ('<b>350 engine + API tests / passed</b>','Two are skipped because they need optional local engines. Thirteen new ones cover the topmost hand-off: when the application steps aside, when it takes the front back, and that every route which opens an external window asks first. Covers direct on-page editing, run grouping, text deletion, Unicode and right-to-left text, rotations, merging and splitting, documents kept open, the offline summariser and prompt parser, the model client against a stub endpoint, form fields and filling, annotations, true text/image redaction, attachment stripping, permissions, encryption preservation, real exports, Office import, OCR, printing, saving, sharing and registration.'),
 ('<b>235 controls / 0 dead</b>','A dead-button audit reads every id in the interface and every control the interface renders from JavaScript, then drives each one in a real Chromium and requires an observable result: 274 static steps and 82 live steps, 356 passed, 0 problems. It fails on any uncaught JavaScript error, any 5xx from the engine, and any request leaving the machine — none occurred.'),
 ('<b>11 direct-edit checks / passed</b>','A real browser clicks, types over text, cancels, deletes a line, and syncs the side panel. Every claim is asserted against the reopened exported PDF, including that a longer line keeps its original font size and that a grown box never overlaps the next table cell.'),
 ('<b>12 sharing checks / passed</b>','Drives the real share and default-app dialogs and asserts the requests carry the prepared path, recipient, subject and attachment flag. Arabic typed through the interface must read back as logical letters with the editor switched to right-to-left.'),
 ('<b>20 browser workflows / passed</b>','Browser actions, real downloaded files, signature placement, page management, Excel export, encryption, OCR and scan-text replacement. No JavaScript runtime errors or external page-resource requests.'),
 ('<b>2 privacy + 8 save checks / passed</b>','Hosted browser mode is labelled accurately and asks for consent before the first file upload. Desktop-mode saving writes over the opened file, follows Save as, refuses a file changed behind its back, and writes nothing when the dialog is cancelled. These are not an independent privacy or security audit.'),
 ('<b>Windows build / passed</b>','Both Windows targets were built here and each passed a 20-check frozen self-test, including Arabic write/read-back/search and building a real .eml with the PDF attached. The one-file EXE was then launched as a user would: it opened a loopback service on 127.0.0.1, refused an unauthenticated request with HTTP 401, served its own interface, and opened a native window. A further 5 checks confirmed a second launch hands its file to the running copy and exits, with no duplicate window and no duplicate service. All three artifacts re-hashed to match SHA256SUMS.txt. A separate 10-check probe drove a real WebView2 window: an external window sat behind KADOMA (Z-order 1) while the topmost style was set, then moved in front (Z-order 0) after the release.'),
 ('<b>Still outstanding</b>','The Windows installer (Inno Setup not installed here); both Mac APP/DMG builds and launches; typing by hand under WebView2 and WKWebView; confirming the default app in the real Windows Settings page; right-to-left font quality on machines without Arial or Tahoma; native Save-dialog behavior; OS minimum versions; signing/notarization; real-machine performance and independent security review. <b>No real language-model provider was used to verify the optional model connection</b> &mdash; it was exercised end to end against a stub endpoint on this computer, which proves the request, the key handling, the reply parsing and every error path, but not how any particular provider behaves.')]),
          Spacer(1,18),card('Before using confidential or important documents','Use the local desktop version, not the hosted demo. Keep an original backup. Export edits before closing. Reopen the exported file and inspect redactions and extracted data. Existing certificate signatures can be invalidated by modifications. This is an initial, not independently security-audited application.'),
          p('Included source and documentation','PDSection'),
          p('<b>README.md</b> - installation and native build instructions<br/><b>FEATURES.md</b> - requested features vs. implemented scope<br/><b>QA_REPORT.md</b> - actual checks and outstanding acceptance tests<br/><b>LICENSE / THIRD_PARTY_NOTICES.md</b> - licensing, especially PyMuPDF/MuPDF'),
          p('Open-source licensing','PDSection'),
          p('KADOMA original code uses GNU AGPL-3.0-or-later. PyMuPDF/MuPDF has AGPL or commercial licensing conditions. Read the included notices before commercial or closed-source distribution. Native releases may need upstream corresponding sources as required by their licenses; the app source ZIP is not a guarantee of complete release-license compliance.','PDSmall')]

document=SimpleDocTemplate(str(TARGET),pagesize=(595,842),leftMargin=48,rightMargin=48,topMargin=78,bottomMargin=58,
                           title='KADOMA — Getting Started',author='KADOMA project')
document.build(story,onFirstPage=footer,onLaterPages=footer)
print(TARGET)
