"""Click Save in a real browser and check what actually reached the disk.

This is the one check that can prove the feature rather than describe it. It
runs against a local server started with `--qa-desktop`, stands in for the two
things a browser cannot provide — the native file dialogs — and then presses the
real buttons. Everything after the dialog is the shipping code: the request, the
engine's write, the temporary file, the move into place, and the header.

    python run_preview.py --port 8020 --qa-desktop
    python scripts/check_save.py --base-url http://127.0.0.1:8020

The file on disk is compared before and after, so a passing run means a real PDF
changed on a real filesystem.
"""
from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path
from urllib.parse import urlparse

import pymupdf as fitz
from playwright.sync_api import sync_playwright, expect
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from support.demo_document import make_demo


def make_pdf(path: Path, text: str):
    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((72, 120), text, fontsize=20)
        path.write_bytes(doc.tobytes(deflate=True))


def text_of(path: Path) -> str:
    with fitz.open(path) as doc:
        return '\n'.join(page.get_text() for page in doc)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', default='http://127.0.0.1:8020')
    parser.add_argument('--output', default='qa')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    work = output / 'save-work'
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)

    original = work / 'Save check.pdf'
    copy = work / 'Save check copy.pdf'
    make_pdf(original, 'BEFORE SAVING')
    steps, errors, external, calls = [], [], [], []

    def record(name):
        print('PASS:', name, flush=True)
        steps.append(name)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        page.set_default_timeout(35000)
        page.on('pageerror', lambda error: errors.append(str(error)))
        allowed = urlparse(args.base_url).netloc
        page.on('request', lambda request: external.append(request.url)
                if request.url.startswith(('http://', 'https://')) and urlparse(request.url).netloc != allowed else None)
        page.on('request', lambda request: calls.append((urlparse(request.url).path,
                                                         request.post_data or ''))
                if request.method == 'POST' and '/save' in request.url else None)

        # The native dialogs, replaced by answers the test decides. Nothing else
        # about the desktop shell is simulated.
        page.add_init_script("""
            window.__qaOpen = null;
            window.__qaSave = null;
            window.pywebview = {api: {
                choose_open_path: async () => window.__qaOpen || {cancelled: true},
                choose_save_path: async () => window.__qaSave || {cancelled: true}
            }};
        """)

        page.goto(args.base_url, wait_until='networkidle')
        # The application ships no sample document, so the check opens the
        # report it works on through the same file picker a person uses.
        report = output / 'report.pdf'
        if not report.exists():
            report.write_bytes(make_demo())
        page.locator('#file-input').set_input_files(str(report))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        # The application opens on its home screen. These checks are about the
        # document, so step into it the way a person does: the Edit tab, then the
        # Edit text tool where the check needs text boxes on the page.
        page.click('#navigation [data-view="edit"]')

        assert page.evaluate('() => state.capabilities.desktop') is True, \
            'the server is not in desktop mode; start it with --qa-desktop'

        # ---- open by path, the way a double-click does ------------------------
        page.evaluate('path => { window.__qaOpen = {path}; }', str(original))
        page.click('#open-document')
        expect(page.locator('#document-name')).to_have_text('Save check.pdf', timeout=20000)
        assert page.evaluate('() => state.doc.path') == str(original)
        assert page.evaluate('() => state.doc.canSave') is True
        assert page.inner_text('#document-change') == 'On this device'
        record('Opening a file by path gives the document somewhere to save to')

        # ---- an edit, made the way the application makes one ------------------
        page.evaluate("""async () => {
            await perform({action:'add_text', page:0, rect:[60,300,420,340],
                           text:'AFTER SAVING', size:18, color:'#111111', family:'sans-serif'},
                          'Adding text…');
        }""")
        expect(page.locator('#document-change')).to_have_text('Unsaved changes')
        assert 'AFTER SAVING' not in text_of(original), 'the edit reached the disk before Save was pressed'
        record('An edit stays in memory: the file on disk is untouched until Save')

        # ---- Save ------------------------------------------------------------
        before = original.stat().st_mtime_ns
        time.sleep(0.02)
        page.click('#save-document')
        expect(page.locator('#toast-stack')).to_contain_text('Saved to Save check.pdf', timeout=20000)
        assert 'AFTER SAVING' in text_of(original), 'Save did not write the edit to the file'
        assert original.stat().st_mtime_ns > before
        assert page.inner_text('#document-change') == 'Saved'
        assert page.evaluate('() => state.doc.dirty') is False
        assert [path for path, _ in calls] == ['/api/documents/%s/save' % page.evaluate('() => state.doc.id')]
        record('Save writes the edit over the file it was opened from, and the header says Saved')

        # ---- Save as ---------------------------------------------------------
        page.evaluate('path => { window.__qaSave = {path}; }', str(copy))
        page.click('#save-as-document')
        expect(page.locator('#toast-stack')).to_contain_text('Saved as Save check copy.pdf', timeout=20000)
        assert copy.is_file() and 'AFTER SAVING' in text_of(copy)
        expect(page.locator('#document-name')).to_have_text('Save check copy.pdf')
        assert page.evaluate('() => state.doc.path') == str(copy)
        record('Save as writes the copy, and the document follows it')

        # ---- a later Save goes to the copy, not back to the original ---------
        page.evaluate("""async () => {
            await perform({action:'add_text', page:0, rect:[60,380,420,420],
                           text:'SECOND EDIT', size:18, color:'#111111', family:'sans-serif'},
                          'Adding text…');
        }""")
        page.click('#save-document')
        expect(page.locator('#toast-stack')).to_contain_text('Saved to Save check copy.pdf', timeout=20000)
        assert 'SECOND EDIT' in text_of(copy)
        assert 'SECOND EDIT' not in text_of(original)
        record('After Save as, Save keeps writing to the copy and never to the original')

        # ---- somebody else changed the file: refuse, do not overwrite --------
        make_pdf(copy, 'CHANGED BY ANOTHER PROGRAM')
        page.evaluate("""async () => {
            await perform({action:'add_text', page:0, rect:[60,460,420,500],
                           text:'THIRD EDIT', size:18, color:'#111111', family:'sans-serif'},
                          'Adding text…');
        }""")
        page.click('#save-document')
        expect(page.locator('#toast-stack .toast.error')).to_contain_text('changed on disk', timeout=20000)
        assert 'CHANGED BY ANOTHER PROGRAM' in text_of(copy), 'the other program\'s change was overwritten'
        record('A file changed by another program is refused rather than overwritten')

        # ---- cancelling the dialog writes nothing ----------------------------
        page.evaluate('() => { window.__qaSave = {cancelled: true}; }')
        before = copy.stat().st_mtime_ns
        page.click('#save-as-document')
        page.wait_for_timeout(700)
        assert copy.stat().st_mtime_ns == before
        assert not page.is_visible('#modal')
        record('Cancelling the save dialog writes nothing and opens no other window')

        page.screenshot(path=output / 'save-after.png')
        assert not external, external
        assert not errors, errors
        record('No JavaScript errors and no external requests during the run')
        browser.close()

    print(f'\n{len(steps)} checks passed.')
    (output / 'save-checks.json').write_text(json.dumps(
        {'checks': steps, 'errors': errors, 'externalRequests': external,
         'workFolder': str(work)}, indent=2), encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
