"""Icon assets, derived from the supplied KADOMA artwork.

The artwork lives in `assets/kadoma-source.jpg` and is the only image input:
every size below is resampled from it, so the icons cannot drift apart. The
rounded square is cut out with a transparent mask, because the source has white
corners and a white square looks wrong on a dark taskbar or dock.

    python scripts/make_icons.py
"""
from __future__ import annotations

import io
import struct
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'assets' / 'kadoma-source.jpg'
ASSETS = ROOT / 'assets'
STATIC = ROOT / 'app' / 'static'

# The artwork is a rounded square that fills its frame; this is its corner
# radius as a fraction of the side.
CORNER = 0.225


def rounded(image: Image.Image, radius_fraction: float = CORNER) -> Image.Image:
    """The same picture with its corners cut away, on transparency."""
    side = image.size[0]
    mask = Image.new('L', (side, side), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, side - 1, side - 1),
                                           radius=round(side * radius_fraction), fill=255)
    out = image.convert('RGBA')
    out.putalpha(mask)
    return out


def square(image: Image.Image, side: int) -> Image.Image:
    return image.resize((side, side), Image.LANCZOS)


def icns(images: dict[int, Image.Image], target: Path) -> None:
    """A minimal .icns writer: PNG chunks, which is what macOS reads.

    Pillow cannot write ICNS, and shelling out to `iconutil` only works on a
    Mac, so the container is assembled here: a header, then one PNG per type
    code, each with its own length.
    """
    codes = {128: b'ic07', 256: b'ic08', 512: b'ic09', 1024: b'ic10'}
    chunks = b''
    for size, code in codes.items():
        if size not in images:
            continue
        buffer = io.BytesIO()
        images[size].save(buffer, 'PNG')
        payload = buffer.getvalue()
        chunks += code + struct.pack('>I', len(payload) + 8) + payload
    target.write_bytes(b'icns' + struct.pack('>I', len(chunks) + 8) + chunks)


def main() -> None:
    if not SOURCE.exists():
        raise SystemExit(f'The artwork is missing: {SOURCE}')
    art = Image.open(SOURCE).convert('RGB')
    side = min(art.size)
    art = art.crop(((art.width - side) // 2, (art.height - side) // 2,
                    (art.width + side) // 2, (art.height + side) // 2))
    master = rounded(art)

    master.resize((1024, 1024), Image.LANCZOS).save(ASSETS / 'KADOMA.png')
    master.save(ASSETS / 'KADOMA.ico',
                sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    icns({size: square(master, size) for size in (128, 256, 512, 1024)}, ASSETS / 'KADOMA.icns')

    # The mark on its own — the K, without the wordmark — for the 20 px brand in
    # the top bar and for the browser tab, where a wordmark would be a smudge.
    mark = art.crop((round(side * .18), round(side * .05), round(side * .84), round(side * .71)))
    mark = mark.resize((128, 128), Image.LANCZOS)
    rounded(mark, .22).save(STATIC / 'logo.png')

    # A small copy for print. ReportLab embeds whatever file it is given, and a
    # 1024 px PNG stamped on every page of the guide made the PDF 1.8 MB.
    square(master, 96).save(ASSETS / 'KADOMA-print.png')

    print('Wrote assets/KADOMA.png, .ico, .icns, KADOMA-print.png and app/static/logo.png')


if __name__ == '__main__':
    main()
