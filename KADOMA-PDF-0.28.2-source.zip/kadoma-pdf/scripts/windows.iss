; Build using Inno Setup 6 on Windows. This is an installer, not a macOS binary.
; The version must be supplied, because a stale default here does not fail — it
; silently produces a correctly built installer labelled with the wrong release.
; scripts/build.py passes /DAppVersion=<app version> automatically.
#ifndef AppVersion
  #error Pass /DAppVersion=<version> on the ISCC command line, or build with scripts/build.py.
#endif

[Setup]
AppId=KADOMA.OfflinePDFStudio
AppName=KADOMA PDF
AppVersion={#AppVersion}
AppPublisher=KADOMA contributors
DefaultDirName={localappdata}\Programs\KADOMA PDF
DefaultGroupName=KADOMA PDF
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\release
OutputBaseFilename=KADOMA-PDF-{#AppVersion}-Windows-x64-Setup
SetupIconFile=..\assets\KADOMA.ico
UninstallDisplayIcon={app}\KADOMA.exe
LicenseFile=..\LICENSE
InfoBeforeFile=..\assets\INSTALL_NOTES.txt
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
CloseApplications=yes

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
Source: "..\dist\KADOMA\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{userprograms}\KADOMA"; Filename: "{app}\KADOMA.exe"; WorkingDir: "{app}"
Name: "{userdesktop}\KADOMA"; Filename: "{app}\KADOMA.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\KADOMA.exe"; Description: "Open KADOMA PDF"; Flags: nowait postinstall skipifsilent
