"""Verify that double-clicking a PDF reuses the running window.

This is the behaviour the "default PDF app" feature is judged on. When a PDF is
double-clicked, Windows starts a *new* process. That process must notice the
running copy, hand the path over, and exit — otherwise every double-click leaves
another window and another copy of the engine behind.

The check drives the real executable:

1. start instance A with one PDF;
2. start instance B with a second PDF;
3. B must exit by itself, quickly, with status 0;
4. no second loopback service and no second window may appear;
5. nothing may be left stuck in the handoff queue.

    python scripts/check_open_with.py release/KADOMA-0.6.0-Windows-x64-standalone.exe
    python scripts/check_open_with.py --cleanup

Two things to know before chasing a failure.

First, a leftover copy of the application invalidates this check completely, and
the symptom it produces is misleading. The one-file build runs the application as
a *child* of the PyInstaller bootloader, so terminating the process this script
launched leaves the real application alive. An orphan still holds the
single-instance mutex, so the next run's "first" instance takes the handoff path,
queues its file, exits 0 — and opens no service. This script then reports "The
first instance never opened its loopback service", which is true but has nothing
to do with the build.

Second, the second launch is slow for the one-file build, and how slow depends on
the machine. That build unpacks its whole ~55 MB payload before it can look for
the running copy, so the handoff measured about 33 s cold and about 2.3 s for the
portable folder build on the same machine in the same session. If the second
launch is killed at the default 45 s budget, that is usually a cold cache or a
busy machine rather than a broken handoff — confirm with
`--handoff-timeout 120` before reporting a defect.

Two guards cover it: a pre-flight that refuses to run while a copy is alive, and
an early-exit test inside the wait loop so a silent exit is reported as a silent
exit. Cleanup itself is tree-aware, so a normal run no longer leaves the orphan
that caused the problem. `--cleanup` clears any copy left behind by a crash or a
hard kill.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_exe import (loopback_listeners, kadoma_processes,  # noqa: E402
                       stop_process, terminate_tree, visible_windows)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from desktop import pending_dir  # noqa: E402


def make_pdf(path: Path, heading: str) -> Path:
    """A real, minimal PDF — the app opens it for real, so it must be valid."""
    import pymupdf
    document = pymupdf.open()
    page = document.new_page()
    page.insert_text((72, 96), heading, fontsize=20)
    document.save(str(path))
    document.close()
    return path


def kadoma_windows() -> list[tuple[int, str]]:
    return [(pid, title) for pid, title in visible_windows() if 'kadoma' in title.lower()]


def wait_for(predicate, timeout: float, interval: float = .4):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(interval)
    return None


def cleanup() -> int:
    """Kill every running copy, including the orphaned children of earlier runs."""
    found = kadoma_processes()
    if not found:
        print('No KADOMA instance is running.')
        return 0
    for pid, name in found:
        print(f'Stopping {name} (pid {pid})', flush=True)
        terminate_tree(pid)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and kadoma_processes():
        time.sleep(.5)
    remaining = kadoma_processes()
    if remaining:
        print('Still running: ' + ', '.join(f'{name} (pid {pid})' for pid, name in remaining))
        return 1
    print('All KADOMA processes stopped.')
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('executable', nargs='?', default=None)
    parser.add_argument('--cleanup', action='store_true',
                        help='Stop every running copy (including orphans) and exit.')
    parser.add_argument('--timeout', type=float, default=90.0)
    parser.add_argument('--handoff-timeout', type=float, default=45.0,
                        help='How long the second launch may take to hand its file over and exit. '
                             'The one-file build unpacks ~55 MB before it can see the running copy, '
                             'so on a cold cache or a busy machine this can be tens of seconds. '
                             'The portable folder build does it in about two.')
    parser.add_argument('--json-out', default=None)
    args = parser.parse_args()
    if args.cleanup:
        return cleanup()
    if not args.executable:
        parser.error('an executable path is required (or use --cleanup)')
    executable = Path(args.executable).resolve()
    if not executable.is_file():
        raise SystemExit(f'Not found: {executable}')

    # A leftover copy holds the single-instance mutex. The launch below would hand
    # its file to that copy and exit 0 without serving anything, and the report
    # would blame the build. Refuse instead of misdiagnosing.
    leftover = kadoma_processes()
    if leftover:
        raise SystemExit('A KADOMA instance is already running (pid '
                         + ', '.join(str(pid) for pid, _ in leftover)
                         + '), so this check cannot start from a clean state. '
                           'Run: python scripts/check_open_with.py --cleanup')

    scratch = ROOT / 'qa' / 'open-with'
    scratch.mkdir(parents=True, exist_ok=True)
    first = make_pdf(scratch / 'first document.pdf', 'First document')
    second = make_pdf(scratch / 'second document.pdf', 'Second document')
    print(f'Launching {executable.name} with "{first.name}"', flush=True)

    checks, warnings = [], []
    ports_before = set(loopback_listeners())
    windows_before = len(kadoma_windows())
    queue_before = {p.name for p in pending_dir().glob('*.open')}

    primary = subprocess.Popen([str(executable), str(first)], cwd=str(executable.parent))
    secondary = None
    try:
        # Watch the process as well as the ports. Without the exit test a copy that
        # silently handed its file over would be reported as one that "never opened
        # its loopback service", which points the reader at the wrong thing.
        def started_or_gone():
            if primary.poll() is not None:
                return ('gone', primary.returncode)
            fresh = sorted({p for p in loopback_listeners() if p not in ports_before})
            return ('up', fresh) if fresh else None

        outcome = wait_for(started_or_gone, args.timeout)
        if outcome is None:
            raise SystemExit('The first instance neither opened a loopback service nor exited '
                             f'within {args.timeout:.0f}s.')
        if outcome[0] == 'gone':
            raise SystemExit(f'The first instance exited immediately (code {outcome[1]}) without '
                             'opening a service. Another copy was probably already running, or '
                             'the launch was handed a file it refused.')
        new_ports = outcome[1]
        checks.append(f'first instance started and opened a service on 127.0.0.1 port(s) {new_ports}')

        # ---- the double-click -------------------------------------------------
        started = time.monotonic()
        secondary = subprocess.Popen([str(executable), str(second)], cwd=str(executable.parent))
        try:
            code = secondary.wait(timeout=args.handoff_timeout)
        except subprocess.TimeoutExpired:
            secondary.kill()
            raise SystemExit(f'The second instance kept running for more than '
                             f'{args.handoff_timeout:.0f}s: it would open a duplicate window. '
                             f'Raise --handoff-timeout to allow for a cold one-file launch.')
        elapsed = round(time.monotonic() - started, 1)
        if code != 0:
            raise SystemExit(f'The second instance exited with code {code}, not 0.')
        checks.append(f'the second instance handed the file over and exited by itself (code 0, {elapsed}s)')

        extra_ports = sorted(set(loopback_listeners()) - ports_before - set(new_ports))
        if extra_ports:
            raise SystemExit(f'A second service was started on port(s) {extra_ports}.')
        checks.append('no second service was started — the running engine was reused')

        time.sleep(2.0)
        windows_after = len(kadoma_windows())
        if windows_after > windows_before + 1:
            raise SystemExit(f'{windows_after} KADOMA windows are open; expected at most '
                             f'{windows_before + 1}.')
        checks.append(f'no duplicate window ({windows_before} before, {windows_after} after)')

        # The running instance drains the queue on a timer. A leftover file means
        # the handoff never completed and the document was silently dropped.
        def leftover():
            stuck = {p.name for p in pending_dir().glob('*.open')} - queue_before
            return sorted(stuck) if stuck else None

        drained = wait_for(lambda: not leftover(), 15.0)
        if not drained:
            stuck = leftover()
            raise SystemExit(f'The running instance never picked up the handed-over file: {stuck}')
        checks.append('the running instance drained the handoff queue — the file was not dropped')
    finally:
        # Tree-aware: the application is a child of the PyInstaller bootloader, so
        # terminating only the handle we hold would leave it running and holding the
        # mutex — poisoning the next run of this check and of check_exe.py.
        for process in (secondary, primary):
            stop_process(process)

    for name in checks:
        print('PASS:', name, flush=True)
    for name in warnings:
        print('WARN:', name, flush=True)
    result = {'executable': str(executable), 'checks': checks, 'warnings': warnings}
    if args.json_out:
        Path(args.json_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json_out).write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'\n{len(checks)} checks passed, {len(warnings)} warnings.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
