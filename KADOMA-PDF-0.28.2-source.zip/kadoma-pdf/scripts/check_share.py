"""Exercise the sharing, default-app and Arabic interfaces in a real browser.

The share and default-app features only run in the desktop shell, which a plain
browser preview is not. Rather than weakening the application to make it
testable, this script simulates the desktop shell from the *test* side: it
rewrites the `/api/health` response to report `desktop: true` and stubs the
`/api/share/*` and `/api/system/*` endpoints. That exercises the real interface
code — dialog markup, request payloads, error handling — without the test
depending on a clipboard, a mail client or the Windows registry.

Requires Playwright + Chromium and a running local preview server:

    python run_preview.py --port 8000
    python scripts/check_share.py --base-url http://127.0.0.1:8000
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright, expect
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from support.demo_document import make_demo

ARABIC = 'مرحبا بالعالم'
FAKE_SHARE = {
    'path': r'C:\Users\Public\AppData\Local\Temp\KADOMA Share\Quarterly performance.pdf',
    'name': 'Quarterly performance.pdf',
    'size': 20988,
    # What the server says the draft should say before anybody edits it.
    'defaultBody': 'Please see the attached file',
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', default='http://127.0.0.1:8000')
    parser.add_argument('--output', default='qa')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    steps, errors, external = [], [], []
    calls: list[tuple[str, dict]] = []

    def record(name):
        print('PASS:', name, flush=True)
        steps.append(name)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        page.set_default_timeout(35000)
        page.on('pageerror', lambda error: errors.append(str(error)))
        allowed = urlparse(args.base_url).netloc
        page.on('request', lambda request: external.append(request.url)
                if request.url.startswith(('http://', 'https://')) and urlparse(request.url).netloc != allowed else None)

        # ---- stand in for the desktop shell ----------------------------------
        def health(route):
            response = route.fetch()
            body = response.json()
            body['desktop'] = True
            body['rtlText'] = True
            body['rtlQuality'] = 'exact'
            route.fulfill(response=response, json=body)

        def record_and_ok(route):
            body = {}
            if route.request.post_data:
                try:
                    body = json.loads(route.request.post_data)
                except ValueError:
                    body = {}
            calls.append((urlparse(route.request.url).path, body))
            route.fulfill(json={'ok': True, 'note': 'stubbed'})

        def system_status(route):
            if route.request.method == 'GET':
                route.fulfill(json={'desktop': True, 'supported': True, 'registered': False,
                                    'isDefault': False, 'currentHandler': 'JOPDF.pdf'})
            else:
                record_and_ok(route)

        page.route('**/api/health', health)
        page.route('**/api/share/prepare', lambda route: route.fulfill(json=FAKE_SHARE))
        page.route('**/api/share/email', record_and_ok)
        page.route('**/api/share/clipboard', record_and_ok)
        page.route('**/api/share/reveal', record_and_ok)
        page.route('**/api/system/default-app', system_status)
        page.route('**/api/system/pending-open', lambda route: route.fulfill(json={'paths': []}))

        page.goto(args.base_url, wait_until='networkidle')
        # The application ships no sample document, so the check opens the
        # report it works on through the same file picker a person uses.
        report = output / 'report.pdf'
        if not report.exists():
            report.write_bytes(make_demo())
        page.locator('#file-input').set_input_files(str(report))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        # The application opens on its home screen. These checks are about the
        # document, so step into it the way a person does: the Edit tab, then the
        # Edit text tool where the check needs text boxes on the page.
        page.click('#navigation [data-view="edit"]')
        expect(page.locator('#share-document')).to_be_visible()
        expect(page.locator('#default-app-button')).to_be_visible()
        record('Share and default-app controls are present in the toolbar')

        # ---- share panel ------------------------------------------------------
        page.locator('#share-document').click()
        expect(page.locator('.share-file strong')).to_have_text(FAKE_SHARE['name'])
        for selector in ('#share-email-attach', '#share-email-draft', '#share-copy', '#share-reveal'):
            expect(page.locator(selector)).to_be_visible()
        record('Share panel opens and lists all four real options')

        note = page.locator('.share-note').inner_text()
        assert 'never sends anything' in note and 'mailto' in note, note
        record('Share panel states plainly that nothing is sent and mailto cannot attach')

        # The message box arrives with the sentence the server sends, and what is
        # typed over it is what the draft carries.
        body_value = page.locator('#share-body').input_value()
        assert body_value == 'Please see the attached file', body_value
        record('The email draft starts with the default message')

        page.locator('#share-to').fill('client@example.com')
        page.locator('#share-subject').fill('Your invoice')
        page.locator('#share-body').fill('Here is the invoice you asked for.')
        page.locator('#share-email-attach').click()
        expect(page.locator('#share-email-attach')).to_be_enabled()
        record('Email-with-attachment option sends the typed recipient, subject and message')

        page.locator('#share-copy').click()
        expect(page.locator('#share-copy')).to_be_enabled()
        page.locator('#share-reveal').click()
        expect(page.locator('#share-reveal')).to_be_enabled()
        record('Copy-file and show-in-folder options complete')

        page.screenshot(path=output / 'share-panel.png')

        paths = [path for path, _body in calls]
        assert paths.count('/api/share/email') == 1, paths
        assert '/api/share/clipboard' in paths and '/api/share/reveal' in paths, paths
        email_body = next(body for path, body in calls if path == '/api/share/email')
        assert email_body['attach'] is True, email_body
        assert email_body['to'] == 'client@example.com', email_body
        assert email_body['subject'] == 'Your invoice', email_body
        assert email_body['body'] == 'Here is the invoice you asked for.', email_body
        assert email_body['path'] == FAKE_SHARE['path'], email_body
        record('Requests carry the prepared path, recipient, subject and attach flag')

        page.locator('#modal [data-close]').first.click()
        expect(page.locator('#modal')).not_to_be_visible()

        # ---- default app ------------------------------------------------------
        calls.clear()
        page.locator('#default-app-button').click()
        expect(page.locator('#register-app')).to_be_visible()
        body = page.locator('.modal-body').inner_text()
        assert 'will not let any app claim the default silently' in body, body
        assert 'JOPDF.pdf' in body, body
        record('Default-app panel names the current handler and explains the Windows limit')

        page.locator('#register-app').click()
        expect(page.locator('#register-app')).to_be_visible(timeout=15000)
        assert any(path == '/api/system/default-app' for path, _ in calls), calls
        register_body = next(b for path, b in calls if path == '/api/system/default-app')
        assert register_body.get('action') == 'register', register_body
        record('Register button posts the register action')
        page.locator('#modal [data-close]').first.click()

        # ---- Arabic in the editor --------------------------------------------
        page.evaluate("""async text => {
            await perform({action:'add_text', page:0, rect:[60,700,420,735], text,
                           size:18, color:'#111111', family:'sans-serif'}, 'Adding Arabic text…');
        }""", ARABIC)
        page.wait_for_function("() => state.content && state.content.runs.some(r => r.rtl)")
        run = page.evaluate("() => state.content.runs.find(r => r.rtl)")
        assert ARABIC.split()[0] in run['text'], run
        record('Arabic text added to the page reads back as logical letters with rtl=true')

        index = page.evaluate("() => state.content.runs.findIndex(r => r.rtl)")
        page.evaluate('index => openInlineEdit(index)', index)
        expect(page.locator('#inline-editor')).to_be_visible()
        direction = page.evaluate("() => getComputedStyle(document.querySelector('#inline-text')).direction")
        assert direction == 'rtl', direction
        editor_dir = page.evaluate("() => document.querySelector('#inline-text').dir")
        assert editor_dir == 'auto', editor_dir
        record('Inline editor switches to right-to-left for Arabic (dir=auto resolves to rtl)')

        page.screenshot(path=output / 'arabic-inline-editor.png')
        page.evaluate('() => closeInlineEdit()')

        # ---- the demo document is untouched by any of this --------------------
        assert not external, external
        assert not errors, errors
        record('No JavaScript errors and no external requests during the run')

        browser.close()

    print(f'\n{len(steps)} checks passed.')
    (output / 'share-checks.json').write_text(json.dumps(
        {'checks': steps, 'errors': errors, 'externalRequests': external}, indent=2), encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
