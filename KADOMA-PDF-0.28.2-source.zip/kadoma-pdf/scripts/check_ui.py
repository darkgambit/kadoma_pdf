"""Exercise real editing/export workflows in the running browser UI.

Requires separately installed Playwright + Chromium. Does not launch a public
server, use a remote browser, or depend on an online PDF service.
"""
from __future__ import annotations
import argparse
import io
import json
import sys
from pathlib import Path
from urllib.parse import urlparse

import pymupdf as fitz
from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright, expect
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from support.demo_document import make_demo


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', default='http://127.0.0.1:8000')
    parser.add_argument('--output', default='qa')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    steps, errors, external = [], [], []

    def record(name):
        print('PASS:', name, flush=True)
        steps.append(name)

    with fitz.open() as doc:
        page = doc.new_page()
        page.insert_text((50,70),'Merged via file picker',fontsize=16)
        doc.save(output / 'merge-fixture.pdf')
    Image.new('RGB',(400,180),'#7162da').save(output / 'image-purple.png')
    Image.new('RGB',(400,180),'#53a49a').save(output / 'image-green.png')
    scan = Image.new('RGB',(1600,650),'white')
    draw = ImageDraw.Draw(scan)
    draw.text((90,100),'INVOICE 4012',font=ImageFont.load_default(size=90),fill='black')
    draw.text((90,260),'TOTAL 5200',font=ImageFont.load_default(size=90),fill='black')
    scan.save(output / 'invoice-scan.png')

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width':1440,'height':1000}, accept_downloads=True)
        page.set_default_timeout(35000)
        page.on('pageerror', lambda error: errors.append(str(error)))
        allowed_origin = urlparse(args.base_url).netloc
        page.on('request', lambda request: external.append(request.url)
                if request.url.startswith(('http://','https://')) and urlparse(request.url).netloc != allowed_origin else None)
        page.goto(args.base_url, wait_until='networkidle')
        # The application ships no sample document, so the check opens the
        # report it works on through the same file picker a person uses.
        report = output / 'report.pdf'
        if not report.exists():
            report.write_bytes(make_demo())
        page.locator('#file-input').set_input_files(str(report))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        # The application opens on its home screen. These checks are about the
        # document, so step into it the way a person does: the Edit tab, then the
        # Edit text tool where the check needs text boxes on the page.
        page.click('#navigation [data-view="edit"]')
        page.click('[data-tool="edit"]')
        expect(page.locator('.text-hit').first).to_be_visible()
        page.locator('#zoom-select').select_option('page')
        page.screenshot(path=str(output / 'workspace.png'))
        record('The opened report, local font, thumbnails, and renderer load')

        def wait_idle():
            expect(page.locator('#busy-overlay')).to_be_hidden(timeout=150000)
            page.wait_for_function('() => state.content !== null')

        def draw_rect(rect):
            page.locator('#paper').scroll_into_view_if_needed()
            box = page.locator('#pdf-page').bounding_box()
            dims = page.evaluate('state.doc.pages[state.page]')
            x0=box['x']+rect[0]/dims['width']*box['width']
            y0=box['y']+rect[1]/dims['height']*box['height']
            x1=box['x']+rect[2]/dims['width']*box['width']
            y1=box['y']+rect[3]/dims['height']*box['height']
            page.mouse.move(x0,y0);page.mouse.down();page.mouse.move(x1,y1,steps=12);page.mouse.up()

        def point(x,y):
            box=page.locator('#pdf-page').bounding_box()
            dims=page.evaluate('state.doc.pages[state.page]')
            page.mouse.click(box['x']+x/dims['width']*box['width'],box['y']+y/dims['height']*box['height'])

        def pdf_download(name):
            page.locator('#export-document').click()
            with page.expect_download() as download:
                page.locator('#start-export').click()
            download.value.save_as(output / name)
            expect(page.locator('#modal')).not_to_be_visible()
            wait_idle()
            return output / name

        page.locator('[data-span][aria-label="Edit text: Quarterly"]').click()
        page.locator('#edit-text-value').fill('Annual')
        page.locator('#apply-text').click();wait_idle()
        expect(page.locator('[data-span][aria-label="Edit text: Annual"]')).to_be_visible()
        record('Direct text replacement')
        page.locator('#undo').click();wait_idle()
        expect(page.locator('[aria-label="Edit text: Quarterly"]')).to_be_visible()
        page.locator('#redo').click();wait_idle()
        expect(page.locator('[aria-label="Edit text: Annual"]')).to_be_visible()
        record('Undo and redo')

        page.locator('[data-tool="text"]').click()
        draw_rect([400,630,550,662])
        page.locator('#edit-text-value').fill('Local note')
        page.locator('#apply-text').click();wait_idle()
        page.locator('#document-search').fill('Local note')
        expect(page.locator('.search-match')).to_have_count(1)
        record('Add text and offline search')

        page.locator('[data-view="forms"]').click()
        page.locator('#current-page').fill('4');page.locator('#current-page').press('Tab');wait_idle()
        page.get_by_label('Reviewer name',exact=True).fill('Taylor Reed')
        page.get_by_label('Approval status',exact=True).select_option('Approved')
        page.get_by_label('I have reviewed this report',exact=True).check()
        page.locator('#save-form-values').click();wait_idle()
        expect(page.get_by_label('Reviewer name',exact=True)).to_have_value('Taylor Reed')
        record('Fill actual text, dropdown, and checkbox fields')

        page.locator('[data-tool="field-text"]').click()
        draw_rect([400,300,550,330])
        page.locator('#field-name').fill('department')
        page.locator('#create-field').click();wait_idle()
        expect(page.get_by_label('department',exact=True)).to_be_visible()
        record('Create a fillable PDF field')

        page.locator('[data-tool="signature"]').click()
        page.locator('#signature-name').fill('Taylor Reed')
        page.locator('#use-signature').click()
        draw_rect([70,485,325,550]);wait_idle()
        record('Typed visual signature placement')

        page.locator('[data-view="edit"]').click()
        page.locator('#current-page').fill('1');page.locator('#current-page').press('Tab');wait_idle()
        page.locator('[data-tool="highlight"]').click()
        draw_rect([48,385,480,402]);wait_idle()
        page.locator('[data-tool="comment"]').click()
        point(500,350)
        page.locator('#comment-value').fill('Check the quarter totals before sharing.')
        page.locator('#add-comment').click();wait_idle()
        expect(page.locator('.annotation-card')).to_have_count(2)
        record('PDF highlights and comments')
        page.screenshot(path=str(output / 'annotations.png'))

        page.locator('[data-view="pages"]').click()
        page.locator('[data-action="rotate-pages"]').click();wait_idle()
        assert page.evaluate('state.doc.pages[0].rotation') == 90
        page.locator('[data-action="duplicate-pages"]').click()
        if page.locator('#confirm-action').is_visible(): page.locator('#confirm-action').click()
        wait_idle();assert page.evaluate('state.doc.pageCount') == 5
        page.locator('[data-action="delete-pages"]').click();page.locator('#confirm-action').click();wait_idle()
        assert page.evaluate('state.doc.pageCount') == 4
        # The thumbnail column is off by default now — it takes width the page
        # wants — so the reorder drag has to switch it on first.
        if page.locator('#pages-panel').is_hidden(): page.locator('#toggle-thumbnails').click()
        page.wait_for_timeout(400)
        page.locator('.thumb-row[data-page="1"]').drag_to(page.locator('.thumb-row[data-page="3"]'))
        wait_idle()
        record('Rotate, duplicate, delete, and drag-reorder pages')
        page.screenshot(path=str(output / 'organizer.png'))

        page.locator('#merge-document').click()
        with page.expect_file_chooser() as chooser:
            page.locator('#merge-add-files').click()
        chooser.value.set_files(output / 'merge-fixture.pdf')
        wait_idle()
        expect(page.locator('.merge-row')).to_have_count(1)
        page.locator('#merge-run').click();wait_idle()
        assert page.evaluate('state.doc.pageCount') == 5
        record('Merge a PDF through the combine window')

        page.locator('[data-view="edit"]').click()
        page.locator('#image-input').set_input_files(output / 'image-purple.png')
        draw_rect([70,110,330,250]);wait_idle()
        # Placing an image returns to the reading view; selecting one is a tool.
        page.locator('[data-tool="select"]').click()
        expect(page.locator('.image-hit')).to_have_count(1)
        page.locator('.image-hit').click()
        page.locator('#replace-image').click();page.locator('#confirm-action').click()
        page.locator('#image-input').set_input_files(output / 'image-green.png');wait_idle()
        record('Insert and replace embedded images')

        page.locator('[data-view="convert"]').click()
        page.locator('[data-format="xlsx"]').click()
        with page.expect_download() as download:
            page.locator('#convert-export').click()
        download.value.save_as(output / 'ui-tables.xlsx');wait_idle()
        from openpyxl import load_workbook
        workbook=load_workbook(output / 'ui-tables.xlsx')
        assert any('Table' in name for name in workbook.sheetnames)
        record('Actual XLSX export from the interface')

        pdf = pdf_download('ui-edited.pdf')
        with fitz.open(pdf) as document:
            text=''.join(p.get_text() for p in document)
            assert 'Annual' in text and 'Local note' in text
            values={w.field_name:w.field_value for p in document for w in p.widgets() or []}
            assert values['reviewer_name']=='Taylor Reed' and values['approval_status']=='Approved'
            assert 'department' in values
        record('Exported PDF contains real edits and form values')

        page.locator('[data-view="protect"]').click()
        page.locator('#open-password').fill('reader-2026')
        page.locator('#owner-password').fill('owner-2026')
        with page.expect_download() as download:
            page.locator('#protect-export').click()
        download.value.save_as(output / 'ui-protected.pdf');wait_idle()
        with fitz.open(output / 'ui-protected.pdf') as document:
            assert document.needs_pass and document.authenticate('reader-2026')
            assert not document.permissions & fitz.PDF_PERM_MODIFY
        record('AES-256 protected PDF export')

        page.locator('#document-search').fill('NL-2048-9931')
        expect(page.locator('.search-match')).to_have_count(1)
        page.wait_for_function('() => state.searchMatches.length === 1 && state.content !== null')
        rect=page.evaluate('state.searchMatches[0].rect')
        page.locator('[data-view="protect"]').click()
        page.locator('[data-tool="redact"]').click()
        draw_rect([rect[0]-.5,rect[1]-.5,rect[2]+.5,rect[3]+.5])
        page.locator('#apply-redaction').click();page.locator('#confirm-action').click();wait_idle()
        expect(page.locator('#undo')).to_be_disabled()
        pdf=pdf_download('ui-redacted.pdf')
        with fitz.open(pdf) as document:
            assert 'NL-2048-9931' not in ''.join(p.get_text() for p in document)
        record('Permanent redaction verified in downloaded PDF')

        cap=page.evaluate('state.capabilities')
        if cap['tesseract']:
            page.locator('#file-input').set_input_files(output / 'invoice-scan.png');wait_idle()
            page.locator('[data-view="ocr"]').click()
            page.locator('#run-ocr').click();page.locator('#confirm-action').click();wait_idle()
            page.locator('#document-search').fill('INVOICE')
            expect(page.locator('.search-match')).to_have_count(1)
            pdf=pdf_download('ui-ocr.pdf')
            with fitz.open(pdf) as document:
                assert 'INVOICE' in document[0].get_text()
            record('Local OCR produces saved searchable text')
            page.locator('[data-view="edit"]').click();wait_idle()
            page.locator('[data-tool="edit"]').click()
            index=next(i for i,span in enumerate(page.evaluate('state.content.spans')) if 'INVOICE' in span['text'])
            page.locator(f'[data-span="{index}"]').click()
            page.locator('#edit-text-value').fill('PAID 4012')
            page.locator('#apply-text').click();wait_idle()
            pdf=pdf_download('ui-ocr-edited.pdf')
            with fitz.open(pdf) as document:
                assert 'PAID' in document[0].get_text() and 'INVOICE' not in document[0].get_text()
            record('Localized scan-text replacement removes old OCR text')
        else:
            print('SKIP: OCR UI test (Tesseract not installed)',flush=True)

        # Verify responsive layout and honest guide states without fake tools.
        page.locator('#help-button').click()
        expect(page.locator('#modal')).to_contain_text('No cloud synchronization')
        page.locator('.modal-footer [data-close]').click()
        page.set_viewport_size({'width':1080,'height':760})
        page.screenshot(path=str(output / 'compact-layout.png'))
        record('Responsive desktop layout and scope guide')

        # ---- a scanned page becomes editable -------------------------------
        # A page that is a picture of text: one image, no text layer at all.
        page.set_viewport_size({'width':1440,'height':900})
        # A local name of its own: `fitz` is used earlier in this function, and
        # importing it here under that name would make it local to the whole
        # function and break the earlier use.
        import pymupdf as mupdf
        source = mupdf.open()
        shot = source.new_page(width=595, height=842)
        shot.insert_text((60, 110), 'SCANNED PAGE', fontsize=26)
        shot.insert_text((60, 160), 'Nothing here can be clicked.', fontsize=13)
        png = shot.get_pixmap(dpi=120).tobytes('png')
        source.close()
        scan = mupdf.open()
        sheet = scan.new_page(width=595, height=842)
        sheet.insert_image(mupdf.Rect(0, 0, 595, 842), stream=png)
        fixture = output / 'scan-fixture.pdf'
        scan.save(fixture)
        scan.close()

        page.locator('#file-input').set_input_files(str(fixture))
        page.wait_for_timeout(4000)
        if page.locator('#modal').is_visible():
            page.locator('#confirm-action').click()
            page.wait_for_timeout(3000)
        page.locator('[data-tool="edit"]').click()
        page.wait_for_timeout(800)
        assert page.evaluate('() => (state.content?.spans||[]).length') == 0, 'the fixture has a text layer'
        expect(page.locator('.scan-banner')).to_be_visible()
        assert page.locator('.text-hit').count() == 0
        page.locator('[data-scan-edit]').click()
        page.wait_for_selector('#modal[open]')
        page.locator('#confirm-action').click()
        page.wait_for_function('() => (state.content?.spans||[]).length > 0', timeout=180000)
        page.wait_for_timeout(1500)
        expect(page.locator('.scan-banner')).to_have_count(0)
        assert page.locator('.text-hit').count() > 0, 'the recognised page has no editable text'
        assert page.evaluate('() => state.tool') == 'edit', 'the text tool was not armed after OCR'
        page.locator('.text-hit').first.click()
        page.wait_for_timeout(600)
        assert page.locator('#inline-editor').is_visible(), 'the recognised text cannot be edited'
        page.screenshot(path=str(output / 'scan-editable.png'))
        record('A scanned page is recognised and becomes editable in one press')
        assert not errors, errors
        assert not external, external
        record('No JavaScript runtime errors or external page requests')
        browser.close()
    result={'passed':len(steps),'steps':steps,'javascriptErrors':errors,'externalPageRequests':external,
            'nativeGUI':'Not tested by browser checks','baseURL':args.base_url}
    (output / 'ui-results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2),flush=True)


if __name__ == '__main__':
    main()
