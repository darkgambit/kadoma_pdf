"""Fill a prepared form in another PDF application, and watch the pixels change.

The unit tests prove the file carries what a reader needs. This proves a reader
uses it: the exported form is opened in the machine's own Chrome — a completely
different PDF engine (PDFium) from the one inside KADOMA (MuPDF) — and every
field is typed into. After each field the ink on the page is counted again; a
field that cannot be typed into does not gain any.

Nothing is clicked on the fields themselves. The page is clicked once in an empty
margin and then Tab moves from field to field, which is how the reader's own tab
order is exercised — no pixel arithmetic that could land a click in the wrong
place and be read as a broken field.

Chrome is used rather than Acrobat because it can be driven headlessly and its
PDF viewer is still there. If Chrome is not installed the check says so and exits
2, so a missing browser is never mistaken for a pass.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))

import pymupdf as fitz
from PIL import Image
from playwright.sync_api import sync_playwright

from app import engine, form_prep

QA = ROOT / 'qa'
CHROME = Path('C:/Program Files/Google/Chrome/Application/chrome.exe')
VIEW = (1100, 900)
MARKER = {'text': 'Angelo', 'date': '2026-10-29'}


def build_form() -> bytes:
    """A flat page with the four things the scan looks for."""
    with fitz.open() as doc:
        page = doc.new_page(width=595, height=842)
        page.insert_text((60, 120), 'Name:', fontsize=12)
        page.insert_text((60, 160), 'Date of birth:', fontsize=12)
        page.insert_text((60, 200), 'Signature ______________________', fontsize=12)
        page.draw_rect(fitz.Rect(60, 230, 72, 242), color=(0, 0, 0), width=1)
        page.insert_text((80, 240), 'I agree to the terms', fontsize=12)
        return doc.tobytes()


def prepared_pdf(path: Path) -> tuple[Path, list[dict]]:
    machine = engine.Engine()
    ident = machine.load(build_form(), 'application form.pdf')['id']
    with machine.opened(machine.get(ident)) as doc:
        found = form_prep.scan(doc)
    machine.operation(ident, {'action': 'prepare_form', 'fields': found})
    path.write_bytes(machine.export(ident, 'pdf')[0])
    return path, found


def page_box(image_path: Path) -> tuple[int, int, float]:
    """Where the page sits on screen, and how many pixels a PDF point is worth.

    The longest white run in a row is the page. Taking the first and last white
    pixel instead finds the white *thumbnails* in the sidebar and measures the
    whole window as the page, which lands every click in the wrong place.
    """
    image = Image.open(image_path).convert('RGB')
    width, height = image.size
    best = (0, 0, 0, 0)
    for y in range(80, height, 6):
        run_start, longest = None, 0
        for x in range(width):
            white = image.getpixel((x, y)) == (255, 255, 255)
            if white and run_start is None:
                run_start = x
            elif not white and run_start is not None:
                if x - run_start > longest:
                    longest, best = x - run_start, (run_start, x, y, y)
                run_start = None
        if run_start is not None and width - run_start > longest:
            longest, best = width - run_start, (run_start, width, y, y)
    if not longest:
        raise SystemExit('The page did not render, so nothing can be measured.')
    left, right = best[0], best[1]
    top = next(y for y in range(0, height, 2)
               if sum(1 for x in range(left, right, 8)
                      if image.getpixel((x, y)) == (255, 255, 255)) > 20)
    return left, top, (right - left) / 595.0


def changed(before: Path, after: Path, box: tuple[int, int, int, int]) -> int:
    """How many pixels differ between two screenshots.

    Counting absolute ink is useless here: the viewer's own dark surround is in
    the picture and swamps a typed word. What matters is whether *anything*
    changed on the page after a keystroke, and a field that refuses input leaves
    the picture identical.
    """
    one = Image.open(before).convert('L').crop(box)
    two = Image.open(after).convert('L').crop(box)
    a, b = one.get_flattened_data(), two.get_flattened_data()
    return sum(1 for x, y in zip(a, b) if abs(x - y) > 30)


def main() -> int:
    if not CHROME.exists():
        print('Chrome is not installed here, so the other-reader check cannot run.')
        return 2
    QA.mkdir(exist_ok=True)
    target, found = prepared_pdf(QA / 'reader-form.pdf')
    url = 'file:///' + str(target).replace('\\', '/')

    with sync_playwright() as play:
        browser = play.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width': VIEW[0], 'height': VIEW[1]},
                                color_scheme='light')
        page.goto(url)
        page.wait_for_timeout(5000)
        empty = QA / 'reader-empty.png'
        page.screenshot(path=str(empty))
        left, top, scale = page_box(empty)
        print(f'{len(found)} fields · page at {left},{top} · {scale:.3f} px per point')

        failures = []
        for index, item in enumerate(found):
            x0, y0, x1, y1 = item['rect']
            # The scan reports rectangles the way PyMuPDF does — y measured from
            # the top of the page — so they map straight onto the screen.
            box = (round(left + x0 * scale), round(top + y0 * scale),
                   round(left + x1 * scale), round(top + y1 * scale))
            before = QA / f'reader-field-{index}-before.png'
            page.screenshot(path=str(before))
            # A person clicks the box and types into it. Space is not enough:
            # a checkbox takes a focus ring from Space and stays empty, which
            # would look like a pass.
            page.mouse.click((box[0] + box[2]) // 2, (box[1] + box[3]) // 2)
            page.wait_for_timeout(400)
            if item['kind'] != 'checkbox':
                # A checkbox is ticked by the click itself; clicking it twice
                # would tick it and untick it again.
                page.keyboard.type(MARKER.get(item['kind'], 'x'))
            page.wait_for_timeout(700)
            after = QA / f'reader-field-{index}-after.png'
            page.screenshot(path=str(after))
            moved = changed(before, after, box)
            ok = moved > 12
            print(f'  {item["kind"]:<8} {item["label"][:26]:<26} '
                  f'{moved:>5} px changed in its box  {"filled" if ok else "NOT FILLED"}')
            if not ok:
                failures.append(f'{item["label"]} ({item["kind"]})')

        page.screenshot(path=str(QA / 'reader-filled.png'))
        browser.close()

    if failures:
        print('Fields another reader could not fill:', ', '.join(failures))
        return 1
    print(f'All {len(found)} fields took typing in Chrome — no KADOMA involved.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
