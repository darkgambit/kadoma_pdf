"""Package the KADOMA source + build kit into one deterministic ZIP.

Source only: build outputs (`build/`, `dist/`, `release/`), caches, virtual
environments and QA scratch data are excluded, so the archive stays small and
diffable. Entry timestamps are pinned to a fixed epoch, which makes the archive
byte-reproducible: building the same source twice yields the same SHA-256.

    python scripts/make_kit.py ../KADOMA-0.6.0-source-and-build-kit.zip
"""
from __future__ import annotations

import argparse
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE_DIRS = {
    '.git', '.venv', 'venv', 'env', 'build', 'dist', 'release', 'qa',
    '__pycache__', '.pytest_cache', '.mypy_cache', '.workbuddy-ai',
    '.idea', '.vscode', 'node_modules',
}
EXCLUDE_SUFFIXES = ('.pyc', '.pyo', '.pyd')
# 1980-01-01, the earliest timestamp a ZIP entry can carry.
EPOCH = (1980, 1, 1, 0, 0, 0)


def wanted(path: Path) -> bool:
    if path.suffix.lower() in EXCLUDE_SUFFIXES:
        return False
    return not any(part in EXCLUDE_DIRS for part in path.relative_to(ROOT).parts)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('output', nargs='?', default=str(ROOT.parent / 'KADOMA-source-and-build-kit.zip'))
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and wanted(p))
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            arcname = Path(ROOT.name) / path.relative_to(ROOT)
            info = zipfile.ZipInfo(str(arcname).replace('\\', '/'), date_time=EPOCH)
            info.compress_type = zipfile.ZIP_DEFLATED
            # 0o644 files / 0o755 for anything executable, recorded explicitly so
            # the archive does not depend on the building machine's umask.
            info.external_attr = (0o755 if path.suffix in ('.command', '.cmd') else 0o644) << 16
            archive.writestr(info, path.read_bytes())

    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(f'{len(files)} files -> {output}')
    print(f'{output.stat().st_size:,} bytes')
    print(f'sha256 {digest}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
