"""Check that a non-loopback browser preview does NOT claim local processing."""
import argparse
import json
import tempfile
from pathlib import Path
from urllib.parse import urlparse
import pymupdf as fitz
from playwright.sync_api import sync_playwright, expect


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--base-url',default='http://127.0.0.1:8000')
    parser.add_argument('--output',default='qa')
    args=parser.parse_args()
    base=urlparse(args.base_url)
    if base.hostname not in ('localhost','127.0.0.1') or base.scheme!='http':
        raise SystemExit('Use a local HTTP preview server for this controlled hostname test.')
    port=base.port or 80
    target=f'http://kadoma-preview.test:{port}'
    output=Path(args.output);output.mkdir(exist_ok=True,parents=True)
    with tempfile.TemporaryDirectory(prefix='kadoma-privacy-check-') as tmp, sync_playwright() as p:
        fixture=Path(tmp)/'public-sample.pdf'
        with fitz.open() as doc:
            doc.new_page().insert_text((50,60),'Non-sensitive privacy test sample')
            doc.save(fixture)
        browser=p.chromium.launch(headless=True,args=['--no-sandbox','--proxy-server=direct://',
                   '--host-resolver-rules=MAP kadoma-preview.test 127.0.0.1'])
        page=browser.new_page(viewport={'width':1440,'height':960})
        uploads=[];errors=[]
        page.on('request',lambda request:uploads.append(request.url) if request.url.endswith('/api/documents/upload') else None)
        page.on('pageerror',lambda error:errors.append(str(error)))
        # An arbitrary session hash must not spoof the local-processing claim.
        page.goto(target+'/#session=not-a-native-session',wait_until='networkidle')
        # No document ships with the application, so the browser opens on Home
        # with nothing sent anywhere. That is the state the privacy claim is
        # made in, and the state the upload count is measured from.
        expect(page.locator('#home-view')).to_be_visible()
        expect(page.locator('#status-text')).to_contain_text('not on your computer')
        assert len(uploads)==0
        page.locator('#file-input').set_input_files(fixture)
        expect(page.locator('#modal')).to_contain_text('sends uploaded files to the hosted workspace')
        assert len(uploads)==0
        page.locator('#confirm-action').click()
        expect(page.locator('#document-name')).to_have_text('public-sample.pdf')
        page.wait_for_function('() => state.content !== null')
        assert len(uploads)==1
        expect(page.locator('#document-change')).to_contain_text('In hosted workspace')
        # The warning lives in the tools panel of an open document, and the
        # editor really is live on the file that was just opened.
        page.click('#navigation [data-view="edit"]')
        expect(page.locator('.hosted-privacy')).to_contain_text('Uploads leave your device')
        page.click('[data-tool="edit"]')
        expect(page.locator('.text-hit').first).to_be_visible()
        page.screenshot(path=str(output/'hosted-preview.png'))
        assert not errors
        browser.close()
    result={'passed':2,'checks':['Hosted-preview privacy labeling','Explicit consent before first file upload'],
            'javascriptErrors':errors,'uploadsBeforeConsent':0,'uploadsAfterConsent':1}
    (output/'privacy-results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
