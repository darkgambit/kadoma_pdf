"""Exercise direct on-page text editing in a real browser and verify the output PDF.

Requires separately installed Playwright + Chromium and a running local preview
server. Nothing is sent to a remote service; the exported PDF is reopened locally
with PyMuPDF so the checks assert real document content, not screenshots.

    python run_preview.py --port 8000
    python scripts/check_direct_edit.py --base-url http://127.0.0.1:8000
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from urllib.parse import urlparse

import pymupdf as fitz
from playwright.sync_api import sync_playwright, expect
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from support.demo_document import make_demo

# The number of checks below. A step that raises aborts the run, but a step that
# is skipped for any other reason must not be counted as a pass — update this
# when a check is added, or the script reports a false failure.
EXPECTED_STEPS = 11


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', default='http://127.0.0.1:8000')
    parser.add_argument('--output', default='qa')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    steps, errors, external = [], [], []

    def record(name):
        print('PASS:', name, flush=True)
        steps.append(name)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        page.set_default_timeout(35000)
        page.on('pageerror', lambda error: errors.append(str(error)))
        allowed = urlparse(args.base_url).netloc
        page.on('request', lambda request: external.append(request.url)
                if request.url.startswith(('http://', 'https://')) and urlparse(request.url).netloc != allowed else None)
        page.goto(args.base_url, wait_until='networkidle')
        # The application ships no sample document, so the check opens the
        # report it works on through the same file picker a person uses.
        report = output / 'report.pdf'
        if not report.exists():
            report.write_bytes(make_demo())
        page.locator('#file-input').set_input_files(str(report))
        page.wait_for_function('() => state.doc && !state.busy', timeout=90000)
        # The application opens on its home screen. These checks are about the
        # document, so step into it the way a person does: the Edit tab, then the
        # Edit text tool where the check needs text boxes on the page.
        page.click('#navigation [data-view="edit"]')
        page.click('[data-tool="edit"]')
        expect(page.locator('.text-hit').first).to_be_visible()

        def wait_idle():
            expect(page.locator('#busy-overlay')).to_be_hidden(timeout=150000)
            page.wait_for_function('() => state.content !== null')

        def runs():
            return page.evaluate('state.content.runs')

        def run_box(text):
            """Bounding box of the editable run whose text contains `text`."""
            index = page.evaluate(
                'text => state.content.runs.findIndex(r => r.text.includes(text))', text)
            assert index >= 0, f'no editable run containing {text!r}'
            return index, page.evaluate(
                """index => { const r = state.content.runs[index].rect, p = state.doc.pages[state.page];
                     const b = document.querySelector('#pdf-page').getBoundingClientRect();
                     return {x0:b.x + r[0]/p.width*b.width, y0:b.y + r[1]/p.height*b.height,
                             x1:b.x + r[2]/p.width*b.width, y1:b.y + r[3]/p.height*b.height}; }""", index)

        def download_pdf(name):
            page.locator('#export-document').click()
            with page.expect_download() as download:
                page.locator('#start-export').click()
            path = output / name
            download.value.save_as(path)
            expect(page.locator('#modal')).not_to_be_visible()
            wait_idle()
            return path

        page.locator('#zoom-select').select_option('page')
        wait_idle()
        # The page stack is rebuilt when the zoom changes. Waiting for the
        # render scale to catch up is what makes the coordinates below stable;
        # `state.content` alone is already non-null and proves nothing.
        page.wait_for_function('() => Math.abs(state.renderedScale - renderScale()) < 0.01')
        page.wait_for_timeout(400)

        # 1. Clicking text opens an editable box laid over that exact line.
        index, box = run_box('Quarterly')
        page.locator('.text-hit').nth(0)  # ensure the overlay is populated
        page.mouse.click((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        editor = page.locator('#inline-text').bounding_box()
        assert abs(editor['x'] - box['x0']) < 4, f"editor x {editor['x']} vs run {box['x0']}"
        assert abs(editor['width'] - (box['x1'] - box['x0'])) < 6, 'editor width does not match the text'
        assert page.locator('#inline-text').inner_text().strip() == 'Quarterly'
        typed_size = page.evaluate("parseFloat(getComputedStyle(document.querySelector('#inline-text')).fontSize)")
        assert typed_size > 20, f'editor font size {typed_size} does not follow the original 32pt text'
        page.screenshot(path=str(output / 'direct-edit-open.png'))
        record('Clicking a line opens an editable box over that exact text')

        # 2. Typing on the page writes into the PDF, and a longer line keeps its size.
        page.keyboard.press('Control+A')
        page.keyboard.type('Quarterly performance summary')
        page.keyboard.press('Enter')
        wait_idle()
        assert not page.evaluate("!!state.inline"), 'the editor should close after Enter'
        assert page.evaluate(
            "() => state.content.runs.some(r => r.text.includes('Quarterly performance summary'))")
        page.locator('#document-search').fill('Quarterly performance summary')
        expect(page.locator('.search-match')).to_have_count(1)
        page.locator('#document-search').fill('')
        record('Typing directly on the page updates the PDF text')

        # 3. The edit survives export, and the grown line keeps the 32pt size.
        exported = download_pdf('direct-edit.pdf')
        with fitz.open(exported) as doc:
            spans = [s for b in doc[0].get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
            match = [s for s in spans if 'Quarterly performance summary' in s['text']]
            assert match, 'exported PDF does not contain the typed text'
            assert not any(s['text'].strip() == 'Quarterly' for s in spans), 'the original text was left behind'
            assert round(match[0]['size'], 1) == 32.0, f"font size changed to {match[0]['size']}"
            assert match[0]['bbox'][2] - match[0]['bbox'][0] > 300, 'the line did not grow into free space'
        record('Exported PDF contains the edit at the original font size')

        # 4. Undo restores the original wording.
        page.locator('#undo').click()
        wait_idle()
        assert page.evaluate("() => state.content.runs.some(r => r.text.trim() === 'Quarterly')")
        record('Undo restores the original text')

        # 5. Double-click works with any tool active.
        page.locator('[data-tool="select"]').click()
        box = run_box('Quarterly')[1]
        page.mouse.dblclick((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        assert page.locator('#inline-text').inner_text().strip() == 'Quarterly'
        record('Double-click starts a direct edit with the Select tool active')

        # 6. Escape cancels without touching the document.
        revision = page.evaluate('state.doc.revision')
        page.keyboard.press('Control+A')
        page.keyboard.type('discard me')
        page.keyboard.press('Escape')
        expect(page.locator('#inline-editor')).to_be_hidden()
        assert page.evaluate('state.doc.revision') == revision, 'Escape still changed the document'
        record('Escape cancels an edit without changing the document')

        # The two buttons on the editor's own toolbar. Escape is the keyboard
        # way out; these are what somebody with a mouse actually presses, and
        # neither had ever been pressed by a check.
        revision = page.evaluate('state.doc.revision')
        box = run_box('Quarterly')[1]
        page.mouse.dblclick((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        page.keyboard.press('Control+A')
        page.keyboard.type('never applied')
        page.locator('#inline-cancel').click()
        expect(page.locator('#inline-editor')).to_be_hidden()
        assert page.evaluate('state.doc.revision') == revision, \
            'the cancel button changed the document'
        record('The cancel button discards an edit without changing the document')

        box = run_box('Department')[1]
        page.mouse.dblclick((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        page.locator('#inline-delete').click()
        wait_idle()
        trashed = download_pdf('direct-edit-trash.pdf')
        with fitz.open(trashed) as doc:
            text = doc[0].get_text()
            assert 'Department' not in text, 'the trash button did not remove the line'
            assert 'Quarterly' in text, 'the trash button removed more than the line'
        page.locator('#undo').click()
        wait_idle()
        record('The trash button removes that line, and undo brings it back')

        # 7. Clearing the text and applying removes it from the PDF.
        box = run_box('Quarterly')[1]
        page.mouse.dblclick((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        page.keyboard.press('Control+A')
        page.keyboard.press('Delete')
        page.locator('#inline-apply').click()
        wait_idle()
        removed = download_pdf('direct-edit-removed.pdf')
        with fitz.open(removed) as doc:
            text = doc[0].get_text()
            assert 'Quarterly' not in text, 'deleted text is still in the exported PDF'
            assert 'performance report' in text, 'unrelated text on the same page was removed'
        record('Clearing the box deletes only that line from the PDF')

        # 8. The panel and the page stay in step.
        page.locator('#undo').click()
        wait_idle()
        box = run_box('Quarterly')[1]
        page.mouse.dblclick((box['x0'] + box['x1']) / 2, (box['y0'] + box['y1']) / 2)
        expect(page.locator('#inline-editor')).to_be_visible()
        page.keyboard.press('Control+A')
        page.keyboard.type('Panel sync check')
        expect(page.locator('#edit-text-value')).to_have_value('Panel sync check')
        page.locator('#edit-text-value').fill('Panel sync check two')
        expect(page.locator('#inline-text')).to_have_text('Panel sync check two')
        page.locator('#apply-text').click()
        wait_idle()
        assert page.evaluate("() => state.content.runs.some(r => r.text.includes('Panel sync check two'))")
        record('The side panel and the on-page editor stay in sync')

        # 9. The text is still selectable for the panel workflow (no regression).
        page.locator('[data-tool="edit"]').click()
        expect(page.locator('.text-hit').first).to_be_visible()
        record('Text selection targets remain available')

        browser.close()

    print()
    for name in steps:
        print('  ok -', name)
    result = {'passed': len(steps), 'steps': steps, 'javascriptErrors': errors,
              'externalPageRequests': external, 'nativeGUI': 'Not tested by browser checks',
              'baseURL': args.base_url}
    (output / 'direct-edit-results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    if errors:
        print('\nJavaScript errors:')
        for error in errors:
            print('  !', error)
    if external:
        print('\nUnexpected external requests:')
        for url in external:
            print('  !', url)
    print(json.dumps(result, indent=2))
    print(f'\n{len(steps)} direct-edit checks passed, {len(errors)} JavaScript errors, {len(external)} external requests.')
    return 0 if not errors and not external and len(steps) == EXPECTED_STEPS else 1


if __name__ == '__main__':
    sys.exit(main())
